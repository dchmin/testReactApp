/*
Command line to start, build project
npm start for running the localhost
npm run dev for building development bundle
npm run prod for building production bundle
PLUGINS:
npm install --save-dev html-webpack-plugin - creation of HTML files to serve your webpack bundles
npm install --save-dev clean-webpack-plugin - cleans dist folder before bundling the prod build
KNOWN ISSUE:
https://github.com/jantimon/html-webpack-plugin/issues/895
*/
const path = require('path');
const webpack = require('webpack');
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
const HtmlWebPackPlugin = require("html-webpack-plugin");
const CleanWebpackPlugin = require('clean-webpack-plugin');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
const OptimizeCSSAssetsPlugin = require("optimize-css-assets-webpack-plugin");
const EncodingPlugin = require('webpack-encoding-plugin');
const devMode = process.env.NODE_ENV !== 'production';
module.exports = {
    entry: {
        vendors: ['react', 'react-dom'],
        app: './src/index.js'
    },
    output: {
        path: path.resolve(__dirname, './dist'),
        filename: '[name].bundle.js',
    },
    module: {
        rules: [
            //JAVASCRIPT
            {
                test: /\.(js|jsx)$/,
                exclude: /node_modules/,
                use: {
                    loader: "babel-loader"
                }
            },
            //SCSS and CSS
            {
                test: /\.(sa|sc|c)ss$/,
                use: [
                    // {
                    //     loader: 'file-loader',
                    //     options: {
                    //         sourceMap: true,
                    //         name: '[name].css'
                    //     }
                    // },
                    {
                        //loader: devMode ? 'style-loader' : MiniCssExtractPlugin.loader
                        loader: MiniCssExtractPlugin.loader
                    },
                    {
                        loader: 'css-loader',
                        options: {
                            sourceMap: true
                        }
                    },
                    {
                        loader: 'sass-loader',
                        options: {
                            implementation: require("sass"),
                            sourceMap: true
                        }
                    }
                ]
            }
        ]
    },
    //Create chunks
    optimization: {
        splitChunks: {
            cacheGroups: {
                commons: {
                    chunks: "initial",
                    minChunks: 2,
                    maxInitialRequests: 5,
                    minSize: 0
                },
                vendors: {
                    test: /[\\/]node_modules[\\/]/,
                    name: 'vendors',
                    chunks: 'initial',
                    priority: 10,
                    enforce: true
                }
            }
        },
        //Uglify JavaScript and minify CSS
        minimizer: [
            new UglifyJsPlugin({
                test: /\.(js|jsx)$/i,
                exclude: /\/node_modules/,
                cache: false,
                extractComments: false,
                parallel: 4,
                sourceMap: true,
                uglifyOptions: {
                    compress: {},
                    output: {
                        comments: false
                    }
                }
            }),
            new OptimizeCSSAssetsPlugin({
                filename: "./styles/components.css"
            })
        ]
    },
    plugins: [
        new CleanWebpackPlugin(['dist']),
        new HtmlWebPackPlugin({
            template: path.resolve(__dirname, "src", "index.html"),
            filename: "index.html",
            inject: true,
            xhtml: true
        }),
        new MiniCssExtractPlugin({
            // Options similar to the same options in webpackOptions.output
            // both options are optional
            filename: "./styles/components.css",
            chunkFilename: "./styles/[id].css"
        }),
        new webpack.SourceMapDevToolPlugin({
            module: false,
            noSources: false,
            exclude: ['./styles/components.css']
        }),
        new EncodingPlugin({
            test: /(\.js|\.css)($|\?)/i,
            encoding: 'iso-8859-1',
            exclude: /\/node_modules/
        })
        //Optional use for analysing the bundle output only when required
        //new BundleAnalyzerPlugin()
    ],
    devtool: devMode ? 'source-map' : 'eval-source-map',
    devServer: {
        // hot: true,
        // inline: true,
        // port: 8080,
        contentBase: [path.join(__dirname, 'src/styles/scss'), path.join(__dirname, 'src/components')],
        watchContentBase: true
    }
};