import React from "react";
require('./styles/scss/main.scss');
import ReactDOM from "react-dom";
import Header from './components/Header';
import Body from './components/body';
import Footer from './components/Footer';
const Index = () => {
    return (
        <React.Fragment>
            <div className="yellow-stripe"></div>
            <Header />
            <Body />
            <Footer />
        </React.Fragment>
    )
};

ReactDOM.render(<Index />, document.getElementById("app"));