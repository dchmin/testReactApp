import React from "react";
require('../styles/scss/header.scss');
const Header = () => {
    return (
        <header>
            <div className="container">
                <div className="row">
                    <div className="col-sm-12 text-right">
                        <ul className="list-inline utility-nav" role="navigation" aria-label="Helpful links">
                            <li><a href="/ca/Find+an+advisor?vgnLocale=en_CA">Find an advisor</a></li>
                            <li><a href="/ca/Get+a+quote?vgnLocale=en_CA">Get a quote</a></li>
                            <li><a href="/ca/Customer+support?vgnLocale=en_CA">Customer support</a></li>
                        </ul>
                    </div>
                    <div className="col-sm-12 col-md-3">
                        <svg aria-label="Sun Life Financial" width="128px" height="60px" version="1.1" xmlns="http://www.w3.org/2000/svg" xlinkHref="http://www.w3.org/1999/xlink">
                            <image xlinkHref="//cdn.sunlife.com/static/slfglobal/globalweb/responsive/images/en/sunlife-logo-web-en.svg" x="0" y="0" height="53px" width="128px"></image>
                        </svg>
                    </div>
                </div>
            </div>
        </header>
    );
};
export default Header;