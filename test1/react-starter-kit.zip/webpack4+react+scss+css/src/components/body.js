import React from "react";
require('../styles/scss/body.scss');
const Body = () => {
    return (
        <div className="main container">
            <div className="row">
                <div className="col-sm-12">
                    <p>This is main content</p>
                </div>
            </div>
        </div>
    );
};
export default Body;