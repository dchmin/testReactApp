const webpack = require('webpack');
const path = require('path');
const devMode = process.env.NODE_ENV !== 'production';
const OptimizeCSSAssetsPlugin = require('optimize-css-assets-webpack-plugin');
const config = {
    entry: [
        './scss/bootstrap-notResponsive.scss',
        './scss/bootstrap-responsive.scss',
        './scss/main-ie8.scss',
        './scss/main-ie9.scss',
        './scss/palette-notResponsive.scss',
        './scss/palette-notResponsive_AMSC.scss',
        './scss/palette-notResponsive_MAGNA.scss',
        './scss/palette-notResponsive_NCR.scss',
        './scss/palette-notResponsive_PPG.scss',
        './scss/palette-notResponsive_Western.scss',
        './scss/palette-responsive.scss',
        './scss/palette-responsive_AMSC.scss',
        './scss/palette-responsive_MAGNA.scss',
        './scss/palette-responsive_NCR.scss',
        './scss/palette-responsive_PPG.scss',
        './scss/palette-responsive_Western.scss'
    ],
    output: {
        path: path.resolve(__dirname, 'css'),
        filename: 'bundle.js'
    },
    module: {
        rules: [{
            test: /\.scss$/,
            use: [{
                    loader: 'file-loader',
                    options: {
                        name: '[name].css'
                    }
                },
                {
                    loader: "sass-loader",
                    options: {
                        name: '[name].scss'
                    }
                }
            ]
        }]
    },
    optimization: {
        minimizer: [
            new OptimizeCSSAssetsPlugin({
                cssProcessorPluginOptions: {
                    preset: ['default', {
                        discardComments: {
                            removeAll: true
                        }
                    }],
                }
            })
        ],
    },
    mode: 'production',
    devtool: false,
    plugins: [
        new webpack.SourceMapDevToolPlugin({
            append: '\n//# sourceMappingURL=https://sunlife.ca/sourcemap/[url]',
            publicPath: 'https://sunlife.ca/project/',
            fileContext: 'public',
            filename: 'sourcemap/[name].css.map'
        })
    ]
}
module.exports = config;