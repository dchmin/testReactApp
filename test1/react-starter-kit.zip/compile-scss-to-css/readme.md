## Introduction  
A light weight Webpack config file to compile SCSS to CSS and minify.
## Setup  
- Copy all the files into the project folder
- Open command prompt and changed directory to project folder
- type `npm install` (without quotes) and hit enter
- wait for the installation to complete
- Go to next section "Config instructions"
## Config instructions:  
- Add the SCSS file path you want to compile to CSS under "entry" in `webconfig.js`. You can add as many files you want using comma separted as shown in the example below.
````
entry:[
    './styles/scss/homepage.scss',
    './styles/scss/about-us.scss'
]
````
- Output file path name to default to bundle.js. As we all know Webpack expects *.js file to be output.   
````
output: {
        path: path.resolve(__dirname, 'css'),
        filename: 'bundle.js'
    }
````   
*Do not change the output file name as this for rules purpose only* 
## Command Line:  
Use any one command line to complie SCSS. My favorite one is **npm run watch**
- **npm run build** to compile SCSS to CSS and minify the output CSS file
- **npm run watch** auto detects SCSS changes and compile to CSS. Recommended
## Plugins used  
**Webpack**: webpack is a module bundler. Its main purpose is to bundle JavaScript files for usage in a browser, yet it is also capable of transforming, bundling, or packaging just about any resource or asset.  
URL: https://github.com/webpack/webpack

**webpack-cli**: webpack CLI provides a flexible set of commands for developers to increase speed when setting up a custom webpack project. As of webpack v4, webpack is not expecting a configuration file, but often developers want to create a more custom webpack configuration based on their use-cases and needs. webpack CLI addresses these needs by providing a set of tools to improve the setup of custom webpack configuration.  
URL: https://github.com/webpack/webpack-cli#readme

**file-loader**: The file-loader resolves import/require() on a file into a url and emits the file into the output directory.   
URL: https://webpack.js.org/loaders/file-loader/

**node-sass**: Allows you to natively compile .scss files to css at incredible speed and automatically via a connect middleware.  
URL: https://github.com/sass/node-sass

**optimize-css-assets-webpack-plugin**: It will search for CSS assets during the Webpack build and will optimize \ minimize the CSS (by default it uses cssnano but a custom CSS processor can be specified).  
URL: https://github.com/NMFR/optimize-css-assets-webpack-plugin

**sass-loader**: Loads a Sass/SCSS file and compiles it to CSS.  
URL: https://github.com/NMFR/optimize-css-assets-webpack-plugin

**SourceMapDevToolPlugin**: This plugin enables more fine grained control of source map generation. It is also enabled automatically by certain settings of the devtool configuration option.  
URL: https://webpack.js.org/plugins/source-map-dev-tool-plugin/  
*Go through the supported options and add/delete/modify based on your project requirement* 

**CopyWebpackPlugin**: Copies individual files or entire directories, which already exist, to any directory.  
URL: https://webpack.js.org/plugins/copy-webpack-plugin/#root  
*Not included in the webpack.config.js. Add it based on your requirement.*

## Font Awesome icon compiling issue  
Current fontawesome 4.0 is not compiling the icons during the Webpack build. This issue not related to webpack, but how fontawesome 4.0 is structured scss files/folder. More info related to the issue can be found [here](https://github.com/FortAwesome/Font-Awesome/pull/6728) 
#### Solution:  
1. Open _variable.scss from the vendors folder
2. Modify your styles as below

**Add the below function**
```
@function prepend-slash($value) {
    @return unquote('"\\#{$value}"');
}

```
**Replace all the existing styles as shown below**
````
$fa-var-500px: "\f26e"; ==> $fa-var-500px: unquote('"\\f26e"');
$fa-var-address-book: "\f2b9"; ==> $fa-var-address-book: unquote('"\\f2b9"');
$fa-var-address-book-o: "\f2ba"; ==> $fa-var-address-book-o: unquote('"\\f2ba"');
$fa-var-address-card: "\f2bb"; ==> $fa-var-address-card: unquote('"\\f2bb"');
$fa-var-address-card-o: "\f2bc"; ==> $fa-var-address-card-o: unquote('"\\f2bc"');
$fa-var-adjust: "\f042"; ==> $fa-var-adjust: unquote('"\\f042"');

````
**Output after compile**
````
.fa-500px:before {
  content: "\f26e"; }

.fa-address-book:before {
  content: "\f2b9"; }

.fa-address-book-o:before {
  content: "\f2ba"; }

.fa-vcard:before,
.fa-address-card:before {
  content: "\f2bb"; }

.fa-vcard-o:before,
.fa-address-card-o:before {
  content: "\f2bc"; }

.fa-adjust:before {
  content: "\f042"; }

.fa-adn:before {
  content: "\f170"; }
````