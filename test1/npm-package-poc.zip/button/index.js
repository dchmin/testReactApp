export const SLFButton = (props) => {
  return ( 
    <button type = "button" id={props.btnId} className={props.btnClasses}>{props.text}</button>
  );
}