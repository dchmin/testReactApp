## Setup
-   Checkout the package from BitBucket
-   Open command prompt and changed directory to project folder
-   type **npm install** and hit enter
-   wait for the installation to complete

## Development
1. In the root of your library, do this to build. It will give you a quick report of any errors.
    ```
    npm run build
    ```
2. Storybook will live update in your browser if you make changes to your component.

  ```
    npm run storybook
  ```

## Create NPM Package
Since this library is not officially published to artifactory yet, please follow below steps for local testing in other project.
    
1. In the root of your library, do this to build.
    ```
    npm run build
    ```
2. Create a symlink package that points to your module.
    ```
    npm link
    ```
To solve local "Invalid hook call" issue, it's caused by npm link when testing locally, need to link to the react node-module in your test-app
    ```
    npm link {your path}/POC-test-app/node_modules/react
    ```
    ```
    npm link {your path}/POC-test-app/node_modules/react-dom
    ```

## Use NPM Package (local testing)
This is for local testing in the other project which needs to consume your package 

1. Go to other project (e.g. POC-test-app, assum it's already set up and running) 
    ```
    npm link poc_onesun_library
    ```
2. Import component from the package in the test project

    ```
    // test project: src/component/test.js
    import { DummyText } from 'poc_onesun_library';
    ```
    ```
    <DummyText primary={true} label="Hello world" />
    ```

## TO DO: publish to artifactory (private npm registry)
