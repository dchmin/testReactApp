import React from 'react';

import FooterWidget from "../components/footer/FooterWidget";

export default {
  title: 'FooterWidget',
  component: FooterWidget
};

export const Default = () => <FooterWidget />;