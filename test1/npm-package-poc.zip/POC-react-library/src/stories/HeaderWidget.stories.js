import React from 'react';

import HeaderWidget from "../components/header/HeaderWidget";

export default {
  title: 'HeaderWidget',
  component: HeaderWidget
};

export const Default = () => <HeaderWidget />;