import React from 'react';

import Product from "../components/Product/Product";

export default {
  title: 'Product',
  component: Product
};

export const Default = () => <Product />;