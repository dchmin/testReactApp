import React from 'react';

import DummyAPI from "../components/DummyAPI/DummyAPI";

export default {
  title: 'DummyAPI',
  component: DummyAPI
};

export const Default = () => <DummyAPI />;