import React from 'react';

import DummyText from "../components/DummyText/DummyText";

export default {
  title: 'DummyText',
  component: DummyText
};

const Template = (args) => <DummyText {...args} />;

export const Primary = Template.bind({});
Primary.args = {
  primary: true,
  label: 'Primary DummyText',
};

export const Secondary = Template.bind({});
Secondary.args = {
  label: 'Secondary DummyText',
};