
import { getAPIData } from "./apiService";
import { getLang } from "./utilityFunctions"



let headerServiceUrl = "/public/secure.sunlife.ca/brands/common/OneSun/content/json/headerData.json";
let headerContentUrl = "/public/secure.sunlife.ca/brands/common/OneSun/content/json/headerContent.json";
let footerServiceUrl = "/public/secure.sunlife.ca/brands/common/OneSun/content/json/footerData.json";
let footerContentUrl = "/public/secure.sunlife.ca/brands/common/OneSun/content/json/footerContent.json";
export let imagePath = "/public/secure.sunlife.ca/brands/COMMON/OneSun/dist/images/";

// if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
  headerServiceUrl = `https://sit-www.sunnet.sunlife.com${headerServiceUrl}`;
  headerContentUrl = `https://sit-www.sunnet.sunlife.com${headerContentUrl}`;
  footerServiceUrl = `https://sit-www.sunnet.sunlife.com${footerServiceUrl}`;
  footerContentUrl = `https://sit-www.sunnet.sunlife.com${footerContentUrl}`;
  imagePath = `https://sit-www.sunnet.sunlife.com${imagePath}`;
// } 

function retrieveData(serviceUrl, normalizeFn) {
  return getAPIData(serviceUrl)
  .then(normalizeFn)
  .catch(function(error) {
    console.log(error);
  });
}
export const getHeaderData = async () => { return retrieveData(headerServiceUrl, normalizeHeaderData) }
export const getFooterData = async () => { return retrieveData(footerServiceUrl, normalizeFooterData) }
export const getFooterContent = async () => { return retrieveData(footerContentUrl, normalizeContentData) }
export const getHeaderContent = async () => { return retrieveData(headerContentUrl, normalizeContentData) }


function normalizeHeaderData(response) {
  return {
    utilityNav: response.utilityNav.menuItems,
    callShadow: response.callShadow,
    apology: response.apology
  };
}
function normalizeFooterData(response) {
  return {
    footerLinks: response.footerLinks,
    callShadow: response.callShadow
  };
}
function normalizeContentData(response) {
  return {
    content: response.translation[getLang()]
  }
}