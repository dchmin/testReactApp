
export const footerLinks = [
  {
    id: "0",
    hrefID: "legalHref",
    labelID: "legal",
    target:"_blank"
  },
  {
    id: "1",
    hrefID: "privaryHref",
    labelID: "privacy",
    target:"_blank"
  },
  {
    id: "2",
    hrefID: "securityHref",
    labelID: "security",
    target:"_blank"
  },
  {
    id: "3",
    hrefID: "accessibilityHref",
    labelID: "accessibility",
    target:"_blank"
  },
  {
    id: "4",
    hrefID: "contactusHref",
    labelID: "contactus",
    target:""
  },
];