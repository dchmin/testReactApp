const localeSeperator = "_";

function getParameterByName(name, url = window.location.href) {
  name = name.replace(/[\[\]]/g, '\\$&');
  var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
      results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
function updateQueryStringParameter(uri, key, value) {
  var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
  var separator = uri.indexOf('?') !== -1 ? "&" : "?";
  if (uri.match(re)) {
    return uri.replace(re, '$1' + key + "=" + value + '$2');
  }
  else {
    return uri + separator + key + "=" + value;
  }
}
export function getLang() {
  let locale = getParameterByName("locale");
  let lang = locale ? locale.split(localeSeperator)[0] : "en";
  return lang;
}
// return locale url param from language 
export function addLangQueryParamtoUrl(uri, lang) {
  let langValue = lang + localeSeperator + "CA";
  return updateQueryStringParameter(uri, "locale", langValue );
}
