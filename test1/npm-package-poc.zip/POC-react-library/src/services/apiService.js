import axios from "axios";
// import sanitize from "./Security";

/**
 * 
 * @param {string} url : url to which we have to make a get call
 * @param {Object} customConfig : custom config consists of content type and params
 */
export const getAPIData = async (url, customConfig) => {
    const axiosConfig = (customConfig) ? customConfig : '';
    try {
        return (await axios.get(url, axiosConfig)).data;
    } catch (error) {
        // TODO: handle API response error         
        return null;
    }
}
 
/**
 * 
 * @param {string} url : url to which we have to make a post call
 * @param {Object} data : data which is posted
 * @param {Object} customConfig : custom config consists of content type and params
 */
export const postAPIData = async (url, data, customConfig) => {
    const axiosConfig = (customConfig) ? customConfig : '';
    return (await axios.post(url, data, axiosConfig));
}

/**
 * 
 * @param {string} url : url to which we have to make a put call
 * @param {Object} data : data which is posted
 * @param {Object} customConfig : custom config consists of content type and params
 */
export const putAPIData = async (url, data, customConfig) => {
    const axiosConfig = (customConfig) ? customConfig : '';
    return (await axios.post(url, data, axiosConfig));
}
