export const translation = {
  en: {
    legal: "Legal",
    privacy: "Privacy",
    security: "Security",
    accessibility: "Accessibility",
    contactus: "Contact us",
    tagline: "Life's brighter under the sun",
    trademark: "\xA9 Sun Life Assurance Company of Canada. All rights reserved.",
    slflogo: "Sun Life",
    legalHref: "/login.wca/English/legal.html",
    privaryHref: "/login.wca/English/privacy.html",
    securityHref: "/login.wca/English/secinfo.html",
    contactusHref: "/mbrportal/req/secure/pphp/profile/contactus?from=Portal",
    accessibilityHref: "https://www.sunlife.ca/en/about-us/accessibility-commitment/",
    opensInNewWindow: "Opens in a new window"
  },
  fr: {
    legal: "Notice juridique",
    privacy: "Confidentialité",
    security: "Sécurité",
    accessibility: "Accessibilité",
    contactus: "Communiquer avec nous",
    tagline: "La vie est plus radieuse sous le soleil",
    trademark: "\xA9 Sun Life du Canada, compagnie d'assurance- vie. Tous droits réservés",
    slflogo: "Sun Life",
    legalHref: "/login.wca/French/legal.html",
    privaryHref: "/login.wca/French/privacy_fr.html",
    securityHref: "/login.wca/French/secinfo.html",
    contactusHref: "/mbrportal/req/secure/pphp/profile/contactus?from=Portal",
    accessibilityHref: "https://www.sunlife.ca/fr/about-us/accessibility-commitment/",
    opensInNewWindow: "Une nouvelle fenêtre s'ouvrira"
  }
}
