import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const GreyCircledIcon = ({iconClass}) => {
  return (
    <div class="icon-flex">
      <div class="icon-wrapper"><FontAwesomeIcon icon={iconClass} /></div>
    </div>
  );
};
export default GreyCircledIcon;
