import PropTypes from 'prop-types'; // ES6
import React from 'react';

const Link = ({href, label, ...props}) => {
  return (
    <a href={href} {...props}>{label}</a>
  )
}

Link.propTypes = {
  label   : PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
	href		: PropTypes.string
};

export default Link;



