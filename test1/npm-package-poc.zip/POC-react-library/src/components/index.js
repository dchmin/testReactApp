
/**
 * Export components to src/index.js
 */
export { default as DummyText } from './DummyText';
export { default as DummyAPI } from './DummyAPI';
export { default as DummyAccordion } from './DummyAccordion';
export { default as Product } from './Product';
export { default as HeaderWidget } from './header';
export { default as FooterWidget } from './footer';
