import React, {useEffect, useState} from "react";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Link from "./../common/Link";
import {getLang} from '../../services/utilityFunctions';
import {getFooterData, getFooterContent, imagePath} from '../../services/dataRetrieval'; 


let lang = getLang();

function ListItems({label, href, index, lastLinkIndex, target="", content}) {
  const listItems = [];
  const value = [label]; 
  if (target === "_blank") {
    value.push(<span key={`sr${index}`} className="sr-only"> {content["opensInNewWindow"]}</span>);
  }
  listItems.push(
    <li key={label} className="list-group-item first">
        <Link key={`${label}link`} href={href} target={target} label={value} />
    </li>
  );
  if (index !== lastLinkIndex) {
    listItems.push(<li key={index} aria-hidden="true" className="lnk-sep"><span></span></li>);
  }
  return (<>{listItems} </>);  
};
const FooterWidget = () => {
  const [footerLinks, setFooterLinks] = useState([]);
  const [content, setContent] = useState([]);
  useEffect(() => {
    getFooterContent().then(response => {
      if (response && response.content !== undefined) {
        setContent(response.content);
      } else {
        console.log("Could not retrieve content");
      }
    });
    getFooterData().then(response => {
      if (response && response.footerLinks !== undefined) {
        console.log(response);
        setFooterLinks(response.footerLinks);
      } else {
        console.log("Could not retrieve footer links");
      }
    });
  }, [])

  let lastLinkIndex = footerLinks.length-1;
  return (
    <footer id="footer">
      <Container>
        <Row>
          <Col>
            <div className="oslf-legal d-xs-flex flex-xs-column">
              <ul className="list-group list-group-horizontal">
              {
              footerLinks.map((item, index) => (
                <ListItems 
                  key={index}
                  label={content[item.labelID]} 
                  href={content[item.hrefID]} 
                  index={index} 
                  lastLinkIndex={lastLinkIndex}
                  target={item.target}
                  content={content}
                />
              ))
              }
              </ul>
            </div>
          </Col>
        </Row>
        <Row>
          <Col>
            <div className="brand-sec">
              <img src={`${imagePath}SL_CLR_RWT_RGB.png`} alt={content["slfLogo"]}/>
              <p className="tag-line">{content["tagline"]}</p>
              <p>{content["trademark"]}</p>
            </div>
          </Col>
        </Row>
        
      </Container>
    </footer>
  )
}

export default FooterWidget;