## Usage
```javascript
import React, { Component } from 'react';
import { FooterWidget } from 'poc_onesun_library';

class MyApp extends Component {
  render() {
    return (
      <div>
        <FooterWidget />
      </div>
    );
  }
}

export default MyApp;
```
