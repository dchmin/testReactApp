import React from "react";
import PropTypes from 'prop-types';

import './dummy-text.css';

const DummyText = ({ primary, label }) => {  
  const mode = primary ? 'storybook-dummytext--primary' : 'storybook-dummytext--secondary';
    return (
      <div className={mode}>
        {label}
      </div>
    );
};

DummyText.propTypes = {  
  /**
   * Is this the principal call to action on the page?
   */
  primary: PropTypes.bool,
  /**
   * What text to display
   */
  label: PropTypes.string
}

DummyText.defaultProps = {
  primary: false,
  label: null
};

export default DummyText;