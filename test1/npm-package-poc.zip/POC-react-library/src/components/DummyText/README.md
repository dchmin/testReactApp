This is a Simple Component to List ToDo List in https://jsonplaceholder.typicode.com/todos

## Usage
```javascript
import React, { Component } from 'react';
import { DummyText } from 'poc_onesun_library';

class MyApp extends Component {
  render() {
    return (
      <div>
        <DummyText 
          primary={true} 
          label="Hello world" />
      </div>
    );
  }
}

export default MyApp;
```
