## Usage
```javascript
import React, { Component } from 'react';
import { DummyAccordion } from 'poc_onesun_library';

class MyApp extends Component {
  render() {
    return (
      <div>
        <DummyAccordion />
      </div>
    );
  }
}

export default MyApp;
```
