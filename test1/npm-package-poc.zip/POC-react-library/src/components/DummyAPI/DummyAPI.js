import React, { Component } from "react";
import { connection } from "../../constants/connection";

class DummyAPI extends Component {

    constructor(props) {
        super(props);
    }
    state = {
        toDoList: [],
    };

    componentDidMount() {
        connection.get("/todos")
            .then(response => {
                this.setState({ toDoList: response.data })
            })
            .catch(error => {
                console.log(error);
            })
    }

    render() {

        let listToDos = this.state.toDoList.map((toDo, index) =>
            <div>
                <li key={index}>{toDo.id}</li>
            </div>
        );

        return (
            <div>
                <ul>{listToDos}</ul>
            </div>
        );
    }
}

export default DummyAPI;