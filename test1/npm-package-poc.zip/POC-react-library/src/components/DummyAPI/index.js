// Import the component from this folder and send it down to ./components/index.js
import DummyAPI from './DummyAPI';

export default DummyAPI;