## Usage
```javascript
import React, { Component } from 'react';
import { DummyAPI } from 'poc_onesun_library';

class MyApp extends Component {
  render() {
    return (
      <div>
        <DummyAPI />
      </div>
    );
  }
}

export default MyApp;
```
