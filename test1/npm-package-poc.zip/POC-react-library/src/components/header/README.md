## Usage
```javascript
import React, { Component } from 'react';
import { HeaderWidget } from 'poc_onesun_library';

class MyApp extends Component {
  render() {
    return (
      <div>
        <HeaderWidget />
      </div>
    );
  }
}

export default MyApp;
```
