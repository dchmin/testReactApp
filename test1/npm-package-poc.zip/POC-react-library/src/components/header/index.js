// Import the component from this folder and send it down to ./components/index.js
import HeaderWidget from './HeaderWidget';

export default HeaderWidget;