import React, {useEffect, useState} from "react";
import { library } from '@fortawesome/fontawesome-svg-core';
import { faEnvelope, faFile  } from '@fortawesome/free-regular-svg-icons';

import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import NavDropdown from 'react-bootstrap/NavDropdown';

import styled from 'styled-components';

import UtilityNav from './UtilityNav';
import {getHeaderData, getHeaderContent} from '../../services/dataRetrieval'; 

library.add(faEnvelope, faFile );


const OneSunHeader = styled.header`
	border-top: 4px solid $color-sl-medium-yellow;

`


const HeaderWidget = () => {
    const [menuItems, setMenuItems] = useState([]);
    const [content, setContent] = useState([]);

    useEffect(() => {
      getHeaderContent().then(response => {
        if (response && response.content !== undefined) {
          setContent(response.content);
        } else {
          console.log("Could not retrieve content");
        }
      });
      getHeaderData().then(response => {
        if (response && response.utilityNav !== undefined) {
          setMenuItems(response.utilityNav);
          // console.log("data retrieval passed");
        } else {
          console.log("Could not retrieve header links");
        }
      })
    }, []);

    return (
      <OneSunHeader id="main-header" className="header-top-border slf-header">
         <div className="container">
            <a href="#page-content" className="btn btn-lg btn-secondary sr-only sr-only-focusable">Skip to content</a>
            <a href="#footer" className="btn btn-lg btn-secondary sr-only sr-only-focusable">Skip to footer</a>


            <Navbar collapseOnSelect expand="lg" bg="light" variant="light">
              <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand>
              <Navbar.Toggle aria-controls="responsive-navbar-nav" />
              <Navbar.Collapse id="responsive-navbar-nav">
                <Nav className="m-auto justify-content-center">
                  <Nav.Link href="#Home">Home</Nav.Link>
                  <Nav.Link href="#pricing">Benefits</Nav.Link>
                  <Nav.Link href="#pricing">Insurance</Nav.Link>      
                </Nav>
                <Nav>
                  <Nav.Link href="#deets">Fr</Nav.Link>
                  <Nav.Link href="#memes">
                    msg
                  </Nav.Link>
                  <NavDropdown title="Dropdown" id="collasible-nav-dropdown">
                    <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
                    <NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
                    <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
                    <NavDropdown.Divider />
                    <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
                  </NavDropdown>
                </Nav>
              </Navbar.Collapse>
            </Navbar>


            {/* <nav className="navbar navbar-expand-lg navbar-light bg-light">
              <a className="navbar-brand" href="#">SLF Logo</a>
              <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
              </button>

              <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <ul className="navbar-nav mr-auto">
                  <li className="nav-item active">
                    <a className="nav-link" href="#">Home <span className="sr-only">(current)</span></a>
                  </li>
                </ul>

                <UtilityNav menuItems={menuItems} />
              </div>
            </nav> */}
            <p>
              
            </p>

          </div>
      </OneSunHeader>
    );
};
export default HeaderWidget;