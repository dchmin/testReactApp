import React from 'react';
import GreyCircledIcon from '../common/icons/GreyCircledIcon';
import {content} from './HeaderWidget';

function ListItem({type, label, url, iconClass}) {
  if (type.toLowerCase() === "icon") {
    return (
      <li>
        <a className="icon-lnk" href={url}>
          <span className="sr-only">{content[label]}</span>
          <GreyCircledIcon iconClass={iconClass} />
        </a>
      </li>
    )
  } else {
    return (
    <li>
      <a href={url}>{label}</a>
    </li>
    );
  }
}

const UtilityNav = ({menuItems}) => {
  return (
      <ul className="utility-nav navbar-nav">
        {
          menuItems.map(({type, label, url, iconClass, altText}) => (
            <ListItem type={type} label={label} iconClass={iconClass} url={url} />
          
          ))
        }
      </ul>
  )
}

export default UtilityNav;