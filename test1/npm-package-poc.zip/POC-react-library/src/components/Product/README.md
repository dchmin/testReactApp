## Usage
```javascript
import React, { Component } from 'react';
import { Product } from 'poc_onesun_library';

class MyApp extends Component {
  render() {
    return (
      <div>
        <Product />
      </div>
    );
  }
}

export default MyApp;
```
