import React, { useEffect, useState } from "react";
import { connection } from "../../constants/connection";

const Product = () => {
    const [toDoList, setToDoList] = useState([]);
    useEffect(() => {
        connection.get("/todos")
            .then(response => {
                setToDoList(response.data)
            })
            .catch(error => {
                console.log(error);
            })
    }, []);


    let listToDos = toDoList.map((toDo, index) =>
        <div>
            <li key={index}>{toDo.title}</li>
        </div>
    );

    return (
        <div>
            <ul>{listToDos}</ul>
        </div>
    );
}

export default Product;