// Import the component from this folder and send it down to ./components/index.js
import Product from './Product';

export default Product;