## Setup  
- Copy all the files into the project folder
- Open command prompt and changed directory to project folder
- type ```npm install``` (without quotes) and hit enter
- wait for the installation to complete
- Go to next section "Command Line"
## Command Line:  
- ```npm start``` to run the project in localhost
- ```npm run dev``` for building development bundle
- ```npm run prod``` for building production bundle
## Registry setup: 
- Verify the value of your registry by typing ```npm config list```. If the registry contains the default value of https://registry.npmjs.org/ run the following command:
npm config set registry http://artifactory.sunlifecorp.com/artifactory/api/npm/npm-remote

- In order to properly run this project, upgrade your nodeJS version to the latest available. Older versions may cause issues while trying to run ```npm install```
## Plugins used  
**CSS loader**: The css-loader interprets @import and url() like import/require() and will resolve them.  
URL: https://github.com/webpack-contrib/css-loader

**SCSS loader**: Use the css-loader or the raw-loader to turn it into a JS module and the mini-css-extract-plugin to extract it into a separate file. Looking for the webpack 1 loader? Check out the archive/webpack-1 branch.  
URL: https://github.com/webpack-contrib/sass-loader

**OptimizeCSSAssetsPlugin**: It will search for CSS assets during the Webpack build and will optimize \ minimize the CSS (by default it uses cssnano but a custom CSS processor can be specified).  
URL: https://github.com/NMFR/optimize-css-assets-webpack-plugin

**MiniCssExtractPlugin**: This plugin extracts CSS into separate files. It creates a CSS file per JS file which contains CSS. It supports On-Demand-Loading of CSS and SourceMaps.  
URL: https://webpack.js.org/plugins/mini-css-extract-plugin/#root

**UglifyJsPlugin**: This plugin uses uglify-js to minify your JavaScript.  
URL: https://webpack.js.org/plugins/uglifyjs-webpack-plugin/

**HtmlWebPackPlugin**: The HtmlWebpackPlugin simplifies creation of HTML files to serve your webpack bundles. This is especially useful for webpack bundles that include a hash in the filename which changes every compilation.  
URL: https://webpack.js.org/plugins/html-webpack-plugin/#root

**CleanWebpackPlugin**: A webpack plugin to remove/clean your build folder(s). By default, this plugin will remove all files inside webpack's output.path directory, as well as all unused webpack assets after every successful rebuild.  
URL: https://github.com/johnagan/clean-webpack-plugin

**SourceMapDevToolPlugin**: This plugin enables more fine grained control of source map generation. It is also enabled automatically by certain settings of the devtool configuration option.  
URL: https://webpack.js.org/plugins/source-map-dev-tool-plugin/#root

**Webpack Encoding Plugin**: Take control over the encoding of emitted webpack assets. This can be useful, if the delivering webserver enforces a specific content-type, so that your js-code is not interpreted as utf-8 by the browser.  
URL: https://www.npmjs.com/package/webpack-encoding-plugin

**BundleAnalyzerPlugin**: Visualize size of webpack output files with an interactive zoomable treemap.  
URL: https://www.npmjs.com/package/webpack-bundle-analyzer  
*It's commented out in webpack.config.js. Uncomment it if you want to analyze your bundle.* 

**React Router DOM**: react-router-dom exports DOM-aware components, like Link and BrowserRouter. It is wrapper around react-router.  
URL: https://github.com/ReactTraining/react-router/tree/master/packages/react-router-dom

**Resolve URL Loader**: A webpack loader that rewrites relative paths in url() statements based on the original source file.  
URL: https://github.com/bholloway/resolve-url-loader/blob/master/packages/resolve-url-loader/README.md

## Known issues:  
- [Webpack 4 Entrypoint undefined](https://github.com/jantimon/html-webpack-plugin/issues/895)