/*
Command line to start, build project
npm start for running the localhost
npm run dev for building development bundle
npm run prod for building production bundle
PLUGINS:
npm install --save-dev html-webpack-plugin - creation of HTML files to serve your webpack bundles
npm install --save-dev clean-webpack-plugin - cleans dist folder before bundling the prod build
KNOWN ISSUE:
https://github.com/jantimon/html-webpack-plugin/issues/895
*/
const path = require("path");
const webpack = require("webpack");
const BundleAnalyzerPlugin = require("webpack-bundle-analyzer")
  .BundleAnalyzerPlugin;
const HtmlWebPackPlugin = require("html-webpack-plugin");
const {
  CleanWebpackPlugin
} = require("clean-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const TerserPlugin = require('terser-webpack-plugin');
const OptimizeCSSAssetsPlugin = require("optimize-css-assets-webpack-plugin");
const devMode = process.env.NODE_ENV === "production";
module.exports = (env, options) => {
  const isWebpackProdMode = options.mode === 'production'
  return {
  entry: {
    vendors: ["react", "react-dom"],
    app: "./src/index.js"
  },
  output: {
    filename: isWebpackProdMode ? "js/spa-gb-coaching-[name].[contenthash:6].js": "js/[name].js",
    path: path.resolve(__dirname, "./dist"),
    publicPath: "/gbcoaching/optionallifeinsurance/"
  },
  module: {
    rules: [
      //JAVASCRIPT
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader"
        }
      },
      //SCSS and CSS
      {
        test: /\.(sa|sc|c)ss$/,
        use: [{
            //loader: devMode ? 'style-loader' : MiniCssExtractPlugin.loader
            loader: MiniCssExtractPlugin.loader
          },
          {
            loader: "css-loader",
            options: {
              sourceMap: true
            }
          },
          {
            loader: "sass-loader",
            options: {
              implementation: require("sass"),
              sourceMap: true
            }
          }
        ]
      },
      {
        test: /\.(png|jpg|gif|svg)$/,
        loader: "file-loader",
        options: {
          // sourceMap: false,
          //context: path.resolve(__dirname, "src/"),
          name: "[path][name].[ext]",
          publicPath: '../'
          //outputPath: 'src/',
          //useRelativePaths: true
        }
      }
    ]
  },
  //Create chunks
  optimization: {
    runtimeChunk: 'single',
    splitChunks: {
      automaticNameDelimiter: '-',
      cacheGroups: {
        commons: {
          chunks: "initial",
          minChunks: 1,
          maxInitialRequests: 5,
          minSize: 0
        },
        vendors: {
          test: /[\\/]node_modules[\\/]/,
          name: "vendors",
          chunks: "all",
          priority: 10,
          enforce: true
        }
      }
    },
    //Uglify JavaScript and minify CSS
    minimizer: [
      new TerserPlugin({
        test: /\.js(\?.*)?$/i,
        exclude: /\node_modules/,
        parallel: true,
        parallel: 4,
        cache: false,
        sourceMap: false,
      }),
    ]
  },
  plugins: [
    // new webpack.optimize.LimitChunkCountPlugin({
    //   maxChunks: 1
    // }),
    new CleanWebpackPlugin(),
    new HtmlWebPackPlugin({
      template: path.resolve(__dirname, "src", "index.html"),
      filename: "index.html",
      inject: true,
      xhtml: false
    }),
    new MiniCssExtractPlugin({
      // Options similar to the same options in webpackOptions.output
      // both options are optional
      filename: isWebpackProdMode ? "css/spa-gb-coaching-[name].[contenthash:6].css" : "css/[name].css",
      publicPath: "../"
    }),
    // new webpack.SourceMapDevToolPlugin({
    //   module: false,
    //   noSources: false,
    //   exclude: ["css/coa.min.css"]
    // })
    //Optional use for analysing the bundle output only when required
    new BundleAnalyzerPlugin({
      analyzerMode: 'disabled',
      generateStatsFile: true,
      statsOptions: { source: false }
    })
  ],
  devtool: isWebpackProdMode ? "none" : "source-map",
  devServer: {
    //hot: true,
    // inline: true,
    // port: 8080,
    contentBase: [
      path.join(__dirname, "src/styles/scss"),
      path.join(__dirname, "src/components"),
      path.join(__dirname, "src/screens"),
      path.join(__dirname, "src/constants")
    ],
    watchContentBase: true,
    disableHostCheck: true,
    contentBasePublicPath: "/gbcoaching/optionallifeinsurance/",
    openPage:"gbcoaching/optionallifeinsurance",
    historyApiFallback: {
      index: "/gbcoaching/optionallifeinsurance/"
    }
  }
 }
};