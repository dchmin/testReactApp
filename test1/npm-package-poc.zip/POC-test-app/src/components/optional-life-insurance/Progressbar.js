import React from "react";
import ProgressBar from "react-bootstrap/ProgressBar";
import { getLocaleText } from "./../services/dictionary";

require("./../../styles/scss/progress-bar.scss");

const localeText = getLocaleText("optionalLifeInsurance");

const Progressbar = () => {
    const currentProgress = 100;
    return (
        <div id="progress-bar">
            <img id="progress-bar-img" src="https://www.sunnet.sunlife.com/static/ExportSite/COA/Images/hr3-867018718-feature-1200x600.jpg" alt="" />
            <h3 id="progress-bar-title" className="progress-bar-title">{localeText.progressbar.title}</h3>
            <p id="estimated-time" className="estimated-time">
                <span className="estimated-time-text">{localeText.progressbar.estimatedTimeText}</span>: {localeText.progressbar.estimatedTime}
            </p>
            <div className="row">
                <div className="col-10 progress-bar-coverage">
                    <ProgressBar now={currentProgress} />
                </div>
                <div className="col-2 progress-bar-percentile">
                    {currentProgress}%
                </div>
            </div>
        </div>
    );
}

export default Progressbar;