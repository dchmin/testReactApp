import React from "react";
import { Link } from "react-router-dom";
import { getLocaleText } from "./../services/dictionary";

require("./../../styles/scss/article-tile.scss");

const localeText = getLocaleText("optionalLifeInsurance");

const ArticleTile = () => {
    return (
        <div className="row" id="article-tile">
            <div className="col-12 col-md-8 article-tile-content">
                <h3 id="article-tile-title" className="article-tile-title">{localeText.articleTile.title}</h3>
                {/* <Link id="article-tile-read-more" className="article-tile-read-more" to="#">
                    {localeText.articleTile.readMore}
                </Link> */}
                <a href="#" id="article-tile-read-more" className="article-tile-read-more">
                    {localeText.articleTile.readMore}
                </a>
            </div>
            <img id="article-tile-img" className="col-12 col-md-4 d-none d-sm-none d-md-block article-tile-img" src="https://www.sunnet.sunlife.com/static/ExportSite/COA/Images/hlt20-getty-881467810-feature-1200x600.jpg" />
        </div>
    );
}

export default ArticleTile;