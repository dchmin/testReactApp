import React from "react";
import { Link } from "react-router-dom";
import { getLocaleText } from "./../services/dictionary";

require("./../../styles/scss/video-tile.scss");

const localeText = getLocaleText("optionalLifeInsurance");

const VideoTile = () => {
    return (
        <div className="row" id="video-tile">
            <div className="col-12 col-md-8 video-tile-content">
                <h3 id="video-tile-title" className="video-tile-title">{localeText.videoTile.title}</h3>
                {/* <Link id="video-tile-read-more" className="video-tile-read-more" to="#">
                    {localeText.videoTile.watchNow}
                </Link> */}
                <a href="#" id="video-tile-read-more" className="video-tile-read-more" to="#">
                    {localeText.videoTile.watchNow}
                </a>
            </div>
            <img id="video-tile-img" className="col-12 col-md-4 d-none d-sm-none d-md-block video-tile-img" src="https://cdn.vidyard.com/thumbnails/7372282/HvIQ7-DJM8scwg-fRTyT20vZ5yafQgCD.jpg" />
        </div>
    );
}

export default VideoTile;