import React from "react";
import { getLocaleText } from "./../services/dictionary";

require("./../../styles/scss/ella-intro.scss");

const localeText = getLocaleText("optionalLifeInsurance");

const EllaIntro = () => {
    return (
        <div id="ella-intro">
            <div className="ella-intro-text">
                <p id="ella-intro-text1" className="ella-intro-text1">{localeText.ellaIntro.text1}</p>
                {/* <p id="ella-intro-text2" className="ella-intro-text2">{localeText.ellaIntro.text2}</p>
                <p id="ella-intro-text3" className="ella-intro-text3">{localeText.ellaIntro.text3}</p> */}
            </div>
        </div>
    );
}

export default EllaIntro;