import React from "react";
import { getLocaleText } from "./../services/dictionary";

require("./../../styles/scss/ella-assessment.scss");

const localeText = getLocaleText("optionalLifeInsurance");

const EllaAssessment = () => {
    return (
        <div id="ella-assessment">
            <div className="ella-assessment-card">
                <p id="ella-assessment-text" >{localeText.ellaAssessment.text}</p>
            </div>
            <div className="ella-assessment-speech">
                <div className="ella-assessment-image" id="ella-assessment-image">
                    <img src="http://www.sunlife.ca/static/CS/digital_media/Ella-circle.png" alt="" />
                </div>
                <div className="ella-assessment-action-block">
                    <button className="btn btn-secondary" id="ella-assessment-button">{localeText.ellaAssessment.findOut}</button>
                </div>
            </div>
        </div>
    );
}

export default EllaAssessment;