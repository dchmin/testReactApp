import React from "react";
import { getLocaleText } from "./../services/dictionary";

require("./../../styles/scss/ella-assessment.scss");

const localeText = getLocaleText("optionalLifeInsurance");

const EllaAffirmation = () => {
    return (
        <div id="ella-affirmation">
            <div className="ella-affirmation-card">
                <p id="ella-affirmation-text" >{localeText.ellaAffirmation.text}</p>
            </div>
            <div className="ella-affirmation-speech">
                <div className="ella-affirmation-image" id="ella-affirmation-image">
                    <img src="http://www.sunlife.ca/static/CS/digital_media/Ella-circle.png" alt="" />
                </div>
                <div className="ella-affirmation-action-block">
                    <button className="btn btn-primary" id="ella-affirmation-apply-now-button">{localeText.ellaAffirmation.applyNow}</button>
                    <button className="btn btn-secondary" id="ella-affirmation-save-later-button">{localeText.ellaAffirmation.saveForLater}</button>
                </div>
            </div>
        </div>
    );
}

export default EllaAffirmation;