const lang = (global.getSelectedLanguage === 'fr' || global.getSelectedLanguage === 'fr-CA') ? 'fr_CA' : 'en_CA';
const translation = {
    fr_CA: {
        footer: {
            heading: 'La vie est plus radieuse sous le soleil',
            copyright: "Sun Life du Canada, compagnie d'assurance-vie.",
            legal: 'Notice juridique',
            privacy: 'Confidentialité',
            security: 'Sécurité',
            contact: 'Communiquer avec nous',
            openNewTab: "s’ouvre dans un nouvel onglet"
        },
        error: {
            apology: "Toutes nos excuses, cette page n’est pas disponible actuellement. Veuillez réessayer plus tard.",
            apiFailure: "Oups! Nous sommes désolés, nous ne pouvons pas enregistrer vos résultats dans le planificateur pour le moment. Veuillez réessayer plus tard.",
            registrationApiFailure: "Nous sommes désolés. Quelque chose ne fonctionne pas de notre côté. Veuillez réessayer."
        },
        header: {
            menu: 'Menu',
            lang: 'Français',
        },
        optionalLifeInsurance: {
            progressbar: {
                title: "Optional Life Insurance",
                estimatedTimeText: "Estimated time to complete",
                estimatedTime: "8 minutes"
            },
            ellaIntro: {
                text1: "Have you ever thought about what would happend if you were no longer around to care for your loved ones? It's a big relief to be as prepared as possible for the unexpected, and optional life insurance is an affordable, convienent way to protect your financial future.",
                text2: "When it comes to optional life insurance, which best describes you?",
                radiotext1: "Curious -  You know a bit but want to learn more",
                radiotext2: "Informed - You know more than the average person",
                text3: "Great choice - I've gathered some common questions and easy-to-read articles below."
            },
            accordion: {
                title: "The most common questions",
                faq: [
                    {
                        title: "Why do you need optional life insurance?",
                        content: "FAQ1 content"
                    },
                    {
                        title: "How affordable is it?",
                        content: "FAQ2 content"
                    },
                    {   
                        title: "what if I can't work to pay for the coverage?",
                        content: "With optional life insurance, you'll continue to be covered - even while on total disability(for a definition, see your benefits book) and we'll waive your payments for that period of time too."
                    },
                    {
                        title: "How much is enough",
                        content: "FAQ4 content"
                    }
                ]
            },
            videoTile: {
                title: "Optional life insurance explained (Video)",
                watchNow: "Watch now"
            },
            articleTile: {
                title: "Three good reasons to buy optional life insurance",
                readMore: "Read more"
            },
            ellaAssessment: {
                text: "Now that you're an optional insurance expert, let's find out how much you need. I've already added what I know about you to the calculator to help get you started.",
                findOut: "Find out now"
            },
            ellaAffirmation: {
                text: "Planning ahead can help take the financial strain off you and your loved ones if anything unexpected happens. Don't wait - Apply now to get the coverage you need.",
                applyNow: "Apply now",
                saveForLater: "Save for later"
            }
        },
        optionalLifeInsuranceCalculator: {
            close: "Fermer",
            openNewTab: "s’ouvre dans un nouvel onglet",
            stepNames: [{
                    id: "savings",
                    text: "Épargne",
                    title: "Épargne et assurance"
                },
                {
                    id: "liabilities",
                    text: "Dettes",
                    title: "Dettes et dépenses prévues"
                },
                {
                    id: "family",
                    text: "Famille",
                    title: "Revenu pour votre famille"
                },
                {
                    id: "results",
                    text: "Résultats",
                    title: "Vos résultats"
                }
            ],
            
            savings:{
                cs:"Épargne actuelle:",
                oi:"Autres placements:",
                elic:"Montant d'assurance-vie actuel:"
            },
            liabilities:{
                mortgage:"Solde actuel de votre prêt hypothécaire:",
                othloans:"Autres prêts et dettes que vous n'avez pas fini de rembourser:",
                child:"Frais liés aux études des enfants:",
                funeral:"Frais funéraires:",
                otherexp:"Autres frais:"
            },
            family:{
                ci:"Revenu actuel (après impôts):",
                percentage: "Pourcentage du revenu dont votre famille aura besoin:",
                finance:"Durée pendant laquelle votre famille aura besoin du revenu:"
            },
            result: {
                res: 'Recommandations pour votre assurance-vie',
                totalLife: 'Total de l\'assurance-vie requise',
                existingLife: 'Montant d\'assurance-vie actuel',
                additionalLife: 'Assurance-vie supplémentaire requise',
                assumption: 'Voir les hypotheses',
                quote: 'Obtenir une soumission',
                quoteLink: "https://www.sunlife.ca/ca/Get+a+quote?vgnLocale=fr_CA",
                plan: 'Enregistrer dans le plan',
                reset: 'Reprendre le calcul',
                connectAdvisor1: "Contactez un conseiller pour explorer vos options.",
                connectAdvisor2: "Contacter un conseiller",
                connectAdvLink : "https://www.sunlife.ca/ca/Find+an+advisor?vgnLocale=fr_CA",
                freequoteTitle: "C’est moins cher que vous le pensez.",
                freequoteText1: "Obtenez une soumission gratuite en ligne en quelques minutes. ",
                freequoteText2: "Obtenez une soumission gratuite en ligne.",
                freequoteText: " Ne vous en faites pas, vos objectifs seront là à votre retour."
            },
            tooltipTitle : {
                title1: "Autres placements",
                title2: "Montant d'assurance-vie actuel",
                title3:  "Frais liés aux études des enfants",
                title4:  "Frais funéraires",
                title5: "Autres frais",
                title6: "Pourcentage du revenu dont votre famille aura besoin",
                title7:  "Durée pendant laquelle votre famille aura besoin du revenu"
            },
            tooltipContent : {
                content1: "Comprend les régimes enregistrés d'épargne-retraite (REER), les comptes d'épargne libre d'impôt (CELI), les régimes enregistrés d'épargne-études (REEE), etc.",
                content2: "Comprend toute assurance-vie que vous avez déjà, y compris celle offerte dans le cadre du régime collectif de votre employeur, d'une assurance-vie personnelle ou d'une assurance hypothécaire.",
                content3: "Au pays, les frais de scolarité annuels pour les étudiants de premier cycle s'élevaient en moyenne à 6 571 $ en 2017/2018.",
                content4: "Des funérailles peuvent coûter entre 4 500 $ (services funéraires simples avec incinération) et 15 000 $ (services funéraires complets avec inhumation traditionnelle).",
                content5: "Comprend les autres dépenses importantes à prévoir pour votre famille, notamment les frais de garde d'enfants, les vacances, les dons à des organismes de charité, le mariage d'un enfant, etc.",
                content6: "Réfléchissez au revenu annuel dont votre famille aurait besoin, advenant votre décès, pour maintenir son niveau de vie actuel. Cela comprend tout, des frais téléphoniques mensuels aux dépenses d'alimentation. Ensuite, indiquez pendant combien d'années votre famille aura besoin de ce revenu.",
                content7: "Pour calculer cette durée, vous pouvez vous baser sur le nombre d'années restant d'ici à ce que votre plus jeune enfant atteigne l'âge de 18 ans ou d'ici à ce que votre conjoint ou partenaire prenne sa retraite. Votre famille recevra le montant de l'assurance-vie en un versement unique à utiliser comme bon lui semblera, mais ce chiffre permet d'estimer environ combien de temps cette somme pourrait durer."
            },
            tooltipLinkTitle: {
                title1: "",
                title2: "",
                title3:  "Statistique Canada, septembre 2017",
                title4: "Canadian Funerals Online (en anglais), juillet 2013",
                title5: "",
                title6: "",
                title7:  ""
            },
            tooltipLinks: {
                link1: "",
                link2: "",
                link3: "https://www150.statcan.gc.ca/t1/tbl1/fr/tv.action?pid=3710004501&request_locale=fr",
                link4: "http://www.canadianfunerals.com/funeral-related-articles/differences-in-cost-between-burial-and-cremation-in-canada.html",
                link5: "",
                link6: "",
                link7:  ""
            },
            AssumptionsModal : {
                title: "Hypothèses",
                content: [
                    "L'outil suppose un taux d'inflation de 2 % et un taux de rendement annuel prévu de 4 %.",
                    "L'outil suppose que l'intérêt est composé annuellement.",
                    "L'outil suppose que le revenu est versé au début de chaque année.",
                    "Fourchette de prix : Cette fourchette de prix est établie selon les renseignements que vous nous avez fournis et s'applique aux produits d'assurance-vie temporaire qui sont renouvelables tous les 10 ans. Nous offrons d'autres types d'assurance-vie susceptibles de répondre à vos besoins moyennant différents coûts mensuels.",
                    "Le coût réel d'une assurance-vie varie en fonction de votre état de santé, de votre âge et de votre style de vie. Un conseiller sera en mesure de vous présenter une soumission plus exacte et de déterminer quelle couverture répond à vos besoins.",
                    "La Sun Life du Canada, compagnie d\'assurance-vie est l\'assureur et est membre du groupe Sun Life.",
                    "Les résultats du calculateur vous sont fournis à titre indicatif seulement. Les montants ne sont pas garantis, car ils sont basés sur des hypothèses qui changeront certainement."
                ]
            },
            analytics : {
                breadcrumb: "/Home/Plan builder",
                category: "Plan builder",
                subCategory: "Protecting your family",
                canonicalId: "",
                linkZone: "calc_insure",
                linkType: "action_calculate",
                linkTitle: "see-results",
                linkTypeCTA: "cta",
                linkTitleGQ: "get-a-quote",
                linkTitleCA: "connect-advisor",
                linkTitleAP: "add-to-plan",
                linkTypeNext: "action_next",
                linkTypeBack: "action_back",
                linkTypeContent: "content",
                linkTitleStep1: "step-1",
                linkTitleStep2: "step-2",
                linkTitleBackStep1: "back_to_step1",
                linkTitleBackStep2: "back_to_step2",
                linkTitleBackToStart: "back_to_start",
                linkTitleAssumptions: "assumptions"
            },
            year: "ans",
            week: "Par semaine",
            biWeek: "Aux 2 semaines",
            month: "Par mois",
            annual: "Par année",
            moreInfo: "En savoir plus sur",
            title: "Calculateur d'assurance-vie",
            printTitle: "Calculateur d'assurance-vie – Vos résultats",
            step:"Étape",
            stepof:"de",
            next: "Suivant",
            back: "Retour",
            quote: "Obtenir une soumission",
            reset: "Retour audébut",
            cursav: "Épargne actuelle",
            othinv: "Autres placements",
            exislic: "Montant d'assurance-vie actuel",
            results: "Calculez vos résultats",
            calculateResults: "Calculez vos résultats",
            assumptn: "Voir les hypotheses.",
            additionalLifeInsurance: 'Assurance-vie supplémentaire requise. ',
            plus: "Plus",
            minus:"Moins",
            recalculate: "Reprendre le calcul",
        },
    },
    en_CA: {
        footer: {
            heading: 'Life’s brighter under the sun',
            copyright: 'Sun Life Assurance Company of Canada. All rights reserved.',
            legal: 'Legal',
            privacy: 'Privacy',
            security: 'Security',
            contact: 'Contact Us',
            openNewTab: "opens in a new tab"
        },
        error: {
            apology: "Our apologies, this page is not available at the moment. Please try again.",
            apiFailure: "Oops! We’re sorry, we can’t save to your plan right now. Please try again later.",
            registrationApiFailure: "We’re sorry. Something’s not working on our end. Please try again."
        },
        header: {
            menu: 'Menu',
            lang: 'English',
        },
        optionalLifeInsurance: {
            progressbar: {
                title: "Optional Life Insurance",
                estimatedTimeText: "Estimated time to complete",
                estimatedTime: "8 minutes"
            },
            ellaIntro: {
                text1: "Have you ever thought about what would happend if you were no longer around to care for your loved ones? It's a big relief to be as prepared as possible for the unexpected, and optional life insurance is an affordable, convienent way to protect your financial future.",
                text2: "When it comes to optional life insurance, which best describes you?",
                radiotext1: "Curious -  You know a bit but want to learn more",
                radiotext2: "Informed - You know more than the average person",
                text3: "Great choice - I've gathered some common questions and easy-to-read articles below."
            },
            accordion: {
                title: "The most common questions",
                faq: [
                    {
                        title: "Why do you need optional life insurance?",
                        content: "FAQ1 content"
                    },
                    {
                        title: "How affordable is it?",
                        content: "FAQ2 content"
                    },
                    {   
                        title: "what if I can't work to pay for the coverage?",
                        content: "With optional life insurance, you'll continue to be covered - even while on total disability(for a definition, see your benefits book) and we'll waive your payments for that period of time too."
                    },
                    {
                        title: "How much is enough",
                        content: "FAQ4 content"
                    }
                ]
            },
            videoTile: {
                title: "Optional life insurance explained (Video)",
                watchNow: "Watch now"
            },
            articleTile: {
                title: "Three good reasons to buy optional life insurance",
                readMore: "Read more"
            },
            ellaAssessment: {
                text: "Now that you're an optional insurance expert, let's find out how much you need. I've already added what I know about you to the calculator to help get you started.",
                findOut: "Find out now"
            },
            ellaAffirmation: {
                text: "Planning ahead can help take the financial strain off you and your loved ones if anything unexpected happens. Don't wait - Apply now to get the coverage you need.",
                applyNow: "Apply now",
                saveForLater: "Save for later"
            }
        },
        optionalLifeInsuranceCalculator: {
            close: "close",
            openNewTab: "opens in a new tab",
            stepNames: [{
                    id: "savings",
                    text: "Savings",
                    title: "Your savings and insurance"
                },
                {
                    id: "liabilities",
                    text: "Liabilities",
                    title: "Your liabilities and expected expenses"
                },
                {
                    id: "family",
                    text: "Family",
                    title: "Income for your family"
                },
                {
                    id: "results",
                    text: "Results",
                    title: "Your results"
                }
            ],
            savings: {
                cs:"Current savings:",
                oi:"Other investments:",
                elic:"Existing life insurance coverage:"
            },
            liabilities: {
                    mortgage:"Amount still owing on mortgage:",
                    othloans:"Other loans and debts you still owe:",
                    child:"Child education expenses:",
                    funeral:"Funeral expenses:",
                    otherexp:"Other expenses:"
            },
            family:{
                ci:"Current income (after taxes):",
                percentage: "Percentage of income your family will need:",
                finance:"How long your family will need financial support:"
            },
            result: {
                res: 'Your life insurance recommendations',
                totalLife: 'Total life insurance needed',
                existingLife: 'Existing life insurance coverage',
                additionalLife: 'Additional life insurance needed',
                assumption: 'View assumptions',
                quote: 'Get a quote',
                quoteLink: "https://www.sunlife.ca/ca/Get+a+quote?vgnLocale=en_CA",
                plan: 'Save to plan',
                reset: 'Restart calculator',
                connectAdvisor1: "Connect with an advisor to explore your options.",
                connectAdvisor2: "Connect with an advisor",
                connectAdvLink : "https://www.sunlife.ca/ca/Find+an+advisor?vgnLocale=en_CA",
                freequoteTitle: "It’s cheaper than you think",
                freequoteText1: "Get a free quote online in minutes.",
                freequoteText2: "Get your free online quote",
                freequoteText: " Don’t worry, your goals will be here when you get back."
            },
            tooltipTitle : {
                title1: "Other investments",
                title2: "Existing life insurance coverage",
                title3: "Child education expenses",
                title4: "Funeral expenses",
                title5: "Other expenses",
                title6: "Percentage of income your family will need",
                title7:  "How long your family will need financial support"
            },
            tooltipContent : {
                content1: "This includes registered retirement savings plans (RRSP), tax-free savings accounts (TFSA), registered education savings plans (RESP), etc.",
                content2: "This includes any life insurance coverage that you already have, including group life insurance coverage through your employer, personal life insurance or mortgage insurance.",
                content3:  "The average cost of undergraduate tuition per year in Canada was $6,571 in 2017/2018.",
                content4:  "Funeral costs can range from $4,500 (for a simple cremation service) to $15,000 (for a full-service, traditional burial).",
                content5: "This includes other major expenses you expect your family will need money for, such as, child care, vacations, charitable donations, a child’s wedding, etc.",
                content6: "Think about how much of your income your family would need each year to keep up their current lifestyle if you die. This includes everything from your monthly phone bills to groceries. Then you need to determine how many years your family will need this money.",
                content7:  "You might want to calculate this amount by using either the number of years from now until your youngest child turns 18 or your spouse/partner retires. Your family will receive the life insurance in a single payment, to use as they see fit, but this will give you an idea of how long the money might last."
            },
            tooltipLinkTitle: {
                title1: "",
                title2: "",
                title3: "Statistics Canada, September 2017",
                title4: "Canadian Funerals Online, July 2013",
                title5: "",
                title6: "",
                title7:  ""
            },
            tooltipLinks: {
                link1: "",
                link2: "",
                link3: "https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=3710004501",
                link4: "http://www.canadianfunerals.com/funeral-related-articles/differences-in-cost-between-burial-and-cremation-in-canada.html",
                link5: "",
                link6: "",
                link7:  ""
            },
            AssumptionsModal : {
                title: "Assumptions",
                content: [
                    "This tool assumes an inflation rate of 2% and an annual expected rate of return of 4%.",
                    "Assume interest is compounded annually.",
                    "Assume income is to be paid at the start of each year.",
                    "Cost range: This cost range is based on the information you gave us, and applies to Term Life insurance policies that renew every 10 years. We have other types of life insurance products that may suit your needs, for different monthly costs.",
                    "The actual cost of life insurance depends on your health, age and lifestyle. An advisor can give you a more accurate life insurance quote and find you coverage that suits your needs.",
                    "Sun Life Assurance Company of Canada is the insurer and a member of the Sun Life group of companies.",
                    "The results you received from this calculator are for your information only. The figures are not guaranteed, as they are based on assumptions that are certain to change."
                ]
            },
            analytics : {
                breadcrumb: "/Home/Plan builder",
                category: "Plan builder",
                subCategory: "Protecting your family",
                canonicalId: "",
                linkZone: "calc_insure",
                linkType: "action_calculate",
                linkTitle: "see-results",
                linkTypeCTA: "cta",
                linkTitleGQ: "get-a-quote",
                linkTitleCA: "connect-advisor",
                linkTitleAP: "add-to-plan",
                linkTypeNext: "action_next",
                linkTypeBack: "action_back",
                linkTypeContent: "content",
                linkTitleStep1: "step-1",
                linkTitleStep2: "step-2",
                linkTitleBackStep1: "back_to_step1",
                linkTitleBackStep2: "back_to_step2",
                linkTitleBackToStart: "back_to_start",
                linkTitleAssumptions: "assumptions"
            },
            year: "years",
            week: "Weekly",
            biWeek: "BiWeekly",
            month: "Monthly",
            annual: "Annually",
            moreInfo: "More Information on",
            title: "Life insurance calculator",
            printTitle: "Life insurance calculator - Your results",
            step: "Step",
            stepof:"of",
            next: "Next",
            back: "Back",
            quote: "Get a quote",
            reset: "Back to start",
            cursav: "Current savings",
            othinv: "Other investments",
            exislic: "Existing life insurance coverage",
            results: "See results",
            calculateResults: "Calculate your results",
            assumptn: "View assumptions.",
            additionalLifeInsurance: 'Additional life insurance needed. ',
            plus: "Plus",
            minus:"Minus",
            recalculate: "Restart calculator",
        },
    }
}

let text = translation[lang];
export function getLocaleText(component) {
    return text[component];
}