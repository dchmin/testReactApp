//Utility functions for protecting application security

   //Check for cross site scripting and other types of injections
   export default function sanitize(jsonObj)
    {
        let strContent = JSON.stringify(jsonObj);
        
        //Full list of attack scenarios listed at https://owasp.org/www-community/xss-filter-evasion-cheatsheet
        let strBadTags = ["<iframe","<script","javascript:","java\0script","document.cookie","alert(","fromCharCode"];
        
        for (var i=0; i < strBadTags.length; i++)
        {
            if (strContent.trim().replace(/ /g,"").toLowerCase().includes(strBadTags[i]))
                return false;
        }	
        
        return true;
    }
    
