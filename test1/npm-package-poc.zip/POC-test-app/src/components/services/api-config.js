export const getAQuoteURL = () => {
    let url = "#";
      
    if((window.location.origin.includes("localhost")) || (window.location.origin.includes("sunnet"))) {
        if (getSelectedLanguage === 'fr-CA') {
            url = `https://www.sunlife.ca/fr/get-a-quote/`;
        } else {
            url = `https://www.sunlife.ca/en/get-a-quote/`;
        }        
    }
    return url;
}