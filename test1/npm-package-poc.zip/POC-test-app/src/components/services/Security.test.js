import sanitize from "./Security";
import { XSSAttackInputs } from "./XSSAttackInputs";

const validData = "<p>Whether you are a recent grad in your 20s or married with kids in your 30s or 40s</p>"

describe("Testing Sanitize function", () => {
        it ('Checking for XSS Invalid Inputs', () => {
            XSSAttackInputs.map(XSSAttackInput => {
                const sanitizeResponse = sanitize(XSSAttackInput);
                expect(sanitizeResponse).toBe(false);
            })
        });
        
        it ('Checking for Valid Input', () => {
            const sanitizeResponse = sanitize(validData);
            expect(sanitizeResponse).toBe(true);
        });
});