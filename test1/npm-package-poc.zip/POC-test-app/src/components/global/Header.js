import React from "react";
import { getLocaleText } from "../services/dictionary";
require('../../styles/scss/header.scss');

const localeText = getLocaleText("header");
const Header = () => {
    return (
        <header id="main-header">
            <div className="container">
                <div className="row">
                    <div className="col-6">
                        <div className="sl-logo">
                            <svg width="128px" height="31px" version="1.1" xmlns="http://www.w3.org/2000/svg" xlinkHref="http://www.w3.org/1999/xlink">
                                <title>Sun Life logo</title>
                                <desc>Sun Life logo</desc>
                                <image xlinkHref="https://cdn.sunlife.com/static/slfglobal/globalweb/responsive/images/sunlife-logo-web.svg" x="0" y="0" height="31px" width="127px" alt="Sun Life"></image>
                            </svg>
                        </div>
                    </div>
                    <div className="col-6 text-right">
                        <div className="language">
                            <a href={`?vgnLocale=${vgnLocale}`} onClick={langToggle}>{localeText.lang}</a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    );
};
function langToggle(e){
    // reload screen
    var currentLanguage = ""
    if(global.getSelectedLanguage === 'en')
    {
    		currentLanguage = 'fr-CA';
    }
    else
    {
    		currentLanguage = 'en';
    }
    
    window.sessionStorage.setItem('language', currentLanguage);
}
export default Header;