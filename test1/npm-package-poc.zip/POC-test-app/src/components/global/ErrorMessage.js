import React, { useState } from 'react';
import { Alert } from "react-bootstrap";
import { getLocaleText } from "../services/dictionary";
require("../../styles/scss/error-message.scss");

const localeText = getLocaleText("error");

const ErrorMessage = ({ type, showError, handleShowError, errorMessage }) => {
    let errorContent = null;
    if(type == 'API_ERROR') {
        errorContent = (
        <Alert variant="danger" show={showError} onClose={() => handleShowError(false)} dismissible>
            <p>{errorMessage}</p>
        </Alert>
        );
    } else {
        errorContent = (
        <div className="error-message">
            <p>{localeText.apology}</p>
        </div>
        );
    }
    return (
        <>
         {errorContent}
        </>
    );
};

export default ErrorMessage;