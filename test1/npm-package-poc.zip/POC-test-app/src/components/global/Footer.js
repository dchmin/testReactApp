import React from "react";
import {
  getLocaleText
} from "../services/dictionary";
require("../../styles/scss/footer.scss");

const localeText = getLocaleText("footer");
const Footer = () => {
  return (
    <footer id="main-footer">
      <div className="container">
        <div className="row">
          <div className="col-md">
            <div className="left-sec">
            <p className="tag-line">{localeText.heading}</p>
              <p>&copy; {localeText.copyright}</p>
            </div>
          </div>
          <div className="col-md">
            <div className="right-sec">
              <ul className="footer-list-inline">
                <li>
                  <a
                    href={`https://www.sunlife.ca/slf/PSLF+Canada/Legal?vgnLocale=${getSelectedLanguage}`}
                    rel="noreferrer" target="_blank"
                  >
                    {localeText.legal} <span className="sr-only">{localeText.openNewTab}</span>
                  </a>
                </li>
                <li>
                  <a
                    href={`https://www.sunlife.ca/slf/PSLF+Canada/Privacy?vgnLocale=${getSelectedLanguage}`}
                    rel="noreferrer" target="_blank"
                  >
                    {localeText.privacy} <span className="sr-only">{localeText.openNewTab}</span>
                  </a>
                </li>
                <li>
                  <a
                    href={`https://www.sunlife.ca/slf/PSLF+Canada/Security?vgnLocale=${getSelectedLanguage}`}
                    rel="noreferrer" target="_blank"
                  >
                    {localeText.security} <span className="sr-only">{localeText.openNewTab}</span>
                  </a>
                </li>
                <li>
                  <a
                    href={`https://www.sunlife.ca/ca/Contact+us?vgnLocale=${getSelectedLanguage}`}
                    rel="noreferrer" target="_blank"
                  >
                    {localeText.contact} <span className="sr-only">{localeText.openNewTab}</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
export default Footer;
