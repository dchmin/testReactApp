import React from "react";
import "regenerator-runtime/runtime";
import OptionalLifeInsurancePage from "./../../screens/OptionalLifeInsurancePage";

const Body = () => {
  return (
        <>
          <OptionalLifeInsurancePage />
        </>    
  );
};

export default Body;
