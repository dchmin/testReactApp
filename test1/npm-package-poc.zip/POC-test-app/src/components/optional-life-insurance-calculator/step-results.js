import React, { useState } from "react";
import { getLocaleText } from "../services/dictionary";
import GBModal from "../form-common/modal";
import { format } from "../form-common/calculator-validation";
import { getAQuoteURL } from "./../services/api-config";
require("../../styles/scss/step-results.scss");

const localeText = getLocaleText("optionalLifeInsuranceCalculator");

const StepResults = (props) => {
    const lifeCalcResults = props.data.results;
    const Reset = () => {
        props.moveStep(0);
    }
    const [showAssumptionsModal, setAssumptionsModalShow] = useState(false);
    const handleAssumptionsModalShow = () => setAssumptionsModalShow(!showAssumptionsModal);
    const addIns = lifeCalcResults.additionalInsuranceNeeded;

    return (
        <>
        <div id="results">
            <div className="row">
                <div className="col-12 col-xl-5">
                    <p className="total-life" id="total-life-insurance-needed">{localeText.result.totalLife}</p>
                    <p className="total-life-num" id="total-life-insurance-needed-number">{format(lifeCalcResults.totalInsuranceNeeded, true)}</p>
                    <p className="existing-life" id="existing-life-insurance-coverage">{localeText.result.existingLife}</p>
                    <p className="existing-life-num" id="existing-life-insurance-coverage-number">{format(lifeCalcResults.existingInsurance, true)}</p>
                    <p className="additional-life" id="additional-coverage-needed">{localeText.result.additionalLife}</p>
                    <p className="additional-life-num" id="additional-coverage-needed-number">{format(lifeCalcResults.additionalInsuranceNeeded, true)}</p>
                    <a className="recalculate" id="life-recalculate" onClick={Reset}>
                            {localeText.recalculate}
                    </a>
                </div>
                <div className="col-12 col-xl-7">
                    <p className="free-quote-title" id="free-quote-title">{localeText.result.freequoteTitle}</p>
                    <p className="free-quote-text" id="free-quote-text">
                    {(addIns > 1000000) ?
                        <a href="#" id="advisor-link">
                            {localeText.result.connectAdvisor1}
                        </a> : 
                        <a id="free-quote-link" href={getAQuoteURL()} target="_blank">
                            {localeText.result.freequoteText1} 
                            <span className="sr-only">{localeText.openNewTab}</span>
                        </a>
                    }
                        <span>{localeText.result.freequoteText}</span>
                    </p>
                    <p className="assumption">
                        <button className="assumption-btn" id="assumption-btn" onClick={handleAssumptionsModalShow}>
                            {localeText.result.assumption}
                        </button>
                        <GBModal handleModalShow={handleAssumptionsModalShow} showModal={showAssumptionsModal} ModalTitle={localeText.AssumptionsModal.title} 
                            ModalContent={localeText.AssumptionsModal.content} /> 
                    </p>
                </div>
                <div className="col-12">
                    {(addIns > 1000000) ?
                        <a className="bottom-advisor-link" id="bottom-advisor-link" href="#">
                            {localeText.result.connectAdvisor2}
                            <span className="free-quote-chevron-right"></span>
                        </a> :
                        <a className="bottom-free-quote-link" id="bottom-free-quote-link" href={getAQuoteURL()} target="_blank">
                            {localeText.result.freequoteText2}
                            <span className="sr-only">{localeText.openNewTab}</span>
                            <span className="free-quote-chevron-right"></span>
                        </a>
                    }
                </div>
            </div>
        </div>
        </>
    );
  };
  export default StepResults;