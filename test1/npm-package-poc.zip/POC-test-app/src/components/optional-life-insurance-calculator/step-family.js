import React from "react";
import ItemForm from "../form-common/itemForm";
import ToolTipBox from "../form-common/tooltip";
import {getLocaleText} from "../services/dictionary";
import {validateNumber, format, strip} from "../form-common/calculator-validation";
// import SetAnalytics from "../services/analytics";
require('./../../styles/scss/form.scss');

const localeText = getLocaleText("optionalLifeInsuranceCalculator");
const StepFamily = (props) => {
    const ciMsg = props.data.errors.currentIncome;
    const diMsg = props.data.errors.desiredIncome;
    const idMsg = props.data.errors.incomeDuration;
    const handleChange = evt => {
        let name = evt.target.name;
        let newValue = evt.target.value;
        let strippedValue = 0;

        strippedValue = strip(newValue, global.getSelectedLanguage);
        let strippedName = "";

        if(name.includes("Slider")){
            strippedName = name.replace("Slider","");
        } else {
            strippedName = name;
        }
        props.setForm(strippedName,strippedValue)
    }
    const nextScreen = () => {
        if(ciMsg === "" && diMsg === "" && idMsg === ""){
            // SetAnalytics(localeText.analytics.breadcrumb, localeText.analytics.category,localeText.analytics.subCategory,localeText.analytics.canonicalId,
            //     localeText.analytics.linkZone,localeText.analytics.linkType,localeText.analytics.linkTitle);
            props.moveStep(3);
        }
    }
    const previousScreen = () => {
        // SetAnalytics(localeText.analytics.breadcrumb, localeText.analytics.category,localeText.analytics.subCategory,localeText.analytics.canonicalId,
        //                  localeText.analytics.linkZone,localeText.analytics.linkTypeBack,localeText.analytics.linkTitleBackStep2);
        props.moveStep(1);
    }
    const handleDropDown = evt => {
        const newValue = evt.target.value;
        const fieldName = evt.target.name;
        props.setForm(fieldName,newValue);
    }
    const handlePlus = (name, propName) => {
        let Newvalue = Number(propName) + 1;
        props.setForm(name,Newvalue);
    }
    const handleMinus = (name, propName) => {
        let Newvalue = propName - 1;
        props.setForm(name,Newvalue);
    } 
    return (
        <>
        <div className="lic-form" id="family">
            <p className="step-title">{localeText.stepNames[2].title}</p>
            <form className="form-calculator" name="inc-savings" id="inc-savings">
                <div className={`form-group currentIncome mb-5 ${(ciMsg !== "") ? 'error-container' : "" }`}>
                    <label htmlFor="currentIncome">{localeText.family.ci}</label>
                    <div className="wrapper">
                        <ItemForm
                            inputType="InputWithOutLabel"
                            labelType="false"
                            placeholder="0"
                            inputID="currentIncome"
                            name="currentIncome"
                            minLength="1"
                            maxLength="8"
                            pattern="[0-9,]*"
                            value={format(props.data.currentIncome)}
                            onChange={handleChange} 
                            onInput={validateNumber}/>
                        <div className="annual-dropdown">
                            <select value={props.data.currentIncomeFreq} className="period" id="currentIncomeFreq" name="currentIncomeFreq" onChange={handleDropDown}>
                                <option value="52" >{localeText.week}</option>
                                <option value="26">{localeText.biWeek}</option>
                                <option value="12">{localeText.month}</option>
                                <option value="1">{localeText.annual}</option>
                            </select>
                        </div>
                    </div>
                    {
                    (ciMsg !== "") ? <span className="error-box">{ciMsg}</span> : ""
                    }
                </div>
                <div className={`form-group percentageIncome mb-5 ${(diMsg !== "") ? 'error-container' : "" }`}>
                        <label htmlFor="desiredIncome">{localeText.family.percentage}</label>
                        <ToolTipBox tooltipTitle={localeText.tooltipTitle.title6} tooltipContent={localeText.tooltipContent.content6} tooltipLinkTitle={localeText.tooltipLinkTitle.title6} tooltipLink={localeText.tooltipLinks.link6}/>
                        <div className="desiredIncome-percentile">
                            <div className="wrapper">
                                <div className="minus-sign">
                                    <button
                                        type="button"
                                        onClick={() => handleMinus("desiredIncome",props.data.desiredIncome)}
                                        className="btn-minus">
                                        <span className="sr-only">{localeText.minus}</span>
                                    </button>
                                </div>
                                <ItemForm
                                    pattern="[0-9,]*"
                                    inputType="InputWithPercentile"
                                    labelType="withQuestion"
                                    placeholder="0"
                                    labelFor="desiredIncome"
                                    labelText={localeText.family.percentage}
                                    inputID="desiredIncome"
                                    name="desiredIncome"
                                    minLength="1"
                                    maxLength="3"
                                    value={props.data.desiredIncome}
                                    onChange={handleChange}
                                    onInput={validateNumber}
                                    />
                                <div className="plus-sign">
                                    <button
                                        type="button"
                                        onClick={() => handlePlus("desiredIncome",props.data.desiredIncome)}
                                        className="btn-plus">
                                        <span className="sr-only">{localeText.plus}</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        {
                            (diMsg !== "") ? <span className="error-box">{diMsg}</span> : ""
                        }
                </div>
                <div className={`form-group financialSupport ${(idMsg !== "") ? 'error-container' : "" }`}>
                    <label htmlFor="incomeDuration">{localeText.family.finance}</label>
                    <ToolTipBox tooltipTitle={localeText.tooltipTitle.title7} tooltipContent={localeText.tooltipContent.content7} tooltipLinkTitle={localeText.tooltipLinkTitle.title7} tooltipLink={localeText.tooltipLinks.link7}/>
                  <div className="incomeDuration-years">
                    <div className="wrapper">
                        <div className="minus-sign">
                            <button
                                type="button"
                                disabled={(props.data.incomeDuration === 1) ? true : false }
                                onClick={() => handleMinus("incomeDuration",props.data.incomeDuration)}
                                className="btn-minus">
                                <span className="sr-only">{localeText.minus}</span>
                            </button>
                        </div>
                        <ItemForm
                            inputType="InputWithyears"
                            labelType="withQuestion"
                            pattern="[0-9,]*"
                            placeholder="50"
                            labelFor="incomeDuration"
                            labelText={localeText.family.finance}
                            inputID="incomeDuration"
                            name="incomeDuration"
                            minLength="1"
                            maxLength="2"
                            value={props.data.incomeDuration}
                            onChange={handleChange} 
                            onInput={validateNumber}/>
                            <div className="plus-sign">
                                <button
                                    type="button"
                                    disabled={(props.data.incomeDuration === 50) ? true : false }
                                    onClick={() => handlePlus("incomeDuration",props.data.incomeDuration)}
                                    className="btn-plus">
                                    <span className="sr-only">{localeText.plus}</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    {
                        (idMsg !== "") ? <span className="col-12 error-box">{idMsg}</span> : ""
                    }
                </div>
            </form>
            <div className="col-12 px-0">
                <button className="btn-primary mar-btm" onClick={nextScreen}>{localeText.calculateResults}</button>
            </div>
            <div className="col-12 px-0">
                <button className="btn-transparent" onClick={previousScreen}>{localeText.back}</button>
            </div>
        </div>
        </>
    );
  };
  export default StepFamily;