import React from "react";
import StepSavings from "./step-savings";
import StepLiabilities from "./step-liabilities";
import StepFamily from "./step-family";
import StepResults from "./step-results";
import StepWizard from "../form-common/step-indicator";
import {validateFormData} from "./form-validation";
// import {CoaContext} from "../store/coaContext";
import GetResults from "./life-calculator";
require("../../styles/scss/calculator.scss");
require("../../styles/scss/step-wizard.scss");

class OptionalLifeInsuranceCalculator extends React.Component {
  // static contextType = CoaContext;
  constructor() {
    super();
    this.state = {...this.initialState()};
    this.scrollRef = React.createRef();
  }
  initialState = () => {
    return {
      currentSavings: 0,
      otherInvestments: 0,
      existingCoverage: 0,
      mortgage: 0,
      otherDebts: 0,
      childEducation: 0,
      funeral: 0,
      otherExpenses: 0,
      currentIncome: 35000,
      currentIncomeFreq: 1,
      desiredIncome: 50,
      incomeDuration: 5,
      isResultCalculated: false,
      isLifeResponseAvailable : false,
      totalSteps:4,
      navigation:{
        initialStep: 0,
        currentStep: 0,
      },
      errors: {
        currentSavings: "",
        otherInvestments: "",
        existingCoverage: "",
        mortgage: "",
        otherDebts: "",
        childEducation: "",
        funeral: "",
        otherExpenses: "",
        currentIncome: "",
        desiredIncome: "",
        incomeDuration: ""
      },
      results:{
        replacementIncomeGoal:"",
        replacementIncomeGoalPerYear:"",
        totalInsuranceNeeded:"",
        additionalInsuranceNeeded:"",
        existingInsurance:""
      },
      calcType:"optionalLifeInsuranceCalculator"
    }
  }

  reSetForm = () => {
    this.setState({...this.initialState()});
  }
  setResults = (results) => {
    const newState = {...this.state};
    newState.isResultCalculated = true;
    newState.results = results;
    this.setState(newState);
    // this.putStateIntoContext(newState);
  }
  setForm = (key, value) => {
    const newFormData = {...this.state}
    newFormData[key] = value;
    const validatedData = validateFormData(newFormData);
    this.setState(validatedData);
  }
  getCurrentStep = () => {
    return this.state.navigation.currentStep
  }
  scrollToRef = (ref) => {
    const yOffset = -5;
    const  yCoord = ref.current.getBoundingClientRect().top + window.pageYOffset + yOffset;
    window.scrollTo({
      top:  yCoord,
      behavior: 'smooth'
    });
  };
  next = (nextStepID) => {
    const Nav = {...this.state.navigation}
    Nav.currentStep = nextStepID;
    this.setState({
      navigation: Nav
    })
    this.scrollToRef(this.scrollRef);
  }
  nextAndCalculate = (nextStepID) => {
    const lifeCalcResults = GetResults(this.state);
    this.setResults(lifeCalcResults);
    this.next(nextStepID);
  }  
  // putStateIntoContext =(newState) => {
  //   // localStorage.setItem("lifeCalResults", JSON.stringify(newState));
  //   const context = this.context;
  //   delete newState.errors;
  //   delete newState.totalSteps;
  //   delete newState.navigation;
  //   context.updateLifeCalcState(newState);
  // }
  // componentDidMount() {
  //   let newState = this.context.lifeCalc
  //   this.setState({...newState});
  // }
  // componentDidUpdate() {
  //   if(this.state.isLifeResponseAvailable !== true && this.context.lifeCalc.isLifeResponseAvailable === true ) {
  //     let newState = this.context.lifeCalc;
  //     this.setState({...newState});
  //   }
  // }
  render() {
      const id = this.getCurrentStep();
      let Widget = (<></>);
      switch (id) {
        case 0:
          Widget = (<StepSavings data = {this.state} setForm={this.setForm} moveStep={this.next} />);
          break;
        case 1:
          Widget = (<StepLiabilities data = {this.state} setForm={this.setForm} moveStep={this.next} />);
          break;
        case 2:
          Widget = (<StepFamily data = {this.state} setForm={this.setForm} moveStep={this.nextAndCalculate} />);
          break;
        case 3:
          Widget = (<StepResults data = {this.state} setForm={this.setForm} moveStep={this.next} resetForm={this.reSetForm} />);
          break;
      }
      return(
        <div id="life-calc-wrapper" ref={this.scrollRef}>
        <StepWizard data = {this.state} stepID={id} moveStep={this.next} />
        {Widget}
        </div>
      )
    }
  }
export default OptionalLifeInsuranceCalculator;