const getResults = (inputData) => {
    // init = true; //new logic
    const calcData = {...inputData};
    for (const property in calcData) {
        calcData[property] = Number(calcData[property]);
    }
    calcData.desiredIncome = calcData.desiredIncome/100;
    const init = true;
    const assumptions = { inflationRate: 0.02, growthRate: 0.04 };
    let interest = -1 * assumptions.inflationRate;
    let currentAnnualIncome = calcData.currentIncome * calcData.currentIncomeFreq;
    let replacementIncomeGoal, replacementIncomeGoalPerYear;
    //if(init){
        replacementIncomeGoalPerYear =  Math.ceil(currentAnnualIncome * calcData.desiredIncome);
        replacementIncomeGoal = Math.ceil(replacementIncomeGoalPerYear / calcData.currentIncomeFreq);
    //}
    //else{
        //replacementIncomeGoal = calcData.desiredIncome;
        //replacementIncomeGoalPerYear = Math.ceil(calcData.desiredIncome * calcData.currentIncomeFreq);
    //}
    // if(replacementIncomeGoal == null) {
    //     replacementIncomeGoal = 0;
    // }
    let totalIncomeReq = replacementIncomeGoalPerYear 
            + (replacementIncomeGoalPerYear 
                * (Math.pow(1+interest, calcData.incomeDuration -1) -1)) 
                / (interest * Math.pow(1 + interest, calcData.incomeDuration - 1));
  
    let totalAmountReq = totalIncomeReq + calcData.mortgage + calcData.otherDebts 
            + calcData.childEducation + calcData.funeral + calcData.otherExpenses - calcData.currentSavings - calcData.otherInvestments;
    
    let totalInsuranceNeeded = (totalAmountReq < 0) ? 0 : totalAmountReq;
    let additionalInsuranceNeeded = (totalInsuranceNeeded - calcData.existingCoverage < 0) 
                ? 0 : totalInsuranceNeeded - calcData.existingCoverage;
    
    const results =  {
        replacementIncomeGoal: replacementIncomeGoal,
        replacementIncomeGoalPerYear: replacementIncomeGoalPerYear,
        totalInsuranceNeeded: Math.round(totalInsuranceNeeded),
        additionalInsuranceNeeded: Math.round(additionalInsuranceNeeded),
        existingInsurance: Math.round(calcData.existingCoverage)
    };

    return results;
  }
  export default getResults;