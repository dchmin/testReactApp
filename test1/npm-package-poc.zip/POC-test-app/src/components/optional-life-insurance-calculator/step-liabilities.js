import React from "react";
import {getLocaleText} from "../services/dictionary";
import ItemForm from "../form-common/itemForm";
import RangeSlider from "../form-common/rangeSlider";
// import SetAnalytics from "../services/analytics";
import {validateNumber, format, strip} from "../form-common/calculator-validation";
import {mapSliderScaleToValueScale, mapValueScaleToSliderScale} from "../form-common/slider-validation"; 
require('./../../styles/scss/form.scss');

const localeText = getLocaleText("optionalLifeInsuranceCalculator");
const StepLiability = (props) => {
    const moMsg = props.data.errors.mortgage;
    const odMsg = props.data.errors.otherDebts;
    const ceMsg = props.data.errors.childEducation;
    const fuMsg = props.data.errors.funeral;
    const oeMsg = props.data.errors.otherExpenses;

    const handleExpChange = evt => {
        let name = evt.target.name;
        let newValue = evt.target.value;
        let strippedValue = 0;
        let strippedName = "";
        if (name.includes("Slider")) {
            let exponentialValue = mapSliderScaleToValueScale(name, newValue);
            strippedName = name.replace("Slider","");
            strippedValue = exponentialValue;
        } else {
            strippedName = name;
            strippedValue = strip(newValue, global.getSelectedLanguage);
        }
        props.setForm(strippedName,strippedValue)
    }

    const nextScreen = () => {
        if ( moMsg === "" && odMsg === "" && ceMsg === "" && fuMsg === "" && oeMsg === "" ) {
            // SetAnalytics(localeText.analytics.breadcrumb, localeText.analytics.category,localeText.analytics.subCategory,localeText.analytics.canonicalId,
            //              localeText.analytics.linkZone,localeText.analytics.linkTypeNext,localeText.analytics.linkTitleStep2);
            props.moveStep(2);
        }
    }
    const previousScreen = () => {
        // SetAnalytics(localeText.analytics.breadcrumb, localeText.analytics.category,localeText.analytics.subCategory,localeText.analytics.canonicalId,
        //                  localeText.analytics.linkZone,localeText.analytics.linkTypeBack,localeText.analytics.linkTitleBackStep1);
        props.moveStep(0);
    }
    return (
        <>
        <div className="lic-form" id="liability">
            <p className="step-title">{localeText.stepNames[1].title}</p>
            <form className="form-calculator" name="inc-savings" id="inc-savings">
            <div className={`form-group ${(moMsg !== "") ? 'error-container' : "" }`}>
                <ItemForm
                    inputType="InputWithSymbol"
                    labelType="false"
                    placeholder="0"
                    minLength="1"
                    maxLength="10"
                    pattern="[0-9,]*"
                    labelFor="mortgage"
                    labelText={localeText.liabilities.mortgage}
                    inputID="mortgage"
                    name="mortgage"
                    value={format(props.data.mortgage)}
                    onChange={handleExpChange}
                    onInput={validateNumber} />
                    {
                        (moMsg !== "") ? <span className="error-box">{moMsg}</span> : ""
                    }
                <RangeSlider
                    aria-label={localeText.liabilities.mortgage}
                    mappedRange={true}
                    name="mortgageSlider"
                    id="mortgageSlider"
                    value={mapValueScaleToSliderScale(10000000, props.data.mortgage)}
                    min="0"
                    max="10000000"
                    onChange={handleExpChange} />
            </div>
            <div className={`form-group ${(odMsg !== "") ? 'error-container' : "" }`}>
                <ItemForm
                    inputType="InputWithSymbol"
                    labelType="false"
                    placeholder="0"
                    minLength="1"
                    maxLength="10"
                    pattern="[0-9,]*"
                    labelFor="otherDebts"
                    labelText={localeText.liabilities.othloans}
                    inputID="otherDebts"
                    name="otherDebts"
                    value={format(props.data.otherDebts)}
                    onChange={handleExpChange}
                    onInput={validateNumber} />
                    {
                        (odMsg !== "") ? <span className="error-box">{odMsg}</span> : ""
                    }
                <RangeSlider
                    aria-label={localeText.liabilities.othloans}
                    mappedRange={true}
                    name="otherDebtsSlider"
                    id="otherDebtsSlider"
                    value={mapValueScaleToSliderScale(10000000, props.data.otherDebts)}
                    min="0"
                    max="10000000"
                    onChange={handleExpChange} />
            </div>
            <div className={`form-group ${(ceMsg !== "") ? 'error-container' : "" }`}>        
                <ItemForm
                    inputType="InputWithSymbol"
                    tooltipTitle={localeText.tooltipTitle.title3}
                    tooltipContent={localeText.tooltipContent.content3} 
                    tooltipLinkTitle={localeText.tooltipLinkTitle.title3} 
                    tooltipLink={localeText.tooltipLinks.link3}
                    labelType="withQuestion"
                    placeholder="0"
                    minLength="1"
                    maxLength="10"
                    pattern="[0-9,]*"
                    labelFor="childEducation"
                    labelText={localeText.liabilities.child}
                    inputID="childEducation"
                    name="childEducation"
                    value={format(props.data.childEducation)}
                    onChange={handleExpChange}
                    onInput={validateNumber} />
                    {
                        (ceMsg !== "") ? <span className="error-box">{ceMsg}</span> : ""
                    }
                <RangeSlider
                    aria-label={localeText.liabilities.child}
                    mappedRange={true}
                    name="childEducationSlider"
                    id="childEducationSlider"
                    value={mapValueScaleToSliderScale(10000000, props.data.childEducation)}
                    min="0"
                    max="10000000"
                    onChange={handleExpChange} />
            </div>
            <div className={`form-group ${(fuMsg !== "") ? 'error-container' : "" }`}>
                <ItemForm
                    inputType="InputWithSymbol"
                    labelType="withQuestion"
                    placeholder="0"
                    tooltipTitle={localeText.tooltipTitle.title4} 
                    tooltipContent={localeText.tooltipContent.content4} 
                    tooltipLinkTitle={localeText.tooltipLinkTitle.title4}  
                    tooltipLink={localeText.tooltipLinks.link4}
                    minLength="1"
                    maxLength="10"
                    pattern="[0-9,]*"
                    labelFor="funeral"
                    labelText={localeText.liabilities.funeral}
                    inputID="funeral"
                    name="funeral"
                    value={format(props.data.funeral)}
                    onChange={handleExpChange}
                    onInput={validateNumber} />
                    {
                        (fuMsg !== "") ? <span className="error-box">{fuMsg}</span> : ""
                    }
                <RangeSlider
                    aria-label={localeText.liabilities.funeral}
                    mappedRange={true}
                    name="funeralSlider"
                    id="funeralSlider"
                    value={mapValueScaleToSliderScale(10000000, props.data.funeral)}
                    min="0"
                    max="10000000"
                    onChange={handleExpChange} />
            </div>
            <div className={`form-group ${(oeMsg !== "") ? 'error-container' : "" }`}>
                <ItemForm
                    inputType="InputWithSymbol"
                    labelType="withQuestion"
                    placeholder="0"
                    tooltipTitle={localeText.tooltipTitle.title5} 
                    tooltipContent={localeText.tooltipContent.content5}
                    minLength="1"
                    maxLength="10"
                    pattern="[0-9,]*"
                    labelFor="otherExpenses"
                    labelText={localeText.liabilities.otherexp}
                    inputID="otherExpenses"
                    name="otherExpenses"
                    value={format(props.data.otherExpenses)}
                    onChange={handleExpChange}
                    onInput={validateNumber} />
                <RangeSlider
                    aria-label={localeText.liabilities.otherexp}
                    mappedRange={true}
                    name="otherExpensesSlider"
                    id="otherExpensesSlider"
                    value={mapValueScaleToSliderScale(10000000, props.data.otherExpenses)}
                    min="0"
                    max="10000000"
                    onChange={handleExpChange} />
                    {
                        (oeMsg !== "") ? <span className="error-box">{oeMsg}</span> : ""
                    }
            </div>
            </form>
            <div className="col-12 px-0">
                <button className="btn btn-primary mar-btm" onClick={nextScreen}>{localeText.next}</button>
            </div>
            <div className="col-12 px-0">
                <button className="btn btn-transparent" onClick={previousScreen}>{localeText.back}</button>
            </div>
        </div>
        </>
    );
  };
  export default StepLiability;