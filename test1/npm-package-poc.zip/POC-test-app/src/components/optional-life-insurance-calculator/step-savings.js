import React from "react";
import {getLocaleText} from "../services/dictionary";
import ItemForm from "../form-common/itemForm";
import RangeSlider from "../form-common/rangeSlider";
import {validateNumber, format, strip} from "../form-common/calculator-validation";
import {mapSliderScaleToValueScale, mapValueScaleToSliderScale} from "../form-common/slider-validation"; 
// import SetAnalytics from "../services/analytics";
require('./../../styles/scss/form.scss');

const localeText = getLocaleText("optionalLifeInsuranceCalculator");
const StepSavings = (props) => {
    const csMsg = props.data.errors.currentSavings;
    const oiMsg = props.data.errors.otherInvestments;
    const ecMsg = props.data.errors.existingCoverage;

    const handleExpChange = evt => {
        let name = evt.target.name;
        let newValue = evt.target.value;
        let strippedValue = 0;
        let strippedName = "";
        if (name.includes("Slider")) {
            let exponentialValue = mapSliderScaleToValueScale(name, newValue);
            strippedName = name.replace("Slider","");
            strippedValue = exponentialValue;
        } else {
            strippedName = name;
            strippedValue = strip(newValue, global.getSelectedLanguage);
        }
        props.setForm(strippedName,strippedValue)
    }

    const nextScreen = () => {
        if ( csMsg === "" && oiMsg === "" && ecMsg === "" ) {
            // SetAnalytics(localeText.analytics.breadcrumb, localeText.analytics.category,localeText.analytics.subCategory,localeText.analytics.canonicalId,
            //              localeText.analytics.linkZone,localeText.analytics.linkTypeNext,localeText.analytics.linkTitleStep1);
            props.moveStep(1);
        }
    }

    return (
        <>
        <div className="lic-form" id="savings">
            <p className="step-title">{localeText.stepNames[0].title}</p>
            <form className="form-calculator" name="inc-savings" id="inc-savings">
                <div className={`form-group ${(csMsg !== "") ? 'error-container' : "" }`}>
                    <ItemForm
                        type="text"
                        inputType="InputWithSymbol"
                        labelType="false"
                        maxLength="10"
                        pattern="[0-9,]*"
                        placeholder="0"
                        labelFor="currentSavings"
                        labelText={localeText.savings.cs}
                        inputID="currentSavings"
                        name="currentSavings"
                        value={format(props.data.currentSavings)}
                        onChange={handleExpChange}
                        onInput={validateNumber}
                        />
                        {
                            (csMsg !== "") ? <span className="error-box">{csMsg}</span> : ""
                        }
                    <RangeSlider
                        aria-label={localeText.savings.cs}
                        mappedRange={true}
                        name="currentSavingsSlider"
                        id="currentSavingsSlider"
                        value={mapValueScaleToSliderScale(10000000, props.data.currentSavings)}
                        min="0"
                        max="10000000"
                        onChange={handleExpChange} 
                        />
                </div>
                <div className={`form-group ${(oiMsg !== "") ? 'error-container' : "" }`}>
                    <ItemForm
                        type="text"
                        inputType="InputWithSymbol"
                        labelType="withQuestion"
                        tooltipTitle={localeText.tooltipTitle.title1} 
                        tooltipContent={localeText.tooltipContent.content1}
                        maxLength="10" 
                        pattern="[0-9,]*"                        
                        placeholder="0" 
                        labelFor="otherInvestments"
                        labelText={localeText.savings.oi}
                        inputID="otherInvestments"
                        name="otherInvestments"
                        value={format(props.data.otherInvestments)}
                        onChange={handleExpChange} 
                        onInput={validateNumber}
                        />
                        {
                            (oiMsg !== "") ? <span className="error-box">{oiMsg}</span> : ""
                        }
                    <RangeSlider
                        aria-label={localeText.savings.oi}
                        mappedRange={true}
                        name="otherInvestmentsSlider"
                        id="otherInvestmentsSlider"
                        value={mapValueScaleToSliderScale(10000000, props.data.otherInvestments)}
                        min="0"
                        max="10000000"
                        onChange={handleExpChange} 
                        />
                </div>
                <div className={`form-group ${(ecMsg !== "") ? 'error-container' : "" }`}>
                    <ItemForm
                        type="text"
                        inputType="InputWithSymbol"
                        labelType="withQuestion"
                        tooltipTitle={localeText.tooltipTitle.title2} 
                        tooltipContent={localeText.tooltipContent.content2}
                        maxLength="10"
                        pattern="[0-9,]*"
                        placeholder="0"
                        labelFor="existingCoverage"
                        labelText={localeText.savings.elic}
                        inputID="existingCoverage"
                        name="existingCoverage"
                        value={format(props.data.existingCoverage)}
                        onChange={handleExpChange} 
                        onInput={validateNumber}/>
                        {
                            (ecMsg !== "") ? <span className="error-box">{ecMsg}</span> : ""
                        }
                    <RangeSlider
                        aria-label={localeText.savings.elic}
                        mappedRange={true}
                        name="existingCoverageSlider"
                        id="existingCoverageSlider"
                        value={mapValueScaleToSliderScale(10000000, props.data.existingCoverage)}
                        min="0"
                        max="10000000"
                        onChange={handleExpChange} 
                        />
                </div>
            </form>
            <div className="col-12 px-0">
                <button type="button" className="btn-primary" onClick={nextScreen}>{localeText.next}</button>
            </div>
        </div>
        </>
    );
};
export default StepSavings;