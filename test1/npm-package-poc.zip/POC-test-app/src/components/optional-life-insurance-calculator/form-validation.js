import {getLocaleText} from "../services/dictionary";
const validateFormData = (formData) => {
    let newFormData = {...formData};
    const Names = Object.keys(formData.errors);
    const localeText = getLocaleText("errorMessages");
    Names.forEach((item) => {
        if(newFormData[item] > 10000000) {
            newFormData.errors[item] = localeText.tenMillion
        }
        else {
            newFormData.errors[item] = ""
        }
    });
    //Annually
    if((newFormData.currentIncome > 2000000 || newFormData.currentIncome < 1) && Number(newFormData.currentIncomeFreq) === 1) {
        newFormData.errors.currentIncome = localeText.annually2
    }
    //Monthly
    else if((newFormData.currentIncome > 200000 || newFormData.currentIncome < 1) && Number(newFormData.currentIncomeFreq) === 12) {
        newFormData.errors.currentIncome = localeText.monthly2
    //Biweekly
    } else if((newFormData.currentIncome > 100000 || newFormData.currentIncome < 1) && Number(newFormData.currentIncomeFreq) === 26) {
        newFormData.errors.currentIncome = localeText.biweekly2
    //Weekly
    } else if((newFormData.currentIncome > 50000 || newFormData.currentIncome < 1) && Number(newFormData.currentIncomeFreq) === 52) {
        newFormData.errors.currentIncome = localeText.weekly2
    } 
    else {
        newFormData.errors.currentIncome = ""
    }
    //Desired Income
    if(newFormData.desiredIncome > 200 || newFormData.desiredIncome < 1) {
        newFormData.errors.desiredIncome = localeText.desiredIncome
    } else {
        newFormData.errors.desiredIncome = ""
    }
    //Income Income
    if(newFormData.incomeDuration > 50 || newFormData.incomeDuration < 1) {
        newFormData.errors.incomeDuration = localeText.incomeDuration
    } else {
        newFormData.errors.incomeDuration = ""
    }

    return newFormData;
}
export {validateFormData};