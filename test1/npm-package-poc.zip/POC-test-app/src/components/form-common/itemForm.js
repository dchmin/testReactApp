import React from "react";
import { useState } from "react";
import ToolTipBox from "./tooltip";
import { getLocaleText } from "../services/dictionary";
const localeText = getLocaleText("optionalLifeInsuranceCalculator");
const localeTextResp = getLocaleText("respCalculator");
require('./../../styles/scss/form.scss');

const ItemForm = ({ hasDropDown="false", labelType, labelFor, labelText, inputType, tooltipTitle, tooltipContent, tooltipLinkTitle, tooltipLink, inputID, children, type = "text", dropDownList, ...otherProps }) => { 
  return (
    <>
      {(() => {
        switch (inputType) {
          case "InputWithSymbol":
            return (
              <>
                <label htmlFor={labelFor}>{labelText}</label>
                {labelType === "withQuestion" ?
                  <>
                  <ToolTipBox tooltipTitle={tooltipTitle} tooltipContent={tooltipContent} tooltipLinkTitle={tooltipLinkTitle} tooltipLink={tooltipLink} />
                  </>
                  : null}
                  {hasDropDown === "true" ?
                    <span className="symbol">
                      <input id={inputID} type={type} {...otherProps} />
                    </span>
                    :
                    <div className="wrapper">
                      <span className="symbol">
                        <input id={inputID} type={type} {...otherProps} />
                      </span>
                    </div> 
                }
              </>
            )
            case "InputWithOutLabel":
              return (
                <>
                  <span className="symbol">
                    <input id={inputID} type={type} {...otherProps} />
                  </span>
                </>
              )
          case "InputWithoutSymbol":
            return (
              <>
                <label htmlFor={labelFor}>{labelText} {labelType === "withQuestion" ? <span className="fa fa-question-circle question"></span> : ""}</label>
                <div className="wrapper">
                  <span className="withoutSymbol">
                    <input id={inputID} type={type} {...otherProps} />
                  </span>
                </div>
              </>
            )
          case "InputWithPercentile":
            return (
              <>
                <span className="input-percentage">
                  <input id={inputID} type={type} {...otherProps} />
                </span>
              </>
            )
          case "InputWithyears":
            return (
              <>
                <span className="input-year">
                  <input id={inputID} type={type} {...otherProps} />
                </span>
              </>
            )
          case "InputWithSymbolnDropdown":
            return (
              <>
                <label htmlFor={labelFor}>{labelText} {labelType === "withQuestion" ? <span className="fa fa-question-circle question"></span> : ""} </label>
                <div className="wrapper">
                  <span className="symbol symbolwidth">
                    <input id={inputID} type={type} {...otherProps} />
                  </span>
                </div>
              </>
            )
          case "InputBlank":
            return (
              <>
                <span className="input-blank">
                  <input id={inputID} type={type} {...otherProps} />
                </span>
              </>
            )
          case "InputWitDropdown":
            return (
              <>
                <label htmlFor={labelFor}>{labelText} {labelType === "withQuestion" ? <span className="fa fa-question-circle question"></span> : ""} </label>
                <div className="wrapper school-dropdown">
                  <select className={`period ${otherProps.value == "" ? "placeholder-text": ""}`} value={otherProps.value} id={inputID} onChange={otherProps.onChange}>
                    <option className="choose" value={localeTextResp.choose} >{localeTextResp.choose}</option>
                    {dropDownList.map(e => {
                      return <option value={e.data} key={e.value}>{e.value}</option>
                    })}
                  </select>
                </div>
              </>
            )
          case "InputWitRadioButton":
              return (
                <>
                  <label htmlFor={labelFor}>{labelText}</label>
                    {labelType === "withQuestion" ?
                    <>
                      <ToolTipBox tooltipTitle={tooltipTitle} tooltipContent={tooltipContent} />
                    </>
                    : null}
                    <div className="wrapper">
                      <div className={`radio-btn-college ${otherProps.value ? "radio-btn-selected" : ""}`} >
                        <input id={localeTextResp.costOfEducation.college} checked={otherProps.value} type="radio" value="college" onChange={otherProps.onChange}  name="schoolType"/>
                        <label className="college" htmlFor={localeTextResp.costOfEducation.college}>{localeTextResp.costOfEducation.college}</label>
                      </div>
                      <div className={`radio-btn-university ${!otherProps.value ? "radio-btn-selected" : ""}`}>
                        <input id={localeTextResp.costOfEducation.university} checked={!otherProps.value} type="radio" value="university" onChange={otherProps.onChange} name="schoolType"/>
                        <label className="university" htmlFor={localeTextResp.costOfEducation.university}>{localeTextResp.costOfEducation.university}</label>
                      </div>
                    </div>
                </>
              )
        }
      })()
      }
    </>
  )
}

export default ItemForm;