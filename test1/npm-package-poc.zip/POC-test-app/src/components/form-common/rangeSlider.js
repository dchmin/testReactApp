import React from "react";
import {mapMaxValueToSliderMaxInterval} from "../form-common/slider-validation"
require('./../../styles/scss/form.scss');

const RangeSlider = ({type="range", mappedRange=false, min = "0", max="10000000", ariaLabel, value, typeName, ...otherProps}) => {
    if (mappedRange === true) {
        let maxInterval = mapMaxValueToSliderMaxInterval(Number(max));
        return (
            <>
                <div className="sliderContainer">
                    <input
                        type={type}
                        value={value}
                        min={min}
                        max={maxInterval}
                        step={1}
                        name={typeName}
                        aria-label={ariaLabel}
                        {...otherProps} />
                </div>
            </>
        )
    } else {
        return (
            <>
                <div className="sliderContainer">
                    <input
                        type={type}
                        value={value}
                        min={min}
                        max={max}
                        name={typeName}
                        aria-label={ariaLabel}
                        {...otherProps} />
                </div>
            </>
        )
    }
}
export default RangeSlider