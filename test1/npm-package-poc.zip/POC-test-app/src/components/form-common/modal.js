import React from "react";
import { getLocaleText } from "../services/dictionary";
import { Modal } from "react-bootstrap";

require('./../../styles/scss/modal.scss');

const localeText = getLocaleText("optionalLifeInsuranceCalculator");

const ArticleModal = ({ showModal, handleModalShow, ModalTitle, ModalContent, isHtmlContent, isFooterAvailable, ModalFooterRegister, ModalFooterSignin, isBodyContent, handleNavigation }) => {

  const handleClose = () => {
    handleModalShow();
  };
  
  let modalBody;
  if (isHtmlContent) {
    // HTML Content
  } else if (isBodyContent) {
   
  } else {
    modalBody = 
    <Modal.Body className="gb-coaching-modal-body-list">
      <ul>
        {ModalContent.map((item, i) => {
          return <li key={i}>{item}</li>
        })}
      </ul>
    </Modal.Body>
  }

  let modalFooter;
  if(isFooterAvailable) {
    //footer content
  }
  return (
    <>
      <Modal className="gb-coaching-modal" centered show={showModal} onHide={handleClose}>
        <Modal.Header className="gb-coaching-modal-header" closeButton closeLabel={localeText.close}>
          <Modal.Title className="gb-coaching-modal-title">{ModalTitle}</Modal.Title>
        </Modal.Header>
        {modalBody}
        {modalFooter}
      </Modal>
    </>
  );
}

export default ArticleModal;