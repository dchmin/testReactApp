import React, {useState, useRef} from "react";
import {Popover, OverlayTrigger} from "react-bootstrap";
import { getLocaleText } from "../services/dictionary";
const localeText = getLocaleText("optionalLifeInsuranceCalculator");
require('./../../styles/scss/popover.scss');
const ToolTipBox = ({ tooltipTitle, tooltipContent, tooltipLinkTitle, tooltipLink }) => {
  const [flag, setflag] = useState(false);
  const target = useRef(null);
  if(flag === true) {
    setTimeout(() => {
      target.current.focus()
    }, 500);
  }
  const overlay = (
        <Popover
          aria-hidden={(flag) ? "false" : "true"}
          role="tooltip"
          tabIndex="0"
          className="popover"
          id={tooltipTitle.replace(/\s/g, '')}
          >

          <Popover.Title className="popover-title">
            {tooltipTitle}
          </Popover.Title>

          <Popover.Content className="popover-content">
            <p> {tooltipContent} </p>
            <p className="popover-a">
              {(tooltipLinkTitle) !== "" ? <a href={tooltipLink} target="_blank">{tooltipLinkTitle}</a> : ""}
            </p>
            <span aria-label={localeText.close} className="popover-close">
              <span
                className="fa fa-close"
                role="button"
                tabIndex="0"
                ref={target}
                onClick={(e) => {e.preventDefault();document.body.click();setflag(false);}}
                onKeyPress={(e) => {e.preventDefault();setflag(false);document.body.click()}}
                ></span>
            </span>
          </Popover.Content>
        </Popover>
  )
    return (
      <OverlayTrigger 
        rootClose={true}
        trigger="click"
        placement="top"
        overlay= {overlay}>
        <button
          aria-controls={tooltipTitle.replace(/\s/g, '')}
          aria-expanded={(flag) ? "true" : "false"}
          aria-haspopup="true"
          className="fa fa-question-circle question"
          onClick={(e) => {e.preventDefault();setflag(true)}}
          onKeyUp={(event) => {
              if(event.key === "Space" || event.key === "Enter") {
                setflag(true)
              }
            }
          }
          suppressContentEditableWarning={true}
          >
            <span className="sr-only">{`${localeText.moreInfo} ${tooltipTitle}`}</span>
          </button>
      </OverlayTrigger>
    );
}

export default ToolTipBox;