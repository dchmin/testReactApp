/**
 * Library for rangeSlider operations
 */
const FIVE = 5;
const TEN = 10;
const TWENTY_FIVE = 25;
const FIFTY = 50;
const ONE_HUNDRED = 100;
const ONE_HUNDRED_FIFTY = 150;
const TWO_HUNDRED_FIFTY = 250;
const FIVE_HUNDRED = 500;
const ONE_THOUSAND = 1000;
const ONE_THOUSAND_FIVE_HUNDRED = 1500;
const TWO_THOUSAND_FIVE_HUNDRED = 2500;
const FIVE_THOUSAND = 5000;
const TEN_THOUSAND = 10000;
const FIFTY_THOUSAND = 50000;
const ONE_HUNDRED_THOUSAND = 100000;
const TWO_HUNDRED_THOUSAND = 200000;
const FIVE_HUNDRED_THOUSAND = 500000;
const ONE_MILLION = 1000000;
const TEN_MILLION = 10000000;

const STEPS_TO_1_5K = 46;
const STEPS_TO_2_5K = 69;
const STEPS_TO_5_K = 65;
const STEPS_TO_50_K = 36;
const STEPS_TO_100_K = 38;
const STEPS_TO_200_K = 48;
const STEPS_TO_1_MIL = 74;
const STEPS_TO_10_MIL = 92;

/* External Generic Mapping Functions */

/**
 * Generic function to map the current slider interval value to the correct mapping scale/value
 * based on the .max attribute of the slider
 * @param {String} name 
 * @param {int} value 
 */
const mapSliderScaleToValueScale = (name, value) => {
    let exponentialValue = 0;
    let maxInterval = eval(name+".max");
    let maxValue = mapSliderMaxIntervalToMaxValue(maxInterval);
    switch (maxValue) {
        case TEN_MILLION:
            exponentialValue = map10MSliderToValue(value);
            break;
        case ONE_MILLION:
            exponentialValue = map1MSliderToValue(value);
            break;
        case TWO_HUNDRED_THOUSAND:
            exponentialValue = map200KSliderToValue(value);
            break;
        case ONE_HUNDRED_THOUSAND:
            exponentialValue = map100KSliderToValue(value);
            break;
        case FIFTY_THOUSAND:
            exponentialValue = map50KSliderToValue(value);
            break;
        case FIVE_THOUSAND:
            exponentialValue = map5KSliderToValue(value);
            break;
        case TWO_THOUSAND_FIVE_HUNDRED:
            exponentialValue = map2_5KSliderToValue(value);
            break;
        case ONE_THOUSAND_FIVE_HUNDRED:
            exponentialValue = map1_5KSliderToValue(value);
            break;
    }
    return exponentialValue;
}

/**
 * Generic function to map the current value according to the correct slider interval value based on the max value
 * @param {int} maxValue 
 * @param {int} value 
 */
const mapValueScaleToSliderScale = (maxValue, value) => {
    let exponentialValue = 0;
    switch (Number(maxValue)) {
        case TEN_MILLION:
            exponentialValue = map10MValueToSlider(value);
            break;
        case ONE_MILLION:
            exponentialValue = map1MValueToSlider(value);
            break;
        case TWO_HUNDRED_THOUSAND:
            exponentialValue = map200KValueToSlider(value);
            break;
        case ONE_HUNDRED_THOUSAND:
            exponentialValue = map100KValueToSlider(value);
            break;
        case FIFTY_THOUSAND:
            exponentialValue = map50KValueToSlider(value);
            break;
        case FIVE_THOUSAND:
            exponentialValue = map5KValueToSlider(value);
            break;
        case TWO_THOUSAND_FIVE_HUNDRED:
            exponentialValue = map2_5KValueToSlider(value);
            break;
        case ONE_THOUSAND_FIVE_HUNDRED:
            exponentialValue = map1_5KValueToSlider(value);
            break;
    }
    return exponentialValue;
}

/* Max value/interval mapper functions */

/**
 * Maps the max value to the correct amount of intervals for the slider mapping
 * @param {int} max 
 */
const mapMaxValueToSliderMaxInterval = (max) => {
        // Use defined constant for specific interval range
        // Supports scaling mappings listed below
        let maxInterval = 0;
        switch(Number(max)) {
            case TEN_MILLION:
                maxInterval = STEPS_TO_10_MIL;
                break;
            case ONE_MILLION:
                maxInterval = STEPS_TO_1_MIL;
                break;
            case TWO_HUNDRED_THOUSAND:
                maxInterval = STEPS_TO_200_K;
                break;
            case ONE_HUNDRED_THOUSAND:
                maxInterval = STEPS_TO_100_K;
                break;
            case FIFTY_THOUSAND:
                maxInterval = STEPS_TO_50_K;
                break;
            case FIVE_THOUSAND:
                maxInterval = STEPS_TO_5_K;
                break;
            case TWO_THOUSAND_FIVE_HUNDRED:
                maxInterval = STEPS_TO_2_5K;
                break;
            case ONE_THOUSAND_FIVE_HUNDRED:
                maxInterval = STEPS_TO_1_5K;
                break;
            default:
                maxInterval = Number(max);
                break;
        }
        return maxInterval;
}

/**
 * Maps the mapped slider max interval back to max value
 * @param {int} interval 
 */
const mapSliderMaxIntervalToMaxValue = (interval) => {
    let maxValue = 0;
    switch(Number(interval)) {
        case STEPS_TO_10_MIL:
            maxValue = TEN_MILLION;
            break;
        case STEPS_TO_1_MIL:
            maxValue = ONE_MILLION;
            break;
        case STEPS_TO_200_K:
            maxValue = TWO_HUNDRED_THOUSAND;
            break;
        case STEPS_TO_100_K:
            maxValue = ONE_HUNDRED_THOUSAND;
            break;
        case STEPS_TO_50_K:
            maxValue = FIFTY_THOUSAND;
            break;
        case STEPS_TO_5_K:
            maxValue = FIVE_THOUSAND;
            break;
        case STEPS_TO_2_5K:
            maxValue = TWO_THOUSAND_FIVE_HUNDRED;
            break;
        case STEPS_TO_1_5K:
            maxValue = ONE_THOUSAND_FIVE_HUNDRED;
            break;
        default:
            maxValue = Number(interval);
            break;
    }
    return maxValue;
}

/**
 * Maps the 4 allowed frequency values (weekly, bi-weekly, monthly, annually) 
 * to the max slider value allowed
 * @param {int} freq 
 */
const mapDropdownFrequencyToMaxValue = (freq) => {
    switch (Number(freq)) {
        case 52:
            return ONE_THOUSAND_FIVE_HUNDRED;
        case 26:
            return TWO_THOUSAND_FIVE_HUNDRED;
        case 12:
            return FIVE_THOUSAND;
        case 1:
            return FIFTY_THOUSAND;
        default:
            return 0;
    }
}

/**
 * Maps using correct value scale based on the current dropdown frequency
 * @param {int} freq 
 * @param {int} currentValue 
 */
const mapDropdownValueToSlider = (freq, currentValue) => {
    return mapValueScaleToSliderScale(mapDropdownFrequencyToMaxValue(freq), currentValue);
}

/** Internal Value Mapping Functions **/

/** 1.5K max range functions **/

/**
 * Logic to map the slider value to the correct display value interval
 * Max value interval is equivalent to 46
 * @param {int} stepValue 
 */
const map1_5KSliderToValue = (stepValue) => {
    let mappedValue = 0;
    switch(true) {
        case stepValue >= 0 && stepValue < 10:
            mappedValue = stepValue*FIVE;
            break;
        case stepValue >= 10 && stepValue < 15:
            mappedValue = FIFTY+((stepValue-10)*TEN);
            break;
        case stepValue >= 15 && stepValue < 21:
            mappedValue = ONE_HUNDRED+((stepValue-15)*TWENTY_FIVE);
            break;
        case stepValue >= 21 && stepValue < 46:
            mappedValue = TWO_HUNDRED_FIFTY+((stepValue-21)*FIFTY);
            break;
        case stepValue >= 46:
            mappedValue = ONE_THOUSAND_FIVE_HUNDRED;
            break;
    }
    return mappedValue;
}

/**
 * Logic to map the display value to the corresponding slider value
 * Max value interval is ONE_THOUSAND_FIVE_HUNDRED
 * @param {int} value 
 */
const map1_5KValueToSlider = (value) => {
    let mappedValue = 0;
    switch(true) {
        case value >= 0 && value < FIFTY:
            mappedValue = Math.floor(value/FIVE);
            break;
        case value >= FIFTY && value < ONE_HUNDRED:
            mappedValue = Math.floor((value-FIFTY)/TEN)+10;
            break;
        case value >= ONE_HUNDRED && value < TWO_HUNDRED_FIFTY:
            mappedValue = Math.floor((value-ONE_HUNDRED)/TWENTY_FIVE)+15;
            break;
        case value >= TWO_HUNDRED_FIFTY && value < ONE_THOUSAND_FIVE_HUNDRED:
            mappedValue = Math.floor((value-TWO_HUNDRED_FIFTY)/FIFTY)+21;
            break;
        case value >= ONE_THOUSAND_FIVE_HUNDRED:
            mappedValue = 46;
            break;
    }
    return mappedValue;
}

/** 2.5K max range functions **/

/**
 * Logic to map the slider value to the correct display value interval
 * Max value interval is equivalent to 69
 * @param {int} stepValue 
 */
const map2_5KSliderToValue = (stepValue) => {
    let mappedValue = 0;
    switch(true) {
        case stepValue >= 0 && stepValue < 15:
            mappedValue = stepValue*TEN;
            break;
        case stepValue >= 15 && stepValue < 29:
            mappedValue = ONE_HUNDRED_FIFTY+((stepValue-15)*TWENTY_FIVE);
            break;
        case stepValue >= 29 && stepValue < 69:
            mappedValue = FIVE_HUNDRED+((stepValue-29)*FIFTY);
            break;
        case stepValue >= 69:
            mappedValue = TWO_THOUSAND_FIVE_HUNDRED;
            break;
    }
    return mappedValue;
}

/**
 * Logic to map the display value to the corresponding slider value
 * Max value interval is TWO_THOUSAND_FIVE_HUNDRED
 * @param {int} value 
 */
const map2_5KValueToSlider = (value) => {
    let mappedValue = 0;
    switch(true) {
        case value >= 0 && value < ONE_HUNDRED_FIFTY:
            mappedValue = Math.floor(value/TEN);
            break;
        case value >= ONE_HUNDRED_FIFTY && value < FIVE_HUNDRED:
            mappedValue = Math.floor((value-ONE_HUNDRED_FIFTY)/TWENTY_FIVE)+15;
            break;
        case value >= FIVE_HUNDRED && value < TWO_THOUSAND_FIVE_HUNDRED:
            mappedValue = Math.floor((value-FIVE_HUNDRED)/FIFTY)+29;
            break;
        case value >= TWO_THOUSAND_FIVE_HUNDRED:
            mappedValue = 69;
            break;
    }
    return mappedValue;
}

/** 5K max range functions **/

/**
 * Logic to map the slider value to the correct display value interval
 * Max value interval is equivalent to 65
 * @param {int} stepValue 
 */
const map5KSliderToValue = (stepValue) => {
    let mappedValue = 0;
    switch(true) {
        case stepValue >= 0 && stepValue < 10:
            mappedValue = stepValue*TWENTY_FIVE;
            break;
        case stepValue >= 10 && stepValue < 25:
            mappedValue = TWO_HUNDRED_FIFTY+((stepValue-10)*FIFTY);
            break;
        case stepValue >= 25 && stepValue < 65:
            mappedValue = ONE_THOUSAND+((stepValue-25)*ONE_HUNDRED);
            break;
        case stepValue >= 65:
            mappedValue = FIVE_THOUSAND;
            break;
    }
    return mappedValue;
}

/**
 * Logic to map the display value to the corresponding slider value
 * Max value interval is FIVE_THOUSAND
 * @param {int} value 
 */
const map5KValueToSlider = (value) => {
    let mappedValue = 0;
    switch(true) {
        case value >= 0 && value < TWO_HUNDRED_FIFTY:
            mappedValue = Math.floor(value/TWENTY_FIVE);
            break;
        case value >= TWO_HUNDRED_FIFTY && value < ONE_THOUSAND:
            mappedValue = Math.floor((value-TWO_HUNDRED_FIFTY)/FIFTY)+10;
            break;
        case value >= ONE_THOUSAND && value < FIVE_THOUSAND:
            mappedValue = Math.floor((value-ONE_THOUSAND)/ONE_HUNDRED)+25;
            break;
        case value >= FIVE_THOUSAND:
            mappedValue = 65;
            break;
    }
    return mappedValue;
}

/** 50K max range functions **/

/**
 * Logic to map the slider value to the correct display value interval
 * Max value interval is equivalent to 36
 * @param {int} stepValue 
 */
const map50KSliderToValue = (stepValue) => {
    let mappedValue = 0;
    switch(true) {
        case stepValue >= 0 && stepValue < 20:
            mappedValue = stepValue*FIVE_HUNDRED;
            break;
        case stepValue >= 20 && stepValue < 36:
            mappedValue = TEN_THOUSAND+((stepValue-20)*TWO_THOUSAND_FIVE_HUNDRED);
            break;
        case stepValue >= 36:
            mappedValue = FIFTY_THOUSAND;
            break;
    }
    return mappedValue;
}

/**
 * Logic to map the display value to the corresponding slider value
 * Max value interval is FIFTY_THOUSAND
 * @param {int} value 
 */
const map50KValueToSlider = (value) => {
    let mappedValue = 0;
    switch(true) {
        case value >= 0 && value < TEN_THOUSAND:
            mappedValue = Math.floor(value/FIVE_HUNDRED);
            break;
        case value >= TEN_THOUSAND && value < FIFTY_THOUSAND:
            mappedValue = Math.floor((value-TEN_THOUSAND)/TWO_THOUSAND_FIVE_HUNDRED)+20;
            break;
        case value >= FIFTY_THOUSAND:
            mappedValue = 36;
            break;
    }
    return mappedValue;
}

/** 100K max range functions **/

/**
 * Logic to map the slider value to the correct display value interval
 * Max value interval is equivalent to 38
 * @param {int} stepValue 
 */
const map100KSliderToValue = (stepValue) => {
    let mappedValue = 0;
    switch(true) {
        case stepValue >= 0 && stepValue < 20:
            mappedValue = stepValue*FIVE_HUNDRED;
            break;
        case stepValue >= 20 && stepValue < 38:
            mappedValue = TEN_THOUSAND+((stepValue-20)*FIVE_THOUSAND);
            break;
        case stepValue >= 38:
            mappedValue = ONE_HUNDRED_THOUSAND;
            break;
    }
    return mappedValue;
}

/**
 * Logic to map the display value to the corresponding slider value
 * Max value interval is ONE_HUNDRED_THOUSAND
 * @param {int} value 
 */
const map100KValueToSlider = (value) => {
    let mappedValue = 0;
    switch(true) {
        case value >= 0 && value < TEN_THOUSAND:
            mappedValue = Math.floor(value/FIVE_HUNDRED);
            break;
        case value >= TEN_THOUSAND && value < ONE_HUNDRED_THOUSAND:
            mappedValue = Math.floor((value-TEN_THOUSAND)/FIVE_THOUSAND)+20;
            break;
        case value >= ONE_HUNDRED_THOUSAND:
            mappedValue = 38;
            break;
    }
    return mappedValue;
}

/** 200K max range functions **/

/**
 * Logic to map the slider value to the correct display value interval
 * Max value interval is equivalent to 48
 * @param {int} stepValue 
 */
const map200KSliderToValue = (stepValue) => {
    let mappedValue = 0;
    switch(true) {
        case stepValue >= 0 && stepValue < 20:
            mappedValue = stepValue*FIVE_HUNDRED;
            break;
        case stepValue >= 20 && stepValue < 38:
            mappedValue = TEN_THOUSAND+((stepValue-20)*FIVE_THOUSAND);
            break;
        case stepValue >= 38 && stepValue < 48:
            mappedValue = ONE_HUNDRED_THOUSAND+((stepValue-38)*TEN_THOUSAND);
            break;
        case stepValue >= 48:
            mappedValue = TWO_HUNDRED_THOUSAND;
            break;
    }
    return mappedValue;
}

/**
 * Logic to map the display value to the corresponding slider value
 * Max value interval is TWO_HUNDRED_THOUSAND
 * @param {int} value 
 */
const map200KValueToSlider = (value) => {
    let mappedValue = 0;
    switch(true) {
        case value >= 0 && value < TEN_THOUSAND:
            mappedValue = Math.floor(value/FIVE_HUNDRED);
            break;
        case value >= TEN_THOUSAND && value < ONE_HUNDRED_THOUSAND:
            mappedValue = Math.floor((value-TEN_THOUSAND)/FIVE_THOUSAND)+20;
            break;
        case value >= ONE_HUNDRED_THOUSAND && value < TWO_HUNDRED_THOUSAND:
            mappedValue = Math.floor((value-ONE_HUNDRED_THOUSAND)/TEN_THOUSAND)+38;
            break;
        case value >= TWO_HUNDRED_THOUSAND:
            mappedValue = 48;
            break;
    }
    return mappedValue;
}

/** 1 million max range functions **/

/**
 * Logic to map the slider value to the correct display value interval
 * Max value interval is equivalent to 74
 * @param {int} stepValue 
 */
const map1MSliderToValue = (stepValue) => {
    let mappedValue = 0;
    switch(true) {
        case stepValue >= 0 && stepValue < 20:
            mappedValue = stepValue*FIFTY;
            break;
        case stepValue >= 20 && stepValue < 38:
            mappedValue = ONE_THOUSAND+((stepValue-20)*FIVE_HUNDRED);
            break;
        case stepValue >= 38 && stepValue < 56:
            mappedValue = TEN_THOUSAND+((stepValue-38)*FIVE_THOUSAND);
            break;
        case stepValue >= 56 && stepValue < 74:
            mappedValue = ONE_HUNDRED_THOUSAND+((stepValue-56)*FIFTY_THOUSAND);
            break;
        case stepValue >= 74:
            mappedValue = ONE_MILLION;
            break;
    }
    return mappedValue;
}

/**
 * Logic to map the display value to the corresponding slider value
 * Max value interval is ONE_MILLION
 * @param {int} value 
 */
const map1MValueToSlider = (value) => {
    let mappedValue = 0;
    switch(true) {
        case value >= 0 && value < ONE_THOUSAND:
            mappedValue = Math.floor(value/FIFTY);
            break;
        case value >= ONE_THOUSAND && value < TEN_THOUSAND:
            mappedValue = Math.floor((value-ONE_THOUSAND)/FIVE_HUNDRED)+20;
            break;
        case value >= TEN_THOUSAND && value < ONE_HUNDRED_THOUSAND:
            mappedValue = Math.floor((value-TEN_THOUSAND)/FIVE_THOUSAND)+38;
            break;
        case value >= ONE_HUNDRED_THOUSAND && value < ONE_MILLION:
            mappedValue = Math.floor((value-ONE_HUNDRED_THOUSAND)/FIFTY_THOUSAND)+56;
            break;
        case value >= ONE_MILLION:
            mappedValue = 74;
            break;
    }
    return mappedValue;
}

/** 10 million max range functions **/

/**
 * Logic to map the slider value to the correct display value interval
 * Max value interval is equivalent to 92
 * @param {int} stepValue 
 */
const map10MSliderToValue = (stepValue) => {
    let mappedValue = 0;
    switch(true) {
        case stepValue >= 0 && stepValue < 20:
            mappedValue = stepValue*FIFTY;
            break;
        case stepValue >= 20 && stepValue < 38:
            mappedValue = ONE_THOUSAND+((stepValue-20)*FIVE_HUNDRED);
            break;
        case stepValue >= 38 && stepValue < 56:
            mappedValue = TEN_THOUSAND+((stepValue-38)*FIVE_THOUSAND);
            break;
        case stepValue >= 56 && stepValue < 74:
            mappedValue = ONE_HUNDRED_THOUSAND+((stepValue-56)*FIFTY_THOUSAND);
            break;
        case stepValue >= 74 && stepValue < 92:
            mappedValue = ONE_MILLION+((stepValue-74)*FIVE_HUNDRED_THOUSAND);
            break;
        case stepValue >= 92:
            mappedValue = TEN_MILLION;
            break;
    }
    return mappedValue;
}

/**
 * Logic to map the display value to the corresponding slider value
 * Max value interval is TEN_MILLION
 * @param {int} value 
 */
const map10MValueToSlider = (value) => {
    let mappedValue = 0;
    switch(true) {
        case value >= 0 && value < ONE_THOUSAND:
            mappedValue = Math.floor(value/FIFTY);
            break;
        case value >= ONE_THOUSAND && value < TEN_THOUSAND:
            mappedValue = Math.floor((value-ONE_THOUSAND)/FIVE_HUNDRED)+20;
            break;
        case value >= TEN_THOUSAND && value < ONE_HUNDRED_THOUSAND:
            mappedValue = Math.floor((value-TEN_THOUSAND)/FIVE_THOUSAND)+38;
            break;
        case value >= ONE_HUNDRED_THOUSAND && value < ONE_MILLION:
            mappedValue = Math.floor((value-ONE_HUNDRED_THOUSAND)/FIFTY_THOUSAND)+56;
            break;
        case value >= ONE_MILLION && value < TEN_MILLION:
            mappedValue = Math.floor((value-ONE_MILLION)/FIVE_HUNDRED_THOUSAND)+74;
            break;
        case value >= TEN_MILLION:
            mappedValue = 92;
            break;
    }
    return mappedValue;
}

export {mapMaxValueToSliderMaxInterval, mapSliderScaleToValueScale, mapDropdownFrequencyToMaxValue, mapDropdownValueToSlider, mapValueScaleToSliderScale}