const validateNumber = event => {
    var lang = global.getSelectedLanguage;
    // if invalid - remove last character
    if(!event.target.validity.valid){
        if(lang == "fr-CA")
        {
            var number = event.target.value.replace(/\s/g, '');
            if(isNaN(number))
            {
                // if it's not a number, remove last character
                event.target.value = event.target.value.slice(0, -1);
            }
            else
            {
                event.target.value = number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
            }
        }
        else
        {
            // Logic for English
            event.target.value = event.target.value.slice(0, -1);
        }
    }
    else{
        var number;
        if(lang == 'en') {
            if(!isNaN(parseFloat(event.target.value.replace(/,/g, '')))){
                number = parseFloat(event.target.value.replace(/,/g, ''));
            }
                
        } else if(lang == "fr-CA") {
            if(!isNaN(parseFloat(event.target.value.replace(/\s/g, '')))) {
                number = parseFloat(event.target.value.replace(/\s/g, ''))
            }
        }
        if(lang == "en" && number != undefined){
            event.target.value = number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
        else if(lang == "fr-CA" && number != undefined){
            event.target.value = number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        }
    }
};

const format = (inputValue, dollarFlag = false) => {
    let formattedValue = "";
    if(lang == "en"){
        formattedValue = inputValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    else
    {
        formattedValue = inputValue.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    }
    if (dollarFlag) {
        formattedValue = (lang === "en") ? "$" + formattedValue : formattedValue + " $";
    }
    
    return formattedValue;
}

const rateOfReturnFormat = (inputValue) => {
    let formattedValue = "";
    var numberOfDots = 0;

    if(inputValue.length == 2)
    {
        if(inputValue[0] == "0" && Number(inputValue[1]) > 0 )
        {
            inputValue = inputValue.substring(1);
        }
        else if(inputValue[0] == "0" && Number(inputValue[1]) == "0" )
        {
            inputValue = inputValue.substring(1);
        }
    }

    if(lang == "en"){
        formattedValue = inputValue.toString().replace(",", "");
        if(formattedValue != "")
        {
            var currentValue = formattedValue.match(/\./g);
            if(currentValue != null)
            {
                numberOfDots = formattedValue.match(/\./g).length;
            }
        }
    }
    else
    {
        formattedValue = inputValue.toString().replace(".", ",");
        if(formattedValue != "")
        {
            var currentValue = formattedValue.match(/\,/g);
            if(currentValue != null)
            {
                numberOfDots = formattedValue.match(/\,/g).length;
            }
        }
    }

    // if there is 2 dots and 2 commas, remove it
    if(numberOfDots > 1)
    {
        formattedValue = formattedValue.slice(0, -1);
    }
    
    return formattedValue;
}

const strip = (inputValue, lang) => {
    let strippedValue = "";
    if(lang == "en"){
        // if it has a comma remove it. This value will be used in the slider
        if(!isNaN(parseFloat(inputValue.replace(/,/g, '')))){
            strippedValue = inputValue.replace(/,/g, '');
        }
    }
    else
    {
        if(!isNaN(parseFloat(inputValue.replace(/\s/g, '')))){
            strippedValue = inputValue.replace(/\s/g, '');
        }
    }
    strippedValue = (strippedValue == "") ? 0 : strippedValue;
    return strippedValue;
}

export {validateNumber, format, strip, rateOfReturnFormat};
