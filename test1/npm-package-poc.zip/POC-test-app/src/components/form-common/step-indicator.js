import React from "react";
import {getLocaleText} from "../services/dictionary";
require("../../styles/scss/step-wizard.scss");

const stepWizard = (props) => {
    const id = props.stepID
    const ts = props.data.totalSteps
    const localeText = getLocaleText(props.data.calcType);
    const calcType = props.data.calcType;
    return(
        <>
         <p className="calc-title">{ id === 3 ?
                    (calcType === "optionalLifeInsuranceCalculator" && localeText.result.res) 
                    : localeText.title }</p>
        {id !== 3 && <>
            <ul className="step-wizard">
                {localeText.stepNames.map((items, i) => {
                    return (
                        <li key={i} id={`${items.id}`}>
                            <span className={`${(id === i)?"step-indicator current":""} ${(id !== i)?"step-indicator":""} ${(id > i)?"completed":""}`}>
                                <span className="sr-only">step {i+1}</span>
                            </span>
                            {(id === i) ? <strong className="step-name">{items.text}</strong> : <span className="step-name">{items.text}</span>}
                        </li>
                    );
                })}
            </ul>
            <div className="step-number-mobile">
                <p>{localeText.step} {id+1} {localeText.stepof} {ts} : {localeText.stepNames[id].text}</p>
            </div>
        </>
        }
        </>
    )
}

export default stepWizard;