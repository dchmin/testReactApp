package ca.sunlife.appdev.metric;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class WebAppsGradleController {

    @GetMapping(path = "/")
    public @ResponseBody String greeting(){
        return "Hello, Gradle!!!";
    }

    public String sayHello() {
        return "Hello";
    }
}
