package ca.sunlife.appdev.metric;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@SpringBootApplication
public class WebAppsGradleApplication {
	static final Log logger = LogFactory.getLog(WebAppsGradleApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(WebAppsGradleApplication.class, args);
		logger.debug("WebAppsGradleApplication starts");
	}
}
