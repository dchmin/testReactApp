package ca.sunlife.appdev.metric;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.beans.factory.annotation.Autowired;

@SpringBootTest
class WebAppsGradleApplicationTests {

	@Autowired
	private WebAppsGradleController controller;

	@Test
	void contextLoads() throws Exception {
		assertThat(controller).isNotNull();
	}

	@Test
	void greetingTest() throws Exception {
		assertThat(controller.greeting()).isEqualTo("Hello, Gradle!!!");
	}

	@Test
	void sayHelloTest() throws Exception{
		assertThat(controller.sayHello()).isEqualTo("Hello");
	}

}
