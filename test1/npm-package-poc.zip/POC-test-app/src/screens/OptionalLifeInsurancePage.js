import React from "react";
import Progressbar from "./../components/optional-life-insurance/Progressbar";
import EllaIntro from "./../components/optional-life-insurance/EllaIntro";
import VideoTile from "./../components/optional-life-insurance/VideoTile";
import ArticleTile from "./../components/optional-life-insurance/ArticleTile";
import EllaAssessment from "./../components/optional-life-insurance/EllaAssessment";
import EllaAffirmation from "./../components/optional-life-insurance/EllaAffirmation";
import OptionalLifeInsuranceCalculator from "./../components/optional-life-insurance-calculator/calculator";

const OptionalLifeInsurancePage = () => {
    const eventKey = [1, 2, 3, 4];
    return (
        <main id="optional-life-insurance">
            <div id="main-content">
                <div className="container">
                    <div className="row">
                        <div className="col-12 col-lg-4">
                            <Progressbar />
                        </div>
                        <div className="col-12 col-lg-8">
                          <EllaIntro />
                          {/* <VideoTile /> */}
                          <ArticleTile />
                          {/* <EllaAssessment /> */}
                          {/* <div id="life-calculator">
                            <OptionalLifeInsuranceCalculator />
                          </div> */}
                          {/* <EllaAffirmation /> */}
                        </div>
                    </div>
                 </div>
             </div>
         </main>
    );
}

export default OptionalLifeInsurancePage;