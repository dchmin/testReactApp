import React,  { useEffect, useState } from "react";
require('./styles/scss/main.scss');
import 'bootstrap/dist/css/bootstrap.min.css';
import ReactDOM from "react-dom";
import Header from './components/global/Header';
import Body from './components/global/Body';
import Footer from './components/global/Footer';

import 'poc_onesun_library/dist/css/main.css';
import { DummyText, DummyAPI, Product, DummyAccordion, FooterWidget, HeaderWidget } from 'poc_onesun_library';

const lang = (document.documentElement.lang === 'en' || document.documentElement.lang === 'en_ca') ? 'en_CA' : 'fr_CA';

(process.env.NODE_ENV !== 'production') ? require('./styles/scss/main-dev.scss') : require('./styles/scss/main.scss');

const Index = () => {
    return (
        <React.Fragment>
            <HeaderWidget />
            <DummyText
                primary={true}
                label="Hello world" />
            <DummyText
                primary={false}
                label="Dummy Text" />
            {/* <DummyAccordion /> */}
            {/* <DummyAPI /> */}
            {/* <Product /> */}

            <Body />
            <FooterWidget />
        </React.Fragment>
    )
};

ReactDOM.render(<Index />, document.getElementById("spa-gb-coaching"));