#!/usr/bin/env bash
npm run dev
rm ROOT.war
cp ROOT-template.war ROOT.war
cd dist
jar -uvf ../ROOT.war .