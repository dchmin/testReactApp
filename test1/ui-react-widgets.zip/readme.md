# UI React Widgets

__Author(s): Alexis Blondin, .__

## First Steps to run React

1. Install **Node.js**: https://nodejs.org/en/download/

2. Open terminal anywhere and run: `npm config set registry http://sv64856:8081/artifactory/api/npm/npm-remote`
This command needs to be run only once. It makes sure you can download all node packages through a custom **registry** owned by SLF. (My guess: this is for security reasons).

3. Clone this repository to your local where ever it makes sense to you.

4. Run `npm i` (which is a shorthand for `npm install`) from the folder project you want to execute. For example: run it from `/reactWidgets/` if you want to run this particular application.

5. (Optional) Install **React Developer Tools** to inspect and debug easily React Code from Chrome: https://github.com/facebook/react-devtools

6. (Optional) For testing your react code within the JAVA environement with Chrome you need to disable security flag.
Create a new shortcut for Chrome and add at the end of target field the following flags: ` --disable-web-security  --user-data-dir="c:/chromedev"`

## General Knowledge / Recommandations

- A good introduction to React is the tutorial from the official website: https://reactjs.org/tutorial/tutorial.html
- Our project has been created from **create react app** https://github.com/facebook/create-react-app. It is an easy environment to setup and run React without struggling. At some point we _ejected_ from create-react-app: https://github.com/facebook/create-react-app#philosophy
- Good tutorials can be found on pluralsight. As a great introduction to React: https://www.pluralsight.com/courses/react-big-picture

## Tips

### Script for testing build locally

To test the build locally, you have to run `npm run test-build-local`.
It allows you to test the final JS build file before sharing it or testing it in Java Environment.
It using a Node Environement variable set to `staging`.
Do not forget to run `npm run build-server` to test your JS build file.
If everything looks good, finally run `npm run build` to create the final version that you will actually use in the Java Environment.



## TODO:

- using json server for local testing from react.js : https://www.npmjs.com/package/json-server