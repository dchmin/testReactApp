# email&phoneWidget

## Purpose

email&phoneWidget repo is supposed to hold all email and phone widgets.

## Steps to run and build

- Dev local testing:  `npm run dev`
- Build react Code:  `npm run prod`

## Quick Tips

## To Do

