var path = require("path");
var webpack = require("webpack");
var ExtractTextPlugin = require("extract-text-webpack-plugin");
var CommonsChunkPlugin = require("./node_modules/webpack/lib/optimize/CommonsChunkPlugin");

var isProd = process.env.NODE_ENV === "production"; // true or false
process.env.NODE_ENV = isProd ? "production" : "development";
var cssDev = ["style-loader", "css-loader"];
var cssProd = ExtractTextPlugin.extract({
  fallback: "style-loader",
  use: "css-loader"
});
var cssConfig = isProd ? cssProd : cssDev;

console.log("isProd = " + isProd);

module.exports = {
  entry: {
    //vendor: ["intl-tel-input"],
    emailWidgetV3: "./src/entry_email.js",
    phoneWidgetV3: "./src/entry_phone.js"
  },
  output: {
    filename: "[name].js",
    path: path.resolve(__dirname, "build")
  },

  module: {
    rules: [
      { test: /\.css$/, loader: cssConfig },
      {
        test: /\.js$/,
        exclude: /node_modules/,
        loader: "babel-loader",
        query: { presets: ["babel-preset-react-app"] }
      }
    ]
  },

  plugins: [
    new ExtractTextPlugin({
      filename: "emailWidget.css",
      disable: !isProd,
      allChunks: true
    }),
    //new CommonsChunkPlugin({ name: "vendor", minChunks: Infinity, }),
    new webpack.HotModuleReplacementPlugin() // Enable HMR
  ],

  devServer: {
    hot: true, // Tell the dev-server we're using HMR
    contentBase: path.resolve(__dirname, "build"),
    publicPath: "/",
    port: 9100,
    //	host: '10.66.142.161',
    stats: "errors-only",
    open: true
  }
};
