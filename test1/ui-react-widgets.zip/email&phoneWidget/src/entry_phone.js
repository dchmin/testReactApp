import React from "react";
import ReactDOM from "react-dom";
import PhoneWidget from "./components/phone/PhoneWidget";

ReactDOM.render(<PhoneWidget />, document.getElementById("phoneNumWidget"));
