import React from "react";
import EmailViewTable from "./EmailViewTable";
import EmailEditTable from "./EmailEditTable";

// Global variables
var saveMsgTimer = null; //Used for reseting timer for the successful saved message
var animateHideTimer = null; //Used for animating the save succesful message
var correctPreferred = false; // User has the preferred flag set correctly
var pageName = "Personal Information";
var callShadow = false;
var lang =
  document.getElementsByTagName("html")[0].getAttribute("lang") + "_CA";
if (lang === undefined || lang === null) {
  lang = "en_CA";
}
export const emailLabels = lang === "en_CA" ? emailContent.en : emailContent.fr;
class EmailWidget extends React.Component {
  /**
   * Construnctor Method: Here we initialize all STATE objects
   */
  constructor(props, context) {
    super(props, context);

    this.state = {
      emails: [],
      originalEmails: [],
      emailTypes: [
        {
          id: "O",
          desc_En: emailContent.en.typeLabel,
          desc_Fr: emailContent.fr.typeLabel
        },
        {
          id: "H",
          desc_En: emailContent.en.personalLabel,
          desc_Fr: emailContent.fr.personalLabel
        },
        {
          id: "B",
          desc_En: emailContent.en.workLabel,
          desc_Fr: emailContent.fr.workLabel
        }
      ],
      friendlyIdOptions: [],
      friendlyIdHasChanged: false,
      oldFriendlyId: "",
      accessID: "",
      isNumericIDApplicable: false,
      emailTypesAvailable: ["H", "B"],
      selectedFriendlyId: "",
      displayMode: "load",
      language: "en_CA",
      vaStatusEmailList: []
    };

    this.toggleDisplayMode = this.toggleDisplayMode.bind(this);
    this.handleAddEvent = this.handleAddEvent.bind(this);
    this.handleEmailEditEvent = this.handleEmailEditEvent.bind(this);
    this.handleDeleteRow = this.handleDeleteRow.bind(this);
    this.handleCancelClick = this.handleCancelClick.bind(this);
    this.addEmailType = this.addEmailType.bind(this);
    this.removeEmailType = this.removeEmailType.bind(this);
    this.handleEmailTypeChange = this.handleEmailTypeChange.bind(this);
    this.handleSaveRowSubmit = this.handleSaveRowSubmit.bind(this);
    this.handleFilterEmailInputCharacter = this.handleFilterEmailInputCharacter.bind(
      this
    );
    this.handlePreferredEmailChange = this.handlePreferredEmailChange.bind(
      this
    );
    this.handleFriendlyIdSelection = this.handleFriendlyIdSelection.bind(this);
    this.saveUpdatedEmails = this.saveUpdatedEmails.bind(this);
  }

  componentDidMount() {
    this.getEmailInfoFromServer();
  }
  getEmailInfoFromServer() {
    // Initializa Language
    var lang =
      document.getElementsByTagName("html")[0].getAttribute("lang") + "_CA";
    if (lang === undefined || lang === null) {
      lang = "en_CA";
    }
    this.setState({ language: lang });

    if (process.env.NODE_ENV === "production") {
      var url = emailDetailsServiceURL + "/" + lang;
    } else {
      var url = emailDetailsServiceURL;
    }

    // Set Initial State for Data
    var emailWidgetObj = this;
    $.ajax({
      url: url,
      dataType: "json",
      cache: false,
      success: function(data) {
        //set call shadow flag
        if (data.callShadow === true) {
          callShadow = true;
        }

        var originalDisplayMode =
          $("#emailWidget").attr("displayMode") === "edit" ? "edit" : "view";

        emailWidgetObj.setState({ displayMode: originalDisplayMode });
        var filteredEmails = [];
        var vaStatusEmails = [];
        for (var i = 0; i < data.emailInfo.length; i++) {
          var curEmailInfo = data.emailInfo[i];
          if (curEmailInfo.addrCntxtCd == "H") {
            filteredEmails.unshift(curEmailInfo);
            if (curEmailInfo.emailAddrStatCd === "VA") {
              vaStatusEmails.unshift(curEmailInfo.emailAddrNm);
            }
          } else if (curEmailInfo.addrCntxtCd == "B") {
            filteredEmails.push(curEmailInfo);
            if (curEmailInfo.emailAddrStatCd === "VA") {
              vaStatusEmails.push(curEmailInfo.emailAddrNm);
            }
          }
          if (
            typeof (curEmailInfo.preferredEmail != "undefined") &&
            curEmailInfo.preferredEmail === "Y"
          ) {
            correctPreferred = true;
          }
        }

        emailWidgetObj.setState({ emails: filteredEmails });
        emailWidgetObj.setState({ originalEmails: filteredEmails });
        emailWidgetObj.setState({ vaStatusEmailList: vaStatusEmails });

        //remove existing emailTypes from emailTypesAvailable list
        for (var j = 0; j < data.emailInfo.length; j++) {
          emailWidgetObj.removeEmailType(data.emailInfo[j].addrCntxtCd);
        }
      }.bind(this),
      error: function(xhr, status, err) {}
    });
  }
  getVaStatusEmails() {
    var url = emailDetailsServiceURL + "/" + this.state.language;
    var emailWidgetObj = this;
    $.ajax({
      url: url,
      dataType: "json",
      cache: false,
      success: function(data) {
        var vaStatusEmails = [];
        for (var i = 0; i < data.emailInfo.length; i++) {
          var curEmailInfo = data.emailInfo[i];
          if (curEmailInfo.addrCntxtCd == "H") {
            if (curEmailInfo.emailAddrStatCd === "VA") {
              vaStatusEmails.unshift(curEmailInfo.emailAddrNm);
            }
          } else if (curEmailInfo.addrCntxtCd == "B") {
            if (curEmailInfo.emailAddrStatCd === "VA") {
              vaStatusEmails.push(curEmailInfo.emailAddrNm);
            }
          }
        }
        emailWidgetObj.setState({ vaStatusEmailList: vaStatusEmails });
      }.bind(this),
      error: function(xhr, status, err) {}
    });
  }
  handleDeleteRow(event) {
    var emailId = event.target.id;
    var currEmails = JSON.parse(JSON.stringify(this.state.emails));
    var index = this.findIndexByProperty(emailId, currEmails, "id");
    var prevRowId = "emailAnchor";
    if (index >= 0) {
      // Add the deleted Phone Type to list of available Phone Types
      this.addEmailType(currEmails[index].addrCntxtCd);

      // Remove deleted row and update State
      currEmails.splice(index, 1);
      this.updatePreferredEmail(currEmails, 0);
      if (index > 0) {
        prevRowId = prevRowId + (emailId - 1).toString();
      }
      this.setState({ emails: currEmails }, this.focusOnPrevRow(prevRowId));
    }
    event.preventDefault();
  }

  focusOnPrevRow(anchorId) {
    if (
      document.getElementById(anchorId) != null &&
      document.getElementById(anchorId) != undefined
    ) {
      document.getElementById(anchorId).focus();
    }
  }

  /**
   * Returns an array index from a   integer between min (inclusive) and max (inclusive)
   * Using Math.round() will give you a non-uniform distribution!
   */
  findIndexByProperty(value, arr, prop) {
    for (var i = 0; i < arr.length; i++) {
      if (Number(arr[i][prop]) === Number(value)) {
        return i;
      }
    }
    return -1; //to handle the case where the value doesn't exist
  }

  handleAddEvent(event) {
    var id = 0;
    var temp = [];
    var currentEmails = this.state.emails;
    if (currentEmails.length > 0) {
      id = parseInt(currentEmails[currentEmails.length - 1].id) + 1;
      temp = JSON.parse(JSON.stringify(currentEmails));
    }

    var isPreferred = temp.length === 0 ? "Y" : "N";

    var email = {
      id: id,
      emailAddrNm: "",
      addrCntxtCd: "",
      emailAddrStatCd: "",
      preferredEmail: isPreferred
    };

    temp.push(email);

    this.setState({ emails: temp });
  }

  /**
   * Returns a random integer between min (inclusive) and max (inclusive)
   * Using Math.round() will give you a non-uniform distribution!
   */
  getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  handleEmailEditEvent(event) {
    $(event.target)
      .parsley()
      .reset(); //Reset inline error
    var curInput = {
      id: event.target.id,
      value: event.target.value
    };

    var rowId = curInput.id.replace("emailTxt", "");
    var index = this.findIndexByProperty(rowId, this.state.emails, "id");

    var temp = JSON.parse(JSON.stringify(this.state.emails));
    temp[index].emailAddrNm = curInput.value;

    this.setState({ emails: temp });
  }

  handleFilterEmailInputCharacter(event) {
    var keyCode = event.keyCode ? event.keyCode : event.which;
    if (keyCode == 32) {
      // Prevent user from entering spaces
      event.preventDefault();
    }
  }

  handleCancelClick() {
    //var tmp = [{id: 1, emailTypeCd: 'H',emailTxt: 'John.Doe@rogers.ca'}, {id: 2,emailTypeCd: 'B',emailTxt: 'John.Doe@sunlife.com'}];
    //$('#emailWidgetForm').parsley().reset();	//Reset inline parsley error
    var previousEmailState = JSON.parse(
      JSON.stringify(this.state.originalEmails)
    );
    this.setState({ emails: previousEmailState });

    //remove existing emailTypes from emailTypesAvailable list
    var acceptedEmailTypes = ["H", "B"];
    for (var j = 0; j < previousEmailState.length; j++) {
      var index = acceptedEmailTypes.indexOf(previousEmailState[j].addrCntxtCd);
      if (index >= 0) {
        acceptedEmailTypes.splice(index, 1);
      }
    }
    this.setState({ emailTypesAvailable: acceptedEmailTypes });
    this.toggleDisplayMode();
  }

  toggleDisplayMode(event) {
    //if clicked on the edit button to go from view to edit
    if (this.state.displayMode === "view") {
      if (!correctPreferred) {
        //set preferred flag if does not exist.
        var numEmails = this.state.emails.length;
        if (numEmails > 0) {
          var temp = JSON.parse(JSON.stringify(this.state.emails));
          temp[0].preferredEmail = "Y";
          if (numEmails === 2) {
            temp[1].preferredEmail = "N";
          }
          this.setState({ emails: temp });
        }
      }
      //tealium tagging on click of the edit button
      if (typeof utag !== "undefined") {
        utag.link({
          ev_type: "other",
          ev_action: "clk",
          ev_title: pageName,
          ev_data_one: "Email - Edit"
        });
      }
      //Add new row in edit view if no emails exist
      if (this.state.emails.length === 0) {
        this.handleAddEvent(event);
      }
    }
    var newDisplayMode = this.state.displayMode === "view" ? "edit" : "view";
    this.setState({ displayMode: newDisplayMode });
  }

  removeEmailType(emailType) {
    var typeList = this.state.emailTypesAvailable;
    var index = typeList.indexOf(emailType);
    if (index >= 0) {
      typeList.splice(index, 1);
      this.setState({ emailTypesAvailable: typeList });
    }
  }

  addEmailType(emailType) {
    var typeList = this.state.emailTypesAvailable;
    var index = typeList.indexOf(emailType);
    if (index == -1) {
      typeList.push(emailType);
      this.setState({ emailTypesAvailable: typeList });
    }
  }

  handleEmailTypeChange(event) {
    var curValue = event.target.value;
    var prevValue = event.target.getAttribute("data-previousval");
    this.addEmailType(prevValue);
    this.removeEmailType(curValue);

    event.target.dataset.previousval = curValue;
    var rowId = event.target.id.replace("emailType", "");
    var index = this.findIndexByProperty(rowId, this.state.emails, "id");
    if (index >= 0) {
      var temp = JSON.parse(JSON.stringify(this.state.emails));
      temp[index].addrCntxtCd = curValue;
      this.setState({ emails: temp });
    }
    $(event.target)
      .parsley()
      .reset(); //Reset inline error
  }
  handlePreferredEmailChange(event) {
    var curInput = {
      id: event.target.id,
      value: event.target.value
    };

    var rowId = curInput.id.replace("preferredEmail", "");
    var index = this.findIndexByProperty(rowId, this.state.emails, "id");

    var temp = JSON.parse(JSON.stringify(this.state.emails));
    this.updatePreferredEmail(temp, index);

    this.setState({ emails: temp });
  }
  handleFriendlyIdSelection(friendlyId, event) {
    this.setState({ selectedFriendlyId: friendlyId });
  }
  updatePreferredEmail(emailsArray, index) {
    for (var k = 0; k < emailsArray.length; k++) {
      if (k === index) {
        emailsArray[index].preferredEmail = "Y";
      } else {
        emailsArray[k].preferredEmail = "N";
      }
    }
  }
  showErrorCounter() {
    $("#email-server-error").hide();
    var errorCount = $("#emailWidgetForm .parsley-errors-list").children()
      .length;
    var oneErrorMsg = emailLabels.oneError;
    var multiErrorMsg = emailLabels.multipleErrors;

    // Display appropriate error message
    if (errorCount != 0) {
      if (errorCount === 1) {
        $("#email-error-num").text(oneErrorMsg);
      } else {
        var errorMsg = multiErrorMsg.replace("<x>", errorCount);
        $("#email-error-num").text(errorMsg);
      }
      $("#email-error-num").show();
      document.getElementById("email-error-num").focus();
    } else {
      $("#email-error-num, #email-server-error").hide();
    }
  }
  handleSaveRowSubmit(event) {
    this.checkDuplicateEmails();
    $("#emailWidget form")
      .parsley()
      .validate();
    this.showErrorCounter();
    if (
      $("#emailWidgetForm")
        .parsley()
        .isValid() &&
      !$("#emailWidgetForm").hasClass("form-disabled") &&
      !$("#emailWidgetForm").hasClass("form-has-error")
    ) {
      this.disableFields();
      if (callShadow) {
        event.preventDefault();
        this.enableFields();
        $("#accessRestricted").modal({ backdrop: "static" });
      } else {
        var setFriendlyId = "";
        this.saveUpdatedEmails(setFriendlyId, event);
      }
    }
  }
  saveUpdatedEmails(setFriendlyId, event) {
    var apologyErrorMsg = emailLabels.apologyError;

    // Format request JSON to include selected Friendly ID
    var emailRequestJson = {};
    emailRequestJson.emails = this.state.emails;
    emailRequestJson.friendlyId = setFriendlyId;

    // Set indicator that friendly id is set or not
    if (setFriendlyId === "") {
      emailRequestJson.friendlyIdSelected = false;
    } else {
      emailRequestJson.friendlyIdSelected = true;
    }

    var appObject = this;
    event.preventDefault();
	let csrfToken = document.getElementsByName('CSRFToken')[0] ? document.getElementsByName('CSRFToken')[0].value : "";
    $.ajax({
	  headers: {
		'MBRWIDGETS-ANTICSRF-TOKEN': csrfToken
	  },
      url: submitEmailServiceURL + "/" + this.state.language,
      type: "POST",
      data: JSON.stringify(emailRequestJson),
      contentType: "application/json; charset=utf-8",
      dataType: "json",
      success: function(response) {
        if (response.errorCode == "0" || response.errorCode == "-1") {
          var friendlyHasChanged = false;

          // Check if friendly object exists
          if (typeof response.friendlyIdInfo !== "undefined") {
            friendlyHasChanged = response.friendlyIdInfo.friendlyIdHasChanged;
          }

          if (friendlyHasChanged) {
            // Friendly ID needs to be selected
            appObject.setFriendlyIDStates(appObject, response.friendlyIdInfo);
            $("#friendlyIdPopup").modal({ backdrop: "static" });
            appObject.enableFields();
          } else {
            // Email Saved successfully
            appObject.emailSavedSucessfully(appObject);
            appObject.enableFields();
          }
        } else {
          appObject.enableFields();
          $("#email-server-error").text(response.errorMsg);
          $("#email-server-error").show();
          document.getElementById("email-server-error").focus();
        }
      },
      error: function(xhr, status, err) {
        appObject.enableFields();
        $("#email-server-error").text(apologyErrorMsg);
        $("#email-server-error").show();
        document.getElementById("email-server-error").focus();
      }
    });
  }
  emailSavedSucessfully(appObject) {
    appObject.setState({ displayMode: "view" });
    appObject.displaySaveSuccessMsg(appObject); //Show "save successful" message
    appObject.setState({ originalEmails: appObject.state.emails });
    appObject.getVaStatusEmails();

    //tealium tagging for successful save of email info
    if (typeof utag !== "undefined") {
      utag.link({
        ev_type: "other",
        ev_action: "clk",
        ev_title: pageName,
        ev_data_one: "Email - Successful save"
      });
    }
  }
  setFriendlyIDStates(appObject, responseStates) {
    // Update Friendly ID State
    appObject.setState({ friendlyIdOptions: responseStates.friendlyIds });
    appObject.setState({ oldFriendlyId: responseStates.oldFriendlyId });
    appObject.setState({ accessID: responseStates.accessId });
    appObject.setState({
      isNumericIDApplicable: responseStates.isNumericIDApplicable
    });
    var isFriendlyIdSet = false;

    for (var i = 0; i < responseStates.friendlyIds.length; i++) {
      if (responseStates.friendlyIds[i].available) {
        appObject.setState({
          selectedFriendlyId: responseStates.friendlyIds[i].emailAddrNm
        });
        isFriendlyIdSet = true;
        break;
      }
    }
    if (!isFriendlyIdSet) {
      appObject.setState({ selectedFriendlyId: responseStates.accessId });
    }
  }
  removeSpaces(event) {
    var emailInput = event.target.value;
    emailInput = emailInput.replace(/\s/g, "");
    event.target.value = emailInput;
  }
  disableFields() {
    var validatingLabel = emailLabels.validatingLabel;
    // Input fields
    $("#emailWidget form").addClass("form-disabled");
    $("#emailsTable input, #emailsTable select, #addEmailButton").prop(
      "disabled",
      true
    );
    $("#emailsTable .removeCol a, .btnArea .cancel-btn").prop("tabindex", "-1");

    // Save Button
    $("#emailsContainer .save-btn").text(validatingLabel);
    $("#emailsContainer .save-btn").addClass("is-busy");
  }
  enableFields() {
    var saveLabel = emailLabels.saveLabel;
    $("#emailWidget form").removeClass("form-disabled");
    $("#emailsTable input, #emailsTable select, #addEmailButton").prop(
      "disabled",
      false
    );
    $("#emailsTable .removeCol a, .btnArea .cancel-btn").removeAttr("tabindex");

    // Save button
    $("#emailsContainer .save-btn").html(
      saveLabel +
        '<span class="sr-only"> ' +
        emailLabels.emailWidgetTitle +
        "<span>"
    );
    $("#emailsContainer .save-btn").removeClass("is-busy");
  }
  displaySaveSuccessMsg(appObject) {
    $("#successful-save-email-msg").show(); //Show "save successful" message
    $("#successful-save-email-msg").focus();
    if (saveMsgTimer) {
      //Cancel the previous timer
      clearTimeout(saveMsgTimer);
      saveMsgTimer = null;
    }
    saveMsgTimer = setTimeout(function() {
      appObject.easeOutMsg();
    }, 5000); //Animate fading of message
  }

  easeOutMsg() {
    var appObject = this; //Save React pointer
    var savedMsg = $("#successful-save-email-msg");
    savedMsg.addClass("hideElementAnimate");
    savedMsg.one("transitionend", function(e) {
      //Animate fading of message
      appObject.hideSaveSuccessMsg();
    });
  }

  hideSaveSuccessMsg() {
    // Clear timer
    clearTimeout(saveMsgTimer);
    saveMsgTimer = null;
    // Hide message
    var savedMsg = $("#successful-save-email-msg");
    savedMsg.hide();
    savedMsg.removeClass("hideElementAnimate");
  }
  checkDuplicateEmails() {
    var emails = $("input[type='email']");
    if (emails.length > 1) {
      $("#emailWidgetForm").removeClass("form-has-error");
      $("#email-duplicate-error").hide();
      if (
        emails[0].value.trim() !== "" &&
        emails[0].value.trim().toUpperCase() ===
          emails[1].value.trim().toUpperCase()
      ) {
        $("#emailWidgetForm").addClass("form-has-error");
        $("#email-duplicate-error").show();
        document.getElementById("email-duplicate-error").focus();
      }
    } else {
      $("#emailWidgetForm").removeClass("form-has-error");
      $("#email-duplicate-error").hide();
    }
  }
  render() {
    var emailTitle = emailLabels.emailWidgetTitle;
    if (this.state.displayMode === "load") {
      return null;
    } else if (this.state.displayMode === "view") {
      return (
        <div id="emailsContainer" className="viewMode no-outline" tabIndex="-1">
          <h2>{emailTitle}</h2>
          <EmailViewTable
            emails={this.state.emails}
            vaStatusEmails={this.state.vaStatusEmailList}
            emailTypes={this.state.emailTypes}
            onRowAdd={this.handleAddEvent}
            toggleView={this.toggleDisplayMode}
            lang={this.state.language}
          />
        </div>
      );
    } else {
      return (
        <div id="emailsContainer" className="editMode no-outline" tabIndex="-1">
          <h2>{emailTitle}</h2>
          <EmailEditTable
            emails={this.state.emails}
            vaStatusEmails={this.state.vaStatusEmailList}
            emailTypes={this.state.emailTypes}
            emailTypesAvailable={this.state.emailTypesAvailable}
            onEmailTypeChange={this.handleEmailTypeChange}
            onEmailEdit={this.handleEmailEditEvent}
            onRowAdd={this.handleAddEvent}
            onRowDel={this.handleDeleteRow}
            onCancel={this.handleCancelClick}
            onRowSave={this.handleSaveRowSubmit}
            filterEmailInputCharacter={this.handleFilterEmailInputCharacter}
            onPreferredEmailChange={this.handlePreferredEmailChange}
            formatUserInput={this.removeSpaces}
            lang={this.state.language}
            callShadow={callShadow}
            friendlyIdOptions={this.state.friendlyIdOptions}
            friendlyIdHasChanged={this.state.friendlyIdHasChanged}
            oldFriendlyId={this.state.oldFriendlyId}
            accessID={this.state.accessID}
            canChooseAccessId={this.state.isNumericIDApplicable}
            onFriendlyIdSelection={this.handleFriendlyIdSelection}
            selectedFriendlyId={this.state.selectedFriendlyId}
            onSaveFriendlySelection={this.saveUpdatedEmails}
          />
        </div>
      );
    }
  }
}

export default EmailWidget;
