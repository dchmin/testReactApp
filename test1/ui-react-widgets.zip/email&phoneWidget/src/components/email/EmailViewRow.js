import React from "react";
import PropTypes from "prop-types";
import { emailLabels } from "./EmailWidget";

class EmailViewRow extends React.Component {
  getEmailTypeDesc(emailType) {
    var myArray = this.props.emailTypes;
    for (var i in myArray) {
      if (myArray[i].id === emailType) {
        return this.props.lang === "en_CA"
          ? myArray[i].desc_En
          : myArray[i].desc_Fr;
      }
    }
  }

  getPreferredEmail(emailPref) {
    var preferredMsg = emailLabels.preferredEmailViewLabel; //Get label text

    // Display preferred label
    if (
      typeof emailPref !== "undefined" &&
      emailPref.toUpperCase() === "Y" &&
      this.props.emailLength > 1
    ) {
      return <span className="preferredEmail">{preferredMsg}</span>;
    }
  }

  render() {
    return (
      <tr
        className="viewRow"
        key={this.props.email.id}
        id={"emailViewRow" + this.props.email.id}
      >
        <td
          className="view-cell"
          data-title="Type"
          aria-label={emailLabels.typeLabel}
        >
          <div>{this.getEmailTypeDesc(this.props.email.addrCntxtCd)}</div>
        </td>
        <td
          className="view-cell"
          data-title="Email"
          aria-label={emailLabels.emailWidgetTitle}
        >
          <span className="emailAddrTxt">{this.props.email.emailAddrNm}</span>
          {this.getPreferredEmail(this.props.email.preferredEmail)}
        </td>
      </tr>
    );
  }
}

EmailViewRow.propTypes = {
  emailTypes: PropTypes.array,
  email: PropTypes.object
};
export default EmailViewRow;
