import React from 'react';
import EmailTextInput from '../commons/EmailTextInput';
import ToggleDropdown from '../commons/ToggleDropdown';
import ButtonLink from '../commons/ButtonLink';
import {emailLabels} from './EmailWidget';

class EmailEditRow extends React.Component {

  render() {
      // States
      var email = this.props.email;
			var emailAddress = this.props.email.emailAddrNm;
      var emailId = this.props.email.id;
      var lang = this.props.lang;
      var emailTypes  = this.props.emailTypes;
      var emailTypesAvailable = this.props.emailTypesAvailable
			var numEmails = this.props.numEmails;
			var isPreferred = this.props.email.preferredEmail === 'Y' ? true : false;
      
      // Labels
			var removeLabel = emailLabels.removeLabel;
      var emailLabel = emailLabels.emailTxtLabel;
      var placeholderTxt = emailLabels.emailShadowTxt;
			var preferredLabel = emailLabels.preferredEmailLabel;
			
			var removeLink = null;
			var preferredCheckbox = null;
			if (numEmails>1) {
				removeLink = (<ButtonLink href="#emailsContainer" id={this.props.email.id} value={removeLabel} cssClass="del-btn" onClick={this.props.onRowDel}/>);
			}
			
			//var isdisabled = numEmails === 1 ? true : false; 
			if (numEmails>1) {
				preferredCheckbox = (
					<div className="mar-top-10">
						<input id={"preferredEmail"+emailId} name="preferredEmail" type="checkbox" data-parsley-multiple="preferredEmail" checked={isPreferred} onChange={this.props.onPreferredEmailChange}/>
						<label className="radio-label" htmlFor={"preferredEmail"+emailId}>
						{preferredLabel}
						</label>
					</div>
				);
			}
			
		return (
      <tr className="eachRow" key={this.props.email.id} id={"emailEditRow"+this.props.email.id}>
				<ToggleDropdown
					name="emailTypeCd"
					id={emailId}              
					emailTypes={emailTypes}     
					emailTypesAvailable={emailTypesAvailable}             
					email={email}
					onEmailTypeChange={this.props.onEmailTypeChange}
					lang={lang}/>
				
				<td>
					<EmailTextInput
						label={emailLabel}
						name="emailTxt"
						id={emailId}
						value={emailAddress}
						placeholder={placeholderTxt}
						onChange={this.props.onEmailEdit}
						onKeyPress={this.props.filterEmailInputCharacter}
						onBlur={this.props.removeSpaces}
						cssClass="form-control"
						maxLength="64" 
						requiredField={true} 
						lang={lang}/>
						
					{preferredCheckbox}
				</td>
							 
				<td className="removeCol">
					{removeLink}
				</td>
      </tr>
		);
	}
}

module.exports = EmailEditRow;
