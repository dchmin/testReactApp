var React = require('react');
var createReactClass = require('create-react-class');
import {emailLabels} from './EmailWidget';

var AddNewEmailButton = createReactClass({

  onChange: function(e) {
    this.props.onClick(e);
  },

  createAddButton: function(emailSize){

		if (emailSize > 1 ) {
			return null
		}else{
			return (
				<tr style={{border:'none'}}>
					<td className="btn-centered-container" colSpan="2">
						 <button name="addEmailButton" id="addEmailButton" type="button" className="btn btn-green" onClick={this.onChange}>
								<span className="fa fa-plus-circle mar-right-5"></span>
								{emailLabels.addLabel}
						 </button>
					</td>
				</tr>
			)
		}
  },

	render: function() {

		return this.createAddButton(this.props.emailSize);
     
	}
});

module.exports = AddNewEmailButton;
