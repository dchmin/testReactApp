import React from "react";
import PropTypes from "prop-types";
import EmailViewRow from "./EmailViewRow";
import ButtonLink from "../commons/ButtonLink";
import { emailLabels } from "./EmailWidget";

class EmailViewTable extends React.Component {
  render() {
    var emails = null;
    var buttonLabel = emailLabels.editLabel;
    var successLabel = emailLabels.successLabel;
    var emailSeperator = emailLabels.andLabel;
    var vaWarningLabel = emailLabels.vaStatusWarning;
    var vaStatusEmailString = this.props.vaStatusEmails.join(
      " " + emailSeperator + " "
    );
    vaWarningLabel = vaWarningLabel.replace("<x>", vaStatusEmailString);
    var displayWarningClass =
      this.props.vaStatusEmails.length === 0 ? "hide" : "";
    var displayFriendlyIdWarningClass = this.props.friendlyIdWarning
      ? ""
      : "hide";
    if (this.props.emails.length > 0) {
      emails = this.props.emails.map(email => {
        return (
          <EmailViewRow
            email={email}
            key={email.id}
            emailTypes={this.props.emailTypes}
            lang={this.props.lang}
            emailLength={this.props.emails.length}
          />
        );
      });
    } else {
      var emptyMsg = emailLabels.noEmailLabel;
      emails = (
        <tr>
          <td className="autoWidth">{emptyMsg}</td>
        </tr>
      );
    }

    return (
      <div>
        <div className="widgetTableContainer">
          <div id="email-successNotifContainer">
            <div
              id="successful-save-email-msg"
              className="field-set-validation-success"
              style={{ display: "none" }}
              tabIndex="0"
            >
              {successLabel}
            </div>
            <div
              id="VA-warning"
              className={
                "field-set-validation-errors slf-yellow-bg " +
                displayWarningClass
              }
              role="note"
            >
              {vaWarningLabel}
            </div>
          </div>

          <table className="dataTable-responsive" style={{ width: "100%" }}>
            <thead>
              <tr>
                <th>{emailLabels.emailWidgetTitle}</th>
                <th>{emailLabels.typeLabel}</th>
              </tr>
            </thead>
            <tbody>{emails}</tbody>
          </table>
        </div>
        <div className="btnArea">
          <ButtonLink
            value={[
              buttonLabel,
              <span className="sr-only"> {emailLabels.emailWidgetTitle}</span>
            ]}
            cssClass="btn btn-blue"
            label="Title"
            href="#emailsContainer"
            onClick={this.props.toggleView}
          />
        </div>
      </div>
    );
  }
}

EmailViewTable.propTypes = {
  emailTypes: PropTypes.array.isRequired,
  emails: PropTypes.array.isRequired
};

export default EmailViewTable;
