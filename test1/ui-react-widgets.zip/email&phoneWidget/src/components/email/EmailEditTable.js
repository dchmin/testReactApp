import React from "react";
import PropTypes from "prop-types";
import EmailEditRow from "./EmailEditRow";
var AddNewEmailButton = require("./AddNewEmailButton");
import ButtonLink from "../commons/ButtonLink";
import OneBtnPopupModal from "../commons/OneBtnPopupModal";
import FriendlyIdPopup from "../commons/FriendlyIdPopup";
import { emailLabels } from "./EmailWidget";

class EmailEditTable extends React.Component {
  render() {
    // Functions
    var emails = null;
    var onEmailEdit = this.props.onEmailEdit;
    var onRowDel = this.props.onRowDel;
    var onEmailTypeChange = this.props.onEmailTypeChange;
    var filterEmailInputCharacter = this.props.filterEmailInputCharacter;
    var onPreferredEmailChange = this.props.onPreferredEmailChange;
    var removeSpaces = this.props.formatUserInput;

    // Email States
    var emailTypes = this.props.emailTypes;
    var emailTypesAvailable = this.props.emailTypesAvailable;
    var numEmails = this.props.emails.length;
    var displayWarningClass =
      this.props.vaStatusEmails.length === 0 ? "hide" : "";

    // Labels
    var lang = this.props.lang;
    var cancelLabel = emailLabels.cancelLabel;
    var saveLabel = emailLabels.saveLabel;
    var duplicateEmailError = emailLabels.duplicateEmailError;
    var emailSeperator = emailLabels.andLabel;
    var vaWarningLabel = emailLabels.vaStatusWarning;
    var vaStatusEmailString = this.props.vaStatusEmails.join(
      " " + emailSeperator + " "
    );
    vaWarningLabel = vaWarningLabel.replace("<x>", vaStatusEmailString);
    var restrictedModalHeader = emailLabels.restrictedModalHeader;
    var restrictedModalContent = emailLabels.restrictedModalContent;
    var restrictedModalBtn = emailLabels.okayLabel;
    var closeBtnLabel = emailLabels.closeLabel;
    var friendlyIdModalHeader = emailLabels.friendlyIdModalHeader;

    if (typeof (this.props.emails != "undefined")) {
      if (numEmails > 0) {
        emails = this.props.emails.map(email => {
          return (
            <EmailEditRow
              email={email}
              key={email.id}
              emailTypes={emailTypes}
              emailTypesAvailable={emailTypesAvailable}
              onEmailTypeChange={onEmailTypeChange}
              onEmailEdit={onEmailEdit}
              onPreferredEmailChange={onPreferredEmailChange}
              onRowDel={onRowDel}
              filterEmailInputCharacter={filterEmailInputCharacter}
              lang={lang}
              numEmails={numEmails}
              removeSpaces={removeSpaces}
            />
          );
        });
      } else {
        var emptyMsg = emailLabels.noEmailLabel;
        emails = (
          <tr>
            <td colSpan="2">{emptyMsg}</td>
          </tr>
        );
      }
    }
    return (
      <div>
        <form
          id="emailWidgetForm"
          className="form-group"
          data-parsley-validate
          data-parsley-focus="none"
        >
          <div className="widgetTableContainer">
            <div id="email-notifContainer">
              <div
                id="email-server-error"
                className="field-set-validation-errors"
                style={{ display: "none" }}
                tabIndex="0"
              />
              <div
                id="email-duplicate-error"
                className="field-set-validation-errors"
                style={{ display: "none" }}
                tabIndex="0"
              >
                {duplicateEmailError}
              </div>
              <div
                id="email-error-num"
                className="field-set-validation-errors"
                style={{ display: "none" }}
                tabIndex="0"
              />
              <div
                id="VA-warning"
                className={
                  "field-set-validation-errors slf-yellow-bg " +
                  displayWarningClass
                }
              >
                {vaWarningLabel}
              </div>
            </div>
            <a id="emailAnchor" tabIndex="-1" aria-hidden="true" />
            <table
              id="emailsTable"
              className="dataTable-responsive"
              role="presentation"
            >
              <thead>
                <tr>
                  <th />
                  <th />
                </tr>
              </thead>
              <tbody>
                {emails}
                <AddNewEmailButton
                  emailSize={this.props.emails.length}
                  onClick={this.props.onRowAdd}
                  lang={this.props.lang}
                />
              </tbody>
            </table>
          </div>
          <div className="btnArea">
            <ButtonLink
              value={cancelLabel}
              cssClass="btn btn-link cancel-btn"
              href="#emailsContainer"
              onClick={this.props.onCancel}
            />

            <ButtonLink
              id="emailSaveBtn"
              value={[
                saveLabel,
                <span className="sr-only"> {emailLabels.emailWidgetTitle}</span>
              ]}
              cssClass="btn btn-yellow save-btn"
              href="#email-notifContainer"
              onClick={this.props.onRowSave}
            />
          </div>
        </form>
        <OneBtnPopupModal
          id="accessRestricted"
          headerText={restrictedModalHeader}
          contentText={restrictedModalContent}
          primaryBtnText={restrictedModalBtn}
          closeBtnText={closeBtnLabel}
        />
        <FriendlyIdPopup
          id="friendlyIdPopup"
          headerText={friendlyIdModalHeader}
          lang={this.props.lang}
          friendlyIdOptions={this.props.friendlyIdOptions}
          oldFriendlyId={this.props.oldFriendlyId}
          accessID={this.props.accessID}
          canChooseAccessId={this.props.canChooseAccessId}
          emailInfo={this.props.emails}
          onFriendlyIdSelection={this.props.onFriendlyIdSelection}
          selectedFriendlyId={this.props.selectedFriendlyId}
          onSaveFriendlySelection={this.props.onSaveFriendlySelection}
        />
      </div>
    );
  }
}

EmailEditTable.propTypes = {
  emailTypes: PropTypes.array.isRequired,
  emails: PropTypes.array.isRequired
};

export default EmailEditTable;
