import PropTypes from 'prop-types'; 
import React from 'react';

const ToggleSwitch = ({id, name, emailTypeCd, onChange, lang}) => {
  return (
    <td>
      <button id={id}
              name={name}
              onClick={onChange}
              type="button"
              className={emailTypeCd === 'H' ?  "btn btn-secondary" : "btn btn-warning"}
              value="B">{lang === 'en_CA' ?  "Work" : "Travail"}
      </button>
      <button id={id}
              name={name}
              onClick={onChange}
              type="button"
              className={emailTypeCd === 'B' ?  "btn btn-secondary" : "btn btn-warning"}
              value="H">{lang === 'en_CA' ?  "Personal" : "Personnel"}
      </button>
    </td>
  );
};

ToggleSwitch.propTypes = {
  id          : PropTypes.number.isRequired,
  name        : PropTypes.string,
  emailTypeCd : PropTypes.string.isRequired,
  onChange    : React.PropTypes.func.isRequired,
  lang        : PropTypes.string.isRequired
};

export default ToggleSwitch;
