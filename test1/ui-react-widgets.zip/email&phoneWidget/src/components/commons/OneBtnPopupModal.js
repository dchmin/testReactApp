import PropTypes from 'prop-types'; // ES6
import React from 'react';

const OneBtnPopupModal = ({id, headerText, contentText, primaryBtnText, closeBtnText}) => {
  return (	
		<div className="modal slf-modal" id={id} aria-labelledby={id+"Title"} role="dialog" tabIndex="-1">
			<div className="modal-dialog slf-yellow-modal" role="document">
				<div className="modal-content">
					<div className="modal-header">
						<h3 id={id+"Title"} className="modal-title inline-block">{headerText}</h3>
						<button type="button" className="close" data-dismiss="modal" aria-label={closeBtnText}>
							<span className="fa fa-times" aria-hidden="true"></span>
						</button>
					</div>
					<div className="modal-body">
						<p>{contentText}</p>
					</div>
					<div className="modal-footer">
						<button type="button" className="btn btn-yellow" data-dismiss="modal">{primaryBtnText}</button>
					</div>
				</div>
			</div>
		</div>
		
  );
};

OneBtnPopupModal.propTypes = {
  id         		: PropTypes.string.isRequired,
  headerText   		: PropTypes.string,
  contentText   		: PropTypes.string,
  primaryBtnText   		: PropTypes.string,
  closeBtnText   		: PropTypes.string
};

export default OneBtnPopupModal;
