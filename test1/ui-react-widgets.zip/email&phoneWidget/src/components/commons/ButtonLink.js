import PropTypes from 'prop-types'; // ES6
import React from 'react';

const ButtonLink = ({id, href, value, cssClass, onClick}) => {

  return (
    <a href={href} id={id} onClick={onClick} className={cssClass}>{value}</a>
  );
};

ButtonLink.propTypes = {
  value   : PropTypes.string.isRequired,
  cssClass: PropTypes.string,
  onClick : React.PropTypes.func.isRequired,
	href		: PropTypes.string
};

export default ButtonLink;
