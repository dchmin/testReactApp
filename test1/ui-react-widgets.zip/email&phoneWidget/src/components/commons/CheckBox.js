import PropTypes from 'prop-types'; // ES6
import React from 'react';

const CheckBox = ({id, name, value, label, ...props}) => {

  return (
   <div>
			<input type="checkbox" name={name} value={value} id={id} {...props}/>
			<label htmlFor={id}>
				{label}
			</label>
		</div>
  );
};

CheckBox.propTypes = {
  id  	 : PropTypes.string.isRequired,
  value  : PropTypes.string.isRequired,
  name   : PropTypes.string.isRequired,
  label  : PropTypes.string.isRequired
};

export default CheckBox;
