import PropTypes from 'prop-types'; 
import React from 'react';

//var ToggleDropdown = createReactClass({
var ToggleDropdown = React.createClass({
	componentDidMount: function() {
		if (this.mySelectDropdown.value === "") {
			this.mySelectDropdown.focus();
		}
	},
	createPhoneTypeList: function(selectedType){      
		var emailTypes = this.props.emailTypes;
		var options = [];
		var selectTxt = this.props.lang === 'en_CA' ? emailContent.en.selectLabel : emailContent.fr.selectLabel;
		options.push(<option key={"select"+this.props.email.id} value="">{selectTxt}</option>);
      
      // Determine which types to display
		if ((this.props.emailTypesAvailable.indexOf("H") === -1) && (selectedType !== "H")){
			// do not show the option
		} else {
			options.push(<option key={"personal"+this.props.email.id} value="H">{this.getLabelForEmailType(emailTypes, "H")}</option>);
		}
		if ((this.props.emailTypesAvailable.indexOf("B") === -1) && (selectedType !== "B")){
			// do not show the option
		} else {
         options.push(<option key={"work"+this.props.email.id} value="B">{this.getLabelForEmailType(emailTypes, "B")}</option>);
		}
		return options;
	},
   
   getLabelForEmailType: function(emailTypes, emailTypeCd) {
      // Given the type code and language return the correct label 
      var emailObj = emailTypes.filter(function( obj ) {
        return obj.id === emailTypeCd;
      })[0];
      return this.props.lang === 'en_CA' ? emailObj.desc_En : emailObj.desc_Fr;
   },

	render: function() {      
      // States
      var selectedType = this.props.email.addrCntxtCd;
      
      // Labels
      var dropdownTypeLabel = this.props.lang === 'en_CA' ?  emailContent.en.typeLabel   : emailContent.fr.typeLabel;
			var reqFieldError = this.props.lang === 'en_CA' ? emailContent.en.reqFieldError : emailContent.fr.reqFieldError;

		return (
     <td>
      <div>
				<a id={"emailAnchor"+this.props.email.id} tabIndex="-1" aria-hidden="true"></a>
				<label htmlFor={"emailType"+this.props.email.id}>{dropdownTypeLabel}</label>
				<div className="select-arrow-wrapper">
					<select 
						value={selectedType}
						data-previousval={selectedType}
						id={"emailType"+this.props.email.id}
						className="type-dropdown form-control" 
						required="" 
						required={true} 
						onChange={this.props.onEmailTypeChange} 
						data-parsley-required-message={reqFieldError} 
						ref={(ref => this.mySelectDropdown = ref)}
						>
						{this.createPhoneTypeList(selectedType)}
					</select>
				</div>
			</div>
    </td>
		);
	}
});

export default ToggleDropdown;
