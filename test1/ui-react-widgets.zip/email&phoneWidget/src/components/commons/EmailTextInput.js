import PropTypes from 'prop-types'; // ES6
import React from 'react';

const EmailTextInput = ({label, name, id, onChange, onKeyPress, onBlur, cssClass, placeholder, value, maxLength, requiredField, lang}) => {
	//error messages
	var reqFieldError = lang === 'en_CA' ? emailContent.en.reqFieldError : emailContent.fr.reqFieldError;
	var invalidFrmtError = lang === 'en_CA' ? emailContent.en.invalidFrmtError : emailContent.fr.invalidFrmtError;
	
	
  return (
    <div>
			<label htmlFor={name+id}>{label}</label>
			<input
				type="email"
				name={name}
				id={name+id}
				className={cssClass}
				placeholder={placeholder}
				defaultValue={value}
				onChange={onChange}
				onKeyPress={onKeyPress} 
				onBlur={onBlur} 
				data-parsley-required={requiredField} 
				data-parsley-pattern="/^([_A-Za-z0-9-!#$%&amp;'*+\/=?^_`{}~\+]+(\.[_A-Za-z0-9-!#$%&amp;'*+\/=?^_`{}~]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*(\.[A-Za-z]{2,})|[_A-Za-z0-9-!#$%&amp;'*+\/=?^_`{}~\+]+(\.[_A-Za-z0-9-!#$%&amp;'*+\/=?^_`{}~]+)*@(?:[0-9]{1,3}\.){3}[0-9]{1,3})$/"
				data-parsley-required-message={reqFieldError}
				data-parsley-type-message={invalidFrmtError} 
				data-parsley-pattern-message={invalidFrmtError}
				maxLength={maxLength}
				autoComplete="off"
				required={requiredField}/> 
    </div>
  );
};

EmailTextInput.propTypes = {
	label			 		: PropTypes.string,
  name       		: PropTypes.string,
  id         		: PropTypes.number.isRequired,
  onChange   		: PropTypes.func.isRequired,
  onKeyPress   	: PropTypes.func.isRequired,
  onBlur   			: PropTypes.func.isRequired,
  cssClass   		: PropTypes.string,
  placeholder		: PropTypes.string,
  value      		: PropTypes.string,
	maxLength  		: PropTypes.string,
	requiredField : PropTypes.bool,
	lang					: PropTypes.string
};

export default EmailTextInput;
