import React from 'react';

export const AlertBox = ({stylingClasses, childrenElements}) => {
  return (
    <div className={stylingClasses + " slf-alert-box"}>
      <div>
        {childrenElements}
      </div>
    </div>
  );
}
