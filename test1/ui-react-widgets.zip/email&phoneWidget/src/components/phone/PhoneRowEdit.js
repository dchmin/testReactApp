/* var $ = require('jquery'); */
var React = require("react");
import OneBtnPopupModal from "../commons/OneBtnPopupModal";

var PhoneRowEdit = React.createClass({
  formatUsersInput: function(phoneInfo, event) {
    var inputVal = event.target.value;

    var countryCode = $(event.target).intlTelInput("getSelectedCountryData")
      .dialCode;
    var countryIso2 = $(event.target).intlTelInput("getSelectedCountryData")
      .iso2;
    if (
      (phoneInfo.phoneFrmtCd === " " || countryCode === "1") &&
      countryIso2 != "uu"
    ) {
      // NANPA phone number
      inputVal = inputVal.replace(/\s/g, "");
      inputVal = inputVal.replace(/-/g, "");
      if (inputVal.length === 10 && /^\d+$/.test(inputVal)) {
        //	$(event.target).intlTelInput("setNumber", "+"+countryCode+inputVal);
        var newInputVal = this.props.formatNANPA(inputVal);
        if (event.target.value != newInputVal) {
          event.target.value = newInputVal;
        }
      }
    } else {
      // Non NANPA phone number
      inputVal = inputVal.replace(/^((-)+|(\s)+)+/g, "");
      inputVal = inputVal.replace(/((-)+|(\s)+)+$/g, "");
      if (event.target.value != inputVal) {
        event.target.value = inputVal;
      }
    }
  },
  displayPhoneNumber: function(phoneInfo) {
    var currentCountryCode = "+";
    if (phoneInfo.forgnPhonNum !== "" || phoneInfo.phoneNum !== "") {
      if (phoneInfo.phoneFrmtCd === "I") {
        // if Non-NANPA phone
        return (
          currentCountryCode +
          phoneInfo.forgnCountryCode +
          phoneInfo.forgnPhonNum
        );
      } else {
        //NANPA phone number
        currentCountryCode += "1";
        return (
          currentCountryCode +
          this.props.formatNANPA(phoneInfo.phoneAreaCd + phoneInfo.phoneNum)
        );
      }
    }
  },
  getCorrectNum(phoneInfo) {
    return this.props.formatNANPA(phoneInfo.phoneAreaCd + phoneInfo.phoneNum);
  },
  displayWorkExtension(phoneInfo) {
    if (phoneInfo.addrCntxtCd === "B" && phoneInfo.phoneFrmtCd === " ") {
      //NANPA work extension
      return (
        <div className="workExt mar-left-10">
          <label htmlFor={"ext" + phoneInfo.id}>
            {this.props.labels.extensionLabel}
          </label>
          <input
            id={"ext" + phoneInfo.id}
            className="form-control"
            onChange={this.props.onExtensionChange}
            type="tel"
            value={phoneInfo.phoneExtNum}
            maxLength="5"
            placeholder="55555"
            data-parsley-type="integer"
            data-parsley-type-message={this.props.labels.invalidFrmtError}
          />
        </div>
      );
    }
  },
  displayAddButton: function() {
    if (this.props.phones.length < 3) {
      return (
        <tr style={{ border: "none" }}>
          <td className="btn-centered-container" colSpan="2">
            <button
              className="btn btn-green"
              id="addAnotherPhone"
              onClick={this.props.addPhone}
              name="addAnotherPhone"
              type="button"
            >
              <span className="fa fa-plus-circle mar-right-5" />
              {this.props.labels.addLabel}
            </button>
          </td>
        </tr>
      );
    }
  },
  createPhoneTypeList: function(phone) {
    var selectedType = phone.addrCntxtCd;
    var options = [];
    options.push(
      <option key={"select" + phone.id} value="">
        {this.props.labels.selectLabel}
      </option>
    );
    if (
      this.props.phoneTypesAvailable.indexOf("H") === -1 &&
      selectedType !== "H"
    ) {
      // do not show the option
    } else {
      options.push(
        <option key={"home" + phone.id} value="H">
          {this.getLabelForPhoneType("H")}
        </option>
      );
    }
    if (
      this.props.phoneTypesAvailable.indexOf("U") === -1 &&
      selectedType !== "U"
    ) {
      // do not show the option
    } else {
      options.push(
        <option key={"cell" + phone.id} value="U">
          {this.getLabelForPhoneType("U")}
        </option>
      );
    }
    if (
      this.props.phoneTypesAvailable.indexOf("B") === -1 &&
      selectedType !== "B"
    ) {
      // do not show the option
    } else {
      options.push(
        <option key={"work" + phone.id} value="B">
          {this.getLabelForPhoneType("B")}
        </option>
      );
    }
    return options;
  },
  getLabelForPhoneType: function(phoneType) {
    var phoneLabel = this.props.labels.homeLabel;
    if (phoneType === "U") {
      phoneLabel = this.props.labels.cellLabel;
    } else if (phoneType === "B") {
      phoneLabel = this.props.labels.workLabel;
    }
    return phoneLabel;
  },
  clearParsleyError: function(event) {
    $(event.target)
      .parsley()
      .reset(); //Reset inline error
  },
  setValidationAttributes: function(phoneInfo) {
    var flagInfo = $("#phone" + phoneInfo.id).intlTelInput(
      "getSelectedCountryData"
    );
    var countryCode = flagInfo.dialCode;
    var maxInputLength = 20;
    var inputProps = {};
    //If unknown flag
    if (phoneInfo.phoneFrmtCd === " " || countryCode === "1") {
      //NANPA
      if (flagInfo.iso2 != "uu") {
        //Known NANPA country
        inputProps = {
          required: true,
          "data-parsley-pattern": "/^[0-9]{3}-[0-9]{3}-[0-9]{4}$/",
          placeholder: "555-555-5555",
          "data-parsley-country-flag": flagInfo.iso2
        };
      } else {
        //Unknown NANPA
        inputProps = {
          required: true,
          "data-parsley-country-flag": ""
        };
      }
    } else {
      //NON-NANPA
      if (typeof flagInfo.iso2 != "undefined") {
        //Known International country
        var countryCodeLength = flagInfo.dialCode.length;
        maxInputLength = maxInputLength - countryCodeLength - 1; //max input length allowed is 20 with country code plus number plus the delimiter
      }
      inputProps = {
        required: true,
        "data-parsley-pattern": "/^[- 0-9]+$/",
        "data-parsley-country-flag":
          typeof flagInfo.iso2 != "undefined" ? flagInfo.iso2 : "",
        "data-parsley-length": "[1," + maxInputLength + "]"
      };
    }
    return inputProps;
  },
  setExtensionClass: function(phoneInfo) {
    if (phoneInfo.phoneFrmtCd === " " && phoneInfo.addrCntxtCd === "B") {
      return "showExtension";
    }
  },
  filterPhoneInputCharacter: function(event) {
    var keyCode = event.keyCode ? event.keyCode : event.which;
    if (keyCode == 43) {
      // Prevent user from entering "+" (plus) character
      event.preventDefault();
    }
  },
  restrictedPopupModal: function() {
    return (
      <OneBtnPopupModal
        id="accessRestricted"
        headerText={this.props.labels.restrictedModalHeader}
        contentText={this.props.labels.restrictedModalContent}
        primaryBtnText={this.props.labels.okayLabel}
        closeLabel={this.props.labels.closeLabel}
      />
    );
  },
  render: function() {
    // Call Shadow
    var saveHref = "#notifContainer";

    //if (this.props.callShadow) {
    //	saveHref = "javascript:void(0);";
    //}

    var createPhoneRow = function(phone) {
      return (
        <tr key={phone.id} id={"phoneEditRow" + phone.id}>
          <td data-title={this.props.labels.typeLabel}>
            <div>
              <a
                id={"phoneAnchor" + phone.id}
                tabIndex="-1"
                aria-hidden="true"
              />
              <label htmlFor={"type" + phone.id}>
                {this.props.labels.typeLabel}
              </label>
              <div className="select-arrow-wrapper">
                <select
                  data-previousval={phone.addrCntxtCd}
                  value={phone.addrCntxtCd}
                  onChange={this.props.onTypeChange}
                  id={"type" + phone.id}
                  required=""
                  className="type-dropdown form-control"
                  required={true}
                  data-parsley-required-message={
                    this.props.labels.reqFieldError
                  }
                >
                  {this.createPhoneTypeList(phone)}
                </select>
              </div>
            </div>
          </td>
          <td data-title={this.props.labels.phoneLabel}>
            <div>
              <div className={this.setExtensionClass(phone) + " inline-block"}>
                <label htmlFor={"phone" + phone.id}>
                  {this.props.labels.phoneLabel}
                </label>
                <input
                  defaultValue={this.displayPhoneNumber(phone)}
                  ref={input => {
                    this.props.createFlagDropdown(input);
                  }}
                  id={"phone" + phone.id}
                  className="phoneInput form-control"
                  type="tel"
                  onBlur={event => this.formatUsersInput(phone, event)}
                  onChange={this.props.onPhoneInputChange}
                  onKeyPress={this.filterPhoneInputCharacter}
                  maxLength="20"
                  {...this.setValidationAttributes(phone)}
                  data-parsley-required-message={
                    this.props.labels.reqFieldError
                  }
                  data-parsley-pattern-message={
                    this.props.labels.invalidFrmtError
                  }
                  data-parsley-country-flag-message={
                    this.props.labels.invalidFrmtError
                  }
                  data-parsley-length-message={this.props.labels.maxLengthError}
                />
              </div>
              {this.displayWorkExtension(phone)}
            </div>
          </td>
          <td className="removeCol">
            <a
              href="#phonesContainer"
              onClick={event => this.props.onRowDel(phone.id, event)}
            >
              {this.props.labels.removeLabel}
            </a>
          </td>
        </tr>
      );
    };
    if (this.props.phones.length > 0) {
      return (
        <div id="editContainer">
          <form
            id="phonesWidgetForm"
            className="form-group"
            data-parsley-validate
            data-parsley-focus="none"
          >
            <div className="contentArea">
              <div id="notifContainer">
                <div
                  id="server-error"
                  className="field-set-validation-errors"
                  style={{ display: "none" }}
                  tabIndex="0"
                />
                <div
                  id="error-num"
                  className="field-set-validation-errors"
                  style={{ display: "none" }}
                  tabIndex="0"
                />
              </div>
              <a id="phoneEditFormAnchor" tabIndex="-1" aria-hidden="true" />
              <table
                id="phonesTable"
                className="dataTable-responsive"
                role="presentation"
              >
                <tbody>
                  {this.props.phones.map(createPhoneRow, this)}
                  {this.displayAddButton()}
                </tbody>
              </table>
            </div>
            <div className="btnArea">
              <a
                className="btn btn-link cancel-btn"
                onClick={this.props.onCancel}
                href="#phonesContainer"
              >
                {this.props.labels.cancelLabel}
              </a>
              <a
                className="btn btn-yellow save-btn"
                onClick={this.props.onRowSave}
                href={saveHref}
              >
                {this.props.labels.saveLabel}
                <span className="sr-only"> {this.props.labels.phoneLabel}</span>
              </a>
            </div>
          </form>
          {this.restrictedPopupModal()}
        </div>
      );
    } else {
      return (
        <div id="editContainer">
          <form
            id="phonesWidgetForm"
            className="form-group"
            data-parsley-validate
            data-parsley-focus="none"
          >
            <div className="contentArea">
              <div id="notifContainer">
                <div
                  id="server-error"
                  className="field-set-validation-errors"
                  style={{ display: "none" }}
                  tabIndex="0"
                />
                <div
                  id="error-num"
                  className="field-set-validation-errors"
                  style={{ display: "none" }}
                  tabIndex="0"
                />
              </div>
              <a id="phoneEditFormAnchor" tabIndex="-1" aria-hidden="true" />
              <table
                id="phonesTable"
                className="dataTable-responsive"
                role="presentation"
              >
                <tbody>
                  <tr>
                    <td>{this.props.labels.noPhoneLabel}</td>
                  </tr>
                  {this.displayAddButton()}
                </tbody>
              </table>
            </div>
            <div className="btnArea">
              <a
                className="btn btn-link cancel-btn"
                onClick={this.props.onCancel}
                href="#phonesContainer"
              >
                {this.props.labels.cancelLabel}
              </a>
              <a
                className="btn btn-yellow save-btn"
                onClick={this.props.onRowSave}
                href={saveHref}
              >
                {this.props.labels.saveLabel}
                <span className="sr-only"> {this.props.labels.phoneLabel}</span>
              </a>
            </div>
          </form>
          {this.restrictedPopupModal()}
        </div>
      );
    }
  }
});

module.exports = PhoneRowEdit;
