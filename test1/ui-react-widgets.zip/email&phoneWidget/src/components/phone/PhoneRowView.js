/* var $ = require('jquery'); */
import { AlertBox } from "../commons/AlertBox";

var React = require("react");

var PhoneRowView = React.createClass({
  getInitialState: function() {
    return {
      editing: null
    };
  },
  toggleEditing(rowId) {
    this.setState({ editing: rowId });
    //$("tr:first").css("background-color", "red");
  },

  handleChange: function(event) {
    this.setState({ value: event.target.value });
  },
  getCorrectNum(phoneInfo) {
    if (phoneInfo.phoneFrmtCd === "I") {
      return $("#editContainer #phone" + phoneInfo.id).val();
    } else {
      return this.props.formatNANPA(phoneInfo.phoneAreaCd + phoneInfo.phoneNum);
    }
  },
  getCorrectCountryCode: function(rowID) {
    var dialCode = $(
      "#phoneEditRow" + rowID + " input.phoneInput"
    ).intlTelInput("getSelectedCountryData").dialCode;

    if (typeof dialCode === "undefined") {
      //Don't set the dial/country code if it's undefined and remove "+" in phone number
      var curVal = $("#phoneEditRow" + rowID + " input.phoneInput").val();
      if (typeof curVal != "undefined") {
        if (curVal[0] == "+") {
          var updatedVal = curVal.substring(1);
          $("#phoneEditRow" + rowID + " input.phoneInput").val(updatedVal);
        }
      }
      return "";
    }
    return "+" + dialCode;
  },
  getCorrectFlag: function(phoneInfo) {
    return $("#phoneEditRow" + phoneInfo.id + " input.phoneInput").intlTelInput(
      "getSelectedCountryData"
    ).iso2;
  },
  displayWorkExtension(phoneInfo, labelInfo, displayMode) {
    if (
      phoneInfo.addrCntxtCd === "B" &&
      phoneInfo.phoneExtNum != "" &&
      phoneInfo.phoneFrmtCd === " "
    ) {
      return (
        <span>
          <span className="extSeperator">{labelInfo.extSepLabel}</span>
          {phoneInfo.phoneExtNum}
        </span>
      );
    }
  },
  displayPhoneType: function(phoneInfo, labelInfo) {
    if (phoneInfo.addrCntxtCd === "B") {
      return labelInfo.workLabel;
    } else if (phoneInfo.addrCntxtCd === "H") {
      return labelInfo.homeLabel;
    } else {
      return labelInfo.cellLabel;
    }
  },
  render: function() {
    var createPhoneRow = function(phone) {
      return (
        <tr key={phone.id} id={"viewRow" + phone.id}>
          <td
            data-title={this.props.labels.typeLabel}
            aria-label={this.props.labels.typeLabel}
          >
            <div>{this.displayPhoneType(phone, this.props.labels)}</div>
          </td>
          <td
            data-title={this.props.labels.phoneLabel}
            aria-label={this.props.labels.phoneLabel}
          >
            <div className="viewPhone">
              <div className={"iti-flag " + this.getCorrectFlag(phone)}> </div>
              <div className="countryCode">
                {this.getCorrectCountryCode(phone.id)}
              </div>
              <div className="phoneNumber">{this.getCorrectNum(phone)}</div>
              <div className="workExtension">
                {this.displayWorkExtension(
                  phone,
                  this.props.labels,
                  this.props.displayMode
                )}
              </div>
            </div>
          </td>
        </tr>
      );
    };

    if (typeof (this.props.phones != "undefined") && !this.props.serverError) {
      if (this.props.phones.length > 0) {
        return (
          <div id="viewContainer">
            <div className="contentArea">
              <div id="successNotifContainer">
                <div
                  id="successful-save-phone-msg"
                  className="field-set-validation-success"
                  style={{ display: "none" }}
                  tabIndex="0"
                >
                  {this.props.labels.successLabel}
                </div>
              </div>
              <table
                id="phonesTable"
                className="dataTable-responsive"
                role="presentation"
                style={{ width: "100%" }}
              >
                <tbody>{this.props.phones.map(createPhoneRow, this)}</tbody>
              </table>
            </div>
            <div className="btnArea">
              <a
                className="btn btn-blue btn-large xs-full-width"
                onClick={this.props.onEdit}
                href="#phonesContainer"
              >
                {this.props.labels.editLabel}
                <span className="sr-only"> {this.props.labels.phoneLabel}</span>
              </a>
            </div>
          </div>
        );
      } else {
        return (
          <div id="viewContainer">
            <div className="contentArea">
              <div id="successNotifContainer">
                <div
                  id="successful-save-phone-msg"
                  className="field-set-validation-success"
                  style={{ display: "none" }}
                  tabIndex="0"
                >
                  {this.props.labels.successLabel}
                </div>
              </div>
              <table
                id="phonesTable"
                className="dataTable-responsive"
                role="presentation"
                style={{ width: "100%" }}
              >
                <tbody>
                  <tr>
                    <td className="autoWidth">
                      {this.props.labels.noPhoneLabel}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="btnArea">
              <a
                className="btn btn-blue"
                onClick={this.props.onEdit}
                href="#phonesContainer"
              >
                {this.props.labels.editLabel}
                <span className="sr-only"> {this.props.labels.phoneLabel}</span>
              </a>
            </div>
          </div>
        );
      }
    } else {
      return (
        <div id="viewContainer">
          <div className="outage-container">
            <AlertBox
              stylingClasses="slf-burgundy-bg-10 slf-alert-box-error"
              childrenElements={this.props.labels.apologyError}
            />
          </div>
        </div>
      );
    }
  }
});

module.exports = PhoneRowView;
