var React = require('react');
var PhoneRowView = require('./PhoneRowView');
var PhoneRowEdit = require('./PhoneRowEdit');

var PhoneTable = React.createClass({

	handleSaveRow: function( newphone ) {
			this.props.onRowSaveHandler(newphone);
	},

	render: function() {
		
		return (
			<div>
				<PhoneRowView onEdit={this.props.onEdit} phones={this.props.phonesList} labels={this.props.phoneLabels} displayMode={this.props.displayMode} formatNANPA={this.props.formatNANPAPhone} serverError={this.props.serverError}/>
				<PhoneRowEdit phoneTypesAvailable={this.props.availablePhoneTypes} phones={this.props.phonesList} labels={this.props.phoneLabels} displayMode={this.props.displayMode} onRowDel={this.props.onRowDelete} onRowSave={this.props.onRowSave} onCancel={this.props.onCancel} formatNANPA={this.props.formatNANPAPhone} onInputChange={this.props.onInputChange} removePhoneType={this.props.removePhoneType} onTypeChange={this.props.onPhoneTypeChange} onExtensionChange={this.props.onPhoneExtensionChange} onPhoneInputChange={this.props.onPhoneInputChange} addPhone={this.props.onPhoneAdd} createFlagDropdown={this.props.createFlagDropdown} callShadow={this.props.callShadow}/>
			</div>		
		);
	}
});

module.exports = PhoneTable;
