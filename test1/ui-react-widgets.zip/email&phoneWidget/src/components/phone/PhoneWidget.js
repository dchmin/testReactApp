var React = require("react");
var PhoneTable = require("./PhoneTable");

// Custom Parsley Validator
window.Parsley.addValidator("countryFlag", {
  requirementType: "string",
  validateString: function(inputVal, flagVal) {
    // Verify that flag is not empty
    return flagVal !== "";
  },
  priority: 599
});

//Added for phone flag dropdown web accessibility
$(document).on("keydown", function(e) {
  var key = e.which;
  var upKey = 38;
  var downKey = 40;
  if (key == upKey || key == downKey) {
    //find the focused item in the country list
    var current = $(e.target)
      .next()
      .find("li.highlight");
    var next = key == upKey ? current.prev() : current.next();
    //update the aria-activedescendant with the country focused on the dropdown
    $(e.target).attr("aria-activedescendant", next.attr("id"));
  }
});

// Global variables
var saveMsgTimer = null; //Used for reseting timer for the successful saved message
var animateHideTimer = null; //Used for animating the save succesful message
var pageName = "Personal Information";
var callShadow = false;
// Initializa Language and Data
var lang =
  document.getElementsByTagName("html")[0].getAttribute("lang") + "_CA";
if (lang === undefined || lang === null) {
  lang = "en_CA";
}
var labels = lang === "en_CA" ? phoneContent.en : phoneContent.fr;
var PhoneWidget = React.createClass({
  getInitialState: function() {
    return {
      originalPhonesState: [],
      currentPhonesState: [],
      phoneTypesAvailable: ["H", "U", "B"],
      displayMode: "viewMode",
      pageLang: "en_CA",
      serverError: false
    };
  },
  extractInternationalCountryCode: function(phoneInfo) {
    return phoneInfo;
  },
  formatNANPA: function(phoneNum) {
    phoneNum = phoneNum.replace(/\s/g, "");
    phoneNum = phoneNum.replace(/\D/g, "");
    phoneNum = phoneNum.replace(/(\d{3})(\d{3})/, "$1-$2-");
    return phoneNum;
  },
  initPhoneInput: function(currentPhoneInput) {
    // Don't initialize phone library if object is null or if object is already initialized
    if (
      currentPhoneInput == null ||
      typeof $(currentPhoneInput).intlTelInput("getNumber") == "string"
    ) {
      return;
    }
    var appObject = this;
    //initializing the phone input with flag dropdown
    $(currentPhoneInput).intlTelInput({
      autoHideDialCode: true,
      autoPlaceholder: "polite",
      preferredCountries: ["ca", "us"],
      separateDialCode: true
    });

    //Code added for flag dropdown web accessibility START
    var phoneContainer = $(currentPhoneInput).parent();

    phoneContainer.find(".selected-flag").attr("role", "combobox");
    phoneContainer.find(".selected-flag").attr("aria-autocomplete", "list");
    phoneContainer.find(".country-list").attr("role", "listbox");
    phoneContainer.find("li.country").attr("role", "option");
    phoneContainer
      .find(".country-list")
      .attr("id", currentPhoneInput.id + "country-list");
    phoneContainer
      .find(".selected-flag")
      .attr("aria-owns", currentPhoneInput.id + "country-list");
    phoneContainer
      .find("ul")
      .find("li")
      .each(function(index) {
        $(this).attr("id", currentPhoneInput.id + "selectedCountry" + index);
      });
    if (phoneContainer.find("li.active").length !== 0) {
      if (typeof phoneContainer.find(".selected-flag") !== "undefined") {
        phoneContainer
          .find(".selected-flag")
          .attr(
            "aria-activedescendant",
            phoneContainer.find("li.active").attr("id")
          );
      }
    } else {
      if (
        typeof phoneContainer.find(".selected-flag") !== "undefined" &&
        typeof phoneContainer.find("li")[0] !== "undefined"
      ) {
        phoneContainer
          .find(".selected-flag")
          .attr("aria-activedescendant", phoneContainer.find("li")[0].id);
      }
      if (typeof phoneContainer.find("li")[0] !== "undefined") {
        $(phoneContainer.find("li")[0]).addClass("highlight");
      }
    }
    //Add title for the unknown countries for web accessibility
    if (
      phoneContainer.find(".selected-flag .iti-flag").hasClass("uu") ||
      phoneContainer.find(".selected-flag .iti-flag")[0].classList.length === 1
    ) {
      phoneContainer
        .find(".selected-flag")
        .attr("title", labels.unknownCountryLabel);
    }
    //Code added for flag dropdown web accessibility END

    //adding styling for flag dropdown on validation fail
    $(currentPhoneInput)
      .parsley()
      .on("field:error", function() {
        if (this.validationResult[0].assert.name === "countryFlag") {
          this.$element.parent().addClass("parsley-flagError");
        }
      });

    $(".selected-flag .uu")
      .closest(".separate-dial-code")
      .addClass("unknownCtry");

    $(currentPhoneInput).on("countrychange", function(event, countryData) {
      $(".unknownCtry").removeClass("unknownCtry");
      $(".selected-flag .uu")
        .closest(".separate-dial-code")
        .addClass("unknownCtry");
      var rowId = this.id.replace("phone", "");
      var index = appObject.findIndexByProperty(
        rowId,
        appObject.state.currentPhonesState,
        "id"
      );
      var temp = JSON.parse(JSON.stringify(appObject.state.currentPhonesState));
      var curVal = $(event.target).val();

      if (countryData.dialCode === "1") {
        temp[index].phoneFrmtCd = " ";
        temp[index].forgnCountryCode = "";

        temp[index] = appObject.setNanpaNumber(temp[index], curVal);
      } else {
        temp[index].phoneFrmtCd = "I";
        temp[index].forgnCountryCode = countryData.dialCode;

        temp[index] = appObject.setNonNanpaNumber(temp[index], curVal);
      }
      $(this)
        .parsley()
        .reset(); //Reset inline error
      $(this)
        .parent()
        .removeClass("parsley-flagError");
      appObject.setState({ currentPhonesState: temp });
    });
  },
  resetFlagDropdown: function(currentPhonesState) {
    for (var i = 0; i < currentPhonesState.length; i++) {
      var currentPhoneInput =
        "#phoneEditRow" + currentPhonesState[i].id + " input.phoneInput";
      var currentCountryCode = "+1";

      if (currentPhonesState[i].phoneFrmtCd === "I") {
        // if Non-NANPA phone
        $(currentPhoneInput).intlTelInput(
          "setNumber",
          "+" +
            currentPhonesState[i].forgnCountryCode +
            currentPhonesState[i].forgnPhonNum
        );
      } else {
        //NANPA phone number
        $(currentPhoneInput).intlTelInput(
          "setNumber",
          currentCountryCode +
            this.formatNANPA(
              currentPhonesState[i].phoneAreaCd + currentPhonesState[i].phoneNum
            )
        );
      }
    }
  },
  setCustomPlaceholder: function(
    selectedCountryPlaceholder,
    selectedCountryData
  ) {
    if (selectedCountryData.iso2 == "uu") {
      //Unknown NANPA
      return "";
    } else if (selectedCountryData.dialCode == "1") {
      //NANPA
      return "555-555-5555";
    } else {
      var newPlaceholder = selectedCountryPlaceholder.replace(/[\(\)]/g, "");
      return newPlaceholder;
    }
  },
  handlePhoneInputChange: function(event) {
    $(event.target)
      .parsley()
      .reset(); //Reset inline error
    // Get the area code and update flag to correct country
    $(event.target)
      .parents(".parsley-flagError")
      .removeClass("parsley-flagError");
    var curVal = event.target.value;
    var rowId = event.target.id.replace("phone", "");
    var index = this.findIndexByProperty(
      rowId,
      this.state.currentPhonesState,
      "id"
    );
    var temp = JSON.parse(JSON.stringify(this.state.currentPhonesState));

    var dialCode = $(event.target).intlTelInput("getSelectedCountryData")
      .dialCode;

    if (curVal.indexOf("+") != -1) {
      // Remove characters that shouldn't be inputted
      var positions = this.getCursorPosition(event.target);
      curVal = curVal.replace(/\+/g, "");
      $(event.target).val(curVal);
      this.setCursorPosition(event.target, positions);
    }
    // Update the state
    if (dialCode === "1") {
      //NANPA number
      temp[index] = this.setNanpaNumber(temp[index], curVal);
    } else {
      // NON-NANPA (International) number
      temp[index] = this.setNonNanpaNumber(temp[index], curVal);
    }
    this.setState({ currentPhonesState: temp });
  },
  getCursorPosition(ele) {
    var positions;
    // Get cursor position for IE >=9 and other browsers
    if (ele.selectionStart || ele.selectionStart == "0") {
      positions = { start: ele.selectionStart, end: ele.selectionEnd };
    } else {
      positions = { start: 0, end: 0 };
    }
    return positions;
  },
  setCursorPosition(ele, positions) {
    // Set cursor position for IE >=9 and other browsers
    if (ele.setSelectionRange) {
      ele.setSelectionRange(positions.start, positions.end);
    }
  },
  setNanpaNumber: function(temp, curVal) {
    var phoneNumVal = curVal.replace(/\D/g, "");
    temp.phoneAreaCd = phoneNumVal.slice(0, 3);
    temp.phoneNum = phoneNumVal.slice(3);
    temp.forgnPhonNum = "";
    return temp;
  },
  setNonNanpaNumber: function(temp, curVal) {
    temp.phoneAreaCd = "";
    temp.phoneNum = "";
    temp.forgnPhonNum = curVal;
    return temp;
  },
  componentDidMount: function() {
    if (process.env.NODE_ENV === "production") {
      var url = phoneDetailsServiceURL + "/" + lang;
    } else {
      var url = phoneDetailsServiceURL;
    }
    this.setState({ pageLang: lang });

    var originalDisplayMode =
      $("#phoneNumWidget").attr("displayMode") === "edit"
        ? "editMode"
        : "viewMode";
    this.setState({ displayMode: originalDisplayMode });
    var appObject = this; //Save the current react object for ajax call
    // Set Initial State for Data and Labels
    $.ajax({
      url: url,
      dataType: "json",
      cache: false,
      success: function(data) {
        for (var i = 0; i < data.phoneInfo.length; i++) {
          if (
            data.phoneInfo[i].phoneFrmtCd === "I" &&
            (
              data.phoneInfo[i].forgnCountryCode +
              data.phoneInfo[i].forgnPhonNum
            ).charAt(0) === "1"
          ) {
            var phoneNum = (
              data.phoneInfo[i].forgnCountryCode +
              data.phoneInfo[i].forgnPhonNum
            ).replace(/\D/g, "");
            data.phoneInfo[i].phoneFrmtCd = " ";
            data.phoneInfo[i].phoneAreaCd = phoneNum.slice(1, 4);
            data.phoneInfo[i].phoneNum = phoneNum.slice(4);
            data.phoneInfo[i].forgnPhonNum = "";
            data.phoneInfo[i].forgnCountryCode = "";
          }
        }
        this.setState({ currentPhonesState: data.phoneInfo });
        this.setState({ originalPhonesState: data.phoneInfo.slice(0) });
        if (typeof data.callShadow != "undefined") {
          callShadow = data.callShadow;
        }

        //set the label for phone flag dropdown
        $(".selected-flag").attr("aria-label", labels.countryCdLabel);

        //remove existing phoneTypes from phoneTypesAvailable list
        for (var j = 0; j < data.phoneInfo.length; j++) {
          this.removePhoneType(data.phoneInfo[j].addrCntxtCd);
        }
      }.bind(this),
      error: function(xhr, status, err) {
        appObject.setState({
          serverError: true
        });
      }
    });
  },
  handleDeleteRowSubmit(phoneId, event) {
    if (!$("#phonesWidgetForm").hasClass("form-disabled")) {
      var currPhoneState = JSON.parse(
        JSON.stringify(this.state.currentPhonesState)
      );
      var index = this.findIndexByProperty(phoneId, currPhoneState, "id");
      if (index >= 0) {
        // Add the deleted Phone Type to list of available Phone Types
        this.addPhoneType(currPhoneState[index].addrCntxtCd);
        // Remove deleted row and update State
        currPhoneState.splice(index, 1);

        // Get the id of the appropriate row to focus on
        var focusPhoneAnchor = this.getPreviousPhoneRowID(
          currPhoneState,
          index
        );

        // Update the states
        this.setState(
          { currentPhonesState: currPhoneState },
          this.delPhoneStateCallBack(focusPhoneAnchor)
        );
      }

      event.preventDefault();
    }
  },

  getPreviousPhoneRowID(currPhoneState, delPhoneIndex) {
    var focusPhoneAnchor = "phoneAnchor";

    if (currPhoneState.length == 0) {
      //All phone numbers are deleted
      return "phoneEditFormAnchor";
    } else if (delPhoneIndex == 0) {
      //First row being deleted - focus on row below
      return focusPhoneAnchor + currPhoneState[delPhoneIndex].id;
    } else {
      //Any other row being deleted - focus on row prior to it
      return focusPhoneAnchor + currPhoneState[delPhoneIndex - 1].id;
    }
  },

  delPhoneStateCallBack: function(focusPhoneAnchor) {
    // Put focus back on the phone row
    if (
      document.getElementById(focusPhoneAnchor) != null &&
      document.getElementById(focusPhoneAnchor) != undefined
    ) {
      $("#" + focusPhoneAnchor).focus();
    }
  },

  createArrayWithNewPhone: function() {
    var id = 0;
    var temp = [];
    if (this.state.currentPhonesState.length > 0) {
      id =
        this.state.currentPhonesState[this.state.currentPhonesState.length - 1]
          .id + 1;
      temp = JSON.parse(JSON.stringify(this.state.currentPhonesState));
    }
    var phone = {
      id: id,
      phoneNum: "",
      phoneAreaCd: "",
      forgnPhonNum: "",
      phoneFrmtCd: " ",
      phoneExtNum: "",
      addrCntxtCd: "",
      forgnCountryCode: ""
    };
    temp.push(phone);
    return temp;
  },
  handleAddPhone: function() {
    var newPhoneData = this.createArrayWithNewPhone();
    this.setState(
      { currentPhonesState: newPhoneData },
      this.addPhoneStateCallBack
    );
  },
  addPhoneStateCallBack: function() {
    $(".type-dropdown:visible:last").focus();
  },
  findIndexByProperty: function getIndex(value, arr, prop) {
    for (var i = 0; i < arr.length; i++) {
      if (arr[i][prop] == value) {
        return i;
      }
    }
    return -1; //to handle the case where the value doesn't exist
  },
  showErrorCounter: function() {
    $("#server-error").hide();
    var errorCount = $("#phonesWidgetForm .parsley-errors-list").children()
      .length;
    if (errorCount != 0) {
      if (errorCount === 1) {
        $("#error-num").text(labels.oneError);
      } else {
        var errorMsg = labels.multipleErrors.replace("<x>", errorCount);
        $("#error-num").text(errorMsg);
      }
      $("#error-num").show();
      $("#error-num").focus();
    } else {
      $("#error-num, #server-error").hide();
    }
  },

  handleSaveRowSubmit: function() {
    $("#phonesWidgetForm")
      .parsley()
      .validate();
    this.showErrorCounter();
    if (
      $("#phonesWidgetForm")
        .parsley()
        .isValid() &&
      !$("#phonesWidgetForm").hasClass("form-disabled")
    ) {
      if (callShadow) {
        $("#accessRestricted").modal({ backdrop: "static" });
      } else {
        this.disableFields();
        this.savePhoneRowEdit(true);
      }
    }
  },
  getFormatCode: function(rowID) {
    //TODO: return either "I" or " "
  },
  disableFields: function() {
    // Input fields
    $("#phonesWidgetForm").addClass("form-disabled");
    $("#phonesTable input, #phonesTable select, #addAnotherPhone").prop(
      "disabled",
      true
    );
    $(
      "#phonesTable .selected-flag, #phonesTable .removeCol a, .btnArea .cancel-btn"
    ).prop("tabindex", "-1");

    // Save Button
    $("#phoneNumWidget .save-btn").text(labels.validatingLabel);
    $("#phoneNumWidget .save-btn").addClass("is-busy");
  },
  enableFields: function() {
    $("#phonesWidgetForm").removeClass("form-disabled");
    $("#phonesTable input, #phonesTable select, #addAnotherPhone").prop(
      "disabled",
      false
    );
    $("#phonesTable .removeCol a, .btnArea .cancel-btn").removeAttr("tabindex");
    $("#phonesTable .selected-flag").prop("tabindex", "0");

    // Save button
    $("#phoneNumWidget .save-btn").html(
      labels.saveLabel +
        '<span class="sr-only"> ' +
        labels.phoneLabel +
        "</span>"
    );
    $("#phoneNumWidget .save-btn").removeClass("is-busy");
  },
  savePhoneRowEdit: function(saveToDB) {
    // Save current phone values entered in the PhoneRowEdit 'page'
    // in the'currentPhonesState' state.
    var newPhonesValuesArray = JSON.parse(
      JSON.stringify(this.state.currentPhonesState)
    );

    for (var i = 0; i < newPhonesValuesArray.length; i++) {
      var targetRowIndex = newPhonesValuesArray[i].id;

      var newAddrCntxtCd = $("#type" + targetRowIndex).val();
      var countryCode = $("#phone" + targetRowIndex).intlTelInput(
        "getSelectedCountryData"
      ).dialCode;
      if (typeof countryCode === "undefined") {
        countryCode = "";
      }
      if (targetRowIndex >= 0) {
        if (countryCode === "1") {
          //NANPA number
          var phoneNumVal = $("#phone" + targetRowIndex)
            .val()
            .replace(/\D/g, "");
          var newPhoneAreaCode = phoneNumVal.slice(0, 3);
          var newPhoneNum = phoneNumVal.slice(3);
          var newPhoneExtNum = $("#ext" + targetRowIndex).val();
          var newPhoneFrmtCd = " ";
          var newForgnPhoneNum = "";
          var newForgnCountryCd = "";
          if (newAddrCntxtCd != "B") {
            //clear extension if not work type
            newPhoneExtNum = "";
          }
        } else {
          // International Number
          var newPhoneAreaCode = "";
          var newPhoneNum = "";
          var newPhoneExtNum = "";
          var newPhoneFrmtCd = "I";
          var newForgnPhoneNum = $("#phone" + targetRowIndex).val();
          var newForgnCountryCd = countryCode;
        }

        newPhonesValuesArray[i].addrCntxtCd = newAddrCntxtCd;
        newPhonesValuesArray[i].phoneAreaCd = newPhoneAreaCode;
        newPhonesValuesArray[i].phoneNum = newPhoneNum;
        newPhonesValuesArray[i].phoneExtNum = newPhoneExtNum;
        newPhonesValuesArray[i].phoneFrmtCd = newPhoneFrmtCd;
        newPhonesValuesArray[i].forgnPhonNum = newForgnPhoneNum;
        newPhonesValuesArray[i].forgnCountryCode = newForgnCountryCd;
      }
    }
    // Update currentPhoneState
    this.setState({ currentPhonesState: newPhonesValuesArray });
    if (saveToDB) {
      var appObject = this; //Save the current react object for ajax call
      var apologyError = labels.apologyError;
	  let csrfToken = document.getElementsByName('CSRFToken')[0] ? document.getElementsByName('CSRFToken')[0].value : "";
      // Ajax call to update backend DB
      $.ajax({
		headers: {
		'MBRWIDGETS-ANTICSRF-TOKEN': csrfToken
		},
        url: submitPhoneServiceURL + "/" + this.state.pageLang,
        type: "POST",
        data: JSON.stringify(newPhonesValuesArray),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(response) {
          appObject.resetFlagDropdown(newPhonesValuesArray);
          appObject.enableFields();
          if (response.errorCode == "0" || response.errorCode == "-1") {
            appObject.setState({ displayMode: "viewMode" });
            appObject.displaySaveSuccessMsg(appObject); //Show "save successful" message
            appObject.setState({
              originalPhonesState: appObject.state.currentPhonesState
            });

            //tealium tagging for tracking number of successful saves
            if (typeof utag !== "undefined") {
              utag.link({
                ev_type: "other",
                ev_action: "clk",
                ev_title: pageName,
                ev_data_one: "Phone - Successful Save"
              });
            }
          } else {
            $("#server-error").text(response.errorMsg);
            $("#server-error").show();
            document.getElementById("server-error").focus();
          }
        },
        error: function(xhr, status, err) {
          appObject.enableFields();
          $("#server-error").text(labels.apologyError);
          $("#server-error").show();
          document.getElementById("server-error").focus();
          // Check if the Siteminder secure session has expired and redirect to the session timeout page if url is provided by Siteminder.
          //ajaxUtilityFunctions.checkSiteminderSecureSessionTimeout(jqXHR);
        }
      });
    }
  },
  displaySaveSuccessMsg: function(appObject) {
    $("#successful-save-phone-msg").show(); //Show "save successful" message
    $("#successful-save-phone-msg").focus();
    if (saveMsgTimer) {
      //Cancel the previous timer
      clearTimeout(saveMsgTimer);
      saveMsgTimer = null;
    }
    saveMsgTimer = setTimeout(function() {
      appObject.easeOutMsg();
    }, 5000); //Animate fading of message
  },
  hideSaveSuccessMsg: function() {
    // Clear timer
    clearTimeout(saveMsgTimer);
    saveMsgTimer = null;
    // Hide message
    var savedPhoneMsg = $("#successful-save-phone-msg");
    savedPhoneMsg.hide();
    savedPhoneMsg.removeClass("hideElementAnimate");
  },
  easeOutMsg: function() {
    var appObject = this; //Save React pointer
    var savedPhoneMsg = $("#successful-save-phone-msg");
    savedPhoneMsg.addClass("hideElementAnimate");
    savedPhoneMsg.one("transitionend", function(e) {
      //Animate fading of message
      appObject.hideSaveSuccessMsg();
    });
  },

  handleEditClick: function() {
    this.setState({ displayMode: "editMode" });
    this.hideSaveSuccessMsg(); //Hide "save successful" message
    if (this.state.currentPhonesState.length === 0) {
      var newPhoneData = this.createArrayWithNewPhone();
      this.setState({ currentPhonesState: newPhoneData });
    }
    //tealium tagging for tracking edit button clicks
    if (typeof utag !== "undefined") {
      utag.link({
        ev_type: "other",
        ev_action: "clk",
        ev_title: pageName,
        ev_data_one: "Phone - Edit"
      });
    }
  },
  handleCancelClick: function() {
    if (!$("#phonesWidgetForm").hasClass("form-disabled")) {
      $("#phonesWidgetForm")
        .parsley()
        .reset();
      $(".parsley-flagError").removeClass("parsley-flagError");
      $("#error-num, #server-error").hide();
      var previousPhonesState = JSON.parse(
        JSON.stringify(this.state.originalPhonesState)
      );
      this.resetFlagDropdown(previousPhonesState);
      this.setState(
        { currentPhonesState: previousPhonesState },
        this.cancelCallback
      );
      //remove existing phoneTypes from phoneTypesAvailable list
      var allPhoneTypes = ["H", "U", "B"];
      for (var j = 0; j < previousPhonesState.length; j++) {
        var index = allPhoneTypes.indexOf(previousPhonesState[j].addrCntxtCd);
        if (index >= 0) {
          allPhoneTypes.splice(index, 1);
        }
        //	this.removePhoneType(previousPhonesState[j].addrCntxtCd);
      }
      this.setState({ phoneTypesAvailable: allPhoneTypes });
    }
  },
  cancelCallback: function() {
    this.setState({ displayMode: "viewMode" });
  },
  removePhoneType: function(phoneType) {
    var typeList = this.state.phoneTypesAvailable;
    var index = typeList.indexOf(phoneType);
    if (index >= 0) {
      typeList.splice(index, 1);
      this.setState({ phoneTypesAvailable: typeList });
    }
  },
  addPhoneType: function(phoneType) {
    var typeList = this.state.phoneTypesAvailable;
    var index = typeList.indexOf(phoneType);
    if (index == -1) {
      typeList.push(phoneType);
      this.setState({ phoneTypesAvailable: typeList });
    }
  },
  handlePhoneTypeChange: function(event) {
    var curValue = event.target.value;
    var prevValue = event.target.getAttribute("data-previousval");
    this.addPhoneType(prevValue);
    this.removePhoneType(curValue);

    event.target.dataset.previousval = curValue;
    var rowId = event.target.id.replace("type", "");
    var index = this.findIndexByProperty(
      rowId,
      this.state.currentPhonesState,
      "id"
    );
    if (index >= 0) {
      var temp = JSON.parse(JSON.stringify(this.state.currentPhonesState));
      temp[index].addrCntxtCd = curValue;
      temp[index].phoneExtNum = "";
      this.setState({ currentPhonesState: temp });
    }
    $(event.target)
      .parsley()
      .reset(); //Reset inline error
  },
  handleExtensionChange: function(event) {
    $(event.target)
      .parsley()
      .reset();
    var curVal = event.target.value;
    var rowId = event.target.id.replace("ext", "");
    var index = this.findIndexByProperty(
      rowId,
      this.state.currentPhonesState,
      "id"
    );
    if (index >= 0) {
      var temp = JSON.parse(JSON.stringify(this.state.currentPhonesState));
      temp[index].phoneExtNum = curVal;
      this.setState({ currentPhonesState: temp });
    }
  },
  render: function() {
    return (
      <div
        id="phonesContainer"
        className={this.state.displayMode + " no-outline"}
        tabIndex="-1"
      >
        <h2>{labels.phoneWidgetTitle}</h2>
        <PhoneTable
          phonesList={this.state.currentPhonesState}
          availablePhoneTypes={this.state.phoneTypesAvailable}
          phoneLabels={labels}
          displayMode={this.state.displayMode}
          onRowDelete={this.handleDeleteRowSubmit}
          onRowSave={this.handleSaveRowSubmit}
          formatNANPAPhone={this.formatNANPA}
          onEdit={this.handleEditClick}
          onCancel={this.handleCancelClick}
          onInputChange={this.handleInputChange}
          removePhoneType={this.removePhoneType}
          onPhoneTypeChange={this.handlePhoneTypeChange}
          onPhoneExtensionChange={this.handleExtensionChange}
          onPhoneInputChange={this.handlePhoneInputChange}
          onPhoneAdd={this.handleAddPhone}
          createFlagDropdown={this.initPhoneInput}
          callShadow={callShadow}
          serverError={this.state.serverError}
        />
      </div>
    );
  }
});

module.exports = PhoneWidget;
