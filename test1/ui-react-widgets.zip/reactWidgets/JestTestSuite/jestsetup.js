/*
 * Set globally used tools for testcases
 */

import "raf/polyfill"; //React 16 (enzyme-adapter-react-16) needs that polyfill
import { configure, shallow, mount } from "enzyme";
import { shallowToJson } from "enzyme-to-json";
import Adapter from "enzyme-adapter-react-16";

/*
 * Importing testing utils
 */
configure({ adapter: new Adapter() });

global.shallow = shallow;
global.shallowToJson = shallowToJson;
global.mount = mount;

/* 
 * jsdom for mocking of HTML
 */
const { jsdom } = require("jsdom");
let dom = jsdom(
  '<!doctype html><html lang="en"><body><p>Hello world</p><div id="root"></div></body></html>'
);

global.dom = dom;
global.document = dom;

global.window = document.defaultView;
global.navigator = {
  userAgent: "node.js"
};

function copyProps(src, target) {
  const props = Object.getOwnPropertyNames(src)
    .filter(prop => typeof target[prop] === "undefined")
    .reduce(
      (result, prop) => ({
        ...result,
        [prop]: Object.getOwnPropertyDescriptor(src, prop)
      }),
      {}
    );
  Object.defineProperties(target, props);
}
copyProps(document.defaultView, global);