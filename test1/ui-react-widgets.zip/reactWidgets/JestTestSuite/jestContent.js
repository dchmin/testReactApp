//---------------------------------
// Paperless Widget
//---------------------------------
global.paperlessContent = require("./content/paperlessContent.js").paperlessContent;
global.permissionPopupContent = require("./content/permissionModalContent.js").permissionPopupContent;

//---------------------------------
// Email Widget
//---------------------------------
//global.emailContent = require("../public/emailContent.js").emailContent;
