import React from "react";
import EmailWidget from '../../../src/components/email/EmailWidget';


it("should create a new empty email row on click of the add button", () => {
  let app = shallow(<EmailWidget />);
  
  let rowAdd = app.instance().createNewEmptyRow();
  
  // expect(app.state[emails]).
})

// test('createNewEmptyRow adds a new empty email row', () => {
//   const startState = {
//     emails: [{
//       id: 1,
//       emailAddrNm: "test@testing.com",
//       addrCntxtCd: "H",
//       emailAddrStatCd: "VA",
//       preferredEmail: "Y",
//       friendlyId: "N"
//     }],
//     originalEmails: [{
//       id: 1,
//       emailAddrNm: "test@testing.com",
//       addrCntxtCd: "H",
//       emailAddrStatCd: "VA",
//       preferredEmail: "Y",
//       friendlyId: "N"
//     }]
//   }
//   const finState = EmailWidget.createNewEmptyRow;
//   expect(finState.emails).toEqual([
//     {
//       id: 1,
//       emailAddrNm: "test@testing.com",
//       addrCntxtCd: "H",
//       emailAddrStatCd: "VA",
//       preferredEmail: "Y",
//       friendlyId: "N"
//     },
//     {
//       id: 2,
//       emailAddrNm: "",
//       addrCntxtCd: "",
//       emailAddrStatCd: "",
//       preferredEmail: "N",
//       friendlyId: "N"
//     }
//   ])
// });