import React from 'react';
import EmailViewTable from '../../../src/components/email/EmailViewTable';

describe("Email - ViewTable", () => {
  it("render - en", () => {
    document.querySelector("html").setAttribute("lang", "en");
    let emails = [{
      "friendlyId": "N",
      "preferredEmail": "Y",
      "emailAddrNm": "s.henriques@sunlife.com",
      "id": 1,
      "addrCntxtCd": "B",
      "emailAddrStatCd": "OK"
    }];
    let emailTypes = [
      {
        id: "O",
        desc_En: "Type",
        desc_Fr: "Type"
      },
      {
        id: "H",
        desc_En: "Personal",
        desc_Fr: "Domicile"
      },
      {
        id: "B",
        desc_En: "Work",
        desc_Fr: "Bureau"
      }
    ]
    const result = shallow(<EmailViewTable emailTypes={emailTypes} emails={emails} originalEmails={emails}/>);
    expect(shallowToJson(result)).toMatchSnapshot();
  })
})