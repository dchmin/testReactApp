import React from 'react';

import ButtonLink from "../../../src/components/commons/ButtonLink";

describe('Commons - ButtonLink', function() {
	
	it ("render", () => {	
		const contentEn = global.paperlessContent.en;                 
		const mockCallBack = jest.fn();

		// Generate result
		const result = shallow(
			<ButtonLink 
				id="button-id"
				value={contentEn.editLabel}
				cssClass="btn btn-blue"
				href="#paperlessContainer"
				onClick={mockCallBack}
				disabled="false"
				aria-disabled="false"
				/>
		);
		
		// Result comparison
		expect(shallowToJson(result)).toMatchSnapshot(); 
	});
});