import React from 'react';

import CheckBox from "../../../src/components/commons/CheckBox";

describe("Commons - CheckBox", () => {
	it ("render", () => {			
		// Generate result
		const result = shallow(
			<CheckBox 
				id="check-box-id" 
				name="input-name" 
				value="input-value" 
				label="label-name"
				parentClass="parent-classNames"
				tabIndex="0"
				required="true"
				aria-disabled="false"
				 />
		);	
		
		// Result comparison
		expect(shallowToJson(result)).toMatchSnapshot(); 
	});
});