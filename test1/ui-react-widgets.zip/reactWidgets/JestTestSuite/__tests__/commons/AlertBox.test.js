import React from 'react';
import { shallow } from 'enzyme';
import { shallowToJson } from 'enzyme-to-json';

import {AlertBox} from "../../../src/components/commons/AlertBox";

describe("Commons - AlertBox", () => {
	it ("render", () => {	
		const paragraph1 = global.paperlessContent.en.paperlessAlertMsgParagOne;
		const paragraph2 = global.paperlessContent.en.paperlessAlertMsgParagTwo;
		
		// Generate result
		const result = shallow(
			<AlertBox id="server-error" className="slf-slate-blue-bg-10 mar-bottom-10"> 
				<p>{paragraph1}</p>
				<p>{paragraph2}</p>
			</AlertBox>
		);	
		
		// Result comparison
		expect(shallowToJson(result)).toMatchSnapshot(); 
	});
});

