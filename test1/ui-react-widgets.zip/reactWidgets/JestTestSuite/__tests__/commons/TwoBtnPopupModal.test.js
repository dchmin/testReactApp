import React from "react";

import { TwoBtnPopupModal } from "../../../src/components/commons/TwoBtnPopupModal";

describe("Commons - TwoBtnPopupModal", function() {
  it("render and mock button clicks are triggering", () => {
    const onPrimaryBtnClick = jest.fn();
    const onLinkBtnClick = jest.fn();
    const onCloseBtnClick = jest.fn();

    // Generate result
    const result = shallow(
      <TwoBtnPopupModal
        id="popup-id"
        headerText="popup header"
        contentText="Single string"
        primaryBtnText="Yellow button text"
        closeBtnText="Close button text"
        topFooterText="top footer text above the button area is rendered"
        onPrimaryBtnClick={onPrimaryBtnClick}
        onLinkBtnClick={onLinkBtnClick}
        onCloseBtnClick={onCloseBtnClick}
      />
    );

    // Result comparison
    expect(shallowToJson(result)).toMatchSnapshot();

    // Validate button click functionality triggers
    // Top modal close button
    result.find("button.close").simulate("click");
    expect(onCloseBtnClick.mock.calls.length).toBe(1);

    // Bottom Button Area - left button on modal
    result.find("button.btn.btn-link").simulate("click");
    expect(onLinkBtnClick.mock.calls.length).toBe(1);

    // Bottom Button Area - right button on modal
    result.find("button.btn.btn-yellow").simulate("click");
    expect(onPrimaryBtnClick.mock.calls.length).toBe(1);
  });

  it("render - No top footer text", () => {
    // Generate result
    const result = shallow(
      <TwoBtnPopupModal
        id="popup-id"
        headerText="popup header"
        contentText="Single string"
        primaryBtnText="Yellow button text"
        closeBtnText="Close button text"
        onPrimaryBtnClick={() => null}
        onLinkBtnClick={() => null}
        onCloseBtnClick={() => null}
      />
    );

    // Result comparison
    expect(shallowToJson(result)).toMatchSnapshot();
  });
});
