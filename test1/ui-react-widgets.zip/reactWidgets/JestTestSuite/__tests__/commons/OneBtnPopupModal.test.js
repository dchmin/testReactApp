import React from "react";

import OneBtnPopupModal from "../../../src/components/commons/OneBtnPopupModal";

describe("Commons - OneBtnPopupModal", function() {
  it("render", () => {
    // Generate result
    const result = shallow(
      <OneBtnPopupModal
        id="popup-id"
        headerText="popup header"
        contentText="Single string"
        primaryBtnText="Yellow button text"
        closeBtnText="Close button text"
      />
    );

    // Result comparison
    expect(shallowToJson(result)).toMatchSnapshot();
  });

  /* No need to run this test case
	it ("render with HTML string content", () => {	
		let htmlContent = "<div><p>Content line 1</p><p>content line 2 with <a href='#'>LINK</a>.</p></div>";

		// Generate result
		const result = shallow(
			<OneBtnPopupModal 
				id="popup-id"
				headerText="popup header"
				contentText={htmlContent}
				primaryBtnText="Yellow button text"
				closeBtnText="Close button text"
				/>
		);
		
		// Result comparison
		expect(shallowToJson(result)).toMatchSnapshot(); 
	});*/
});
