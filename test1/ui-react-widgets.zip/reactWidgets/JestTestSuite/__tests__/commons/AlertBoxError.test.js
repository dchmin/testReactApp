import React from 'react';
import { shallow } from 'enzyme';
import { shallowToJson } from 'enzyme-to-json';

import {AlertBoxError} from "../../../src/components/commons/AlertBoxError";

describe("Commons - AlertBoxError", () => {
  const paragraph1 = global.paperlessContent.en.paperlessAlertMsgParagOne;
  const paragraph2 = global.paperlessContent.en.paperlessAlertMsgParagTwo;
  
  it ("render with children", () => {	
    // Generate result
    const result = shallow(
      <AlertBoxError id="server-error"> 
        <p>{paragraph1}</p>
        <p>{paragraph2}</p>
      </AlertBoxError>
      );	
    
    // Result comparison
    expect(shallowToJson(result)).toMatchSnapshot(); 
  });
  
  it('render passing in attributes', () => {
    // Generate result
    const result = shallow(
      <AlertBoxError id="server-error" tabIndex="0"> 
        <p>{paragraph1}</p>
        <p>{paragraph2}</p>
      </AlertBoxError>
      );	
      
      // Result comparison
    expect(shallowToJson(result)).toMatchSnapshot(); 
  });
  
});