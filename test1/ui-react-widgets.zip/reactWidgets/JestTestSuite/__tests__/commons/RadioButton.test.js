import React from "react";

import RadioButton from "../../../src/components/commons/RadioButton";

describe("Commons - RadioButton", function() {
  it("render - simple string values", () => {
    // Generate result
    const result = shallow(
      <RadioButton
        id="radio-button-id"
        name="textbox-name"
        value="radio-content"
        label="radio-label"
        checked={true}
        onChange={() => null}
        required={true}
        data-parsley-required-message="Required field"
        className="is-checked"
      />
    );

    // Result comparison
    expect(shallowToJson(result)).toMatchSnapshot();
  });

  it("render - pasing in string and html to label", () => {
    // Generate result
    const result = shallow(
      <RadioButton
        id="radio-button-id"
        name="textbox-name"
        value="radio-content"
        label={[
          "Label content for radio button",
          <span
            key="leafEdit"
            className="fa fa-leaf mar-left-10 slf-green-bg-10"
            style={{ background: "none" }}
          />
        ]}
        checked={true}
        onChange={() => null}
        required={true}
        data-parsley-required-message="Required field"
        className="is-checked"
      />
    );

    // Result comparison
    expect(shallowToJson(result)).toMatchSnapshot();
  });

  it("radion button onChange trigger", () => {
    // Set up Mock Function
    const onChangeMockFn = jest.fn();

    // Generate result
    const result = shallow(
      <RadioButton
        id="radio-button-id"
        name="textbox-name"
        value="radio-content"
        label="radio-label"
        checked={true}
        onChange={onChangeMockFn}
        required={true}
        data-parsley-required-message="Required field"
        className="is-checked"
      />
    );

    // Result comparison
    result.find("input").simulate("change");
    expect(onChangeMockFn.mock.calls.length).toBe(1);
  });
});
