import React from "react";

import ViewTable from "../../../src/components/paperless/ViewTable";

describe("Paperless - ViewTable", () => {
  it("render - en", () => {
    global.dom.getElementsByTagName("html")[0].setAttribute("lang", "en");

    // Generate result
    const result = shallow(<ViewTable />);

    // Result comparison
    expect(shallowToJson(result)).toMatchSnapshot();
  });

  it("render - fr", () => {
    global.dom.getElementsByTagName("html")[0].setAttribute("lang", "fr");

    // Generate result
    const result = shallow(<ViewTable />);

    // Result comparison
    expect(shallowToJson(result)).toMatchSnapshot();
  });

  it("showServerErrMsg() - Validate Show Error Message function ", () => {
    // Render component
    let app = shallow(<ViewTable />);

    // No props set - should be null
    expect(app.instance().showServerErrMsg()).toBeNull();

    // Set apology props to "true" - should return a JSX
    app.setProps({ apology: true });
    let func = app.instance().showServerErrMsg();
    let attributes = func.props;

    // Check whether the JSX has appropriate attributes
    expect(attributes.id).toBe("apologyError-serverErrMsg");
    expect(attributes.className).toBe(
      "field-set-validation-errors mar-bottom-10"
    );
    expect(attributes.tabIndex).toBe("0");
    expect(attributes.children).not.toBeNull();
  });

  //We removed the paper alert from paperless widget so this test case does not hold anymore
  // it("showPaperAlert()", () => {
  //   // Render component
  //   let app = shallow(<ViewTable />);

  //   // No props set - should be null
  //   expect(app.instance().showPaperAlert()).toBeNull();

  //   // Set paperlessPreference props to "paperless" - should be null
  //   app.setProps({ paperlessPreference: "paperless" });
  //   expect(app.instance().showPaperAlert()).toBeNull();

  //   // Set paperlessPreference props to "paper" - should return a JSX
  //   app.setProps({ paperlessPreference: "paper" });
  //   let func = app.instance().showPaperAlert();
  //   let attributes = func.props;

  //   expect(func.type.name).toBe("AlertBox"); //Validate the alert box component is being used
  //   expect(attributes.id).toBe("paperSelectionAlert");
  //   expect(attributes.classes).toBe(
  //     "slf-yellow-bg-10 mar-top-10 exclamation-triangle"
  //   );
  //   expect(attributes.children).not.toBeNull();
  // });

  it("editAction()", () => {
    // Set up Mock Function
    const toggleViewMockFn = jest.fn();
    const addTealiumTaggingMockFn = jest.fn();

    // Render
    let app = shallow(<ViewTable />);

    // Set apology props to "true" - Function doesn't do anything
    app.setProps({
      toggleView: toggleViewMockFn,
      addTealiumTagging: addTealiumTaggingMockFn,
      apology: true
    });
    app
      .find("ButtonLink")
      .simulate("click", { preventDefault: () => undefined });

    // Set apology props to "false" - A function outside of component should be called
    app.setProps({ apology: false });
    app.find("ButtonLink").simulate("click");
    expect(toggleViewMockFn.mock.calls.length).toBe(1);
    expect(addTealiumTaggingMockFn.mock.calls.length).toBe(1);
  });
});
