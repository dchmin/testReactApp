import React from 'react';
import ReactDOM from'react-dom';
//import { shallow } from 'enzyme';
//import * as Adapter from 'enzyme-adapter-react-16';
import { configure, shallow } from 'enzyme';
import { shallowToJson } from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-16';

//import {createRenderer} from 'react-addons-test-utils'

//import {paperlessContent} from "../../../public/paperlessContent_test"

//import {PaperlessWidget, content, permissionContent} from "../../../src/components/paperless/PaperlessWidget";
import PaperlessWidget from "../../../src/components/paperless/PaperlessWidget";

import {ViewTable} from "../../../src/components/paperless/ViewTable";



configure({ adapter: new Adapter() });


it ("renders without crashing", () => {
	const div = document.createElement("div");
	
	//ReactDOM.render(<PaperlessWidget />, div);
	//shallow(<PaperlessWidget />);
	
	//const wrapper = shallow(<ViewTable />);
	//createRenderer.render(<PaperlessWidget />);
	  
	
});

it ("paperless widget testing", () => {
	//simple
	//expect(1 + 2).toEqual(3);

	// Validates that the saveSuccessful State is always set to false 
	//expect(PaperlessWidget.state().saveSuccessful).toEqual(false);
	/*
	  expect.hasAssertions();
	  PaperlessWidget(state => {
		expect(validateState(state)).toBeTruthy();
	  });
	  return waitOnState();*/
	  
	  
	  // Need to render it in order to look at states
	  //const div = document.createElement('div');
      //  ReactDOM.render(<PaperlessWidget/>, div);
		
	  
	  //expect(PaperlessWidget.state.saveSuccessful).toEqual(false);
});

