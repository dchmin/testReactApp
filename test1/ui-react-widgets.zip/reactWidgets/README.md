# React Widgets

## Purpose

React Widgets is supposed to hold all widgets for all pages.

## Quick Tips

## To Do

