var marketingContent = {
  en: {
    widgetTitle: "Marketing",
    editLabel: "Edit",
    cancelLabel: "Cancel",
    successLabel: "Your changes have been saved.",
    saveLabel: "Save",
    validatingLabel: "Saving...",
    okayLabel: "OK",
    closeLabel: "Close",
    apologyError:
      "Our apologies! We're having some technical difficulties, please come back later.",
    restrictedModalHeader: "Access restricted",
    restrictedModalContent: "Sorry, you do not have access.",
    pleaseSelectLabel:
      "We'd like to send you information about other products and services that might be of interest to you.",
    yesOption: "Yes",
    noOption: "No",
    notSelected: "Not selected",
    notSelectedAlt:"Choice not selected",
    reqFieldError: "Required field",
    yesOptionDescription: "I'd like to hear about other products and services.",
    noOptionDescription:
      "I don't want to receive information about other products or services. I understand I'll still receive required communications from my employer/advisor and information that will help me make the most of my plans, policies and contracts."
  },
  fr: {
    widgetTitle: "Marketing",
    editLabel: "Modifier",
    cancelLabel: "Annuler",
    successLabel: "Vos changements sont enregistrés.",
    saveLabel: "Enregistrer",
    validatingLabel: "Enregistrement...",
    okayLabel: "OK",
    closeLabel: "Fermer",
    apologyError:
      "Veuillez nous excuser! Nous éprouvons quelques difficultés techniques. Réessayez plus tard.",
    restrictedModalHeader: "Accès restreint",
    restrictedModalContent: "Désolé, vous n'avez pas accès.",
    pleaseSelectLabel:
      "Nous aimerions vous envoyer de l'information sur d'autres produits et services qui pourraient vous intéresser.",
    yesOption: "Oui",
    noOption: "Non",
    notSelected: "Non sélectionné",
    notSelectedAlt:"L'option n'est pas sélectionnée",
    reqFieldError: "Required field",
    yesOptionDescription: "Je veux de l'information sur d'autres produits et services.",
    noOptionDescription:
      "Je ne veux pas recevoir d'information sur d'autres produits et services. Je comprends que je continuerai de recevoir de mon employeur ou de mon conseiller les communications requises, ainsi que de l'information pour m’aider à tirer le maximum de mes régimes et de mes contrats."
  }
};
