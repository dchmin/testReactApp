import { get, post, getDataWithTimeout } from "./client";

if (lang === undefined || lang === null) {
  lang = "en_CA";
}

export var lang = getLang();

function getLang() {
  if (process.env.NODE_ENV === "test") {
    return (
      global.dom.getElementsByTagName("html")[0].getAttribute("lang") + "_CA"
    );
  }
  return document.getElementsByTagName("html")[0].getAttribute("lang") + "_CA";
}

if (process.env.NODE_ENV === "production") {
  var notifAndprefServiceURL = `${global.notifAndprefServiceURL}/${lang}`;
  var contactPrefGetURL = `${global.contactPrefServiceURL}/${lang}`;
  var marketingPrefUrl = `${global.marketingPrefServiceURL}/${lang}`;
  var marketPrefPosturl = `${global.submitMarketingPrefServiceURL}/${lang}`;
  var emailInfoGetUrl = `${global.emailDetailsServiceURL}/${lang}`;
} else {
  var notifAndprefServiceURL = global.notifAndprefServiceURL;
  var contactPrefGetURL = global.contactPrefServiceURL;
  var marketingPrefUrl = global.marketingPrefServiceURL;
  var emailInfoGetUrl = global.emailDetailsServiceURL;
}

function normalizePaperlessData(response) {
  return {
    callShadow: response.callShadow,
    paperlessPreference: response.paperlessPreference,
    apology: response.apology
  };
}
function getErrorCode(response) {
  return { errorCode: response.errorCode, errorMsg: response.errorMsg };
}

function getOnlyErrorCode(response) {
  return { errorCode: response.errorCode };
}
export function getParentPaperlessFlag() {
  return get(notifAndprefServiceURL)
    .then(normalizePaperlessData)
    .catch(function (error) {
      console.log(error);
    });
}

/**
 * get user's Contact Preferences Data
 */
export function getUsersContactPrefData() {
  let csrfToken = document.getElementsByName('CSRFToken')[0] ? document.getElementsByName('CSRFToken')[0].value : "";
  return get(contactPrefGetURL, csrfToken)
    .then(checkIntegrityUserData)
    .catch(function (error) {
      console.log(error);
    });
}

/**
 * get user's Market Preferences Data
 */
export function getUsersMarketingPrefData() {
  return get(marketingPrefUrl)
    .then(normalizeMarketingPrefData)
    .catch(function (error) {
      console.log(error);
    });
}
/* Check integrity of User data from Json file
 * TODO: re-enforce contactPreferences data ?
 */
function checkIntegrityUserData(response) {
  return {
    contactPreferences: response.contactPreferences,
    callShadow: response.callShadow,
    apology: response.apology,
    errorCode: response.errorCode,
    errorMsg: response.errorMsg
  };
}

/**
 * get user's email information
 */
// export function getClientsEmailInfo() {
//   return get(emailInfoGetUrl)
//     .then(normalizeEmailData)
//     .catch(function (error) {
//       console.log(error);
//     })
// }

/**
 * get user's email information with timeout functionality
 */
export function getClientsEmailInfo() {
  return getDataWithTimeout(emailInfoGetUrl, 30000)
    .then(normalizeEmailData)
    .catch(function (error) {
      console.log(error);
    })
}


function normalizeEmailData(response) {
  return {
    emailInfo: response.emailInfo,
    callShadow: response.callShadow,
    currentFriendlyId: response.currentFriendlyId,
    errorCode: response.errorCode
  };
}

/**
 * Check integrity of User data from Json file
 */
function normalizeMarketingPrefData(response) {
  return {
    marketingPreference: response.marketingPreference.toLowerCase(),
    callShadow: response.callShadow,
    apology: response.apology,
    errorCode: response.errorCode,
    errorMsg: response.errorMsg
  };
}

// Format request JSON to include selected Friendly ID
function formatSaveJson(state) {
  var json = {};
  json.paperlessPreference = state.paperlessPreference;
  //	json.permissionFlag = state.permissionFlag;

  return json;
}

export function setEverythingPaperlessFlag(state) {
  // Format Json
  var saveJson = formatSaveJson(state);
  let csrfToken = document.getElementsByName('CSRFToken')[0] ? document.getElementsByName('CSRFToken')[0].value : "";
  // Post request
  var postUrl = global.submitNotifAndprefServiceURL + "/" + lang;
  return post(postUrl, saveJson, csrfToken)
    .then(getErrorCode)
    .catch(function (error) {
      console.log(error);
    });
}
// Generic Post Request
export function submitUserData(saveJson, postUrl) {
  let csrfToken = document.getElementsByName('CSRFToken')[0] ? document.getElementsByName('CSRFToken')[0].value : "";
  return post(postUrl, saveJson,csrfToken)
    .then(getErrorCode)
    .catch(function (error) {
      console.log(error);
    });
}

// MarketPref Post Request
export function submitMarketPrefUserData(state) {
  var saveJson = {};
  saveJson.marketingPreference = state.marketingPref;
  let csrfToken = document.getElementsByName('CSRFToken')[0] ? document.getElementsByName('CSRFToken')[0].value : "";
  return post(marketPrefPosturl, saveJson, csrfToken)
    .then(getErrorCode)
    .catch(function (error) {
      console.log(error);
    });
}

// Get CSRF token and submit email info with the csrf token
// export function submitEmailInfo(emailInfo) {
//   var postURL = global.submitEmailServiceURL + "/" + lang;
//   let csrfToken = document.getElementsByName('CSRFToken')[0] ? document.getElementsByName('CSRFToken')[0].value : "";
//  let reqPage = document.getElementsByName('reqPage')[0] ? document.getElementsByName('reqPage')[0].value : "";
//   return post(postURL, emailInfo, csrfToken, reqPage)
//     .then(normalizeEmailSubmitResponse)
//     .catch(function (error) {
//       console.log(error);
//     });
// }
export function submitEmailInfo(emailInfo) {
  var postURL = global.submitEmailServiceURL;

  return get(postURL)
    .then(normalizeEmailSubmitResponse)
    .catch(function(error){
      console.log(error);
    });
}
function normalizeEmailSubmitResponse(response) {
  return {
    friendlyIdInfo: response.friendlyIdInfo,
    errorCode: response.errorCode
  }
}
