export function get(url, token="") {
	return fetch(url, {
		credentials: 'same-origin',
		headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'Cache': 'no-cache',
			'MBRWIDGETS-ANTICSRF-TOKEN': token
		},
	}).then(response => response.json());
}

export function post(url, data, token="", reqPage="") {
	return fetch(url, {
		method: 'POST',
		body: JSON.stringify(data),
		credentials: "same-origin",
		headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'MBRWIDGETS-ANTICSRF-TOKEN': token,
			'REQUESTING_PAGE_SOURCE' : reqPage
		},
	}).then(response => response.json());
}
/* 
 * return the response headers of the get call
 */
export function getHeaders(url) {
	return fetch(url, {
		credentials: 'same-origin',
		headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'Cache': 'no-cache'
		},
	}).then(response => response.headers);
}
// Don't use this method. It does not work on iPad
export function fetchWithTimeout(url, timeout, token = "") {
	return new Promise((resolve, reject) => {
		let timer = setTimeout(
			() => reject(new Error('Request timed out')),
			timeout
		);
		fetch(url, {
			credentials: 'same-origin',
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json',
				'Cache': 'no-cache',
				'MBRWIDGETS-ANTICSRF-TOKEN': token
			},
		}).then(
			response => resolve(response.json()),
			err => reject(err)
		).finally(() => clearTimeout(timer));
	})
}
// fetch data with time out 
export function getDataWithTimeout(url, timeoutValue, token = "") {
	let didTimeOut = false;
	return new Promise(function (resolve, reject) {
		const timeout = setTimeout(function () {
			didTimeOut = true;
			reject(new Error('Request timed out'));
		}, timeoutValue);
		fetch(
			url
			, {
				credentials: 'same-origin',
				headers: {
					'Accept': 'application/json; charset=utf-8',
					'Content-Type': 'application/json; charset=utf-8',
					'Cache': 'no-cache',
					'MBRWIDGETS-ANTICSRF-TOKEN': token
				}
			}
		)
			.then(function (response) {
				// Clear the timeout as cleanup
				clearTimeout(timeout);
				if (!didTimeOut) {
					resolve(response.json());
				}
			}).then(function (responseJson) {
				resolve(responseJson);
			})
			.catch(function (err) {
				// Rejection already happened with setTimeout
				if (didTimeOut) return;
				// Reject with error
				reject(err);
			});
	});

}
