import React from "react";
import ViewTable from "./ViewTable";
import EditTable from "./EditTable";
import { content, permissionContent } from "./PaperlessWidget";

class PaperlessContainer extends React.Component {
  componentDidMount() {
    this.renderPermissionContent();

    if (typeof window.Parsley !== "undefined") {
      // WAI-ARIA for errors
      window.Parsley.on("field:error", function(formField) {
        var elem = global.$(formField.$element);
        elem.attr({
          "aria-invalid": "true",
          "aria-describedby": "parsley-id-" + formField.__id__
        });
        if (elem.is("input[type='radio']")) {
          elem.attr({
            "aria-describedby": formField._ui.errorsWrapperId
          });
        }
      });
      window.Parsley.on("field:success", function(formField) {
        var elem = global.$(formField.$element);
        elem.attr({
          "aria-invalid": "false"
        });
      });
    }
  }

  //Display the learn more popup
  showPplLearnMorePopup = description => {
    global.$("#termsConditions").collapse("hide")
    global.$("#moreAboutPaperless").modal({ backdrop: "static" });
    this.props.addTealiumTagging(description);
  };

  renderPermissionContent = () => {
    // render the content within the popups
    let permissionPopup = document.getElementById("permissionPopup");
    permissionPopup.querySelectorAll(".modal-body")[0].innerHTML = permissionContent.permissionModalContent;

    let learnMoreSection = document.getElementById("learnMoreParent");
    learnMoreSection.innerHTML = content.pplLearnMorePopupContent;  

    let termsConditionSection = document.getElementById("termsConditions");
    termsConditionSection.querySelectorAll(".content")[0].innerHTML =
      permissionContent.permissionModalContent;

  };

  render() {
    if (this.props.displayMode === "view" || this.props.serverError === true) {
      return (
        <div id="paperlessContainer" className="viewMode" tabIndex="-1">
          <h2>{content.widgetTitle}</h2>
          <ViewTable
            toggleView={this.props.toggleView}
            lang={this.props.lang}
            parentPaperless={this.props.parentPaperless}
            paperlessPreference={this.props.paperlessPreference}
            showSuccessMsg={this.props.showSuccessMsg}
            removeSaveSuccessMsg={this.props.removeSaveSuccessMsg}
            apology={this.props.apology}
            serverError={this.props.serverError}
            showPplLearnMorePopup={this.showPplLearnMorePopup}
            addTealiumTagging={this.props.addTealiumTagging}
          />
        </div>
      );
    } else {
      return (
        <div id="paperlessContainer" className="editMode" tabIndex="-1">
          <h2>{content.widgetTitle}</h2>
          <EditTable
            toggleView={this.props.toggleView}
            lang={this.props.lang}
            onCancelClick={this.props.onCancelClick}
            onSaveClick={this.props.onSaveClick}
            showPermissionPopup={this.props.showPermissionPopup}
            onPermissionConfirmation={this.props.onPermissionConfirmation}
            parentPaperless={this.props.parentPaperless}
            paperlessPreference={this.props.paperlessPreference}
            permissionFlag={this.props.permissionFlag}
            onPaperlessFlagChange={this.props.onPaperlessFlagChange}
            onPaperlessOptionSelection={this.props.onPaperlessOptionSelection}
            onPaperOptionSelection={this.props.onPaperOptionSelection}
            serverErrMsg={this.props.serverErrMsg}
            callShadow={this.props.callShadow}
            addTealiumTagging={this.props.addTealiumTagging}
            showCancel={this.props.showCancel}
            showPplLearnMorePopup={this.showPplLearnMorePopup}
            focusOnElem={this.props.focusOnElem}
          />
        </div>
      );
    }
  }
}

export default PaperlessContainer;
