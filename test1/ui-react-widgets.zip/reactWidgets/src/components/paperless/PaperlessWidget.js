import React from "react";
import "./css/paperlessWidget.css";
import PaperlessContainer from "./PaperlessContainer";
import {
  getParentPaperlessFlag,
  setEverythingPaperlessFlag
} from "../../api/userPreference";
import { lang } from "../../api/userPreference";
import { TwoBtnPopupModal } from "../commons/TwoBtnPopupModal";
import OneBtnPopupModal from "../commons/OneBtnPopupModal";

export const content =
  lang === "en_CA" ? global.paperlessContent.en : global.paperlessContent.fr;
export const permissionContent =
  lang === "en_CA"
    ? global.permissionPopupContent.en
    : global.permissionPopupContent.fr;
export const pageName = "Paperless Widget";

const continueBtn = document.querySelector(".js-continue-button");

class PaperlessWidget extends React.Component {
  state = {
    displayMode: "load",
    originalPaperlessPreference: "blank",
    paperlessPreference: "blank",
    permissionFlag: false,
    callShadow: false,
    saveSuccessful: false,
    language: lang,
    apology: false,
    serverErrMsg: false, //Show or hide server error message
    showCancel: true,
    serverError: false //Paperless Outage error when information cannot be received
  };

  componentDidMount() {
    var initialDisplayMode = global.initialDisplayMode;

    getParentPaperlessFlag().then(pplFlag => {
      if (pplFlag) {
        this.setState(() => ({
          originalPaperlessPreference: pplFlag.paperlessPreference,
          paperlessPreference: pplFlag.paperlessPreference,
          callShadow: pplFlag.callShadow,
          apology: pplFlag.apology,
          displayMode: initialDisplayMode === "edit" ? "edit" : "view",
          showCancel: initialDisplayMode === "edit" ? false : true
        }));
      } else {
        this.setState(() => ({
          displayMode: initialDisplayMode === "edit" ? "edit" : "view",
          showCancel: initialDisplayMode === "edit" ? false : true,
          serverError: true
        }));

        // Enable the Next button on Lobby page
        if (continueBtn !== null) {
          continueBtn.removeAttribute("disabled");
        }
      }
    });
  }
  toggleDisplayMode = e => {
    const newDisplayMode = this.state.displayMode === "view" ? "edit" : "view";

    this.setState(() => ({
      displayMode: newDisplayMode,
      showCancel: true
    }));

    // Able/disable next button for lobby page.

    if (continueBtn !== null) {
      if (newDisplayMode === "edit") {
        continueBtn.setAttribute("disabled", "");
      } else {
        continueBtn.removeAttribute("disabled");
      }
    }
  };
  removeSaveSuccessMsg = () => {
    this.setState(() => ({
      saveSuccessful: false
    }));
  };
  handleCancelClick = () => {
    this.toggleDisplayMode();
    const originalPaperlessPreference = this.state.originalPaperlessPreference;
    this.setState(() => ({
      paperlessPreference: originalPaperlessPreference,
      permissionFlag: false,
      serverErrMsg: false
    }));

    //tealium tagging on click of the edit button
    this.addTealiumTagging("Edit screen - Cancel");
  };

  // handlePaperlessFlagChange = e => {
  // 	// Update parent paperless
  // 	const paperlessFlagChecked = e.target.checked;
  // 	this.setState(() => ({
  // 		parentPaperless: paperlessFlagChecked,
  // 	}));
  // }
  handlePaperlessRadioSelection = e => {
    const selectedOption = e.target.value;
    this.setState(() => ({
      paperlessPreference: selectedOption
    }));
  };

  handlePaperRadioSelection = e => {
    const selectedOption = e.target.value;
    this.setState(() => ({
      paperlessPreference: selectedOption
    }));
  };

  showPermissionPopup = () => {
    global.$("#permissionPopup").modal({ backdrop: "static" });
  };
  handlePermissionConfirmation = () => {
    this.setState(
      {
        permissionFlag: true
      },
      () => {
        //tealium tagging for confirming permission for enabling paperless
        this.addTealiumTagging("Permission modal - Accept");
        this.handleSaveClick();
      }
    );
  };
  disableFields = container => {
    global
      .$(container)
      .find("input")
      .prop("disabled", true);
    global.$(container + " form").addClass("form-disabled");
    global
      .$(container + " .btnArea .cancel-btn, .btnArea .save-btn")
      .prop("tabindex", "-1");
    global.$(container + " .save-btn").text(content.validatingLabel);
    global.$(container + " .save-btn").addClass("is-busy");
  };
  enableFields = container => {
    global
      .$(container)
      .find("input")
      .prop("disabled", false);
    global.$(container + " form").removeClass("form-disabled");
    global
      .$(container + " .btnArea .cancel-btn, .btnArea .save-btn")
      .removeAttr("tabindex", "-1");
    global.$(container + " .save-btn").text(content.saveLabel);
    global.$(container + " .save-btn").removeClass("is-busy");
  };
  handleSaveClick = e => {
    this.disableFields("#paperlessContainer");
    // Submit request
    setEverythingPaperlessFlag(this.state).then(submitResponse => {
      const paperlessPreference = this.state.paperlessPreference;
      // Successful submission
      if (submitResponse && submitResponse.errorCode === "0") {
        // if (true) {
        // Update the state upon successful submission

        this.setState(() => ({
          originalPaperlessPreference: paperlessPreference,
          permissionFlag: false,
          serverErrMsg: false,
          saveSuccessful: true
        }));

        this.enableFields("#paperlessContainer");
        // Display View Mode
        this.toggleDisplayMode();

        //tealium tagging for successful save of paperless info
        this.addTealiumTagging("Edit screen - Successful save");

        //	global.$("#permissionPopup").modal('hide');
        //document.getElementById("success-msg").focus();
      } else {
        // Error upon submission
        this.setState(() => ({
          permissionFlag: false,
          serverErrMsg: true
        }));
        this.enableFields("#paperlessContainer");
        document.getElementById("apologyError-serverErrMsg").focus();

        //tealium tagging for successful save of paperless info
        this.addTealiumTagging("Edit screen - Unsuccessful save");
      }
      var continueBtn = document.querySelector(".js-continue-button");
      if (continueBtn !== null) {
        continueBtn.removeAttribute("disabled");
      }
    });
  };
  getTealiumUserState = () => {
    let userPplState = "paperless no selection";
    if (this.state.paperlessPreference === "paperless") {
      userPplState = "paperless active";
    } else if (this.state.paperlessPreference === "paper") {
      userPplState = "paperless inactive";
    }
    return userPplState;
  };
  addTealiumTagging = description => {
    if (typeof global.utag !== "undefined") {
      global.utag.link({
        ev_type: "other",
        ev_action: "clk",
        ev_title: pageName,
        ev_data_one: description,
        user_state: this.getTealiumUserState()
      });
    }
  };

  onPopupCancel = () => {
    this.addTealiumTagging("Permission modal - Cancel");
    document.getElementById("paperlessSaveBtn").focus();
  };

  onPopupExit = () => {
    this.addTealiumTagging("Permission modal - Exit");
    document.getElementById("paperlessSaveBtn").focus();
  };
  focusOnElem = elemId => {
    if (document.getElementById(elemId) !== null) {
      document.getElementById(elemId).focus();
    }
  };
  renderLearnMorePopupContent = () => {
    return (
      <div>
        <div id="learnMoreParent"></div>
        <div id="accordion-terms-conditions">
          <div className="panel slf-accordion-plus blue">
            <a
              className="accordion-heading"
              data-toggle="collapse"
              href="#termsConditions"
              data-parent="#accordion-terms-conditions"
              aria-expanded="false"
              aria-controls="termsConditions"
              role="button"
            >
              {content.pplTermsConditionHeader}
            </a>
            <div id="termsConditions" className="collapse" >
              <div className="content">
                {permissionContent.permissionModalContent}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  render() {
    if (this.state.displayMode === "load") {
      return null;
    } else {
      return (
        <div>
          <TwoBtnPopupModal
            id="permissionPopup"
            headerText={permissionContent.permissionModalHeader}
            contentText=""
            primaryBtnText={permissionContent.permissionModalButton}
            closeBtnText={content.closeLabel}
            linkBtnText={permissionContent.permissionModalDisagreeButton}
            onPrimaryBtnClick={this.handlePermissionConfirmation}
            onCloseBtnClick={this.onPopupExit}
            onLinkBtnClick={this.onPopupCancel}
            topFooterText={permissionContent.permissionModalFooterContent}
          />
          <OneBtnPopupModal
            id="moreAboutPaperless"
            headerText={content.pplLearnMorePopupHeader}
            contentText={this.renderLearnMorePopupContent()}
            primaryBtnText={content.okayLabel}
            closeBtnText={content.closeLabel}
            onCloseBtnClick={e => this.focusOnElem("learnMoreLink")}
          />
          <PaperlessContainer
            displayMode={this.state.displayMode}
            toggleView={this.toggleDisplayMode}
            lang={this.state.language}
            paperlessPreference={this.state.paperlessPreference}
            showSuccessMsg={this.state.saveSuccessful}
            removeSaveSuccessMsg={this.removeSaveSuccessMsg}
            onCancelClick={this.handleCancelClick}
            onSaveClick={this.handleSaveClick}
            showPermissionPopup={this.showPermissionPopup}
            permissionFlag={this.state.permissionFlag}
            onPaperlessOptionSelection={this.handlePaperlessRadioSelection}
            onPaperOptionSelection={this.handlePaperRadioSelection}
            serverErrMsg={this.state.serverErrMsg}
            apology={this.state.apology}
            callShadow={this.state.callShadow}
            addTealiumTagging={this.addTealiumTagging}
            showCancel={this.state.showCancel}
            serverError={this.state.serverError}
            focusOnElem={this.focusOnElem}
          />
        </div>
      );
    }
  }
}

export default PaperlessWidget;
