import React from "react";
import ButtonLink from "../commons/ButtonLink";
import RadioButton from "../commons/RadioButton";
import { content, pageName } from "./PaperlessWidget";
import { AlertBox } from "../commons/AlertBox";
import OneBtnPopupModal from "../commons/OneBtnPopupModal";

class EditTable extends React.Component {
  // Set up Server Error Message
  showServerErrMsg = () => {
    return this.props.serverErrMsg ? (
      <div
        id="apologyError-serverErrMsg"
        className="field-set-validation-errors mar-bottom-10"
        tabIndex="0"
      >
        {content.apologyError}
      </div>
    ) : null;
    //aria-live="assertive" aria-relevant="all" aria-atomic="true"
  };
  // behaviour for show cancel button
  showCancelButton = () => {
    return this.props.showCancel ? (
      <ButtonLink
        value={content.cancelLabel}
        cssClass="btn btn-link cancel-btn"
        href="#paperlessContainer"
        onClick={this.props.onCancelClick}
      />
    ) : null;
  };
  //show alert on paper option selection
  // showPaperAlert = () => {
  //   return this.props.paperlessPreference === "paper" ? (
  //     <AlertBox
  //       id="paperSelectionAlert"
  //       classes="slf-yellow-bg-10 mar-top-10 exclamation-triangle"
  //     >
  //       <p>{content.paperSelectionAlertEdit}</p>
  //     </AlertBox>
  //   ) : null;
  // };

  // Generate Restricted Access Popup on page
  generateRestrictedAccessPopup = () => {
    return this.props.callShadow ? (
      <OneBtnPopupModal
        id="paperless-accessRestricted"
        headerText={content.restrictedModalHeader}
        contentText={content.restrictedModalContent}
        primaryBtnText={content.okayLabel}
        closeBtnText={content.closeLabel}
        onCloseBtnClick={e => this.props.focusOnElem("paperlessSaveBtn")}
      />
    ) : null;
  };

  // Display Restricted Access Popup
  showRestrictedAccessPopup = () => {
    // Show popup
    global.$("#paperless-accessRestricted").modal({ backdrop: "static" });
  };

  // Set the correct click event function to Save button
  bindSaveEventHandler = (e, parent) => {
    var clickEvent = e;
    global
      .$("#editContainerForm")
      .parsley()
      .validate();
    if (
      global
        .$("#editContainerForm")
        .parsley()
        .isValid()
    ) {
      if (parent.props.callShadow) {
        //Call Shadow
        clickEvent.preventDefault();
        parent.showRestrictedAccessPopup();
      } else if (
        this.props.paperlessPreference === "paperless" &&
        !parent.props.permissionFlag
      ) {
        clickEvent.preventDefault();
        if (typeof global.utag !== "undefined") {
          global.utag.link({
            ev_type: "other",
            ev_action: "clk",
            ev_title: pageName,
            ev_data_one: "Edit screen - Save (open permission modal)",
            user_state: "paperless active"
          });
        }
        return parent.props.showPermissionPopup();
      } else {
        parent.props.onSaveClick();
      }
    } else {
      this.props.addTealiumTagging("Edit screen - Unsuccessful save");
    }
  };
  render() {
    return (
      <div>
        <form
          id="editContainerForm"
          className="form-group"
          data-parsley-validate
        >
          <div className="widgetContentContainer">
            <div id="paperless-notifContainer" className="topNotifContainer">
              {this.showServerErrMsg()}
            </div>
            <p>
              {content.pleaseSelectLabel}{" "}
              <a
                id="learnMoreLink"
                href="javascript:void(0);"
                onClick={e =>
                  this.props.showPplLearnMorePopup(
                    "Edit screen - learn more link (open popup)"
                  )
                }
              >
                {content.paperlessLearnMore}
              </a>
            </p>
            <div>
              <RadioButton
                id="paperlessOption"
                value="paperless"
                name="pplPreferenceOption"
                label={content.paperlessOption}
                checked={this.props.paperlessPreference === "paperless"}
                onChange={this.props.onPaperlessOptionSelection}
                required={true}
                data-parsley-required-message={content.reqFieldError}
                className={
                  this.props.paperlessPreference === "paperless"
                    ? "isChecked"
                    : ""
                }
              />
              <br />
              <RadioButton
                id="paperOption"
                value="paper"
                name="pplPreferenceOption"
                label={content.paperOption}
                checked={this.props.paperlessPreference === "paper"}
                onChange={this.props.onPaperlessOptionSelection}
                className={
                  this.props.paperlessPreference === "paper" ? "isChecked" : ""
                }
                aria-describedby={
                  this.props.paperlessPreference === "paper"
                    ? "paperSelectionAlert"
                    : null
                }
              />
              {/* {this.showPaperAlert()} */}
            </div>
          </div>
          <div className="btnArea">
            {this.showCancelButton()}

            <ButtonLink
              id="paperlessSaveBtn"
              value={content.saveLabel}
              cssClass="btn btn-yellow save-btn"
              href="javascript:void(0);"
              onClick={e => this.bindSaveEventHandler(e, this)}
            />
          </div>
        </form>
        {this.generateRestrictedAccessPopup()}
      </div>
    );
  }
}

export default EditTable;
