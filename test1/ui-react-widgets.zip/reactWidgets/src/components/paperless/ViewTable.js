import React from "react";
import ButtonLink from "../commons/ButtonLink";
import RadioButton from "../commons/RadioButton";
import { content } from "./PaperlessWidget";
import { AlertBox } from "../commons/AlertBox";
import { AlertBoxError } from "../commons/AlertBoxError";
import { SuccessMsg } from "../commons/SuccessMsg";

class ViewTable extends React.Component {
  // Set up apology Error Message
  showServerErrMsg = () => {
    return this.props.apology ? (
      <div
        id="apologyError-serverErrMsg"
        className="field-set-validation-errors mar-bottom-10"
        tabIndex="0"
      >
        {content.apologyError}
      </div>
    ) : null;
  };
  //show alert on paper option selection
  // showPaperAlert = () => {
  //   return this.props.paperlessPreference === "paper" ? (
  //     <AlertBox
  //       id="paperSelectionAlert"
  //       classes="slf-yellow-bg-10 mar-top-10 exclamation-triangle"
  //     >
  //       <p>{content.paperSelectionAlertView}</p>
  //     </AlertBox>
  //   ) : null;
  // };
  editAction = e => {
    if (this.props.apology) {
      e.preventDefault();
    } else {
      this.props.toggleView();
      //tealium tagging on click of the edit button
      this.props.addTealiumTagging("Main screen - Edit");
    }
  };
  render() {
    if (this.props.serverError) {
      return (
        <div>
          <div className="outage-container">
            <AlertBoxError>{content.apologyError}</AlertBoxError>
          </div>
        </div>
      );
    } else {
      return (
        <div>
          <div className="widgetContentContainer">
            <SuccessMsg
              id="paperless-successNotifContainer"
              className="mar-bottom-10"
              content={content.successLabel}
              showSuccessMsg={this.props.showSuccessMsg}
              removeSaveSuccessMsg={this.props.removeSaveSuccessMsg}
              rootContainer={this.refs.paperlessNotifContRef}
            />
            <div
              id="paperless-notifContainer"
              className="topNotifContainer"
              ref="paperlessNotifContRef"
            >
              {this.showServerErrMsg()}
            </div>
            <p>
              {content.pleaseSelectLabel}{" "}
              <a
                id="learnMoreLink"
                href="javascript:void(0);"
                onClick={e =>
                  this.props.showPplLearnMorePopup(
                    "Main screen - learn more link (open popup)"
                  )
                }
              >
                {content.paperlessLearnMore}
              </a>
            </p>
            <div>
              <RadioButton
                id="paperlessOption"
                value="paperless"
                name="pplPreferenceOption"
                label={content.paperlessOption}
                checked={this.props.paperlessPreference === "paperless"}
                onChange={this.props.onPaperlessOptionSelection}
                disabled={true}
                className={
                  this.props.paperlessPreference === "paperless"
                    ? "isChecked"
                    : ""
                }
              />
              <br />
              <RadioButton
                id="paperOption"
                value="paper"
                name="pplPreferenceOption"
                label={content.paperOption}
                checked={this.props.paperlessPreference === "paper"}
                onChange={this.props.onPaperlessOptionSelection}
                disabled={true}
                className={
                  this.props.paperlessPreference === "paper" ? "isChecked" : ""
                }
                aria-describedby={
                  this.props.paperlessPreference === "paper"
                    ? "paperSelectionAlert"
                    : null
                }
              />
              {/* {this.showPaperAlert()} */}
            </div>
          </div>
          <div className="btnArea">
            <ButtonLink
              value={[
                content.editLabel,
                <span className="sr-only"> {content.widgetTitle}</span>
              ]}
              cssClass="btn btn-blue"
              href="#paperlessContainer"
              onClick={this.editAction}
              disabled={this.props.apology}
              aria-disabled={this.props.apology}
            />
          </div>
        </div>
      );
    }
  }
}

export default ViewTable;
