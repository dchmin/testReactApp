import PropTypes from 'prop-types'; // ES6
import React from 'react';

const RadioButton = ({id, name, value, label, parentClass, ...props}) => {

  return (
    <React.Fragment>
			<input id={id} type="radio" name={name} value={value} {...props}/>
			<label htmlFor={id} className="mar-top-10">{label}</label>
    </React.Fragment>
  );
};

RadioButton.propTypes = {
  id  	 : PropTypes.string.isRequired,
  value  : PropTypes.string.isRequired,
  name   : PropTypes.string
};

export default RadioButton;
