// return a cloned object
export function copyObj(src) {
  return Object.assign({}, src);
}