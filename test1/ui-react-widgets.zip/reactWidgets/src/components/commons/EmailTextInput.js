import PropTypes from 'prop-types'; // ES6
import React from 'react';
import { emailLabels } from "../email/EmailWidget";

const EmailTextInput = ({ label, name, id, onChange, onBlur, cssClass, placeholder, value, maxLength, requiredField, lang, friendlyAvailable, ...props }) => {
	//error messages
	var reqFieldError = emailLabels.reqFieldError;
	var invalidFrmtError = emailLabels.invalidFrmtError;


	return (
		<div>
			<label htmlFor={name + id}>{label} <span className="sr-only">{maxLength + " " + emailLabels.maxLengthAlt}</span></label>
			<input
				type="email"
				name={name}
				id={name + id}
				className={cssClass}
				placeholder={placeholder}
				value={value}
				onChange={onChange}
				onBlur={onBlur}
				data-parsley-required={requiredField}
				data-parsley-pattern="/^([_A-Za-z0-9-!#$%&amp;'*+\/=?^_`{}~\+]+(\.[_A-Za-z0-9-!#$%&amp;'*+\/=?^_`{}~]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*(\.[A-Za-z]{2,})|[_A-Za-z0-9-!#$%&amp;'*+\/=?^_`{}~\+]+(\.[_A-Za-z0-9-!#$%&amp;'*+\/=?^_`{}~]+)*@(?:[0-9]{1,3}\.){3}[0-9]{1,3})$/"
				data-parsley-required-message={reqFieldError}
				data-parsley-type-message={invalidFrmtError}
				data-parsley-pattern-message={invalidFrmtError}
				data-parsley-friendly-available={friendlyAvailable}
				data-parsley-type-message={invalidFrmtError}
				data-parsley-friendly-available-message={emailLabels.friendlyIdAlreadyUsed}
				maxLength={maxLength}
				autoComplete="off"
				required={requiredField} 
				{...props}/>
		</div>
	);
};

EmailTextInput.propTypes = {
	label: PropTypes.string,
	name: PropTypes.string,
	id: PropTypes.number.isRequired,
	onChange: PropTypes.func.isRequired,
	onBlur: PropTypes.func.isRequired,
	cssClass: PropTypes.string,
	placeholder: PropTypes.string,
	value: PropTypes.string,
	maxLength: PropTypes.string,
	requiredField: PropTypes.bool,
	lang: PropTypes.string,
	friendlyAvailable: PropTypes.bool
};

export default EmailTextInput;
