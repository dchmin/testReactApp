import React from 'react';
import { emailLabels } from "../email/EmailWidget";

class FriendlyIdPopup extends React.Component {
	createFriendlyIdRadioBtns() {
		var reactObj = this;	
		var disableContent = emailLabels.friendlyIdAlreadyUsed;
		return (
		<div>
		{this.props.friendlyIdOptions.map(function(option,index){
			return (<div key={index}>
				<input type="radio" name="friendlyIdSelection" value={option.emailAddrNm} className="radioCheck" id={"radio"+option.id} checked={reactObj.props.selectedFriendlyId===option.emailAddrNm} onChange={(evt) =>reactObj.props.onFriendlyIdSelection(option.emailAddrNm, evt)} disabled={!option.available}></input>
				<label htmlFor={"radio"+option.id} className={"radio-label mar-top-10 " + ((option.available) ? "": "inline-help")}>
					{option.emailAddrNm}{(option.available) ? "": disableContent} 
				</label>
			</div>);
		})}
		</div>
		);
	}
	insertContentInfo(contentPosition, content, key, value) {
		if (typeof(content)!=="undefined") {
			if (content.indexOf(key)!==-1){
				var contentArray = content.split(key);
				if (contentPosition==="top"){
					content = <p>{contentArray[0]}<strong>{value}</strong>{contentArray[1]}</p>;
				} else {
					content = <div>{contentArray[0]}<strong className="no-break">{value}</strong>{contentArray[1]}</div>;
				}
			} else {
				if (contentPosition==="top"){
					content = <p>{content}</p>;
				} else {
					content = <div>{content}</div>;
				}
			}
			return content;
		}
	}
	getModalContent() {
		var popupTopContent = "";
		var popupBtmContent = "";
		var numFriendlyIdOptions = this.props.friendlyIdOptions.length;
		//Case where user deleted all their emails and can only login with access ID
		if (numFriendlyIdOptions===0){
			//var deletedFriendlyId  = this.props.emailInfo.filter(function(o){return o.friendlyId == true;});
			popupTopContent = emailLabels.friendlyIdNoEmailPopupContentTop;
			popupBtmContent = emailLabels.friendlyIdNoEmailPopupContentBtm;
			popupTopContent = this.insertContentInfo("top",popupTopContent, "<email>", this.props.oldFriendlyId);
			popupBtmContent = this.insertContentInfo("bottom",popupBtmContent, "<accessId>", this.props.accessID.replace(/(.{4})/g,"$1 ").trim());
			//Case where user can't select access Id as friendly Id and their one email is selected as Friendly
		} else if ((numFriendlyIdOptions===1) && (this.props.accessID === "")) {
			popupTopContent = emailLabels.friendlyIdOneEmailPopupContentTop;
			popupTopContent = <p>{popupTopContent}</p>;
			popupBtmContent = emailLabels.friendlyIdOneEmailPopupContentBtm;
			popupBtmContent = this.insertContentInfo("bottom",popupBtmContent, "<email>", this.props.emailInfo[0].emailAddrNm);
			//Case where the user has a list of emails and accessId to pick from
		} else {
			popupTopContent = <p>{emailLabels.friendlyIdSelectionContent}</p>;
			var accessIdTitle = emailLabels.accessIdTitle;
			var emailRadioBtns = this.createFriendlyIdRadioBtns();
			var accessIdRadioBtn;
			if ((typeof(this.props.accessID) !== "undefined") && this.props.accessID !== ""){
				accessIdRadioBtn=(
				<div key="accId">
					<input type="radio" name="friendlyIdSelection" value={this.props.accessID} className="radioCheck" id="accessIdOption" checked={this.props.selectedFriendlyId === this.props.accessID} onChange={(evt) => this.props.onFriendlyIdSelection(this.props.accessID, evt)}></input>
					<label htmlFor="accessIdOption" className="radio-label mar-top-10">
					{accessIdTitle} {this.props.accessID.replace(/(.{4})/g,"$1 ")}
					</label>
				</div>
				);
			}
			popupBtmContent = [this.createFriendlyIdRadioBtns(),accessIdRadioBtn];
			
		}
		
		return (
			<div>
				{popupTopContent}
				{popupBtmContent}
			</div>
		);
	}
	onPopupClose() {
		document.getElementById("emailSaveBtn").focus();
	}
	render() {     
		var closeBtnLabel = emailLabels.closeLabel;	
		var primaryBtnTxt = emailLabels.friendlyIdModalPrimaryBtnTxt;
		var cancelBtnTxt = emailLabels.cancelLabel;
		return (
			<div className="modal slf-modal" id={this.props.id} aria-labelledby={this.props.id+"Title"} role="dialog" tabIndex="-1">
				<div className="modal-dialog slf-yellow-modal" role="document">
					<div className="modal-content">
						<div className="modal-header">
							<h3 id={this.props.id+"Title"} className="modal-title inline-block">{this.props.headerText}</h3>
							<button type="button" className="close" data-dismiss="modal" aria-label={closeBtnLabel} onClick={this.onPopupClose}>
								<span className="fa fa-times" aria-hidden="true"></span>
							</button>
						</div>
						<div className="modal-body">
							{this.getModalContent()}
						</div>
						<div className="modal-footer">
							<button type="button" className="btn btn-link" data-dismiss="modal" onClick={this.onPopupClose}>{cancelBtnTxt}</button>
							<button type="button" className="btn btn-yellow" data-dismiss="modal" onClick={(e) => { this.props.onSaveFriendlySelection(this.props.selectedFriendlyId,e) }}>{primaryBtnTxt}</button>
						</div>
					</div>
				</div>
			</div>
		);
	}
}

export default FriendlyIdPopup;
