import PropTypes from 'prop-types'; // ES6
import React from 'react';

export const TwoBtnPopupModal = ({id, headerText, contentText, primaryBtnText, closeBtnText, linkBtnText, topFooterText, onPrimaryBtnClick, onLinkBtnClick, onCloseBtnClick}) => {
  return (
		<div className="modal slf-modal" id={id} aria-labelledby={id+"Title"} role="dialog" tabIndex="-1">
			<div className="modal-dialog slf-yellow-modal" role="document">
				<div className="modal-content">
					<div className="modal-header">
            <h3 id={id+"Title"} className="modal-title inline-block">{headerText}</h3>
						<button type="button" className="close" onClick={onCloseBtnClick} data-dismiss="modal" aria-label={closeBtnText}>
							<span className="fa fa-times" aria-hidden="true"></span>
						</button>

					</div>
					<div className="modal-body">
						<p>{contentText}</p>
					</div>
					<div className="modal-footer">
						{(topFooterText !== "")? <div className="modal-footer-text-top text-left mar-bottom-10">{topFooterText}</div> : null}
						<button type="button" className="btn btn-link" data-dismiss="modal" onClick={onLinkBtnClick}>{linkBtnText}</button>
						<button type="button" className="btn btn-yellow" data-dismiss="modal" onClick={onPrimaryBtnClick}>{primaryBtnText}</button>
					</div>
				</div>
			</div>
		</div>

  );
};

TwoBtnPopupModal.propTypes = {
  id         				: PropTypes.string.isRequired,
  headerText   			: PropTypes.string,
  primaryBtnText   	: PropTypes.string,
	closeBtnText   		: PropTypes.string,
	linkBtnText				:	PropTypes.string,
};
