import React, { Component } from 'react';
import ReactDOM from 'react-dom';

export class SuccessMsg extends Component {
    
    state = {
        show: false,
        transitionClass:""
    };
    componentDidMount() {
      this.setState(() => ({
        show: this.props.showSuccessMsg,
      }));
      if (this.saveMsgTimer) { //Cancel the previous timer
        clearTimeout(this.saveMsgTimer);
        this.saveMsgTimer = null;
      }
      this.saveMsgTimer = setTimeout(this.unMountStyle, 5000);

    }
    componentWillReceiveProps(newProps) { //check for the mounted props
      if(newProps.showSuccessMsg){
        this.setState(() => ({
          show: newProps.showSuccessMsg,
        }));
        if (this.saveMsgTimer) { //Cancel the previous timer
          clearTimeout(this.saveMsgTimer);
          this.saveMsgTimer = null;
        }
        this.saveMsgTimer = setTimeout(this.unMountStyle, 5000);
      } else {
        this.setState(() => ({
          show: false,
          transitionClass: ""
        }));
      }
    }
    componentWillUnmount() {
      clearTimeout(this.saveMsgTimer);
      this.saveMsgTimer = null;
      this.props.removeSaveSuccessMsg();
    }
    componentDidUpdate() {
      // When success message is rendered
      if (this.props.showSuccessMsg && this.state.transitionClass === "") {
        // Focus on save message        
        if (this.props.rootContainer !== undefined) {
          ReactDOM.findDOMNode(this.props.rootContainer).focus();
        }        
        ReactDOM.findDOMNode(this.refs.saveMsg).focus();
        
        // Validate that the save message is in view
        const top = this.refs.saveMsg.getBoundingClientRect().top;
        const offset = 0;
      
        if ((this.props.rootContainer !== undefined) && ((top + offset) >= 0) && ((top - offset) <= window.innerHeight)) {
          document.getElementById(this.props.rootContainer.id).scrollIntoView(); //scroll the element into view 
        }
      }
    }
    unMountStyle = () => {
      if (this.props.showSuccessMsg){
        this.setState(() => ({
          transitionClass: "hideElementAnimate",
        }));
      }
    }
    transitionEnd = () => {
      if (this.props.showSuccessMsg) {
        this.setState(() => ({
          show: false,
          transitionClass: ""
        }));
        this.props.removeSaveSuccessMsg();
      }
    }
    render() {
      return this.state.show && (
        <div onTransitionEnd={this.transitionEnd} id={this.props.id} className={`${this.state.transitionClass} topNotifContainer`}>
          <div ref="saveMsg" className={`field-set-validation-success ${this.props.className}`} tabIndex="0" id={`${this.props.id}-success-msg`}>{this.props.content}</div>
        </div>
      )
    }
}
