import React from 'react';
import {emailLabels} from '../email/EmailWidget';
//var ToggleDropdown = createReactClass({
class ToggleDropdown extends React.Component {
	componentDidMount() {
		if ((this.mySelectDropdown.value === "") && (this.props.shouldFocusOnSelect)) {
			this.mySelectDropdown.focus();
		}
	}
	createPhoneTypeList(selectedType){      
		var emailTypes = this.props.emailTypes;
		var options = [];
		options.push(<option key={"select"+this.props.email.id} value="">{emailLabels.selectLabel}</option>);
      
      // Determine which types to display
		if ((this.props.emailTypesAvailable.indexOf("H") === -1) && (selectedType !== "H")){
			// do not show the option
		} else {
			options.push(<option key={"personal"+this.props.email.id} value="H">{this.getLabelForEmailType(emailTypes, "H")}</option>);
		}
		if ((this.props.emailTypesAvailable.indexOf("B") === -1) && (selectedType !== "B")){
			// do not show the option
		} else {
         options.push(<option key={"work"+this.props.email.id} value="B">{this.getLabelForEmailType(emailTypes, "B")}</option>);
		}
		return options;
	}
   
   getLabelForEmailType(emailTypes, emailTypeCd) {
      // Given the type code and language return the correct label 
      var emailObj = emailTypes.filter(function( obj ) {
        return obj.id === emailTypeCd;
      })[0];
      return this.props.lang === 'en_CA' ? emailObj.desc_En : emailObj.desc_Fr;
   }

	render() {      
		// States
		var selectedType = this.props.email.addrCntxtCd;
	
		return (
		<td>
		<div>
					<a id={"emailAnchor"+this.props.email.id} tabIndex="-1" aria-hidden="true"></a>
					<label htmlFor={"emailType"+this.props.email.id}>{emailLabels.typeLabel}</label>
					<div className="select-arrow-wrapper">
						<select 
							value={selectedType}
							data-previousval={selectedType}
							id={"emailType"+this.props.email.id}
							className="type-dropdown form-control" 
							required="" 
							required={true} 
							onChange={this.props.onEmailTypeChange} 
							data-parsley-required-message={emailLabels.reqFieldError} 
							ref={(ref => this.mySelectDropdown = ref)}
							>
							{this.createPhoneTypeList(selectedType)}
						</select>
					</div>
				</div>
		</td>
		);
	}
}
export default ToggleDropdown;
