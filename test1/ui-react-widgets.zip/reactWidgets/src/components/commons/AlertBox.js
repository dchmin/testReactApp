import React from 'react';

export const AlertBox = ({classes, ...props}) => {
  return (
    <div className={`slf-alert-box ${classes}`} {...props}>
      <div>
        {props.children}
      </div>
    </div>
  );
}
