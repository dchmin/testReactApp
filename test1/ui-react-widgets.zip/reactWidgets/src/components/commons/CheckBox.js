import PropTypes from 'prop-types'; // ES6
import React from 'react';

const CheckBox = ({id, name, value, label, parentClass, ...props}) => {

  return (
   <div className={parentClass}>
			<input id={id} type="checkbox" name={name} value={value} {...props}/>
			<label htmlFor={id} className="mar-top-10">{label}</label>
		</div>
  );
};

CheckBox.propTypes = {
  id  	 : PropTypes.string.isRequired,
  value  : PropTypes.string.isRequired,
  name   : PropTypes.string,
  label  : PropTypes.string.isRequired
};

export default CheckBox;
