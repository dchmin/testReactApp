import React from 'react';

export const AlertBoxError = ({...props}) => {
  return (
	<div className={"slf-alert-box slf-alert-box-error slf-burgundy-bg-10"} {...props}>
      <div>
        {props.children}
      </div>
    </div>
  );
}
