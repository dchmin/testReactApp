import React from "react";
import ViewMode from "./ViewMode";
import EditMode from "./EditMode";
import { content, permissionContent } from "./MarketingPrefWidget";

class MarketingPrefContainer extends React.Component {
  componentDidMount() {
    if (typeof window.Parsley !== "undefined") {
      // WAI-ARIA for errors
      window.Parsley.on("field:error", function(formField) {
        var elem = global.$(formField.$element);
        elem.attr({
          "aria-invalid": "true",
          "aria-describedby": "parsley-id-" + formField.__id__
        });
        if (elem.is("input[type='radio']")) {
          elem.attr({
            "aria-describedby": formField._ui.errorsWrapperId
          });
        }
      });
      window.Parsley.on("field:success", function(formField) {
        var elem = global.$(formField.$element);
        elem.attr({
          "aria-invalid": "false"
        });
      });
    }
  }
  render() {
    if (this.props.displayMode === "view" || this.props.serverError === true) {
      return (
        <div
          id="marketingPrefContainer"
          className="viewMode no-outline"
          tabIndex="-1"
        >
          <h2>{content.widgetTitle}</h2>
          <ViewMode
            toggleView={this.props.toggleView}
            lang={this.props.lang}
            showSuccessMsg={this.props.showSuccessMsg}
            removeSaveSuccessMsg={this.props.removeSaveSuccessMsg}
            serverError={this.props.serverError}
            addTealiumTagging={this.props.addTealiumTagging}
            marketingPref={this.props.marketingPref}
          />
        </div>
      );
    } else {
      return (
        <div
          id="marketingPrefContainer"
          className="editMode no-outline"
          tabIndex="-1"
        >
          <h2>{content.widgetTitle}</h2>
          <EditMode
            toggleView={this.props.toggleView}
            lang={this.props.lang}
            onCancelClick={this.props.onCancelClick}
            onSaveClick={this.props.onSaveClick}
            marketingPref={this.props.marketingPref}
            onRadioSelectionChange={this.props.onRadioSelectionChange}
            serverErrMsg={this.props.serverErrMsg}
            callShadow={this.props.callShadow}
            addTealiumTagging={this.props.addTealiumTagging}
            focusOnElem={this.props.focusOnElem}
          />
        </div>
      );
    }
  }
}

export default MarketingPrefContainer;
