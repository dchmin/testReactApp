import React from "react";
import "./css/marketingWidget.scss";
import MarketingPrefContainer from "./MarketingPrefContainer";
import {
  lang,
  submitMarketPrefUserData,
  getUsersMarketingPrefData
} from "../../api/userPreference";

export const content =
  lang === "en_CA" ? global.marketingContent.en : global.marketingContent.fr;

export const widgetName = "Marketing Preference Widget";

class MarketingPrefWidget extends React.Component {
  state = {
    displayMode: "load",
    originalMarketingPref: "",
    marketingPref: "",
    callShadow: false,
    saveSuccessful: false,
    language: lang,
    editServerError: false,
    viewServerError: false
  };

  componentDidMount() {
    getUsersMarketingPrefData().then(marketingPrefResponse => {
      if (marketingPrefResponse) {
        this.setState(() => ({
          originalMarketingPref: marketingPrefResponse.marketingPreference,
          marketingPref: marketingPrefResponse.marketingPreference,
          callShadow: marketingPrefResponse.callShadow,
          displayMode: "view"
        }));
      } else {
        this.setState(() => ({
          displayMode: "view",
          serverError: true
        }));
      }
    });
  }
  toggleDisplayMode = e => {
    const newDisplayMode = this.state.displayMode === "view" ? "edit" : "view";
    this.setState(() => ({
      displayMode: newDisplayMode
    }));
  };
  removeSaveSuccessMsg = () => {
    this.setState(() => ({
      saveSuccessful: false
    }));
  };
  handleCancelClick = () => {
    this.toggleDisplayMode();
    const originalMarketingPref = this.state.originalMarketingPref;
    this.setState(() => ({
      marketingPref: originalMarketingPref,
      serverErrMsg: false
    }));
    //tealium tagging on click of the edit button
    this.addTealiumTagging("Edit screen - Cancel");
  };

  handleRadioSelectionChange = e => {
    const selectedOption = e.target.value;
    this.setState(() => ({
      marketingPref: selectedOption
    }));
  };

  disableFields = container => {
    global
      .$(container)
      .find("input")
      .prop("disabled", true);
    global.$(container + " form").addClass("form-disabled");
    global
      .$(container + " .btnArea .cancel-btn, .btnArea .save-btn")
      .prop("tabindex", "-1");
    global.$(container + " .save-btn").text(content.validatingLabel);
    global.$(container + " .save-btn").addClass("is-busy");
  };
  enableFields = container => {
    global
      .$(container)
      .find("input")
      .prop("disabled", false);
    global.$(container + " form").removeClass("form-disabled");
    global
      .$(container + " .btnArea .cancel-btn, .btnArea .save-btn")
      .removeAttr("tabindex", "-1");
    global.$(container + " .save-btn").text(content.saveLabel);
    global.$(container + " .save-btn").removeClass("is-busy");
  };
  handleSaveClick = e => {
    this.disableFields("#marketingPrefEditContainerForm");
    // Submit request
    submitMarketPrefUserData(this.state).then(submitResponse => {
      const marketingPreference = this.state.marketingPref;
      // Successful submission
      if (submitResponse && submitResponse.errorCode === "0") {
        // if (true) {
        // Update the state upon successful submission
        this.setState(() => ({
          originalMarketingPref: marketingPreference,
          serverErrMsg: false,
          saveSuccessful: true
        }));
        this.enableFields("#marketingPrefEditContainerForm");
        // Display View Mode
        this.toggleDisplayMode();
        //tealium tagging for successful save of paperless info
        this.addTealiumTagging("Edit screen - Successful save");
        //	global.$("#permissionPopup").modal('hide');
        //document.getElementById("success-msg").focus();
      } else {
        // Error upon submission
        this.setState(() => ({
          serverErrMsg: true
        }));
        this.enableFields("#marketingPrefEditContainerForm");
        document.getElementById("marketingPref-serverErrMsg").focus();
        //tealium tagging for successful save of paperless info
        this.addTealiumTagging("Edit screen - Unsuccessful save");
      }
    });
  };
  getTealiumUserState = () => {
    let userPplState = "No selection";
    if (this.state.marketingPref === "yes") {
      userPplState = "Yes selected";
    } else if (this.state.marketingPref === "no") {
      userPplState = "No selected";
    }
    return userPplState;
  };
  addTealiumTagging = description => {
    if (typeof global.utag !== "undefined") {
      global.utag.link({
        ev_type: "other",
        ev_action: "clk",
        ev_title: widgetName,
        ev_data_one: description,
        user_state: this.getTealiumUserState()
      });
    }
  };
  focusOnElem = elemId => {
    if (document.getElementById(elemId) !== null) {
      document.getElementById(elemId).focus();
    }
  };
  render() {
    if (this.state.displayMode === "load") {
      return null;
    } else {
      return (
        <div>
          <MarketingPrefContainer
            displayMode={this.state.displayMode}
            toggleView={this.toggleDisplayMode}
            lang={this.state.language}
            marketingPref={this.state.marketingPref}
            showSuccessMsg={this.state.saveSuccessful}
            removeSaveSuccessMsg={this.removeSaveSuccessMsg}
            onCancelClick={this.handleCancelClick}
            onSaveClick={this.handleSaveClick}
            onRadioSelectionChange={this.handleRadioSelectionChange}
            serverErrMsg={this.state.serverErrMsg}
            callShadow={this.state.callShadow}
            addTealiumTagging={this.addTealiumTagging}
            showCancel={this.state.showCancel}
            serverError={this.state.serverError}
            focusOnElem={this.focusOnElem}
          />
        </div>
      );
    }
  }
}

export default MarketingPrefWidget;
