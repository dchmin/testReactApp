import React from "react";
import ButtonLink from "../commons/ButtonLink";
import RadioButton from "../commons/RadioButton";
import { content, widgetName } from "./MarketingPrefWidget";
import OneBtnPopupModal from "../commons/OneBtnPopupModal";

class EditMode extends React.Component {
  // Set up Server Error Message
  showServerErrMsg = () => {
    return this.props.serverErrMsg ? (
      <div
        id="marketingPref-serverErrMsg"
        className="field-set-validation-errors mar-bottom-10"
        tabIndex="0"
      >
        {content.apologyError}
      </div>
    ) : null;
    //aria-live="assertive" aria-relevant="all" aria-atomic="true"
  };

  // Generate Restricted Access Popup on page
  generateRestrictedAccessPopup = () => {
    return this.props.callShadow ? (
      <OneBtnPopupModal
        id="marketingPref-accessRestricted"
        headerText={content.restrictedModalHeader}
        contentText={content.restrictedModalContent}
        primaryBtnText={content.okayLabel}
        closeBtnText={content.closeLabel}
        onCloseBtnClick={e => this.props.focusOnElem("marketingPrefSaveBtn")}
      />
    ) : null;
  };

  // Display Restricted Access Popup
  showRestrictedAccessPopup = () => {
    // Show popup
    global.$("#marketingPref-accessRestricted").modal({ backdrop: "static" });
  };

  // Set the correct click event function to Save button
  bindSaveEventHandler = (e, parent) => {
    var clickEvent = e;
    global
      .$("#marketingPrefEditContainerForm")
      .parsley()
      .validate();
    if (
      global
        .$("#marketingPrefEditContainerForm")
        .parsley()
        .isValid()
    ) {
      if (parent.props.callShadow) {
        //Call Shadow
        clickEvent.preventDefault();
        parent.showRestrictedAccessPopup();
      } else {
        parent.props.onSaveClick();
      }
    } else {
      this.props.addTealiumTagging("Edit screen - Unsuccessful save");
    }
  };
  render() {
    return (
      <div>
        <form
          id="marketingPrefEditContainerForm"
          className="form-group"
          data-parsley-validate
        >
          <div className="widgetContentContainer">
            <div
              id="marketingPref-notifContainer"
              className="topNotifContainer"
            >
              {this.showServerErrMsg()}
            </div>
            <p>{content.pleaseSelectLabel}</p>
            <div>
              <RadioButton
                key="yesOption"
                id="yesOption"
                value="yes"
                name="marketingPreferenceOption"
                label={[content.yesOption, <span className="radio-descr">{content.yesOptionDescription}</span>]}
                checked={this.props.marketingPref === "yes"}
                onChange={this.props.onRadioSelectionChange}
                required={true}
                data-parsley-required-message={content.reqFieldError}
                className={
                  this.props.marketingPref === "yes" ? "isChecked" : ""
                }
              />
              <br />
              <RadioButton
                key="noOption"
                id="noOption"
                value="no"
                name="marketingPreferenceOption"
                label={[content.noOption,<span className="radio-descr">{content.noOptionDescription}</span>]}
                checked={this.props.marketingPref === "no"}
                onChange={this.props.onRadioSelectionChange}
                className={this.props.marketingPref === "no" ? "isChecked" : ""}
              />
            </div>
          </div>
          <div className="btnArea">
            <ButtonLink
              value={content.cancelLabel}
              cssClass="btn btn-link cancel-btn"
              href="#marketingPrefContainer"
              onClick={this.props.onCancelClick}
            />
            <ButtonLink
              id="marketingPrefSaveBtn"
              value={content.saveLabel}
              cssClass="btn btn-yellow save-btn"
              href="javascript:void(0);"
              onClick={e => this.bindSaveEventHandler(e, this)}
            />
          </div>
        </form>
        {this.generateRestrictedAccessPopup()}
      </div>
    );
  }
}

export default EditMode;
