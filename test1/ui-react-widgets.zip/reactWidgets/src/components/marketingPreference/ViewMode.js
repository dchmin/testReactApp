import React from "react";
import ButtonLink from "../commons/ButtonLink";
import { content } from "./MarketingPrefWidget";
import { AlertBoxError } from "../commons/AlertBoxError";
import { SuccessMsg } from "../commons/SuccessMsg";

class ViewMode extends React.Component {
  displayUserPreference = () => {
    if (this.props.marketingPref === "yes") {
      return (
        <div>
          <span className="fa fa-check pos-absolute" />
          <div className="pad-left-30 weight-400">
            {content.yesOption}
          </div>
          <div className="pad-left-30">{content.yesOptionDescription}</div>
        </div>
      );
    } else if (this.props.marketingPref === "no") {
      return (
        <div>
          <span className="fa fa-check pos-absolute" />
          <div className="pad-left-30 weight-400">
            {content.noOption}
          </div>
          <div className="pad-left-30">{content.noOptionDescription}</div>
        </div>
      );
    } else {
      return (
        <div>
          <span className="sr-only">{content.notSelectedAlt}</span>
          <div className="pad-left-30 weight-400" aria-hidden="true">{content.notSelected}</div>
        </div>
      );
    }
  };

  // Set up apology Error Message
  showServerErrMsg = () => {
    return this.props.apology ? (
      <div
        id="apologyError-serverErrMsg"
        className="field-set-validation-errors mar-bottom-10"
        tabIndex="0"
      >
        {content.apologyError}
      </div>
    ) : null;
  };

  editAction = e => {
    this.props.toggleView();
    //tealium tagging on click of the edit button
    this.props.addTealiumTagging("Main screen - Edit");
  };
  render() {
    if (this.props.serverError) {
      return (
        <div>
          <div className="outage-container">
            <AlertBoxError>{content.apologyError}</AlertBoxError>
          </div>
        </div>
      );
    } else {
      return (
        <div>
          <div className="widgetContentContainer">
            <SuccessMsg
              id="marketingPref-successNotifContainer"
              className="mar-bottom-10"
              content={content.successLabel}
              showSuccessMsg={this.props.showSuccessMsg}
              removeSaveSuccessMsg={this.props.removeSaveSuccessMsg}
              rootContainer={this.refs.marketingPrefNotifContRef}
            />
            <div
              id="marketingPref-notifContainer"
              className="topNotifContainer"
              ref="marketingPrefNotifContRef"
            >
              {this.showServerErrMsg()}
            </div>
            <p>{content.pleaseSelectLabel}</p>
            <div className="mar-top-20">
              {this.displayUserPreference()}
            </div>
          </div>
          <div className="btnArea">
            <ButtonLink
              value={[
                content.editLabel,
                <span className="sr-only"> {content.widgetTitle}</span>
              ]}
              cssClass="btn btn-blue"
              href="#marketingPrefContainer"
              onClick={this.editAction}
            />
          </div>
        </div>
      );
    }
  }
}

export default ViewMode;
