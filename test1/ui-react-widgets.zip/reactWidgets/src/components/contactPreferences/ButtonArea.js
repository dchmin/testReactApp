import React from "react";
import PropTypes from "prop-types";
import ButtonLink from '../commons/ButtonLink';

class ButtonArea extends React.Component {
  // *Render
  render() {

      return <div className="btnArea  react-widget__btn-area">
        { this.props.displayMode === 'edit' && 
        <ButtonLink 
                value={this.props.labels.cancelLabel} 
                cssClass="btn btn-link cancel-btn" 
                href="#contactPreferencesContainer" 
                onClick={this.props.cancelAction}
                tabIndex={this.props.disableField ? -1 : 0}
                />
    }
        {this.props.displayMode === 'edit' &&
                <ButtonLink
                id="contactPreferencesSaveBtn"
                value={this.props.disableField ? this.props.labels.validatingLabel : this.props.labels.saveLabel}
                cssClass={`btn btn-yellow save-btn ${this.props.disableField ? "is-busy": ""}`}
                href="#contactPreferencesContainer"
                onClick={this.props.saveAction}
                tabIndex={this.props.disableField ? -1 : 0}
                />
                }
        {this.props.displayMode === 'view' &&  
        <ButtonLink
                  value={this.props.labels.editLabel}
                  cssClass="btn btn-blue"
                  href="#contactPreferencesContainer"
                  onClick={this.props.editAction}
                  disabled={this.props.apology}
                  aria-disabled={this.props.apology}
                />
              }
            </div>
    
  }
}

/**
 * *Check PropTypes
 */
ButtonArea.propTypes = {
  labels: PropTypes.object
};

export default ButtonArea;
