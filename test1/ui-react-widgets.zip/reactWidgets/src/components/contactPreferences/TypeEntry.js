import React from "react";
import PropTypes from "prop-types";
import ChannelEntry from "./ChannelEntry";

import { lang } from "../../api/userPreference";
export const content =
  lang === "en_CA"
    ? global.contactPreferencesContent.en
    : global.contactPreferencesContent.fr;

class TypeEntry extends React.Component {
  displayFieldErrMsg = () => {
    // Display appropriate field error message
    if (this.props.fieldErrorMsg === 1) {
      return (
        <div
          id={`${this.props.name}-one-required-error-message`}
          className="field-set-validation-errors mar-bottom-10 mar-top-5"
        >
          {content.oneEmptyRadioErrMsg}
        </div>
      );
    } else if (this.props.fieldErrorMsg > 1) {
      return (
        <div
          id={`${this.props.name}-multiple-required-error-message`}
          className="field-set-validation-errors mar-bottom-10 mar-top-5"
        >
          {content.multiEmptyRadioErrMsg}
        </div>
      );
    } else {
      return null;
    }
  };

  // *Render
  render() {
    if (this.props.jsonReady === 0) return null;

    return (
      <div className="row  react-widget__item">
        <div className="col-xs-12">
          <p>{this.props.labels.typeEntryLabel}</p>
          <div className={`row ${this.props.name}-row`}>
            {this.props.channelsTypes.map((key, index) => (
              <ChannelEntry
                key={index}
                channelsTypes={key}
                preferencesTypes={this.props.name}
                name={`${this.props.name}-${index}`}
                label={this.props.labels[`${key}Label`]}
                value={this.props.contactPreferences[key]}
                displayMode={this.props.displayMode}
                radioBtnToggle={this.props.radioBtnToggle}
                disableField={this.props.disableField}
                lastIndex={
                  this.props.channelsTypes.length === index + 1 ? true : false
                }
              />
            ))}
          </div>
          {this.displayFieldErrMsg()}

          <hr className="page-separator  hidden-md  hidden-lg  react-widget__item-separator" />
          <div className="mar-bottom-30  visible-md  visible-lg  react-widget__item-spacer" />
        </div>
      </div>
    );
  }
}

/**
 * *Check PropTypes
 */
TypeEntry.propTypes = {
  labels: PropTypes.object,
  contactPreferences: PropTypes.shape({
    email: PropTypes.number,
    mail: PropTypes.number,
    phone: PropTypes.number
  })
};

export default TypeEntry;
