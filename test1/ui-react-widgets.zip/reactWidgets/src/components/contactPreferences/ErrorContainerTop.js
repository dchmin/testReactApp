import React from "react";
import ReactDOM from "react-dom";
import PropTypes from "prop-types";

import { lang } from "../../api/userPreference";
export const content =
  lang === "en_CA"
    ? global.contactPreferencesContent.en
    : global.contactPreferencesContent.fr;

class ErrorContainerTop extends React.Component {
  constructor() {
    super();
    // Keep track if the error counter is already rendered before
    this.initialErrorCountDisplay = 0;
  }

  componentDidUpdate() {
    // If Error message is re-render reset tracker variable
    if (this.props.errCountMsg !== this.initialErrorCount) {
      this.initialErrorCount = 0;
    }

    // Focus on error counter if this is the first time rendering
    if (this.props.errCountMsg >= 1 && this.initialErrorCount === 0) {
      ReactDOM.findDOMNode(this.refs.errCountMsg).focus();
      this.initialErrorCount = this.props.errCountMsg;
    }

    if (this.props.serverErrMsg) {
      ReactDOM.findDOMNode(this.refs.serverErrMsg).focus();
    }
  }

  // *Render
  render() {
    return (
      <div id="contactPreferences-notifContainer" className="topNotifContainer">
        {/* Server error */}
        {this.props.serverErrMsg === true && (
          <div
            id="contactPref-serverErrMsg"
            ref="serverErrMsg"
            className="field-set-validation-errors mar-bottom-10"
            tabIndex="0"
          >
            {content.serverErrMsg}
          </div>
        )}

        {/* Error counter */}
        {this.props.errCountMsg === 1 && (
          <div
            id="contactPref-errCountMsg"
            ref="errCountMsg"
            className="field-set-validation-errors mar-bottom-10"
            tabIndex="0"
          >
            {content.singleError}
          </div>
        )}
        {this.props.errCountMsg > 1 && (
          <div
            id="contactPref-errCountMsg"
            ref="errCountMsg"
            className="field-set-validation-errors mar-bottom-10"
            tabIndex="0"
          >
            {content.multipleErrors.replace("<x>", this.props.errCountMsg)}
          </div>
        )}

        {/* Blank radio buttons message */}
        {this.props.emptyValue && (
          <div
            className={`field-set-validation-errors  slf-yellow-bg  mar-bottom-20`}
          >
            {content.emptyAlert}
          </div>
        )}
      </div>
    );
  }
}

/**
 * *Check PropTypes
 */
ErrorContainerTop.propTypes = {
  labels: PropTypes.object
};

export default ErrorContainerTop;
