import React from "react";
import PropTypes from "prop-types";
import { lang } from "../../api/userPreference";
export const content =
  lang === "en_CA"
    ? global.contactPreferencesContent.en
    : global.contactPreferencesContent.fr;

class ChannelEntry extends React.Component {
  /**
   * * Update value
   */
  updateValues = event => {
    // Get the new value
    let newValue = 1;

    if (event.target.value === "no") {
      newValue = 0;
    }

    this.props.radioBtnToggle(
      newValue,
      this.props.preferencesTypes,
      this.props.channelsTypes
    );
  };

  /**
   * * Render
   */
  render() {
    if (this.props.value === -1) this.valueLabel = content.emptyLabel;
    if (this.props.value === 0) this.valueLabel = content.noLabel;
    if (this.props.value === 1) this.valueLabel = content.yesLabel;
    return (
      <div className="col-xs-12  col-md-4">
        {this.props.displayMode === "edit" ? (
          <div className="row">
            <div className="col-xs-12">
              {/* <div className="col-xs-12 react-widget__item-label">
              <strong>{this.props.label}</strong>
            </div> */}
              <fieldset className="slf-fieldset">
                <legend>{this.props.label}</legend>
                <div
                  className="pad-top-5"
                  data-id={`${this.props.preferencesTypes}_${
                    this.props.channelsTypes
                  }`}
                >
                  {/* YES */}
                  <input
                    onChange={this.updateValues}
                    className="radioCheck"
                    type="radio"
                    value="yes"
                    name={`${this.props.name}`}
                    id={`${this.props.name}-yes`}
                    checked={this.props.value === 1 ? true : false}
                    disabled={this.props.disableField}
                    aria-disabled={this.props.disableField}
                    required="true"
                    data-parsley-required="true"
                    data-parsley-errors-messages-disabled="true"
                  />
                  <label
                    className="radio-label react-widget__item-radioBtn"
                    htmlFor={`${this.props.name}-yes`}
                  >
                    {content.yesLabel}
                  </label>
                  {/* NO */}
                  <input
                    onChange={this.updateValues}
                    className="radioCheck"
                    type="radio"
                    value="no"
                    name={`${this.props.name}`}
                    id={`${this.props.name}-no`}
                    checked={this.props.value === 0 ? true : false}
                    disabled={this.props.disableField}
                    aria-disabled={this.props.disableField}
                  />
                  <label
                    className="radio-label react-widget__item-radioBtn"
                    htmlFor={`${this.props.name}-no`}
                  >
                    {content.noLabel}
                  </label>
                  {!this.props.lastIndex && (
                    <div className="mar-bottom-15  hidden-md  hidden-lg" />
                  )}
                </div>
              </fieldset>
            </div>
          </div>
        ) : (
          <div className="row">
            <div className="col-xs-6  col-sm-4  col-md-12  col-lg-6  react-widget__item-label">
              <strong>{this.props.label}</strong>
            </div>
            <div className="col-xs-6  col-sm-8  col-md-12  col-lg-6  react-widget__item-value">
              <div className="mar-left-10">{this.valueLabel}</div>
            </div>
          </div>
        )}
      </div>
    );
  }
}

/**
 * * Check PropTypes
 */
ChannelEntry.propTypes = {
  value: PropTypes.number
};

export default ChannelEntry;
