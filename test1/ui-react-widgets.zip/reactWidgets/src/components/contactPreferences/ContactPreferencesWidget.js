import React from "react";
import { get } from "../../api/client";
import {
  lang,
  submitUserData,
  getUsersContactPrefData
} from "../../api/userPreference";
import "./css/contactPreferencesWidget.css";
import { SuccessMsg } from "../commons/SuccessMsg";
import { AlertBoxError } from "../commons/AlertBoxError";
import { AlertBox } from "../commons/AlertBox";
import ButtonArea from "./ButtonArea";
import ErrorContainerTop from "./ErrorContainerTop";
import TypeEntry from "./TypeEntry";
import OneBtnPopupModal from "../commons/OneBtnPopupModal";

export const content =
  lang === "en_CA"
    ? global.contactPreferencesContent.en
    : global.contactPreferencesContent.fr;
export const pageName = "Contact Preferences";

class ContactPreferencesWidget extends React.Component {
  /**
   * * Constructor
   */
  constructor() {
    super();
    // array of Types of preferences.
    this.preferencesTypes = ["productMktg", "crossSellingMktg", "survey"];
    // array of Types of channels.
    this.channelsTypes = ["email", "phone", "mail"];
    // State
    this.state = {
      displayMode: "load", // Default is load
      language: lang, // Language French or English
      serverErrMsg: false, //Show or hide server error message
      contactPreferences: {},
      contactPreferencesOriginal: {},
      callShadow: false,
      apology: false,
      errCountMsg: 0, // Counts the total error on the widget
      fieldErrorMsg: {}, // Error displayed per row
      serverError: false, // Outage error when information cannot be received
      jsonReady: 0,
      emptyValue: false, // There are radio buttons unselected
      saveSuccessful: false,
      disableField: false,
      formDisableClass: ""
    };
    this.contactPrefServiceUrl = `${global.contactPrefServiceURL}/${lang}`;
  }

  /**
   * Action associated to Edit Button
   */
  editAction = event => {
    this.setState({
      displayMode: "edit"
    });

    // Remove Save Success Message
    this.removeSaveSuccessMsg();
    // Tealium
    this.sendTealiumEvent({ ev_data_one: "Main screen - Click Edit" });
  };

  /**
   * Action associated to Cancel Button
   */
  cancelAction = event => {
    // Revert State
    this.setState({
      displayMode: "view",
      contactPreferences: JSON.parse(
        JSON.stringify(this.state.contactPreferencesOriginal)
      ),
      serverErrMsg: false,
      errCountMsg: 0,
      fieldErrorMsg: {}
    });

    // Scroll to top of the widget
    this.widgetScrollToTop();
    // Tealium
    this.sendTealiumEvent({ ev_data_one: "Edit screen - Click Cancel" });
  };

  /**
   * Action associated to Save Button to validate the widget first
   */
  validateWidget = event => {
    event.preventDefault(); // Allow Save Message component to handle focus

    // Validate radio buttons
    var form = global.$("#contactPreferencesContainer form").parsley();
    form.validate();

    // Scroll to top of the widget
    this.widgetScrollToTop();

    if (form.isValid()) {
      //No errors
      this.saveAction(event);
    } else {
      //There are errors on the page
      // Find errors
      var errors = document.querySelectorAll(
        "#contactPreferencesContainer .parsley-error"
      );

      if (errors) {
        this.displayFieldErrorMsg(); // Display error per row
        this.displayErrorCounter(errors); // Display error counter

        // creating the error ids value for tealium tagging
        let error_ids;
        for (var index = 0; index < errors.length; index++) {
          if (index === 0) error_ids = errors[index].dataset.id;
          if (index > 0) error_ids += `:${errors[index].dataset.id}`;
        }
        // Tealium
        this.sendTealiumEvent({
          ev_data_one: "Edit Screen - Unsuccessful Save with UI Error",
          ev_data_two: error_ids
        });
      }
    }
  };

  displayFieldErrorMsg = () => {
    var newFieldErrorCount = JSON.parse(
      JSON.stringify(this.state.fieldErrorMsg)
    );

    // Go through each row and display field error messages
    this.preferencesTypes.map((key, index) => {
      var rowName = "." + key + "-row";
      var rowErrorCount = document.querySelectorAll(rowName + " .parsley-error")
        .length;

      newFieldErrorCount[key] = rowErrorCount;
    });

    this.setState({
      fieldErrorMsg: newFieldErrorCount
    });
  };

  displayErrorCounter = errors => {
    // Display error counter
    this.setState({
      errCountMsg: errors.length
    });

    // Focus on error counter
    var errorCountContainer = document.getElementById(
      "contactPref-errCountMsg"
    );
    if (errorCountContainer) {
      errorCountContainer.focus();
    }
  };
  focusOnElem = elemId => {
    if (document.getElementById(elemId) !== null) {
      document.getElementById(elemId).focus();
    }
  };
  generateRestrictedAccessPopup = () => {
    return (
      this.state.callShadow && (
        <OneBtnPopupModal
          id="contactPreferences-accessRestricted"
          headerText={content.restrictedModalHeader}
          contentText={content.restrictedModalContent}
          primaryBtnText={content.okayLabel}
          closeBtnText={content.closeLabel}
          onCloseBtnClick={e => this.focusOnElem("contactPreferencesSaveBtn")}
        />
      )
    );
  };

  /**
   * Action associated to Save with no field errors
   */
  saveAction = event => {
    // Call Shadow Check
    if (this.state.callShadow) {
      // we make sure to remove error count message.
      this.setState({ errCountMsg: 0 });
      event.preventDefault();
      global
        .$("#contactPreferences-accessRestricted")
        .modal({ backdrop: "static" });
      return false;
    }

    // Disable widget interactions during saving process
    this.setState({
      disableField: true,
      formDisableClass: "form-disabled",
      errCountMsg: 0
    });

    // Format json
    let json = {};
    json.contactPreferences = this.state.contactPreferences;

    // Save user preferences
    submitUserData(json, this.contactPrefServiceUrl).then(submitResponse => {
      if (submitResponse && submitResponse.errorCode == "0") {
        // Save successful
        this.setState({
          displayMode: "view",
          contactPreferencesOriginal: JSON.parse(
            JSON.stringify(this.state.contactPreferences)
          ),
          emptyValue: false,
          saveSuccessful: true,
          disableField: false,
          formDisableClass: ""
        });
        // Tealium
        this.sendTealiumEvent({ ev_data_one: "Edit screen - Successful Save" });
      } else {
        // Error upon submission
        this.setState({
          disableField: false,
          formDisableClass: "",
          serverErrMsg: true
        });

        // Tealium
        this.sendTealiumEvent({
          ev_data_one: "Edit Screen - Unsuccessful Save with Server Error"
        });

        // print out error to console
        if (submitResponse && parseInt(submitResponse.errorCode) < 0) {
          console.log(
            "Error Code: " +
              submitResponse.errorCode +
              " - " +
              submitResponse.errorMsg
          );
        }
      }
    });
  };

  /**
   * Action associated to Radio Button
   */
  radioBtnToggle = (newValue, preferencesTypes, channelsTypes) => {
    // Create a mutable copy of object and update new radio value
    let editContactPreferences = JSON.parse(
      JSON.stringify(this.state.contactPreferences)
    );
    let oldValue = editContactPreferences[preferencesTypes][channelsTypes];
    editContactPreferences[preferencesTypes][channelsTypes] = newValue;

    // if blank was updated
    let newFieldError = JSON.parse(JSON.stringify(this.state.fieldErrorMsg));
    if (oldValue === -1) {
      newFieldError[preferencesTypes] -= 1;
    }

    // Update radio button state
    this.setState({
      contactPreferences: editContactPreferences,
      fieldErrorMsg: newFieldError
    });
  };

  /**
   * Action associated to Save Success Message
   */
  removeSaveSuccessMsg = () => {
    this.setState(() => ({
      saveSuccessful: false
    }));
  };

  /**
   * Check empty values from contact preferences User
   * It loops the response.contactPreferences values add look for a single -1 values
   */
  getEmptyValue = contactPrefvalues => {
    let emptyValue = false;

    // Polyfill for IE11
    if (!Object.entries) {
      Object.entries = function(obj) {
        var ownProps = Object.keys(obj),
          i = ownProps.length,
          resArray = new Array(i); // preallocate the Array
        while (i--) resArray[i] = [ownProps[i], obj[ownProps[i]]];

        return resArray;
      };
    }

    Object.entries(contactPrefvalues).forEach(([key, value]) => {
      Object.keys(value).map(item => {
        if (value[item] === -1) emptyValue = true;
      });
    });
    return emptyValue;
  };

  /**
   * Scroll to the top of the widget
   */
  widgetScrollToTop = () => {
    // Validate that the top of the widget container is in view
    const top = this.refs.contactPrefContRef.getBoundingClientRect().top;
    const offset = 0;

    if (top + offset < 0 || top - offset > window.innerHeight) {
      document.getElementById(this.refs.contactPrefContRef.id).scrollIntoView(); //scroll the element into view
    }
  };

  /**
   * Send an Event to Tealium
   * Pass a json object as parameters if needed.
   */
  sendTealiumEvent = datas => {
    // check if utag is defined in the global page
    if (typeof global.utag !== "undefined") {
      // passing datas parameters to utag_datas variable.
      let utag_obj = { ...datas };

      // Define a set of default keys to utag_obj
      if (!utag_obj.ev_type) utag_obj.ev_type = "other";
      if (!utag_obj.ev_action) utag_obj.ev_action = "clk";
      if (!utag_obj.ev_title) utag_obj.ev_title = pageName;

      // Send Tealium Event with utag_obj object
      global.utag.link(utag_obj);

      // console log for each event only in dev env.
      if (process.env.NODE_ENV !== "production")
        console.log("sendTealiumEvent", datas, utag_obj);
    }
  };

  /**
   * * Did mount
   */
  componentDidMount() {
    getUsersContactPrefData().then(response => {
      if (response && response.contactPreferences !== undefined) {
        this.setState(() => ({
          contactPreferences: response.contactPreferences,
          contactPreferencesOriginal: response.contactPreferences,
          callShadow: response.callShadow,
          apology: response.apology,
          errorCode: response.errorCode,
          errorMsg: response.errorMsg,
          jsonReady: 1,
          displayMode: "view",
          emptyValue: this.getEmptyValue(response.contactPreferences)
        }));
      } else {
        this.setState(() => ({
          serverError: true,
          jsonReady: 1,
          displayMode: "view"
        }));
      }
    });
  }

  /**
   * * Render
   */
  render() {
    if (this.state.serverError) {
      return (
        <div
          id="contactPreferencesContainer"
          className="react-widget react-widget--is-not-outlined"
          ref="contactPrefContRef"
          tabIndex="-1"
        >
          <h2>{content.widgetTitle}</h2>
          <div
            className={`react-widget__container react-widget__container--is-${
              this.state.displayMode
            }-mode ${this.state.formDisableClass}
            ${
              this.state.displayMode !== "edit"
                ? "slf-blue-bg-5"
                : "slf-blue-10-border-color"
            }
          `}
          >
            <div>
              <div className="outage-container">
                <AlertBoxError>{content.serverErrMsg}</AlertBoxError>
              </div>
            </div>
          </div>
        </div>
      );
    } else {
      return (
        <div
          id="contactPreferencesContainer"
          className="react-widget react-widget--is-not-outlined"
          ref="contactPrefContRef"
          tabIndex="-1"
        >
          <h2>{content.widgetTitle}</h2>
          <div
            className={`react-widget__container react-widget__container--is-${
              this.state.displayMode
            }-mode ${this.state.formDisableClass}
            ${
              this.state.displayMode !== "edit"
                ? "slf-blue-bg-5"
                : "slf-blue-10-border-color"
            }
          `}
          >
            <div
              className={`widgetContentContainer 
                ${
                  this.state.emptyValue || this.state.saveSuccessful
                    ? "react-widget__content--with-notif-spacing"
                    : "react-widget__content"
                }
              `}
            >
              {/* Messages at top of widget */}
              {!this.state.saveSuccessful && (
                <ErrorContainerTop
                  errCountMsg={this.state.errCountMsg}
                  serverErrMsg={this.state.serverErrMsg}
                  emptyValue={this.state.emptyValue}
                />
              )}
              {/* Save success message */}
              <SuccessMsg
                id="contactPreferences-saveNotif"
                className="mar-bottom-10"
                content={content.successLabel}
                showSuccessMsg={this.state.saveSuccessful}
                removeSaveSuccessMsg={this.removeSaveSuccessMsg}
                rootContainer={this.refs.contactPrefContRef}
              />
              <AlertBox
                id="contactPrefInfoBox"
                classes="slf-slate-blue-bg-10 mar-bottom-30"
              >
                <p>{content.contactPrefInfoAlertBox.split("<br/>")[0]}</p>
                <ol style={{ "margin-bottom": "0px" }}>
                  <li>{content.contactPrefInfoAlertBox.split("<br/>")[1]}</li>
                  <li>{content.contactPrefInfoAlertBox.split("<br/>")[2]}</li>
                </ol>
              </AlertBox>
              <form>
                {this.preferencesTypes.map((key, index) => (
                  <TypeEntry
                    key={key}
                    name={`${this.preferencesTypes[index]}`}
                    labels={{
                      typeEntryLabel:
                        content[`${this.preferencesTypes[index]}Label`],
                      emailLabel: content.emailLabel,
                      phoneLabel: content.phoneLabel,
                      mailLabel: content.mailLabel
                    }}
                    channelsTypes={this.channelsTypes}
                    contactPreferences={this.state.contactPreferences[key]}
                    jsonReady={this.state.jsonReady}
                    displayMode={this.state.displayMode}
                    radioBtnToggle={this.radioBtnToggle}
                    disableField={this.state.disableField}
                    fieldErrorMsg={this.state.fieldErrorMsg[key]}
                  />
                ))}
              </form>
            </div>
            <ButtonArea
              displayMode={this.state.displayMode}
              labels={{
                editLabel: [
                  content.editLabel,
                  <span className="sr-only"> {content.widgetTitle}</span>
                ],
                cancelLabel: content.cancelLabel,
                saveLabel: content.saveLabel,
                validatingLabel: content.validatingLabel
              }}
              editAction={this.editAction}
              cancelAction={this.cancelAction}
              saveAction={this.validateWidget}
              apology={this.props.apology}
              disableField={this.state.disableField}
            />
          </div>
          {this.generateRestrictedAccessPopup()}
        </div>
      );
    }
  }
}

export default ContactPreferencesWidget;
