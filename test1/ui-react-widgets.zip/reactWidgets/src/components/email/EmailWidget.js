import React from "react";
import "./css/emailLobby.css";
import {emailContent} from "./content/emailLobbyContent.js";
import EmailContainer from "./EmailContainer";
import OneBtnPopupModal from "../commons/OneBtnPopupModal";
import { getClientsEmailInfo, submitEmailInfo } from "../../api/userPreference";

// Global variables
var saveMsgTimer = null; //Used for reseting timer for the successful saved message
var animateHideTimer = null; //Used for animating the save succesful message
// var correctPreferred = false; 
let hasPreferred = false; // User has the preferred flag set correctly
let hasFriendlyId = false; // User has the sign-in ID flag set correctly
var callShadow = false;
var lang =
  document.getElementsByTagName("html")[0].getAttribute("lang") + "_CA";
if (lang === undefined || lang === null) {
  lang = "en_CA";
}

const continueBtn = document.querySelector(".js-continue-button");

// export const emailLabels = lang === "en_CA" ? global.emailContent.en : global.emailContent.fr;
export const emailLabels = lang === "en_CA" ? emailContent.en : emailContent.fr;
class EmailWidget extends React.Component {
  /**
   * Construnctor Method: Here we initialize all STATE objects
   */
  constructor(props, context) {
    super(props, context);

    this.state = {
      emails: [],
      originalEmails: [],
      emailTypes: [
        {
          id: "O",
          desc_En: emailContent.en.typeLabel,
          desc_Fr: emailContent.fr.typeLabel
        },
        {
          id: "H",
          desc_En: emailContent.en.personalLabel,
          desc_Fr: emailContent.fr.personalLabel
        },
        {
          id: "B",
          desc_En: emailContent.en.workLabel,
          desc_Fr: emailContent.fr.workLabel
        }
      ],
      friendlyIdOptions: [],
      emailTypesAvailable: ["H", "B"],
      displayMode: "load",
      language: "en_CA",
      hasValidFriendlyId: false, //if friendly ID doesn't match with one of the emails on file then it is invalid
      preferredInErrorState: false,
      saveSuccessful: false,
      vaStatusEmailList: [],
      showAddbutton: false, //flag for showing add button in edit mode
      showCancel: false, //flag for showing cancel button in edit mode on page load
      serverError: false
    };
    this.isAccountSettings = true;
    this.shouldFocusOnSelect = false;
    //url for the previous page on click of cancel. if not provided cancel will go back to the view mode of the widget
    this.cancelURL = (typeof (global.emailNotValidatedPageURL) != "undefined") ? global.emailNotValidatedPageURL : "";
    this.nextBtnOriginalOnClick = continueBtn ? continueBtn.getAttribute("onclick") : null;

    //flag for checking if the user has already made a successful save
    this.successfulSave = false;


    this.toggleDisplayMode = this.toggleDisplayMode.bind(this);
    this.handleAddEvent = this.handleAddEvent.bind(this);
    this.handleEmailEditEvent = this.handleEmailEditEvent.bind(this);
    this.handleDeleteRow = this.handleDeleteRow.bind(this);
    this.handleCancelClick = this.handleCancelClick.bind(this);
    this.addEmailType = this.addEmailType.bind(this);
    this.removeEmailType = this.removeEmailType.bind(this);
    this.handleEmailTypeChange = this.handleEmailTypeChange.bind(this);
    this.handleSaveRowSubmit = this.handleSaveRowSubmit.bind(this);
    this.handleFilterEmailInputCharacter = this.handleFilterEmailInputCharacter.bind(
      this
    );
    this.handlePreferredAndFriendlyChange = this.handlePreferredAndFriendlyChange.bind(
      this
    );
    this.saveUpdatedEmails = this.saveUpdatedEmails.bind(this);
  }

  componentDidMount() {
    this.getEmailInfoFromServer();
  }
  getEmailInfoFromServer() {
    // Initializa Language
    var lang =
      document.getElementsByTagName("html")[0].getAttribute("lang") + "_CA";
    if (lang === undefined || lang === null) {
      lang = "en_CA";
    }
    this.setState({ language: lang });

    // Set Initial State for Data
    var emailWidgetObj = this;
    getClientsEmailInfo().then(data => {
      const emailWidgetRootElement = document.getElementById("emailWidget");
      //if data-displayMode on emailWidget parent element is set to edit then display the widget in edit mode
      const initialDisplayMode = emailWidgetRootElement.getAttribute("data-displayMode") === "edit" ? "edit" : "view";
      this.isAccountSettings = emailWidgetRootElement.getAttribute("data-accountsettings") === "true";

      if (data) {
        callShadow = data.callShadow;
        //ordering the email info
        var filteredEmails = [];
        var vaStatusEmails = [];
        let preferredEmailInErrorState = false;
        for (var i = 0; i < data.emailInfo.length; i++) {
          var curEmailInfo = data.emailInfo[i];
          if (curEmailInfo.preferredEmail && (curEmailInfo.preferredEmail.toLowerCase() === "y")) {
            hasPreferred = true;
            if((curEmailInfo.emailAddrStatCd.toUpperCase() === 'ER') || (curEmailInfo.emailAddrStatCd.toUpperCase() === 'CX')) {
              preferredEmailInErrorState = true;
            }
          }
          if (curEmailInfo.friendlyId && (curEmailInfo.friendlyId.toLowerCase() === "y")) {
            hasFriendlyId = true;
            this.hasValidFriendlyId = true;
          }
          if (curEmailInfo.addrCntxtCd == "H") {
            filteredEmails.unshift(curEmailInfo);
            if (curEmailInfo.emailAddrStatCd === "VA") {
              vaStatusEmails.unshift(curEmailInfo.emailAddrNm);
            }
          } else if (curEmailInfo.addrCntxtCd == "B") {
            filteredEmails.push(curEmailInfo);
            if (curEmailInfo.emailAddrStatCd === "VA") {
              vaStatusEmails.push(curEmailInfo.emailAddrNm);
            }
          }
        }
        
        let shouldShowCancel = initialDisplayMode === "edit" ? false : true;
        if (document.getElementById("emailWidget").getAttribute("data-showcancel") === "true") {
          shouldShowCancel = true;
          this.setState({ cancelHref: "/mbrportal/req/secure/pphp/lobby/EmailNotValidated" });
        }
        let shouldShowAdd = (data.emailInfo.length > 1) ? true : false;
        if (document.getElementById("emailWidget").getAttribute("data-showadd") === "true") {
          shouldShowAdd = true;
        }
        let origEmails =  JSON.parse(JSON.stringify(filteredEmails));

        if ( initialDisplayMode === "edit") {
          //if in edit mode and user doesn't have a preferred or sign-in id set, default to the personal one
          if (filteredEmails.length > 0) {
            //setting preferred and friendly ID as personal email if user does not have one
            if (!hasPreferred) {
              filteredEmails[0].preferredEmail = "Y";
            }
            if (!hasFriendlyId) {
              filteredEmails[0].friendlyId = "Y";
            }
          }
        } 
        
        if (filteredEmails.length === 0) {
          filteredEmails = this.createNewEmptyRow();
        }
       
        this.setState({
          displayMode: initialDisplayMode,
          emails: filteredEmails,
          originalEmails: origEmails,
          vaStatusEmailList: vaStatusEmails,
          showAddbutton: shouldShowAdd,
          showCancel: shouldShowCancel,
          preferredInErrorState: preferredEmailInErrorState
        });

        //remove existing emailTypes from emailTypesAvailable list
        for (var j = 0; j < data.emailInfo.length; j++) {
          let curEmailInfo = data.emailInfo[j];
          emailWidgetObj.removeEmailType(data.emailInfo[j].addrCntxtCd);
        }
      } else {
        //TODO: implement load error scenario
        this.setState({
          displayMode: "view",
          serverError: true
        });
        if (continueBtn !== null) {
          if (global.pphpHomeURL) {
            let pphpUrl = global.pphpHomeURL;
            continueBtn.setAttribute("onclick", `location.href='${pphpUrl}'`);
          }
          continueBtn.removeAttribute("disabled");
        }
      }
      //Parsley Custom validators
      window.Parsley.addValidator("friendlyAvailable", {
        requirementType: "boolean",
        validateString: function (inputVal, friendlyAvailable) {
          // Verify that friendlyID is available
          return friendlyAvailable;
        }
      });
      // WAI-ARIA for errors
      // window.Parsley.on('field:error', function (formField) {
      //   var elem = formField.$element;
      //   elem.attr({
      //     'aria-invalid': 'true',
      //     'aria-describedby': 'parsley-id-' + formField.__id__
      //   });
      // });
      // window.Parsley.on('field:success', function (formField) {
      //   var elem = formField.$element;
      //   elem.attr({
      //     'aria-invalid': 'false'
      //   });
      // });
      this.showErrorCounter();
    });

  }
  getVaStatusEmails() {
    var emailWidgetObj = this;
    getClientsEmailInfo().then(emailInfoResponse => {
      let curEmails = emailWidgetObj.state.emails;
      let errStatusList = ["ER","CX","VA"];
      if (emailInfoResponse) {
        for (var i = 0; i < emailInfoResponse.emailInfo.length; i++) {
          let curEmailInfo = emailInfoResponse.emailInfo[i];
          if (errStatusList.indexOf(curEmailInfo.emailAddrStatCd.toUpperCase()) >= 0) {
           for (let j=0; j<curEmails.length; j++) {
             if (curEmails[j].emailAddrNm === curEmailInfo.emailAddrNm) {
              curEmails[j].emailAddrStatCd = curEmailInfo.emailAddrStatCd;
             }
           } 
          }
        }
        emailWidgetObj.setState({ emails: curEmails });
      }
      // if (emailInfoResponse) {
      //   let vaStatusEmails = [];
      //   for (var i = 0; i < emailInfoResponse.emailInfo.length; i++) {
      //     let curEmailInfo = emailInfoResponse.emailInfo[i];
      //     if (curEmailInfo.addrCntxtCd == "H") {
      //       if (curEmailInfo.emailAddrStatCd === "VA") {
      //         vaStatusEmails.unshift(curEmailInfo.emailAddrNm);
      //       }
      //     } else if (curEmailInfo.addrCntxtCd == "B") {
      //       if (curEmailInfo.emailAddrStatCd === "VA") {
      //         vaStatusEmails.push(curEmailInfo.emailAddrNm);
      //       }
      //     }
      //   }
      //   emailWidgetObj.setState({ vaStatusEmailList: vaStatusEmails });
      // }
    });
  }
  handleDeleteRow(event) {
    var emailId = event.target.id;
    var currEmails = JSON.parse(JSON.stringify(this.state.emails));
    var index = this.findIndexByProperty(emailId, currEmails, "id");
    var prevRowId = "emailAnchor";
    if (index >= 0) {
      // Add the deleted Phone Type to list of available Phone Types
      this.addEmailType(currEmails[index].addrCntxtCd);

      // Remove deleted row and update State
      currEmails.splice(index, 1);
      this.updateFriendlyId(currEmails, 0);
      this.updatePreferredEmail(currEmails, 0);
      if (index > 0) {
        prevRowId = prevRowId + (emailId - 1).toString();
      }
      this.setState({ emails: currEmails }, this.focusOnPrevRow(prevRowId));
    }
    event.preventDefault();
  }

  focusOnPrevRow(anchorId) {
    if (
      document.getElementById(anchorId) != null &&
      document.getElementById(anchorId) != undefined
    ) {
      document.getElementById(anchorId).focus();
    }
  }
  focusOnElem = elemId => {
    if (document.getElementById(elemId) !== null) {
      document.getElementById(elemId).focus();
    }
  };
  /**
   * Returns an array index from a   integer between min (inclusive) and max (inclusive)
   * Using Math.round() will give you a non-uniform distribution!
   */
  findIndexByProperty(value, arr, prop) {
    for (var i = 0; i < arr.length; i++) {
      if (Number(arr[i][prop]) === Number(value)) {
        return i;
      }
    }
    return -1; //to handle the case where the value doesn't exist
  }
  /**
   * Create a list with a new emtpy email data row and returns it
   */
  createNewEmptyRow() {
    var id = 0;
    var temp = [];
    var currentEmails = this.state.emails;
    if (currentEmails.length > 0) {
      id = parseInt(currentEmails[currentEmails.length - 1].id) + 1;
      temp = JSON.parse(JSON.stringify(currentEmails));
    }

    let isPreferred = temp.length === 0 ? "Y" : "N";
    let isFriendly = isPreferred;

    var email = {
      id: id,
      emailAddrNm: "",
      addrCntxtCd: "",
      emailAddrStatCd: "",
      preferredEmail: isPreferred,
      friendlyId: isFriendly
    };

    temp.push(email);
    return temp;
  }
  handleAddEvent() {
    this.shouldFocusOnSelect=true;
    this.setState({ emails: this.createNewEmptyRow() });
  }

  /**
   * Returns a random integer between min (inclusive) and max (inclusive)
   * Using Math.round() will give you a non-uniform distribution!
   */
  getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  handleEmailEditEvent(event) {
    global.$(event.target)
      .parsley()
      .reset(); //Reset inline error
    var curInput = {
      id: event.target.id,
      value: event.target.value
    };

    var rowId = curInput.id.replace("emailTxt", "");
    var index = this.findIndexByProperty(rowId, this.state.emails, "id");

    var temp = JSON.parse(JSON.stringify(this.state.emails));
    temp[index].emailAddrNm = curInput.value;

    this.setState({ emails: temp });

    //remove customFieldError on user input change
    let fieldError = document.getElementById("fieldError"+rowId);
    if (fieldError){
      // fieldError.style.display = "none";
      fieldError.parentNode.removeChild(fieldError);

    }
    
  }

  handleFilterEmailInputCharacter(event) {
    var keyCode = event.keyCode ? event.keyCode : event.which;
    if (keyCode == 32) {
      // Prevent user from entering spaces
      event.preventDefault();
    }
  }
  removeSaveSuccessMsg = () => {
    this.setState(() => ({
      saveSuccessful: false
    }));
  };
  handleCancelClick() {
    //var tmp = [{id: 1, emailTypeCd: 'H',emailTxt: 'John.Doe@rogers.ca'}, {id: 2,emailTypeCd: 'B',emailTxt: 'John.Doe@sunlife.com'}];
    //$('#emailWidgetForm').parsley().reset();	//Reset inline parsley error

    if (this.cancelURL !== "") {
      window.location.href = this.cancelURL;
    } else {
      var previousEmailState = JSON.parse(
        JSON.stringify(this.state.originalEmails)
      );
      this.setState({ emails: previousEmailState });
  
      //remove existing emailTypes from emailTypesAvailable list
      var acceptedEmailTypes = ["H", "B"];
      for (var j = 0; j < previousEmailState.length; j++) {
        var index = acceptedEmailTypes.indexOf(previousEmailState[j].addrCntxtCd);
        if (index >= 0) {
          acceptedEmailTypes.splice(index, 1);
        }
      }
      this.setState({ emailTypesAvailable: acceptedEmailTypes });
      this.toggleDisplayMode();
    }
    if (!this.successfulSave){
      this.addTealiumTagging("Email - Cancel (before save)");
    } else {
      this.addTealiumTagging("Email - Cancel (after save)");
    }
  }

  // If user does not have a preferred email and/or a sign-in id email, set their first one as preferred and/or sign-in
  setPreferredAndSignInIdIfNotAvailable = () => {
    let numEmails = this.state.emails.length;
    if (numEmails > 0) {
      let temp = JSON.parse(JSON.stringify(this.state.emails));
      if (!hasPreferred) {
        temp[0].preferredEmail = "Y";
        if (numEmails === 2) {
          temp[1].preferredEmail = "N";
        }
      }
      if (!hasFriendlyId) {
        temp[0].friendlyId = "Y";
        if (numEmails === 2) {
          temp[1].friendlyId = "N";
        }
      }
      this.setState({ emails: temp });
    }
  }
  toggleDisplayMode(event) {
    //if clicked on the edit button to go from view to edit
    if (this.state.displayMode === "view") {
      this.setPreferredAndSignInIdIfNotAvailable();
      //tealium tagging on click of the edit button
      this.addTealiumTagging("Email - Edit");
      //Add new row in edit view if no emails exist
      if (this.state.emails.length === 0) {
        this.handleAddEvent(event);
      }
    }
    // enable/disable next button for lobby page.
    if (continueBtn !== null) {
      if (this.state.displayMode === "view") {
        continueBtn.setAttribute("disabled", true);
      } else {
        continueBtn.removeAttribute("disabled");
      }
    }
    var newDisplayMode = this.state.displayMode === "view" ? "edit" : "view";
    this.setState(() => ({
      displayMode: newDisplayMode,
      showCancel: true
    }));
  }

  removeEmailType(emailType) {
    var typeList = this.state.emailTypesAvailable;
    var index = typeList.indexOf(emailType);
    if (index >= 0) {
      typeList.splice(index, 1);
      this.setState({ emailTypesAvailable: typeList });
    }
  }

  addEmailType(emailType) {
    var typeList = this.state.emailTypesAvailable;
    var index = typeList.indexOf(emailType);
    if (index == -1) {
      typeList.push(emailType);
      this.setState({ emailTypesAvailable: typeList });
    }
  }

  handleEmailTypeChange(event) {
    var curValue = event.target.value;
    var prevValue = event.target.getAttribute("data-previousval");
    this.addEmailType(prevValue);
    this.removeEmailType(curValue);

    event.target.dataset.previousval = curValue;
    var rowId = event.target.id.replace("emailType", "");
    var index = this.findIndexByProperty(rowId, this.state.emails, "id");
    if (index >= 0) {
      var temp = JSON.parse(JSON.stringify(this.state.emails));
      temp[index].addrCntxtCd = curValue;
      this.setState({ emails: temp });
    }
    global.$(event.target)
      .parsley()
      .reset(); //Reset inline error
  }
  handlePreferredAndFriendlyChange(event) {
    var curInput = {
      id: event.target.id,
      value: event.target.value,
      name: event.target.name
    };

    var rowId = curInput.id.replace(curInput.name, "");
    var index = this.findIndexByProperty(rowId, this.state.emails, "id");

    var temp = JSON.parse(JSON.stringify(this.state.emails));
    if (curInput.name === "preferredEmail") {
      this.updatePreferredEmail(temp, index);
    } else if (curInput.name === "friendlyIdEmail") {
      this.updateFriendlyId(temp, index);
    }

    this.setState({ emails: temp });
  }
  updatePreferredEmail(emailsArray, index) {
    for (var k = 0; k < emailsArray.length; k++) {
      if (k === index) {
        emailsArray[index].preferredEmail = "Y";
      } else {
        emailsArray[k].preferredEmail = "N";
      }
    }
  }
  updateFriendlyId(emailsArray, index) {
    for (var k = 0; k < emailsArray.length; k++) {
      if (k === index) {
        emailsArray[index].friendlyId = "Y";
      } else {
        emailsArray[k].friendlyId = "N";
      }
    }
  }
  showErrorCounter() {
    global.$("#email-server-error").hide();
    var errorCount = global.$("#emailWidgetForm .parsley-errors-list").children()
      .length;
    var oneErrorMsg = emailLabels.oneError;
    var multiErrorMsg = emailLabels.multipleErrors;

    // Display appropriate error message
    if (errorCount != 0) {
      if (errorCount === 1) {
        global.$("#email-error-num").text(oneErrorMsg);
      } else {
        var errorMsg = multiErrorMsg.replace("<x>", errorCount);
        global.$("#email-error-num").text(errorMsg);
      }
      global.$("#email-error-num").show();
      // document.getElementById("email-error-num").focus();
    } else {
      global.$("#email-error-num, #email-server-error").hide();
    }
  }
  handleSaveRowSubmit(event) {
    let customErrors = document.querySelectorAll(".custom-field-warning");
    //remove the custom field errors added for VA and ER/CX status on save
    for (let i=0; i<customErrors.length; i++) {
      customErrors[i].parentNode.removeChild(customErrors[i]);
    }
    //Check for duplicate errors
    this.checkDuplicateEmails(event);
    global.$("#emailWidget form")
      .parsley()
      .validate();
    this.showErrorCounter();
    let errorCount = document.querySelectorAll("#emailWidgetForm .parsley-errors-list").length;
    if (errorCount != 0) {
      document.getElementById("email-error-num").focus();
    }
    if (
      global.$("#emailWidgetForm")
        .parsley()
        .isValid() &&
      !global.$("#emailWidgetForm").hasClass("form-disabled") &&
      !global.$("#emailWidgetForm").hasClass("form-has-error")
    ) {
      this.disableFields();
      if (callShadow) {
        event.preventDefault();
        this.enableFields();
        global.$("#accessRestricted").modal({ backdrop: "static" });
      } else {
        this.saveUpdatedEmails(event);
      }
    }
  }
  saveUpdatedEmails(event) {

    // Format request JSON to include selected Friendly ID
    var emailRequestJson = {};
    emailRequestJson.emails = this.state.emails;

    var appObject = this;
    event.preventDefault();

    submitEmailInfo(emailRequestJson).then(myresponse => {
      if (myresponse && (myresponse.errorCode == "0" || myresponse.errorCode == "-1")) {
        let friendlyIdNotAvailable = false;

        // Check if friendly object exists
        if (typeof myresponse.friendlyIdInfo !== "undefined") {
          friendlyIdNotAvailable = myresponse.friendlyIdInfo.friendlyIdNotAvailable;
        }

        if (friendlyIdNotAvailable) {
          // Friendly ID needs to be selected
          appObject.setFriendlyIDStates(appObject, myresponse.friendlyIdInfo);
          appObject.enableFields();
          global.$("#emailWidget form").parsley().validate();
          appObject.showErrorCounter();
          let errorCount = document.querySelectorAll("#emailWidgetForm .parsley-errors-list").length;
          if (errorCount != 0) {
            document.getElementById("email-error-num").focus();
          }
        } else {
          // Email Saved successfully
          appObject.emailSavedSucessfully(appObject);
          if ((continueBtn !== null) && (this.nextBtnOriginalOnClick !== null)) {
            continueBtn.setAttribute("onclick", this.nextBtnOriginalOnClick);
            continueBtn.removeAttribute("disabled");
          }
          // appObject.enableFields();
        }
      } else {
        appObject.enableFields();
        // Enable the Next button on Lobby page and make Next button go to PPHP instead
        if (continueBtn !== null) {
          if (global.pphpHomeURL) {
            let pphpUrl = global.pphpHomeURL;
            continueBtn.setAttribute("onclick", `location.href='${pphpUrl}'`);
          }
          continueBtn.removeAttribute("disabled");
        }
        global.$("#email-server-error").show();
        document.getElementById("email-server-error").focus();
      }

    });
  }
  emailSavedSucessfully(appObject) {
    appObject.setState({
      displayMode: "view",
      saveSuccessful: true,
      showCancel: true
    });
    this.cancelURL = "";
    this.successfulSave = true;
    // appObject.displaySaveSuccessMsg(appObject); //Show "save successful" message
    appObject.setState({ originalEmails: appObject.state.emails });
    appObject.getVaStatusEmails();

    hasPreferred = true;
    hasFriendlyId = true; 
    appObject.hasValidFriendlyId = true;
    
    //tealium tagging for successful save of email info
    appObject.addTealiumTagging("Email - Successful save");
  }
  setFriendlyIDStates(appObject, responseStates) {
    // Update Friendly ID State
    appObject.setState(() => ({
      friendlyIdOptions: responseStates.friendlyIds
    }));
  }
  removeSpaces = (event) => {
    let curInput = {
      id: event.target.id,
      value: event.target.value
    };
    event.target.type = "text";
    // if the email address has spacing inside, remove the spacing and update the state
    if (curInput.value.indexOf(" ") != -1) {
      // changed the type to text so that it removes the spaces from the input

      let newValue = curInput.value.replace(/^\s+|\s+$/g, '');

      let rowId = curInput.id.replace("emailTxt", "");
      let index = this.findIndexByProperty(rowId, this.state.emails, "id");

      let temp = JSON.parse(JSON.stringify(this.state.emails));
      temp[index].emailAddrNm = newValue;

      this.setState({ emails: temp });
      // changed the type back to email

    }
    event.target.type = "email";
  }
  disableFields() {
    // Save Button
    let saveBtnElem = document.getElementById("emailSaveBtn");
    saveBtnElem.classList.add("is-busy");
    saveBtnElem.innerHTML = emailLabels.validatingLabel;

    document.getElementById("emailWidgetForm").classList.add("form-disabled");

    let inputElems = document.querySelectorAll("#emailsTable input, #emailsTable select, #emailsTable button");
    for (let i = 0; i < inputElems.length; i++) {
      let curElem = inputElems[i];
      curElem.disabled = true;
    }

    let linkElems = document.querySelectorAll("#emailsTable a, #emailWidgetForm .btnArea a.btn-link");
    for (let j = 0; j < linkElems.length; j++) {
      let curElem = linkElems[j];
      curElem.setAttribute("tabindex", "-1");
    }
  }
  enableFields() {

    // Save Button
    let saveBtnElem = document.getElementById("emailSaveBtn");
    saveBtnElem.classList.remove("is-busy");
    saveBtnElem.innerHTML = emailLabels.saveLabel + '<span class="sr-only"> ' + emailLabels.emailWidgetTitle + "<span>";

    document.getElementById("emailWidgetForm").classList.remove("form-disabled");

    let inputElems = document.querySelectorAll("#emailsTable input, #emailsTable select, #emailsTable button");
    for (let i = 0; i < inputElems.length; i++) {
      let curElem = inputElems[i];
      curElem.disabled = false;
    }

    let linkElems = document.querySelectorAll("#emailsTable a, #emailWidgetForm .btnArea a.btn-link");
    for (let j = 0; j < linkElems.length; j++) {
      let curElem = linkElems[j];
      curElem.removeAttribute("tabindex");
    }

    //disable the prefered and sign in checkbox if only one email specified
    let prefAndSignInCheckbox = document.getElementsByName("preferredAndFriendlyIdEmail")[0];
    if (prefAndSignInCheckbox) {
      prefAndSignInCheckbox.disabled = true;
    }

  }
  displaySaveSuccessMsg(appObject) {
    global.$("#successful-save-email-msg").show(); //Show "save successful" message
    global.$("#successful-save-email-msg").focus();
    if (saveMsgTimer) {
      //Cancel the previous timer
      clearTimeout(saveMsgTimer);
      saveMsgTimer = null;
    }
    saveMsgTimer = setTimeout(function () {
      appObject.easeOutMsg();
    }, 5000); //Animate fading of message
  }

  easeOutMsg() {
    var appObject = this; //Save React pointer
    var savedMsg = global.$("#successful-save-email-msg");
    savedMsg.addClass("hideElementAnimate");
    savedMsg.one("transitionend", function (e) {
      //Animate fading of message
      appObject.hideSaveSuccessMsg();
    });
  }

  hideSaveSuccessMsg() {
    // Clear timer
    clearTimeout(saveMsgTimer);
    saveMsgTimer = null;
    // Hide message
    var savedMsg = global.$("#successful-save-email-msg");
    savedMsg.hide();
    savedMsg.removeClass("hideElementAnimate");
  }
  checkDuplicateEmails(e) {
    var emails = global.$("input[type='email']");
    if (emails.length > 1) {
      global.$("#emailWidgetForm").removeClass("form-has-error");
      global.$("#email-duplicate-error").hide();
      if (
        emails[0].value.trim() !== "" &&
        emails[0].value.trim().toUpperCase() ===
        emails[1].value.trim().toUpperCase()
      ) {
        e.preventDefault();
        global.$("#emailWidgetForm").addClass("form-has-error");
        global.$("#email-duplicate-error").show();
        document.getElementById("email-duplicate-error").focus();
      }
    } else {
      global.$("#emailWidgetForm").removeClass("form-has-error");
      global.$("#email-duplicate-error").hide();
    }
  }
  addTealiumTagging = description => {
    if (typeof global.utag !== "undefined") {
      global.utag.link({
        ev_type: "other",
        ev_action: "clk",
        ev_title: description,
      });
    }
  };
  //Display the learn more popup
  showLearnMorePopup = () => {
    global.$("#learnMorePopup").modal({ backdrop: "static" });
    this.addTealiumTagging("Email - Learn more link (" + this.state.displayMode + " mode)");
  };
  displayInfoParagraph = () => {
    const emails = this.state.emails;
    let warningContent = ""; 
    //Display different msg in account settings on top of the widget's edit mode than lobby
    if (this.isAccountSettings) {
      warningContent= emailLabels.confirmationEmailNotif;
    } else {
      if ((emails.length === 0) || ((emails.length === 1) && (emails[0].emailAddrStatCd === "") && (this.state.originalEmails.length===0))) {
        //Display no email on file warning if user has no email
        warningContent = emailLabels.noEmailWarning;
      } else if (this.state.preferredInErrorState) {
        //Display warning if users preferrend email is in ER or CX state
        warningContent = emailLabels.preferredInErrorStateWarning;
      }
    }
    

    return warningContent != "" ? (
      <p className="widgetTopInfo">
        {warningContent}
      </p>
    ) : null;
  }
  handleDisplayWidgetTitle = () => {
    //Show widget title only if in account settings
    if (this.isAccountSettings) {
      return <h2>{emailLabels.emailWidgetTitle}</h2>;
    }
  }
  render() {
    if (this.state.displayMode === "load") {
      return null;
    } else {
      return (
        <div>
          {this.handleDisplayWidgetTitle()}
          <EmailContainer
            displayMode={this.state.displayMode}
            emails={this.state.emails}
            originalEmails={this.state.originalEmails}
            vaStatusEmails={this.state.vaStatusEmailList}
            emailTypes={this.state.emailTypes}
            emailTypesAvailable={this.state.emailTypesAvailable}
            onEmailTypeChange={this.handleEmailTypeChange}
            onEmailEdit={this.handleEmailEditEvent}
            onRowAdd={this.handleAddEvent}
            onRowDel={this.handleDeleteRow}
            onCancel={this.handleCancelClick}
            onRowSave={this.handleSaveRowSubmit}
            onPreferredOrFriendlyIdEmailChange={this.handlePreferredAndFriendlyChange}
            formatUserInput={this.removeSpaces}
            lang={this.state.language}
            cancelHref={this.state.cancelHref}
            toggleView={this.toggleDisplayMode}
            callShadow={callShadow}
            friendlyIdOptions={this.state.friendlyIdOptions}
            serverError={this.state.serverError}
            showAddbutton={this.state.showAddbutton}
            showCancel={this.state.showCancel}
            showLearnMorePopup={this.showLearnMorePopup}
            showErrorCounter={this.showErrorCounter}
            showSuccessMsg={this.state.saveSuccessful}
            removeSaveSuccessMsg={this.removeSaveSuccessMsg}
            shouldFocusOnSelect={this.shouldFocusOnSelect}
            displayInfoParagraph={this.displayInfoParagraph()}
            hasValidFriendlyId={this.hasValidFriendlyId}
            isAccountSettings={this.isAccountSettings}
          />
          <OneBtnPopupModal
            id="learnMorePopup"
            headerText={emailLabels.learnMoreModalHeader}
            contentText={[<h4 className="mar-top-0 h5">{emailLabels.learnMoreModalSignInHeader}</h4>, <p className="mar-bottom-20">{emailLabels.learnMoreModalSignInContent}</p>, <h4 className="h5">{emailLabels.learnMoreModalPreferredHeader}</h4>, <p className="mar-bottom-0">{emailLabels.learnMoreModalPreferredContent}</p>]
            }
            primaryBtnText={emailLabels.okayLabel}
            closeBtnText={emailLabels.closeLabel}
            onCloseBtnClick={e => this.focusOnElem("signInIdlearnMoreLink")}
          />
        </div>
      );
    }
  }
}

export default EmailWidget;
