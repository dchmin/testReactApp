import React from "react";
import PropTypes from "prop-types";
import { emailLabels } from "./EmailWidget";

class EmailViewRow extends React.Component {
  getEmailTypeDesc(emailType) {
    var myArray = this.props.emailTypes;
    for (var i in myArray) {
      if (myArray[i].id === emailType) {
        return this.props.lang === "en_CA"
          ? myArray[i].desc_En
          : myArray[i].desc_Fr;
      }
    }
  }

  showPreferedAndSignInSelection(emailInfo) {
    var preferredMsg = emailLabels.preferredEmailViewLabel; //Get label text

    // Display preferred label
    if (
      typeof emailInfo !== "undefined" &&
      emailInfo.preferredEmail.toUpperCase() === "Y" &&
      emailInfo.friendlyId.toUpperCase() === "Y"
    ) {
      return <div className="preferredEmail">{emailLabels.signInAndsPreferredLabel}</div>;
    } else if (
      typeof emailInfo !== "undefined" &&
      emailInfo.preferredEmail.toUpperCase() === "Y" &&
      emailInfo.friendlyId.toUpperCase() === "N"
      ) {
        return <div className="preferredEmail">{emailLabels.preferredEmailViewLabel}</div>;
      } else if (
        typeof emailInfo !== "undefined" &&
        emailInfo.preferredEmail.toUpperCase() === "N" &&
        emailInfo.friendlyId.toUpperCase() === "Y"
        ) {
          return <div className="preferredEmail">{emailLabels.friendlyIDViewLabel}</div>;
        }
  }
  displayfieldWarning() {
    let statCode = this.props.email.emailAddrStatCd.toUpperCase();
    let errorMessage = "";
    if (statCode === "VA") {
      errorMessage = emailLabels.vaStatusFieldError;
    } else if ((statCode === "CX") || (statCode === "ER")) {
      errorMessage = emailLabels.errorStatusFieldError;
    }
    if (errorMessage !== "") {
      return (
        <div className="field-set-validation-errors mar-top-10 mar-bottom-10">
          {errorMessage}
        </div>
      );
    } else {
      return null;
    }
  }
  render() {
    return (
      <tr
        className="viewRow"
        key={this.props.email.id}
        id={"emailViewRow" + this.props.email.id}
      >
        <td
          className="view-cell"
          data-title="Type"
          aria-label={emailLabels.typeLabel}
        >
          <div>{this.getEmailTypeDesc(this.props.email.addrCntxtCd)}</div>
        </td>
        <td
          className="view-cell"
          data-title="Email"
          aria-label={emailLabels.emailWidgetTitle}
        >
          <div className="emailAddrTxt">{this.props.email.emailAddrNm}</div>
          {this.displayfieldWarning()}
          {this.showPreferedAndSignInSelection(this.props.email)}
        </td>
      </tr>
    );
  }
}

EmailViewRow.propTypes = {
  emailTypes: PropTypes.array,
  email: PropTypes.object
};
export default EmailViewRow;
