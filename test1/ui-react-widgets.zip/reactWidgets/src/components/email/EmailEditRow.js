import React from 'react';
import EmailTextInput from '../commons/EmailTextInput';
import ToggleDropdown from '../commons/ToggleDropdown';
import ButtonLink from '../commons/ButtonLink';
import { emailLabels } from './EmailWidget';

class EmailEditRow extends React.Component {

	createPreferredAndSigninCheckbox() {
		let numEmails = this.props.numEmails;
		let emailId = this.props.email.id;
		let isPreferred = this.props.email.preferredEmail === 'Y' ? true : false;
		let isFriendlyId = this.props.email.friendlyId === 'Y' ? true : false;

		if (numEmails === 1) {
			return (
				<div className="mar-top-10">
					<input id={"preferredAndFriendlyIdEmail" + emailId} name="preferredAndFriendlyIdEmail" type="checkbox" data-parsley-multiple="preferredAndFriendlyIdEmail" checked={true} disabled={true} />
					<label className="radio-label" htmlFor={"preferredAndFriendlyIdEmail" + emailId}>
						{emailLabels.signInAndsPreferredCheckboxLabel}
					</label>
				</div>
			);
		} else if (numEmails > 1) {
			return (
				<React.Fragment>
					<div className="mar-top-10">
						<input id={"preferredEmail" + emailId} name="preferredEmail" type="checkbox" data-parsley-multiple="preferredEmail" checked={isPreferred} onChange={this.props.onPreferredOrFriendlyIdChange} />
						<label className="radio-label" htmlFor={"preferredEmail" + emailId}>
							{emailLabels.preferredEmailLabel}
						</label>
					</div>
					<div className="mar-top-10">
						<input id={"friendlyIdEmail" + emailId} name="friendlyIdEmail" type="checkbox" data-parsley-multiple="friendlyIdEmail" checked={isFriendlyId} onChange={this.props.onPreferredOrFriendlyIdChange} />
						<label className="radio-label" htmlFor={"friendlyIdEmail" + emailId}>
							{emailLabels.friendlyIDLabel}
						</label>
					</div>
				</React.Fragment>
			);

		}
	}
	displayfieldWarning() {
		let statCode = this.props.email.emailAddrStatCd.toUpperCase();
		let errorMessage = "";
		if (statCode === "VA") {
			errorMessage = emailLabels.vaStatusFieldError;
		} else if ((statCode === "CX") || (statCode === "ER")) {
			errorMessage = emailLabels.errorStatusFieldError;
		}
		if (errorMessage !== "") {
			return (
				<ul id={"fieldError"+this.props.email.id} className="custom-field-warning parsley-errors-list filled">
					<li className="parsley-type">{errorMessage}</li>
				</ul>
			);
		} else {
			return null;
		}
	}
	render() {
		// States
		let statCd = this.props.email.emailAddrStatCd.toUpperCase();
		var email = this.props.email;
		var emailAddress = this.props.email.emailAddrNm;
		var emailId = this.props.email.id;
		var lang = this.props.lang;
		var emailTypes = this.props.emailTypes;
		var emailTypesAvailable = this.props.emailTypesAvailable
		var numEmails = this.props.numEmails;
		var isPreferred = this.props.email.preferredEmail === 'Y' ? true : false;
		var isFriendlyId = this.props.email.preferredEmail === 'Y' ? true : false;

		// Labels
		var removeLabel = emailLabels.removeLabel;
		var emailLabel = emailLabels.emailTxtLabel;
		var placeholderTxt = emailLabels.emailShadowTxt;
		var preferredLabel = emailLabels.preferredEmailLabel;

		var removeLink = null;
		let preferredCheckbox = null;
		let friendlyIdCheckbox = null;
		let friendlyIdAndPreferedCheckbox = null;
		if (numEmails > 1) {
			removeLink = (<td className="removeCol"><ButtonLink href="#emailsContainer" id={this.props.email.id} value={[removeLabel, <span className="sr-only"> {emailLabels.widgetSROnlyText}</span>]} cssClass="del-btn" onClick={this.props.onRowDel} /></td>);
		}

		//var isdisabled = numEmails === 1 ? true : false; 

		if (numEmails > 1) {
			preferredCheckbox = (
				<div className="mar-top-10">
					<input id={"preferredEmail" + emailId} name="preferredEmail" type="checkbox" data-parsley-multiple="preferredEmail" checked={isPreferred} onChange={this.props.onPreferredEmailChange} />
					<label className="radio-label" htmlFor={"preferredEmail" + emailId}>
						{preferredLabel}
					</label>
				</div>
			);
		}


		return (
			<tr className="eachRow" key={this.props.email.id} id={"emailEditRow" + this.props.email.id} role="group" aria-label={emailLabel}>
				<ToggleDropdown
					name="emailTypeCd"
					id={emailId}
					emailTypes={emailTypes}
					emailTypesAvailable={emailTypesAvailable}
					email={email}
					onEmailTypeChange={this.props.onEmailTypeChange}
					lang={lang}
					shouldFocusOnSelect={this.props.shouldFocusOnSelect} />

				<td>
					<EmailTextInput
						label={emailLabel}
						name="emailTxt"
						id={emailId}
						value={emailAddress}
						placeholder={placeholderTxt}
						onChange={this.props.onEmailEdit}
						onBlur={this.props.removeSpaces}
						cssClass="form-control"
						maxLength="64"
						requiredField={true}
						friendlyAvailable={this.props.friendlyAvailable}
						lang={lang} 
						aria-describedby={((statCd === "VA") || (statCd === "CX") || (statCd === "ER")) ? "fieldError"+this.props.email.id : ""}/>
						{this.displayfieldWarning()}
					{this.createPreferredAndSigninCheckbox()}
				</td>
					{removeLink}
			</tr>
		);
	}
}

export default EmailEditRow;
