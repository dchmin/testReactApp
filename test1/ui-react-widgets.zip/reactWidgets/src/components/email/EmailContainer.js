import React from "react";
import EmailViewTable from "./EmailViewTable";
import EmailEditTable from "./EmailEditTable";
import { emailLabels } from "./EmailWidget";

class EmailContainer extends React.Component {
  componentDidMount() {
    if (typeof window.Parsley !== "undefined") {
      // WAI-ARIA for errors
      window.Parsley.on('field:error', function (formField) {
        var elem = formField.$element;
        elem.attr({
          'aria-invalid': 'true',
          'aria-describedby': 'parsley-id-' + formField.__id__
        });
        if (elem.is("input[type='radio']")) {
          elem.attr({
            "aria-describedby": formField._ui.errorsWrapperId
          });
        }
      });
      window.Parsley.on("field:success", function(formField) {
        var elem = formField.$element;
        elem.attr({
          "aria-invalid": "false"
        });
      });
    }
  }
  /* Display a warning if the friendly ID on file doesn't match one of users email or there is no friendly Id on file */
  displayFriendlyIdWarning() {
    if (this.props.isAccountSettings && !this.props.hasValidFriendlyId) {
      return (
        <div class="slf-alert-box exclamation-triangle slf-yellow-bg-10 mar-bottom-20">
          <div>
            <p>{emailLabels.friendlyIdWarning}</p>
          </div>
        </div>
      );
    } else {
      return null;
    }
  }
  render() {
    if (this.props.displayMode === "view" || this.props.serverError === true) {
      return (
        <div className="viewMode no-outline">
          <EmailViewTable
            originalEmails={this.props.originalEmails}
            emails={this.props.emails}
            vaStatusEmails={this.props.vaStatusEmails}
            emailTypes={this.props.emailTypes}
            onRowAdd={this.props.onRowAdd}
            toggleView={this.props.toggleView}
            showLearnMorePopup={this.props.showLearnMorePopup}
            showSuccessMsg={this.props.showSuccessMsg}
            removeSaveSuccessMsg={this.props.removeSaveSuccessMsg}
            lang={this.props.lang}
            serverError={this.props.serverError}
          />
        </div>

      );
    } else {
      return (
        <div id="emailsContainer" className="editMode no-outline" tabIndex="-1">
          {this.props.displayInfoParagraph}
          {this.displayFriendlyIdWarning()}
          <EmailEditTable
            emails={this.props.emails}
            vaStatusEmails={this.props.vaStatusEmails}
            emailTypes={this.props.emailTypes}
            emailTypesAvailable={this.props.emailTypesAvailable}
            onEmailTypeChange={this.props.onEmailTypeChange}
            onEmailEdit={this.props.onEmailEdit}
            onRowAdd={this.props.onRowAdd}
            onRowDel={this.props.onRowDel}
            onCancel={this.props.onCancel}
            onRowSave={this.props.onRowSave}
            onPreferredOrFriendlyIdEmailChange={this.props.onPreferredOrFriendlyIdEmailChange}
            formatUserInput={this.props.formatUserInput}
            lang={this.props.lang}
            cancelHref={this.props.cancelHref}
            callShadow={this.props.callShadow}
            friendlyIdOptions={this.props.friendlyIdOptions}
            onFriendlyIdSelection={this.props.onFriendlyIdSelection}
            showAddbutton={this.props.showAddbutton}
            showCancel={this.props.showCancel}
            showLearnMorePopup={this.props.showLearnMorePopup}
            originalEmails={this.props.originalEmails}
            showErrorCounter={this.props.showErrorCounter}
            shouldFocusOnSelect={this.props.shouldFocusOnSelect}
          />
        </div>
      );
    }
  }

}

export default EmailContainer;
