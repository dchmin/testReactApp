import React from "react";
// import createReactClass from'create-react-class';
import {emailLabels} from './EmailWidget';

class AddNewEmailButton extends React.Component {

  createAddButton(emailSize){

		if (!this.props.showAddbutton || (emailSize > 1 )) {
			return null
		}else{
			return (
				<tr style={{border:'none'}}>
					<td className="btn-centered-container" colSpan="2">
						 <button name="addEmailButton" id="addEmailButton" type="button" className="btn btn-green" onClick={this.props.onClick}>
								<span className="fa fa-plus-circle mar-right-5"></span>
								{emailLabels.addLabel}
						 </button>
					</td>
				</tr>
			)
		}
  }
	render() {

		return this.createAddButton(this.props.emailSize);
     
	}
}

export default AddNewEmailButton;

