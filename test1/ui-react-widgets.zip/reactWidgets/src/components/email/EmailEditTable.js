import React from "react";
import PropTypes from "prop-types";
import EmailEditRow from "./EmailEditRow";
import AddNewEmailButton from "./AddNewEmailButton";
import ButtonLink from "../commons/ButtonLink";
import OneBtnPopupModal from "../commons/OneBtnPopupModal";
import FriendlyIdPopup from "../commons/FriendlyIdPopup";
import { emailLabels } from "./EmailWidget";

class EmailEditTable extends React.Component {
  componentDidMount(){
    this.props.showErrorCounter();
  }

  checkIfSelectedFriendlyIdAvailable(emailInfo) {
    const friendlyIdInfo = this.props.friendlyIdOptions;
    if (emailInfo.friendlyId === "Y") {
      for (let i = 0; i < friendlyIdInfo.length; i++) {
        if (emailInfo.emailAddrNm === friendlyIdInfo[i].emailAddrNm) {
          return friendlyIdInfo[i].available;
        }
      }
      return true;
    } else {
      return true;
    }
  }
  showCancelButton = () => {
    return this.props.showCancel ? (
      <ButtonLink
        value={emailLabels.cancelLabel}
        cssClass="btn btn-link cancel-btn"
        href="#emailsContainer"
        onClick={this.props.onCancel}
        key="cancelLink"
      />
    ) : null;
  };
  /**
   * return a warning element for VA status emails or if no email on file, 
   * return null otherwise
   */
  displayWarning = () => {
    const emails = this.props.emails;
    let warningContent = "";
    //Display VA warning for emails that are in VA status
    // if (this.props.vaStatusEmails.length > 0) {
    //   let vaWarningLabel = emailLabels.vaStatusWarning;
    //   let vaStatusEmailString = this.props.vaStatusEmails.join(
    //     " " + emailLabels.andLabel + " "
    //   );
    //   warningContent = vaWarningLabel.replace("<x>", vaStatusEmailString);
    // } else 
    if ((emails.length === 0) || ((emails.length === 1) && (emails[0].emailAddrStatCd === "") && (this.props.originalEmails.length===0))) {
      //Display no email on file warning if user has no email
      warningContent = emailLabels.noEmailWarning;
    }

    return warningContent != "" ? (
      <div
        id="top-warning"
        className="field-set-validation-errors slf-yellow-bg top-warning-msg"
      >
        {warningContent}
      </div>
    ) : null;
  }
  render() {
    // Functions
    var emails = null;
    var onEmailEdit = this.props.onEmailEdit;
    var onRowDel = this.props.onRowDel;
    var onEmailTypeChange = this.props.onEmailTypeChange;
    var filterEmailInputCharacter = this.props.filterEmailInputCharacter;
    var onPreferredOrFriendlyIdChange = this.props.onPreferredOrFriendlyIdEmailChange;
    var removeSpaces = this.props.formatUserInput;

    // Email States
    var emailTypes = this.props.emailTypes;
    var emailTypesAvailable = this.props.emailTypesAvailable;
    var numEmails = this.props.emails.length;

    // Labels
    var lang = this.props.lang;
    var saveLabel = emailLabels.saveLabel;
    var duplicateEmailError = emailLabels.duplicateEmailError;
    var restrictedModalHeader = emailLabels.restrictedModalHeader;
    var restrictedModalContent = emailLabels.restrictedModalContent;
    var restrictedModalBtn = emailLabels.okayLabel;
    var closeBtnLabel = emailLabels.closeLabel;

    if (typeof (this.props.emails != "undefined")) {
      if (numEmails > 0) {
        emails = this.props.emails.map(email => {
          return (
            <EmailEditRow
              email={email}
              key={email.id}
              emailTypes={emailTypes}
              emailTypesAvailable={emailTypesAvailable}
              onEmailTypeChange={onEmailTypeChange}
              onEmailEdit={onEmailEdit}
              onPreferredOrFriendlyIdChange={onPreferredOrFriendlyIdChange}
              onRowDel={onRowDel}
              lang={lang}
              numEmails={numEmails}
              removeSpaces={removeSpaces}
              friendlyAvailable={this.checkIfSelectedFriendlyIdAvailable(email)}
              shouldFocusOnSelect={this.props.shouldFocusOnSelect}
            />
          );
        });
      } else {
        var emptyMsg = emailLabels.noEmailLabel;
        emails = (
          <tr>
            <td colSpan="2">{emptyMsg}</td>
          </tr>
        );
      }
    }
    return (
      <div>
        <form
          id="emailWidgetForm"
          data-parsley-validate
          data-parsley-focus="none"
        >
          <div className="widgetTableContainer">
            <div id="email-notifContainer">
              <div
                id="email-server-error"
                className="field-set-validation-errors"
                style={{ display: "none" }}
                tabIndex="0"
              >{emailLabels.apologyError}</div>
              <div
                id="email-duplicate-error"
                className="field-set-validation-errors"
                style={{ display: "none" }}
                tabIndex="0"
              >
                {duplicateEmailError}
              </div>
              <div
                id="email-error-num"
                className="field-set-validation-errors"
                style={{ display: "none" }}
                tabIndex="0"
              />
            </div>
            
            <a id="emailAnchor" tabIndex="-1" aria-hidden="true" />
            <table
              id="emailsTable"
              className="dataTable-responsive"
              role="presentation"
            >
              <thead>
                <tr>
                  <th />
                  <th />
                </tr>
              </thead>
              <tbody>
                {emails}
                <AddNewEmailButton
                  emailSize={this.props.emails.length}
                  onClick={this.props.onRowAdd}
                  lang={this.props.lang}
                  showAddbutton={this.props.showAddbutton}
                />
              </tbody>
            </table>
          </div>
          <div className="btnArea">
            <ButtonLink
              id="signInIdlearnMoreLink"
              value={[<span className="fa fa-info-circle pad-right-10"></span>, emailLabels.learnMoreLink]}
              cssClass="btn btn-link learnMore-btn"
              href="javascript:void(0);"
              onClick={this.props.showLearnMorePopup}
              key="signInIdlearnMoreLink"
            />

            {this.showCancelButton()}
            <button key="emailSaveBtn" id="emailSaveBtn" className="btn btn-yellow save-btn" type="submit" onClick={this.props.onRowSave}>
              {saveLabel}<span className="sr-only"> {emailLabels.widgetSROnlyText}</span>
            </button>
            {/* <ButtonLink
              id="emailSaveBtn"
              value={[
                saveLabel,
                <span className="sr-only"> {emailLabels.emailWidgetTitle}</span>
              ]}
              cssClass="btn btn-yellow save-btn"
              href="#email-notifContainer"
              onClick={this.props.onRowSave}
              key="emailSaveBtn"
            /> */}
          </div>
        </form>
        <OneBtnPopupModal
          id="accessRestricted"
          headerText={restrictedModalHeader}
          contentText={restrictedModalContent}
          primaryBtnText={restrictedModalBtn}
          closeBtnText={closeBtnLabel}
        />

      </div>
    );
  }
}

EmailEditTable.propTypes = {
  emailTypes: PropTypes.array.isRequired,
  emails: PropTypes.array.isRequired
};

export default EmailEditTable;
