import React from "react";
import PropTypes from "prop-types";
import EmailViewRow from "./EmailViewRow";
import ButtonLink from "../commons/ButtonLink";
import { AlertBoxError } from "../commons/AlertBoxError";
import { emailLabels } from "./EmailWidget";
import { SuccessMsg } from "../commons/SuccessMsg";

class EmailViewTable extends React.Component {
  render() {
    var emails = null;
    var buttonLabel = emailLabels.editLabel;
    var successLabel = emailLabels.successLabel;
    if (this.props.serverError) {
      return (
        <div>
          <div className="outage-container">
            <AlertBoxError>{emailLabels.apologyError}</AlertBoxError>
          </div>
        </div>
      );
    } else if (this.props.originalEmails.length > 0) {
      emails = this.props.emails.map(email => {
        return (
          <EmailViewRow
            email={email}
            key={email.id}
            emailTypes={this.props.emailTypes}
            lang={this.props.lang}
            emailLength={this.props.emails.length}
          />
        );
      });
    } else {
      var emptyMsg = emailLabels.noEmailLabel;
      emails = (
        <tr>
          <td className="autoWidth">{emptyMsg}</td>
        </tr>
      );
    }

    return (
      <div>
        <div className="widgetTableContainer">
          <div className="no-outline" id="emailsContainer" tabIndex="-1"> 
            <SuccessMsg
              id="email-successNotifContainer"
              className="mar-bottom-10"
              content={successLabel}
              showSuccessMsg={this.props.showSuccessMsg}
              removeSaveSuccessMsg={this.props.removeSaveSuccessMsg}
              rootContainer={this.refs.emailNotifContainerRef}
            />
            <div
              id="email-notifContainer"
              className="topNotifContainer"
              ref="emailNotifContainerRef"
            >
            </div>
            <table className="dataTable-responsive" role="presentation" style={{ width: "100%" }}>
              <thead>
                <tr>
                  <th>{emailLabels.emailWidgetTitle}</th>
                  <th>{emailLabels.typeLabel}</th>
                </tr>
              </thead>
              <tbody>{emails}</tbody>
            </table>
          </div>
        </div>
        <div className="btnArea">
            <ButtonLink
              id="signInIdlearnMoreLink"
            value={[<span className="fa fa-info-circle pad-right-10"></span>,emailLabels.learnMoreLink]}
              cssClass="btn btn-link learnMore-btn"
              href="javascript:void(0);"
              onClick={this.props.showLearnMorePopup}
            />
          
          <ButtonLink
            value={[
              buttonLabel,
              <span className="sr-only"> {emailLabels.widgetSROnlyText}</span>
            ]}
            cssClass="btn btn-blue"
            href="#emailsContainer"
            onClick={this.props.toggleView}
          />
        </div>
      </div>
    );
  }
}

EmailViewTable.propTypes = {
  emailTypes: PropTypes.array.isRequired,
  emails: PropTypes.array.isRequired
};

export default EmailViewTable;
