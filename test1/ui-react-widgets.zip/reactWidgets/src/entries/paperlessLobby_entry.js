import React from 'react';
import ReactDOM from 'react-dom';
import PaperlessLobbyPage from '../pages/PaperlessLobbyPage';


ReactDOM.render(<PaperlessLobbyPage />, document.getElementById('paperlessWidget'));

