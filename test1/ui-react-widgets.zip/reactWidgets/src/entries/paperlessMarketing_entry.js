import React from 'react';
import ReactDOM from 'react-dom';
import PaperlessAndMarketing from '../pages/PaperlessAndMarketing';


ReactDOM.render(<PaperlessAndMarketing />, document.getElementById('preferencesPage'));

