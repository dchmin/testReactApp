import React from 'react';
import ReactDOM from 'react-dom';
import PaperlessAndContactPref from '../pages/PaperlessAndContactPref';


ReactDOM.render(<PaperlessAndContactPref />, document.getElementById('preferencesPage'));

