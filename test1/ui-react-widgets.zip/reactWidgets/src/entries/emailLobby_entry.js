
import React from 'react';
import ReactDOM from 'react-dom';
import EmailWidget from '../components/email/EmailWidget';

ReactDOM.render(<EmailWidget/>,document.getElementById('emailWidget'));
