// TODO: experimental component to call every widgets from a single components.
import React from 'react';
import PaperlessWidget from '../components/paperless/PaperlessWidget';

const PaperlessLobbyPage = () => (
    <PaperlessWidget />
  )

export default PaperlessLobbyPage;