// TODO: experimental component to call every widgets from a single components.
import React from "react";
import PaperlessWidget from "../components/paperless/PaperlessWidget";
import MarketingPrefWidget from "../components/marketingPreference/MarketingPrefWidget";

const PaperlessAndMarketing = () => (
  <React.Fragment>
    <PaperlessWidget />
    <div className="mar-top-40" />
    <MarketingPrefWidget />
  </React.Fragment>
);

export default PaperlessAndMarketing;
