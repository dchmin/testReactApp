// TODO: experimental component to call every widgets from a single components.
import React from "react";
import PaperlessWidget from "../components/paperless/PaperlessWidget";
import ContactPreferencesWidget from "../components/contactPreferences/ContactPreferencesWidget";

const PaperlessAndContactPref = () => (
  <React.Fragment>
    <PaperlessWidget />
    <div className="mar-top-40"></div>
    <ContactPreferencesWidget />
  </React.Fragment>
);

export default PaperlessAndContactPref;
