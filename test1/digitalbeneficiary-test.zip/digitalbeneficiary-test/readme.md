# Digital Beneficiary

## Prerequiste

- NodeJS tool is installed
- Registry is set to SLF artifactory

## Setup  

- Copy all the files into the project folder
- Open command prompt and changed directory to project folder
- type "**npm install**" (without quotes) and hit enter
- wait for the installation to complete
- Go to next section "Command Line"

## Command Lines:  

To install dependencies:

```sh
npm install
```

To run the project in localhost:

```sh
npm start
```


To create a production build:

```sh
npm run prod
```

To create a development build:

```sh
npm run build
```

## Running

The webconfig supports running and building all the different versions of the digital beneficiary application at same time.

### Source Version 1 (src folder)
- Initial design for digital beneficiary widget.
- Contains logic and supports beneficiary updates for GB

**localhost/webpack server**:

1) Open up a browser 
2) Go to `localhost:<port>/index.html` in your browser

**Bundle created from build**: `dbeneficiary.bundle.js` and `dbeneficiary.css`

### Source Version 2 (src-v2 folder)
- New designs and components added to beneficiary widget
- Supports beneficiary upadates for both GB and GRS  
    - NOTE: GB experience, layout design, and submissions remains the same as version 1 even with the new components added
- To specifically run GRS beneficiary widget ensure the "reactLob" variable flag is on the page. String value must equal to "GRS". 
    - If "reactLob" is empty or doesn't exist will default to GB beneficiary widget.

**localhost/webpack server**:

To open page with GB digital beneficiary widget
1) Open up a browser 
2) Go to `localhost:<port>/dbeneficiary-v2.html` in your browser

To open page with GRS digital beneficiary widget
1) Open up a browser 
2) Go to `localhost:<port>/dbeneficiary-v2.html?lob=GRS` in your browser. The parameter in url is for developing on local environment only to toggle between GRS and GB without modifying index.html file and rebuild.

**Bundle created from build**: `dbeneficiary-v2.bundle.js` and `dbeneficiary-v2.css`

**Documentation**:
https://sunlifefinancial.sharepoint.com/:f:/r/sites/EI/DigitalSolutions/ProjectDirectory/Client%20Experience%20CXO%20POD%20Projects/Quantum%20Force/01_QF_Implementations/20210328_QF_Implementation?csf=1&web=1&e=Gw0k0t

## Plugins used  
**CSS loader**: The css-loader interprets @import and url() like import/require() and will resolve them.  
URL: https://github.com/webpack-contrib/css-loader

**SCSS loader**: Use the css-loader or the raw-loader to turn it into a JS module and the mini-css-extract-plugin to extract it into a separate file. Looking for the webpack 1 loader? Check out the archive/webpack-1 branch.  
URL: https://github.com/webpack-contrib/sass-loader

**MiniCssExtractPlugin**: This plugin extracts CSS into separate files. It creates a CSS file per JS file which contains CSS. It supports On-Demand-Loading of CSS and SourceMaps.  
URL: https://webpack.js.org/plugins/mini-css-extract-plugin/#root

**UglifyJsPlugin**: This plugin uses uglify-js to minify your JavaScript.  
URL: https://webpack.js.org/plugins/uglifyjs-webpack-plugin/

**HtmlWebPackPlugin**: The HtmlWebpackPlugin simplifies creation of HTML files to serve your webpack bundles. This is especially useful for webpack bundles that include a hash in the filename which changes every compilation.  
URL: https://webpack.js.org/plugins/html-webpack-plugin/#root

## Encoding:  
**source and bundle file**: Uses **UTF-8** encoding for both source file and bundle.

**Regex**: Uses **Hex code** values as special/French character translates properly through bitbucket and different IDE.
