import React, {useReducer} from "react";
import ReactDom from "react-dom";
import BeneficiaryWidget from "./components/beneficiary/BeneficiaryWidget";
import {
	initialState,
	beneficiaryReducer,
	StateContext,
	DispatchContext,
} from "./components/beneficiary/Reducer";
import "./scss/commons.scss";
import {dBeneContent} from "./components/commons/dBeneContent";
let ES6Promise = require("es6-promise");
ES6Promise.polyfill();

export const appContent =
	document.getElementsByTagName("HTML")[0].lang == "en" ||
	document.getElementsByTagName("HTML")[0].lang == "en-CA"
		? dBeneContent.en
		: dBeneContent.fr;

function DigitalBeneficiary() {
	const [state, dispatch] = useReducer(beneficiaryReducer, initialState);
	return (
		<div className='mar-top-20'>
			<div className='row content-area content-gap'>
				<div className='col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2 col-lg-offset-2'>
					<DispatchContext.Provider value={dispatch}>
						<StateContext.Provider value={state}>
							<BeneficiaryWidget />
						</StateContext.Provider>
					</DispatchContext.Provider>
				</div>
			</div>
		</div>
	);
}

var mountNode = document.getElementById("reactBody");
ReactDom.render(<DigitalBeneficiary />, mountNode);
