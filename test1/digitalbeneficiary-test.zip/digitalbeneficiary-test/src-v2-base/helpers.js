import axios from "axios";
import {
	timeoutUrl,
	sessionCheckUrlGB,
	sessionCheckUrlGBME2,
	sessionCheckUrlPPHP,
} from "./components/commons/dBeneContent";
let allUserInput = null;
export function setInputData(inputData) {
	allUserInput = inputData;
}

export function getInputData() {
	return allUserInput;
}

let formInstances = null;
export function setFormInstances(forms) {
	formInstances = forms;
}

export function getFormInstances() {
	return formInstances;
}

let designationSelect = null;
export function setDesignationSelect(val) {
	designationSelect = val;
}

export function getDesignationSelect() {
	return designationSelect;
}

let contingencyChecked = null;
export function setContingencyCheck(val) {
	contingencyChecked = val;
}

export function getContingencyCheck() {
	return contingencyChecked;
}
let language = document.getElementsByTagName("HTML")[0].lang;
export function getCurrentdate() {
	let today = new Date(),
		month = (today.getMonth() + 1 < 10 ? "0" : "") + (today.getMonth() + 1),
		day = (today.getDate() < 10 ? "0" : "") + today.getDate(),
		date =
			today.getFullYear() +
			"-" +
			(language === "en" || language === "en-CA" ? month : day) +
			"-" +
			(language === "en" || language === "en-CA" ? day : month);
	return date;
}

// export function convertAllocation(alloc) {
// 	return alloc.toLocaleString(language, {
// 		minimumFractionDigits: 2,
// 		maximumFractionDigits: 2,
// 	});
// }

//PREPENDS ZERO FOR SINGLE DIGITS
function dobConverter(val) {
	if (Number(val) < 10) return "0" + Number(val);
	else return val;
}

//</br> IS SENT AS CHOSEN BY JAVA..THEY CONVERT IT TO /n BEFORE SENDING DATA TO OASIS
export function getValuesAsPerRelation(
	values,
	relationship,
	relationshipList,
	quebec,
	content
) {
	let addInputVal = "";
	Object.keys(relationshipList).map((eachReln, index) => {
		if (relationshipList[eachReln].value === relationship) {
			switch (Math.floor(relationship)) {
				case 1:
					addInputVal =
						relationshipList[eachReln].label +
						" &#8212 " +
						values.allocation +
						"%</br>";
					break;
				case 2:
					addInputVal =
						values.orgName +
						", " +
						relationshipList[eachReln].label +
						" &#8212 " +
						values.allocation +
						"%</br>" +
						(values.orgAddress !== undefined
							? values.orgAddress + "</br>"
							: "");
					break;
				case 3:
				case 5:
					addInputVal =
						values.firstName +
						" " +
						values.lastName +
						", " +
						relationshipList[eachReln].label +
						(values.yob !== undefined
							? ", " +
							  values.yob +
							  "-" +
							  //   (language === "en-CA"
							  // 		? dobConverter(values.mob)
							  // 		: dobConverter(values.dob))
							  dobConverter(values.mob) +
							  "-" +
							  //   (language === "en-CA"
							  // 		? dobConverter(values.dob)
							  // 		: dobConverter(values.mob))
							  dobConverter(values.dob)
							: "") +
						(values.irrevocableStatus !== undefined
							? values.irrevocableStatus === "irrevocable" ||
							  values.irrevocableStatus[0] === "irrevocable"
								? " " + content.irrevocable
								: quebec
								? " " + content.revocable
								: ""
							: "") +
						" &#8212 " +
						values.allocation +
						"%</br>";
					break;
				case 4:
					addInputVal =
						values.firstName +
						" " +
						values.lastName +
						", " +
						relationshipList[eachReln].label +
						(values.yob !== undefined
							? ", " +
							  values.yob +
							  "-" +
							  //   (language === "en-CA"
							  // 		? dobConverter(values.mob)
							  // 		: dobConverter(values.dob))
							  dobConverter(values.mob) +
							  "-" +
							  //   (language === "en-CA"
							  // 		? dobConverter(values.dob)
							  // 		: dobConverter(values.mob))
							  dobConverter(values.dob)
							: "") +
						(values.irrevocableStatus !== undefined
							? values.irrevocableStatus === "irrevocable" ||
							  values.irrevocableStatus[0] === "irrevocable"
								? " " + content.irrevocable
								: quebec
								? " " + content.revocable
								: ""
							: "") +
						" &#8212 " +
						values.allocation +
						"%</br>" +
						(values.minorSelection === "no" || quebec
							? ""
							: content.trustee +
							  values.trusteeFirstName +
							  " " +
							  values.trusteeLastName +
							  ", " +
							  values.trusteeRel +
							  "</br>");
					break;
			}
		}
	});
	return addInputVal;
}
let impersonatedFlg = false; //RD - for call shadowing no tealium tagging
export function setImpersonatedFlag(val) {
	impersonatedFlg = val;
}

export function uTagCall(url) {
	try {
		if (!impersonatedFlg) {
			global.utag_data.canonical_url = url;
			global.utag_data.page_language =
				language === "en" || language === "en-CA" ? "en-CA" : "fr-CA";
			global.utag.view({
				ev_type: "page_imp",
				ev_action: "page_imp",
			});
		} else console.log("");
	} catch (err) {
		// console.log(err);
	}
}

//DESIGN CHANGE AS JAVA UNABLE TO ACCOMMMODATE SESSION HANDLING
export function checkSession(context) {
	// console.log("context", context, timeoutUrl);
	let relUrl;
	//LOGIC UPDATED AFTER GB_ME2 INCLUSION - 11 Aug 2020
	if (context === "gb_me" || context === "GB_ME") relUrl = sessionCheckUrlGB;
	else if (context === "gb_me2" || context === "GB_ME2")
		relUrl = sessionCheckUrlGBME2;
	else relUrl = sessionCheckUrlPPHP;
	let url = window.location.origin + relUrl,
		httpClient = axios.create();
	httpClient.defaults.timeout = 15000;
	httpClient
		.get(url)
		.then(function (response) {
			if (
				response.status === 200 &&
				response.data.toLowerCase() === "success"
			)
				return true;
			else window.location.href = window.location.origin + timeoutUrl;
		})
		.catch(function (error) {
			// console.log("Unable to call session timeout: ", error);
			// handle error
		});
}
