import React from "react";
import "../../scss/loader-spinner.scss";
// If the Wem COntent is not availabe the loding text won't get populated.. so need to add it as part of the widget.
function LoaderSpinner() {
	var loadingText1 =
		document.documentElement.lang == "en-CA" ||
		document.documentElement.lang == "en"
			? "Loading"
			: "Téléchargement en cours";
	var loadingText2 =
		document.documentElement.lang == "en-CA" ||
		document.documentElement.lang == "en"
			? "One moment, please."
			: "Veuillez patienter.";

	return (
		<div
			id='loadingMessageDiv'
			tabIndex='0'
			role='alert'
			aria-atomic='true'
			aria-live='polite'
			className='loading-spinner'>
			<div className='white-container'>
				<div className='loading-container'>
					<i className='fa fa-spinner fa-pulse' />
					<p>
						<strong>{loadingText1}</strong>
						<strong aria-hidden='true'>...</strong>
					</p>
					<p>{loadingText2}</p>
				</div>
			</div>
		</div>
	);
}
export default LoaderSpinner;
