import React from "react";

let valStrId = "";
let valStrClass = "";
let clickEvent = "";
class PageNavBtns extends React.Component {
	render() {
		const {
			moduleName,
			text,
			srOnlyBtnTxt,
			btnURL,
			ajaxURL,
		} = this.props.btnDetails;
		const {customClass} = this.props;
		let btnType, srOnlyTxt;
		switch (this.props.cssClassName) {
			case "btnLink":
				valStrId = "cancelPageBtns" + this.props.origin;
				valStrClass = "btn-link";
				btnType = "button";
				srOnlyTxt = srOnlyBtnTxt;
				clickEvent = () => {
					if (moduleName === "edit") window.cancel(event);
					else this.props.lnkBtnClk();
				};
				break;
			case "btnTransparent":
				valStrId = "prevPageBtns" + this.props.origin;
				valStrClass = "btn-sec-transparent";
				btnType = "button";
				srOnlyTxt = srOnlyBtnTxt;
				clickEvent = () => {
					if (moduleName === "edit") window.previous(event);
					else this.props.transBtnClk();
				};
				break;
			case "btnYellow":
				valStrId = "btnNext-" + this.props.origin;
				valStrClass = "btn-yellow";
				btnType = "submit";
				srOnlyTxt = srOnlyBtnTxt;
				clickEvent = () => {
					if (moduleName === "edit") {
						window.submit(event);
					} else this.props.ylwBtnClk();
				};
				break;
		}

		return (
			<button
				type={btnType}
				id={valStrId}
				onClick={clickEvent}
				aria-label={srOnlyTxt}
				className={`btn ele-mob-full-stretch ${valStrClass} ${customClass}`}>
				{text}
			</button>
		);
	}
}

export default PageNavBtns;
