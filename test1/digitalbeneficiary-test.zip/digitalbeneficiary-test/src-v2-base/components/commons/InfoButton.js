import React from "react";

const InfoButton = (props) => {
	return (
		<button
			type='button'
			className='info-modal-btn display-inline'
			aria-label={props.srLabel}
			onClick={() => props.openModal(props.modalType)}>
			<i
				className='fa fa-info-circle slf-slate-blue-color'
				aria-hidden='true'
			/>
		</button>
	);
};

export default InfoButton;
