export let saveMbrportalUrl =
	"/mbrportal/req/secure/pphp/profile/saveBeneficiaryDetails";
export let saveGBMEUrl = "/GB_ME/req/secure/saveBeneficiaryDetails";
export let saveGBME2Url = "/GB_ME2/req/secure/saveBeneficiaryDetails"; //NEW
export let errorUrl = "/error/defaultError";
export let sessionCheckUrlGB = "/GB_ME/req/secure/common/keepAlive";
export let sessionCheckUrlGBME2 = "/GB_ME2/req/secure/common/keepAlive"; //NEW
export let sessionCheckUrlPPHP = "/mbrportal/req/secure/pphp/common/keepAlive";
export let timeoutUrl =
	document.getElementsByTagName("HTML")[0].lang == "en" ||
	document.getElementsByTagName("HTML")[0].lang == "en-CA"
		? "/mysunlife/signin/sessionexpired.asp"
		: "/masunlife/signin/sessionexpired.asp";
var tncSubmit_en =
		"I revoke all previously nominated beneficiary designations and make the selected designation(s), where permitted by law.",
	tncSubmit_fr =
		"Je révoque toute désignation de bénéficiaire antérieure et je désigne le ou les bénéficiaires sélectionnés, dans la mesure où la loi le permet.",
	tncSuccess_en =
		"I revoke all previously nominated beneficiary designations and make the above designation, where permitted by law.",
	tncSuccess_fr =
		"Je révoque toute désignation de bénéficiaire antérieure et je désigne le ou les bénéficiaires ci-dessus, dans la mesure où la loi le permet.";
var commonContent = {
	benefitHead_en: "Your benefits",
	benefitHead_fr: "Vos garanties",
	editBenePageTitle_en: "Enter beneficiary details",
	editBenePageTitle_fr: "Entrez des renseignements sur les bénéficiaires",
	disclaimer_en: "Not insured by Sun Life",
	disclaimer_fr: "Non assurée par la Sun Life",
	notepadHead_en: "Your current beneficiary details",
	notepadHead_fr: "Renseignements sur vos bénéficiaires actuels",
	allBeneDesc_en:
		"Your beneficiary selections will apply to all Life benefits you have at the time of your death, including Life benefits you may select after this designation is made. All beneficiary designations need to be entered in full.",
	allBeneDesc_fr:
		"Vos désignations de bénéficiaire s’appliquent à tous les produits d’assurance-vie que vous avez au moment de votre décès, y compris ceux que vous sélectionnez par la suite. Toutes les désignations de bénéficiaire doivent être remplies au complet.",
	byBeneDesc_en:
		"Your beneficiary selections will be paid for each Life benefit you have at the time of your death. If any benefit is missing a beneficiary, the payment will go to your estate. All beneficiary designations need to be entered in full.",
	byBeneDesc_fr:
		"À votre décès, chaque bénéficiaire recevra le capital de la garantie pour laquelle vous l’avez désigné. Si vous ne désignez pas de bénéficiaire pour une garantie, nous verserons le capital à vos ayants droit. Toutes les désignations de bénéficiaire doivent être entrées au complet.",
	designationHead_en: "Beneficiary designation",
	designationHead_fr: "Désignation de bénéficiaire",
	beneDesigInfo_en: {
		modalTitle: "Beneficiary designation",
		modalBody:
			"<div>A beneficiary is a person or an organization (such as a charity) you name to receive the life benefit payable under your plan. You may name several beneficiaries and specify how the life benefit will be divided amongst them. </br>An estate is the collection of all your savings, assets and debts after you  die. Life Benefits are payable to your estate if:<ul><li>You name your estate as the beneficiary;</li><li>You die without naming a beneficiary; or</li><li>All primary and contingent beneficiaries die before you.</li></ul>If proceeds are paid to the estate, they will be distributed along with the remainder of the estate, according to the terms of your Will.</div>",
		modalBtns: {
			btnYellow: {
				text: "OK",
				srOnlyBtnTxt: "okay",
			},
		},
	},
	beneDesigInfo_fr: {
		modalTitle: "Désignation de bénéficiaire",
		modalBody:
			"<div>Un bénéficiaire est une personne ou une organisation (p. ex. un organisme de bienfaisance) que vous désignez pour recevoir le capital-décès de votre assurance-vie payable en vertu de votre régime. Vous pouvez désigner plusieurs bénéficiaires et indiquer comment le capital-décès sera réparti. Une succession est l’ensemble de vos épargnes, de vos biens et de vos dettes après votre décès. Votre succession reçoit le capital-décès de votre assurance-vie si :<ul><li>vous désignez votre succession comme bénéficiaire;</li><li>vous décédez sans désigner de bénéficiaire; ou </li><li>tous les bénéficiaires en premier ordre et en sous-ordre décèdent avant vous.</li></ul>Si le capital-décès est versé à la succession, il sera distribué avec les autres biens de la succession, conformément aux directives de votre testament.</div>",
		modalBtns: {
			btnYellow: {
				text: "OK",
				srOnlyBtnTxt: "okay",
			},
		},
	},
	cancelModal_en: {
		modalTitle: "Cancel?",
		modalBody:
			"Any changes you made will be lost. Are you sure you want to continue?",
		modalBtns: {
			btnLink: {
				text: "No",
				srOnlyBtnTxt: "no",
			},
			btnYellow: {
				text: "Yes",
				srOnlyBtnTxt: "yes",
			},
		},
	},
	cancelModal_fr: {
		modalTitle: "Annuler?",
		modalBody:
			"Toutes les modifications apportées seront perdues. Voulez-vous vraiment continuer?",
		modalBtns: {
			btnLink: {
				text: "Non",
				srOnlyBtnTxt: "non",
			},
			btnYellow: {
				text: "Oui",
				srOnlyBtnTxt: "oui",
			},
		},
	},
	revocableStatus_en: {
		modalTitle: "Warning about naming an irrevocable beneficiary",
		modalBody:
			"When you name an irrevocable beneficiary, you can’t change your beneficiary without their consent. If you nominate a minor child, they cannot provide their consent until the age of 18.",
		modalBtns: {
			btnLink: {
				text: "Cancel",
				srOnlyBtnTxt: "cancel",
				btnURL: "",
			},
			btnYellow: {
				text: "Confirm",
				srOnlyBtnTxt: "confirm",
				btnURL: "",
			},
		},
	},
	revocableStatus_fr: {
		modalTitle:
			"Avertissement concernant la désignation d’un bénéficiaire irrévocable",
		modalBody:
			"Quand vous désignez un bénéficiaire irrévocable, vous ne pouvez pas changer de bénéficiaire sans son consentement. Si vous désignez un enfant mineur, il ne peut pas donner son consentement avant l’âge de 18 ans.",
		modalBtns: {
			btnLink: {
				text: "Annuler",
				srOnlyBtnTxt: "annulern",
				btnURL: "",
			},
			btnYellow: {
				text: "Confirmer",
				srOnlyBtnTxt: "confirmer",
				btnURL: "",
			},
		},
	},

	termsNCondDesc_en:
		"<ul><li>" +
		tncSubmit_en +
		"</li><li>I confirm that I did not previously appoint an irrevocable beneficiary under this group benefits plan issued by Sun Life or any other insurer or alternatively, that I obtained the consent of the irrevocable beneficiary to name the beneficiaries in this form.</li><li>I authorize Sun Life Assurance Company of Canada (Sun Life)* to collect, use and disclose relevant information about me to administer and audit the plan as well as pay claims with its reinsurers and the plan sponsor.</li></ul><div class='legal-text mar-bottom-15'> * Any reference to Sun Life, its reinsurers or the plan sponsor includes their agents and service providers.</div>",
	termsNCondDesc_fr:
		"<ul><li>" +
		tncSubmit_fr +
		"</li><li>J’atteste que je n’ai pas déjà désigné de bénéficiaire irrévocable pour ce régime de garanties collectives établi par la Sun Life ou par tout autre assureur, ou que j’ai obtenu le consentement du bénéficiaire irrévocable pour nommer le ou les bénéficiaires indiqués sur ce formulaire.</li><li>J’autorise la Sun Life du Canada, compagnie d’assurance-vie (la Sun Life)* à recueillir et à utiliser des renseignements pertinents me concernant, et à les communiquer à ses réassureurs et au promoteur de régime, pour assurer la gestion et la vérification du régime et le traitement des demandes de règlement.</li></ul><div class='legal-text mar-bottom-15'> * Toute référence à la Sun Life, à ses réassureurs ou au promoteur de régime comprend leurs mandataires et leurs fournisseurs de services.</div>",
	termsNCondDescSuccess_en:
		"<ul><li>" +
		tncSuccess_en +
		"</li><li> I confirm that I did not previously appoint an irrevocable beneficiary under this group benefits plan issued by Sun Life or any other insurer or alternatively, that I obtained the consent of the irrevocable beneficiary to name the beneficiaries in this form.</li><li> I authorize Sun Life Assurance Company of Canada (Sun Life)* to collect, use and disclose relevant information about me to administer and audit the plan as well as pay claims with its reinsurers and the plan sponsor.</li></ul><div class='legal-text mar-bottom-15'> * Any reference to Sun Life, its reinsurers or the plan sponsor includes their agents and service providers.</div>",
	termsNCondDescSuccess_fr:
		"<ul><li>" +
		tncSuccess_fr +
		"</li><li> J’atteste que je n’ai pas déjà désigné de bénéficiaire irrévocable pour ce régime de garanties collectives établi par la Sun Life ou par tout autre assureur, ou que j’ai obtenu le consentement du bénéficiaire irrévocable pour nommer le ou les bénéficiaires indiqués sur ce formulaire.</li><li> J’autorise la Sun Life du Canada, compagnie d’assurance-vie (la Sun Life)* à recueillir et à utiliser des renseignements pertinents me concernant, et à les communiquer à ses réassureurs et au promoteur de régime, pour assurer la gestion et la vérification du régime et le traitement des demandes de règlement.</li></ul><div class='legal-text mar-bottom-15'> * Toute référence à la Sun Life, à ses réassureurs ou au promoteur de régime comprend leurs mandataires et leurs fournisseurs de services.</div>",
};

export let dBeneContent = {
	en: {
		summary: {
			designationHead: commonContent.designationHead_en,
			designationSrLabel:
				"More information about beneficiary designations",
			designationCont:
				"This designation applies to the following benefits. If you do not nominate a beneficiary, the life benefits payable under your plan will be paid to your estate.",
			summaryHead: "Beneficiary summary",
			summaryDesc:
				"All beneficiary designations need to be entered in full if you make any changes​.",
			editBtn: "Edit beneficiary",
			benefitHead: commonContent.benefitHead_en,
			currentBenefitHead: "Your beneficiary designation",
			disclaimer: commonContent.disclaimer_en,
			noBeneficiary: "No beneficiary information available.",
			successHeader: "Success",
			successDesc: "Your updates have been successfully submitted.",
			successTermsHeader: "Terms and conditions",
			successTermsAgreed: "I have agreed to the following: ",
			successTerms: commonContent.termsNCondDescSuccess_en,
			memberId: "Member ID",
			modal: {
				beneDesignation: commonContent.beneDesigInfo_en,
				irrevocable: {
					modalTitle: "Irrevocable beneficiary",
					modalBody:
						"You are unable to update your designation online because at least one of your beneficiaries is irrevocable.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				ADMIN_PLUS: {
					modalTitle: "Irrevocable beneficiary",
					modalBody:
						"Please complete a paper Irrevocable Beneficiary Update form. From the Welcome page, navigate to the View section. Then select the form in the Forms drop-down listing. ",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				GBA: {
					modalTitle: "Irrevocable beneficiary",
					modalBody:
						"Please complete a paper Irrevocable Beneficiary Update form available from your Employer or Benefits Administrator.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				TRUE_IA: {
					modalTitle: "Irrevocable beneficiary",
					modalBody:
						"Please complete a paper Irrevocable Beneficiary Update form available from your Employer or Benefits Administrator.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				sponsorShadowGBA: {
					modalTitle: "Warning",
					modalBody:
						"Only members are eligible to use this screen to update their beneficiary information.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
			},
		},
		notepad: {
			designationDate: "Designation effective :",
			allBene: "DESIGNATION FOR ALL LIFE BENEFITS </br> (including Life benefits you may select after designation effective date) </br>",
			trustee: "Trustee for minor: ",
			irrevocable: "(Irrevocable)",
			revocable: "(Revocable)",
			contingentAllBene: "CONTINGENT BENEFICIARY FOR ALL LIFE BENEFITS:</br> (including Life benefits you may select after designation effective date) </br>",
		},
		designation: {
			chooseHead: "Choose how to name your beneficiary",
			allBeneLbl: "Same beneficiary for all benefits",
			allBeneDesc: commonContent.allBeneDesc_en,
			byBeneLbl: "Different beneficiary for each benefit",
			byBeneDesc: commonContent.byBeneDesc_en,
			notepadHead: commonContent.notepadHead_en,
			notepadAccTitle: "Your beneficiary designation",
			pageNavBtns: {
				btnLink: {
					text: "Cancel",
					srOnlyBtnTxt: "Cancel",
					moduleName: "designation",
				},
				btnTransparent: {
					text: "Previous",
					srOnlyBtnTxt: "previous",
					moduleName: "designation",
				},
				btnYellow: {
					text: "Next",
					srOnlyBtnTxt: "next",
					moduleName: "designation",
				},
			},
			modal: {
				loseData: {
					modalTitle: "Change selection?",
					modalBody:
						"If you change how to name your beneficiary, you’ll lose the information you’ve already entered.  Are you sure you want to continue?",
					modalBtns: {
						btnLink: {
							text: "Cancel",
							srOnlyBtnTxt: "cancel",
						},
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				cancel: commonContent.cancelModal_en,
			},
		},
		edit: {
			impersonated:
				"The ID you are using is not set up to allow changes.",
			addBeneHeader: commonContent.editBenePageTitle_en,
			allFlowSubHeader: commonContent.allBeneDesc_en,
			byFlowSubHeader: commonContent.byBeneDesc_en,
			beneSumHead: commonContent.benefitHead_en,
			benefitHead: commonContent.designationHead_en,
			designationSrLabel:
				"More information about beneficiary designations",
			disclaimer: commonContent.disclaimer_en,
			addBeneDesc:
				"A beneficiary is any individual, institution, trust or charity you name.",
			relationship: "Relationship",
			allocation: "Allocation",
			allocInfoLabel: "More information about beneficiary allocations",
			allocPlaceHolder: "0.00",
			yobPlaceHolder: "yyyy",
			mobPlaceHolder: "mm",
			dobPlaceHolder: "dd",
			firstName: "First Name",
			lastName: "Last Name",
			revocableStatus: "Revocable status",
			irrevocable: "Irrevocable",
			irrevocableInfoLabel:
				"More information about irrevocable beneficiaries",
			dob: "Date of birth (optional)",
			dobInfoLabel: "More information about entering a date of birth",
			addBtn: "Add another beneficiary",
			contingentBene: "Contingent beneficiary",
			contingentBeneInfoLabel:
				"More information about contingent beneficiaries",
			contingentChkbox: "I want to add a contingent beneficiary.",
			contingentBeneSec: "Contingent beneficiary",
			contingentBeneSecDesc:
				"A contingent beneficiary is a person or an organization you name to receive the Life benefit under your plan if no primary beneficiaries are alive at the time of your death.",
			contingentDisclaimer:
				"This designation will apply to all Life benefits you have at the time of your death, including Life benefits you may select after this designation is made.",
			additionalBene: "Additional beneficiary",
			additionContBene: "Additional contingent beneficiary",
			removeBene: "Remove beneficiary",
			orgName:
				"Organization name (Financial institutions are not eligible)",
			orgAddress: "Address (optional)",
			revocable: "Revocable",
			revocableInfoLabel:
				"More information about revocable beneficiaries",
			under18: "Is this beneficiary under 18?",
			under18InfoLabel:
				"More information about beneficiaries under the age of 18",
			minorYesRadio: "Yes",
			minorNoRadio: "No",
			trusteeHeader: "Trustee for minor beneficiaries",
			trusteeFName: "Trustee first name",
			trusteeLName: "Trustee last name",
			relnToMinor: "Relationship to the minor",
			minorQuebec:
				"In Quebec, any amount payable to a minor will be paid to the parent(s) or legal guardian on his/her behalf. Or you may choose to name your estate as beneficiary and provide a trustee with directions in your will.",
			totalAllocationLabel: "You have allocated",
			trusteeQC:
				"In Quebec, any amount payable to a minor will be paid to the parent(s) or legal guardian on his/her behalf. Or you may choose to name your estate as beneficiary and provide a trustee with directions in your will.",
			tcAccept:
				"I have reviewed the beneficiary details entered for accuracy and agree to the terms and conditions. ",
			effective: "Designation effective : ",
			pageNavBtns: {
				btnLink: {
					text: "Cancel",
					srOnlyBtnTxt: "Cancel",
					moduleName: "edit",
				},
				btnTransparent: {
					text: "Previous",
					srOnlyBtnTxt: "previous",
					moduleName: "edit",
				},
				btnYellow: {
					text: "Submit",
					srOnlyBtnTxt: "submit",
					moduleName: "edit",
				},
			},
			select: "Select",
			modal: {
				allocation: {
					modalTitle: "Allocation",
					modalBody:
						"If you name more than one beneficiary and one of them dies before you, then their percentage will be split between the remaining beneficiaries. In Quebec, this is only true as long as your beneficiaries had equal shares.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				irrevocableCheckbox: commonContent.revocableStatus_en,
				irrevocableRadio: commonContent.revocableStatus_en,
				revocableRadio: commonContent.revocableStatus_en,
				irrevocable: {
					modalTitle: "Irrevocable",
					modalBody:
						"<div>When you name an irrevocable beneficiary, you can’t change your beneficiary without their consent. A beneficiary may be irrevocable for the following reasons:<ul><li>By provincial law: In Québec when you name a legal spouse (married or civil union) as beneficiary, they are presumed to be irrevocable unless you indicate otherwise.</li><li>At your request: You may voluntarily make your beneficiary irrevocable.</li><li>By court ruling: A beneficiary could be irrevocable through a court ruling. For example, a divorce decree may require that your ex-spouse must remain the beneficiary and cannot be changed without their consent.</li></ul></div>",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				revocable: {
					modalTitle: "Revocable",
					modalBody:
						"Naming a revocable beneficiary means that you are able to change your beneficiary at any time.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				dob: {
					modalTitle: "Date of birth",
					modalBody:
						"Completing the date of birth helps identify your beneficiary at the time of your death.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				contingentInfo: {
					modalTitle: "Contingent beneficiary",
					modalBody:
						"A contingent beneficiary is a person or an organization (such as a charity) you name to receive the life benefit under your plan if no primary beneficiaries are alive at the time of your death. You may name several contingent beneficiaries, and specify how the life benefit will be divided amongst them.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				remove: {
					modalTitle: "Remove beneficiary",
					modalBody:
						"Are you sure you want to remove this beneficiary?",
					modalBtns: {
						btnLink: {
							text: "No",
							srOnlyBtnTxt: "no",
						},
						btnYellow: {
							text: "Yes",
							srOnlyBtnTxt: "yes",
						},
					},
				},
				trustee: {
					modalTitle: "Trustee for minor beneficiaries",
					modalBody:
						"If your beneficiary is under the age of 18, a trustee must be named. If the beneficiary is still under 18 when you die, the life benefit will go to the trustee on behalf of the minor.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				beneDesignation: commonContent.beneDesigInfo_en,
				cancel: commonContent.cancelModal_en,
				confirmation: {
					modalTitle: "Terms and conditions",
					modalBody:
						"<div>By saving these changes:" +
						commonContent.termsNCondDesc_en +
						"</div>",
					modalBtns: {
						btnLink: {
							text: "Close",
							srOnlyBtnTxt: "close",
						},
						btnYellow: {
							text: "Finish",
							srOnlyBtnTxt: "Finish",
						},
					},
				},
			},
			relationshipDropdownList: [
				//SPOUSAL (GROUP 3)
				{
					label: "Husband",
					value: "3.02",
					group: "3",
				},
				{
					label: "Wife",
					value: "3.01",
					group: "3",
				},
				{
					label: "Spouse",
					value: "3.03",
					group: "3",
				},
				{
					label: "Common-Law",
					value: "3.04",
					group: "3",
				},
				//SPOUSAL (GROUP 3)
				{
					label: "Civil Union",
					value: "3.05",
					group: "3",
				},
				{
					label: "Father",
					value: "5.01",
					group: "5",
				},
				{
					label: "Mother",
					value: "5.02",
					group: "5",
				},

				{
					label: "Daughter",
					value: "4.02",
					group: "4",
				},
				{
					label: "Son",
					value: "4.01",
					group: "4",
				},
				{
					label: "Estate",
					value: "1",
					group: "1",
				},
				{
					label: "----------------",
					value: "404",
				},
				{
					label: "Brother",
					value: "4.03",
					group: "4",
				},
				{
					label: "Sister",
					value: "4.04",
					group: "4",
				},
				{
					label: "Nephew",
					value: "4.06",
					group: "4",
				},
				{
					label: "Niece",
					value: "4.05",
					group: "4",
				},

				{
					label: "Aunt",
					value: "5.03",
					group: "5",
				},
				{
					label: "Uncle",
					value: "5.04",
					group: "5",
				},
				{
					label: "Cousin",
					value: "4.07",
					group: "4",
				},
				{
					label: "Family-in-Law",
					value: "4.08",
					group: "4",
				},
				{
					label: "Fiancé",
					value: "5.05",
					group: "5",
				},
				{
					label: "Former Spouse",
					value: "5.06",
					group: "5",
				},
				{
					label: "Friend",
					value: "4.09",
					group: "4",
				},
				{
					label: "Grandchild",
					value: "4.10",
					group: "4",
				},
				{
					label: "Grandparent",
					value: "5.08",
					group: "5",
				},
				{
					label: "Organization",
					value: "2",
					group: "2",
				},
				{
					label: "Stepchild",
					value: "5.09",
					group: "5",
				},
				{
					label: "Stepparent",
					value: "5.1",
					group: "5",
				},
				{
					label: "Other",
					value: "5.001",
					group: "5",
				},
			],
		},
		modal: {
			beneDesigInfo: {
				modalTitle: "",
				modalBody:
					"<div>A beneficiary is a person or an organization (such as a charity) you name to receive the life benefit payable under your plan. You may name several beneficiaries and specify how the life benefit will be divided amongst them. </br>An estate is the collection of all your savings, assets and debts after you  die. Life Benefits are payable to your estate if:<ul><li>You name your estate as the beneficiary;<li><li>You die without naming a beneficiary; or</li><li>All primary and contingent beneficiaries die before you.</li></ul>If proceeds are paid to the estate, they will be distributed along with the remainder of the estate, according to the terms of your Will.</div>",
				modalBtns: {
					btnYellow: {
						text: "Close",
						srOnlyBtnTxt: "close",
					},
				},
			},

			termsNCond: {
				modalTitle: "Terms and conditions",
				modalBody: commonContent.termsNCondDesc_en,
				modalBtns: {
					btnYellow: {
						text: "Close",
						srOnlyBtnTxt: "close",
					},
				},
			},
			changeDesignation: {
				modalTitle: "Are you sure you want to change your selection?",
				modalBody:
					"If you change your selection, any information you have entered will be lost.",
				modalBtns: {
					btnYellow: {
						text: "Close",
						srOnlyBtnTxt: "close",
					},
				},
			},
		},
		errors: {
			totalCount1: "There are ",
			totalCount2: " error(s) on this page.",
			allocation: "Total allocation must equal 100.00%",
			mandatory: "Required field",
			technicalError:
				"Our apologies! We're having some technical difficulties, please come back later.",
		},
	},
	fr: {
		summary: {
			designationHead: commonContent.designationHead_fr,
			designationSrLabel:
				"Plus de renseignements sur les désignations de bénéficiaire",
			designationCont:
				"La désignation s’applique aux garanties ci-dessous. Si vous ne désignez pas de bénéficiaire, votre succession recevra le capital-décès prévu par votre régime.",
			summaryHead: "Sommaire des bénéficiaires",
			summaryDesc:
				"Toutes les désignations de bénéficiaire auxquelles vous apportez des modifications doivent être entrées au complet.",
			editBtn: "Modifier les bénéficiaires",
			benefitHead: commonContent.benefitHead_fr,
			currentBenefitHead: "Votre désignation de bénéficiaire",
			disclaimer: commonContent.disclaimer_fr,
			noBeneficiary: "Aucune information sur le bénéficiaire.",
			successHeader: "C’est fait!",
			successDesc: "Nous avons bien reçu vos changements.",
			successTermsHeader: "Conditions",
			successTermsAgreed: "Vous avez accepté ce qui suit : ",
			successTerms: commonContent.termsNCondDescSuccess_fr,
			memberId: "Numéro de Participant",
			modal: {
				beneDesignation: commonContent.beneDesigInfo_fr,
				irrevocable: {
					modalTitle: "Bénéficiaire irrévocable",
					modalBody:
						"Vous ne pouvez pas modifier votre désignation de bénéficiaire en ligne, car au moins un de vos bénéficiaires est irrévocable.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				ADMIN_PLUS: {
					modalTitle: "Bénéficiaire irrévocable",
					modalBody:
						"Remplissez un formulaire papier pour modifier votre désignation de bénéficiaire irrévocable. À partir de la page d’accueil, allez à la section Visualiser (sous Adhésion et sommaire de la couverture). Puis, sélectionnez le formulaire requis dans la liste déroulante Formulaires.	",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				GBA: {
					modalTitle: "Bénéficiaire irrévocable",
					modalBody:
						"Remplissez un formulaire papier pour modifier votre désignation de bénéficiaire irrévocable. Demandez ce formulaire à votre employeur ou au gestionnaire de vos garanties.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				TRUE_IA: {
					modalTitle: "Bénéficiaire irrévocable",
					modalBody:
						"Remplissez un formulaire papier pour modifier votre désignation de bénéficiaire irrévocable. Demandez ce formulaire à votre employeur ou au gestionnaire de vos garanties.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				sponsorShadowGBA: {
					modalTitle: "Avertissement",
					modalBody:
						"Seuls les participants peuvent utiliser cet écran pour modifier les renseignements sur leurs bénéficiaires.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
			},
		},
		notepad: {
			designationDate: "Date d'entrée en vigueur de la désignation :",
			allBene:
				"DÉSIGNATIONS DE BÉNÉFICIAIRE POUR TOUS LES PRODUITS D'ASSURANCE-VIE :</br> (y compris les produits que vous sélectionnez après la date d'entrée en vigueur des désignations) </br>",
			trustee: "Fiduciaire pour un bénéficiaire mineur : ",
			irrevocable: "(irrévocable)",
			revocable: "(révocable)",
			contingentAllBene:
				"DÉSIGNATIONS DE BÉNÉFICIAIRE EN SOUS-ORDRE POUR TOUS LES PRODUITS D'ASSURANCE-VIE :</br> (y compris les produits que vous sélectionnez après la date d'entrée en vigueur des désignations) </br>",
		},
		designation: {
			chooseHead: "Choisissez comment désigner votre bénéficiaire",
			allBeneLbl: "Même bénéficiaire pour toutes les garanties",
			allBeneDesc: commonContent.allBeneDesc_fr,
			byBeneLbl: "Bénéficiaire différent pour chaque garantie",
			byBeneDesc: commonContent.byBeneDesc_fr,
			notepadHead: commonContent.notepadHead_fr,
			notepadAccTitle: "Votre désignation de bénéficiaire",
			pageNavBtns: {
				btnLink: {
					text: "Annuler",
					srOnlyBtnTxt: "annuler",
					moduleName: "designation",
				},
				btnTransparent: {
					text: "Précédent",
					srOnlyBtnTxt: "précédent",
					moduleName: "designation",
				},
				btnYellow: {
					text: "Suivant",
					srOnlyBtnTxt: "suivant",
					moduleName: "designation",
				},
			},
			modal: {
				loseData: {
					modalTitle: "Changer la sélection?",
					modalBody:
						"Si vous changez la façon de désigner un bénéficiaire, vous perdrez les renseignements que vous avez déjà entrés. Voulez-vous vraiment continuer?",
					modalBtns: {
						btnLink: {
							text: "Annuler",
							srOnlyBtnTxt: "annuler",
						},
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				cancel: commonContent.cancelModal_fr,
			},
		},
		edit: {
			impersonated:
				"Le numéro d’identification que vous utilisez ne permet pas les changements.",
			addBeneHeader: commonContent.editBenePageTitle_fr,
			allFlowSubHeader: commonContent.allBeneDesc_fr,
			byFlowSubHeader: commonContent.byBeneDesc_fr,
			beneSumHead: commonContent.benefitHead_fr,
			benefitHead: commonContent.designationHead_fr,
			designationSrLabel:
				"Plus de renseignements sur les désignations de bénéficiaire",
			disclaimer: commonContent.disclaimer_fr,
			addBeneDesc:
				"Un bénéficiaire est une personne, une institution, une fiducie ou un organisme de bienfaisance que vous désignez.",
			relationship: "Lien",
			allocation: "Pourcentage",
			allocInfoLabel:
				"Plus de renseignements sur le pourcentage par bénéficiaire",
			allocPlaceHolder: "0,00",
			yobPlaceHolder: "yyyy",
			mobPlaceHolder: "dd",
			dobPlaceHolder: "mm",
			firstName: "Prénom",
			lastName: "Nom",
			revocableStatus: "Bénéficiaire révocable",
			irrevocable: "Irrévocable",
			irrevocableInfoLabel:
				"Plus de renseignements sur les bénéficiaires irrévocables",
			dob: "Date de naissance (facultatif)",
			dobInfoLabel:
				"Plus de renseignements sur la saisie d’une date de naissance",
			addBtn: "Ajouter un autre bénéficiaire",
			contingentBene: "Bénéficiaire en sous-ordre",
			contingentBeneInfoLabel:
				"Plus de renseignements sur les bénéficiaires en sous-ordre",
			contingentChkbox: "Je veux désigner un bénéficiaire en sous-ordre.",
			contingentBeneSec: "Bénéficiaire en sous-ordre",
			contingentBeneSecDesc:
				"Un bénéficiaire en sous-ordre est une personne ou une organisation que vous désignez pour recevoir le capital de votre régime si aucun bénéficiaire en premier ordre n’est vivant à votre décès.",
			contingentDisclaimer:
				"Cette désignation s’applique à tous les produits d’assurance-vie que vous avez au moment de votre décès, y compris ceux que vous sélectionnez par la suite.",
			additionalBene: "Autre bénéficiaire",
			additionContBene: "Autre bénéficiaire en sous-ordre",
			removeBene: "Supprimer le bénéficiaire",
			orgName:
				"Nom de l’organisation (les institutions financières ne sont pas admissibles)",
			orgAddress: "Adresse (facultatif)",
			revocable: "Révocable",
			revocableInfoLabel:
				"Plus de renseignements sur les bénéficiaires révocables",
			under18: "Ce bénéficiaire a-t-il moins de 18 ans?",
			under18InfoLabel:
				"Plus de renseignements sur les bénéficiaires âgés de moins de 18 ans",
			minorYesRadio: "Oui",
			minorNoRadio: "Non",
			trusteeHeader: "Fiduciaire pour un bénéficiaire mineur",
			trusteeFName: "Fiduciaire - Prénom",
			trusteeLName: "Fiduciaire - Nom",
			relnToMinor: "Lien avec le mineur",
			minorQuebec:
				"Au Québec, tout montant payable à un mineur sera versé au(x) parent(s) ou au tuteur légal pour le compte du bénéficiaire mineur. Les participants peuvent aussi nommer leurs ayants droit comme bénéficiaires et fournir des directives à un fiduciaire dans leur testament.",
			totalAllocationLabel: "Vous avez attribué",
			trusteeQC:
				"Au Québec, tout montant à être payé à un mineur sera payé pour son compte au(x) parent(s) ou au tuteur légal de ce mineur. Une autre option pour vous est de désigner votre succession comme bénéficiaire et de nommer un fiduciaire dans votre testament, avec des directives.",
			tcAccept:
				"J’ai vérifié l’exactitude de mes renseignements sur le bénéficiaire et j’accepte les conditions. ",
			effective: "Date d'entrée en vigueur de la désignation : ",
			pageNavBtns: {
				btnLink: {
					text: "Annuler",
					srOnlyBtnTxt: "annuler",
					moduleName: "edit",
				},
				btnTransparent: {
					text: "Précédent",
					srOnlyBtnTxt: "précédent",
					moduleName: "edit",
				},
				btnYellow: {
					text: "Envoyer",
					srOnlyBtnTxt: "envoyer",
					moduleName: "edit",
				},
			},
			select: "Sélectionnez",
			modal: {
				allocation: {
					modalTitle: "Pourcentage",
					modalBody:
						"Si vous désignez plus d’un bénéficiaire et que l’un d’eux décède avant vous, le pourcentage qui devait lui revenir sera réparti parmi les bénéficiaires restants. Au Québec, cela s’applique seulement si le capital est réparti en parts égales entre les bénéficiaires.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				irrevocableCheckbox: commonContent.revocableStatus_fr,
				irrevocableRadio: commonContent.revocableStatus_fr,
				revocableRadio: commonContent.revocableStatus_fr,
				irrevocable: {
					modalTitle: "Irrévocable",
					modalBody:
						"<div>Lorsque vous désignez un bénéficiaire irrévocable, vous ne pouvez modifier le bénéficiaire sans son consentement. </br> Une désignation de bénéficiaire peut être irrévocable pour les raisons suivantes :<ul><li>En raison de la loi provinciale : Au Québec, lorsque vous désignez votre conjoint légal (uni par le mariage ou une union civile) comme bénéficiaire, cette désignation est considérée comme irrévocable sauf si vous indiquez qu’elle est révocable.</li><li>À votre demande : Vous pouvez expressément désigner un bénéficiaire irrévocable.</li><li>En raison d’une décision judiciaire : Un bénéficiaire pourrait être désigné comme irrévocable en raison d’une décision judiciaire. Par exemple, un jugement de divorce pourrait exiger que l’ancien conjoint demeure le bénéficiaire et que la désignation ne puisse être modifiée sans son consentement.</li></ul></div>",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				revocable: {
					modalTitle: "Révocable",
					modalBody:
						"Une désignation de bénéficiaire révocable vous laisse la possibilité de changer de bénéficiaire à tout moment.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				dob: {
					modalTitle: "Date de naissance",
					modalBody:
						"La date de naissance nous aidera à identifier votre bénéficiaire à votre décès.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				contingentInfo: {
					modalTitle: "Bénéficiaire en sous-ordre",
					modalBody:
						"Un bénéficiaire en sous-ordre est une personne ou une organisation (p. ex. un organisme de bienfaisance) que vous désignez pour recevoir le capital prévu par votre régime si aucun bénéficiaire en premier ordre n’est vivant à votre décès. Vous pouvez nommer plusieurs bénéficiaires en sous-ordre et indiquer le pourcentage du capital à verser à chacun.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				remove: {
					modalTitle: "Supprimer le bénéficiaire",
					modalBody:
						"Voulez-vous vraiment supprimer ce bénéficiaire?",
					modalBtns: {
						btnLink: {
							text: "Non",
							srOnlyBtnTxt: "non",
						},
						btnYellow: {
							text: "Oui",
							srOnlyBtnTxt: "oui",
						},
					},
				},
				trustee: {
					modalTitle: "Fiduciaire pour un bénéficiaire mineur",
					modalBody:
						"Si le bénéficiaire a moins de 18 ans, vous devez nommer un fiduciaire. Si le bénéficiaire n’a pas encore atteint 18 ans à votre décès, nous verserons le capital au fiduciaire pour le compte du bénéficiaire mineur.",
					modalBtns: {
						btnYellow: {
							text: "OK",
							srOnlyBtnTxt: "okay",
						},
					},
				},
				beneDesignation: commonContent.beneDesigInfo_fr,
				cancel: commonContent.cancelModal_fr,
				confirmation: {
					modalTitle: "Conditions",
					modalBody:
						"<div>En enregistrant ces changements :" +
						commonContent.termsNCondDesc_fr +
						"</div>",
					modalBtns: {
						btnLink: {
							text: "Fermer",
							srOnlyBtnTxt: "fermer",
						},
						btnYellow: {
							text: "Compléter",
							srOnlyBtnTxt: "Compléter",
						},
					},
				},
			},
			relationshipDropdownList: [
				//SPOUSAL (GROUP 3)
				{
					label: "Mari",
					value: "3.02",
					group: "3",
				},
				{
					label: "Femme",
					value: "3.01",
					group: "3",
				},
				{
					label: "Époux",
					value: "3.03",
					group: "3",
				},
				{
					label: "Conjoint de fait",
					value: "3.04",
					group: "3",
				},
				//SPOUSAL (GROUP 3)
				{
					label: "Union civile",
					value: "3.05",
					group: "3",
				},
				{
					label: "Père",
					value: "5.01",
					group: "5",
				},
				{
					label: "Mère",
					value: "5.02",
					group: "5",
				},

				{
					label: "Fille",
					value: "4.02",
					group: "4",
				},
				{
					label: "Fils",
					value: "4.01",
					group: "4",
				},
				{
					label: "Ayants droit",
					value: "1",
					group: "1",
				},
				{
					label: "----------------",
					value: "404",
				},
				{
					label: "Frère",
					value: "4.03",
					group: "4",
				},
				{
					label: "Soeur",
					value: "4.04",
					group: "4",
				},

				{
					label: "Neveu",
					value: "4.06",
					group: "4",
				},
				{
					label: "Nièce",
					value: "4.05",
					group: "4",
				},
				{
					label: "Tante",
					value: "5.03",
					group: "5",
				},
				{
					label: "Oncle",
					value: "5.04",
					group: "5",
				},
				{
					label: "Cousin",
					value: "4.07",
					group: "4",
				},
				{
					label: "Belle-famille",
					value: "4.08",
					group: "4",
				},
				{
					label: "Fiancé",
					value: "5.05",
					group: "5",
				},
				{
					label: "Ancien conjoint",
					value: "5.06",
					group: "5",
				},
				{
					label: "Ami",
					value: "4.09",
					group: "4",
				},
				{
					label: "Petit-enfant",
					value: "4.10",
					group: "4",
				},
				//OTHER

				{
					label: "Grand-parent",
					value: "5.08",
					group: "5",
				},
				{
					label: "Organisation",
					value: "2",
					group: "2",
				},
				{
					label: "Autre",
					value: "5.001",
					group: "5",
				},
			],
		},
		modal: {
			beneDesigInfo: commonContent.beneDesigInfo_fr,

			termsNCond: {
				modalTitle: "Modalités et conditions",
				modalBody: commonContent.termsNCondDesc_fr,
				modalBtns: {
					btnYellow: {
						text: "Close",
						srOnlyBtnTxt: "close",
					},
				},
			},

			changeDesignation: {
				modalTitle: "Voulez-vous vraiment changer votre sélection?",
				modalBody:
					"Si vous changez votre sélection, tous les renseignements que vous avez entrés seront perdus.",
				modalBtns: {
					btnYellow: {
						text: "Close",
						srOnlyBtnTxt: "close",
					},
				},
			},
		},
		errors: {
			totalCount1: "Il y a ",
			totalCount2: " erreur(s) sur cette page.",
			allocation: "La somme des pourcentages doit être égale à 100,00 %",
			mandatory: "Champ obligatoire",
			technicalError:
				"Toutes nos excuses! Nous éprouvons des problèmes techniques. Veuillez réessayer plus tard.",
		},
	},
};
export let modalStartEnd = {
	start_en: "Start of modal",
	start_fr: "Début de la fenêtre de dialogue",
	end_en: "End of modal",
	end_fr: "Fin de la fenêtre de dialogue",
};
