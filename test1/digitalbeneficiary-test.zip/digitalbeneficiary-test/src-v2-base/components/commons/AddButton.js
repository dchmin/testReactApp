import React from "react";
import "../../scss/commons.scss";

const AddButton = ({id, href, value, onClick, ...props}) => {
	return (
		<a
			role='button'
			id={id}
			href='#'
			onClick={onClick}
			className='btn add-bene-btn'
			{...props}>
			<i className='fa fa-plus-circle' aria-hidden='true'></i>
			{value}
		</a>
	);
};
export default AddButton;
