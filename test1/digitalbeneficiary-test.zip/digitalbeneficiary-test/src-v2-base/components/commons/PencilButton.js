import React from "react";

const ButtonLink = ({id, href, value, cssClass, onClick, ...props}) => {
	return (
		<span className='edit-btn-span'>
			<i className='fa fa-pencil'></i>
			<a
				href={href}
				id={id}
				onClick={onClick}
				className={cssClass}
				role='button'
				{...props}>
				{value}
			</a>
		</span>
	);
};
export default ButtonLink;
