import React from "react";

const ButtonLink = ({id, href, value, cssClass, onClick, ...props}) => {
	return (
		<a
			href={href}
			id={id}
			onClick={onClick}
			className={cssClass}
			role='button'
			{...props}>
			{value}
		</a>
	);
};
export default ButtonLink;
