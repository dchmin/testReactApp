import React from "react";
import {Modal} from "react-bootstrap";
import PageNavBtns from "../PageNavBtn";
import TermsAgreeCheck from "../../beneficiary/TermsAgreeCheck";
import {modalStartEnd} from "../../commons/dBeneContent";
function ModalWidget(props) {
	const {
		displayModal,
		srOnlyCloseBtn,
		modalTitle,
		modalBtns,
		modalBody,
		modalId,
	} = props;
	const lnkBtnClk = () => props.modalLnkBtnClk();
	const ylwBtnClk = () => props.modalYlwBtnClk();
	const handleClose = () => props.handleClose();
	let start =
			document.getElementsByTagName("HTML")[0].lang == "en" ||
			document.getElementsByTagName("HTML")[0].lang == "en-CA"
				? modalStartEnd.start_en
				: modalStartEnd.start_fr,
		end =
			document.getElementsByTagName("HTML")[0].lang == "en" ||
			document.getElementsByTagName("HTML")[0].lang == "en-CA"
				? modalStartEnd.end_en
				: modalStartEnd.end_fr;
	return (
		<Modal
			show={displayModal}
			onHide={handleClose}
			id={modalId}
			role='dialog'
			className='slf-modal'
			tabIndex='-1'
			dialogClassName='slf-yellow-modal'
			aria-labelledby={`${modalId}-modal-title`}
			backdrop='static'
			aria-modal={true}
			// container={document.getElementById("modal-container")}
		>
			<span className='sr-only'>{start}</span>
			<Modal.Header>
				<div className='modal-main-header'>
					<Modal.Title
						id={`${modalId}-modal-title`}
						className='h3'
						dangerouslySetInnerHTML={{
							__html: modalTitle,
						}}
					/>
					<button
						type='button'
						className='close'
						data-dismiss='modal'
						aria-label={srOnlyCloseBtn}
						onClick={handleClose}>
						<span className='fa fa-times' aria-hidden='true' />
					</button>
				</div>
			</Modal.Header>

			<Modal.Body>
				<>
					<div
						dangerouslySetInnerHTML={{
							__html: modalBody,
						}}></div>
					{props.modalType === "confirmation" && (
						<TermsAgreeCheck
							confirmCheckVal={props.confirmCheckVal}
							modalSubmit={props.modalSubmit}
						/>
					)}
				</>
			</Modal.Body>
			<Modal.Footer>
				{Object.keys(modalBtns).map(
					function (key, index, size) {
						if (modalBtns[key].text !== "") {
							return (
								<PageNavBtns
									key={key}
									index={index}
									size={size}
									btnDetails={modalBtns[key]}
									cssClassName={key}
									customClass={`page-nav-mar`}
									// btnId={this.props.btnId}
									ylwBtnClk={ylwBtnClk}
									// prevClk={prevClk}
									lnkBtnClk={lnkBtnClk}
									origin='modal'
								/>
							);
						}
					}.bind(this)
				)}
			</Modal.Footer>
			<span className='sr-only'>{end}</span>
		</Modal>
	);
}

export default ModalWidget;
