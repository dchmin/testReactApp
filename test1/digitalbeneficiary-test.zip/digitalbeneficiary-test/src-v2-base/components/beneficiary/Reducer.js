import React from "react";

const initialState = {
	pageFlow: "",
	displayMode: "view",
	data: "",
	primaryBeneList: [],
	inputData: ""
};

const StateContext = React.createContext();
const DispatchContext = React.createContext();

function beneficiaryReducer(state, action) {
	switch (action.type) {
		case "UPDATE_DATA": {
			return {...state, data: action.data};
			// return state;
		}

		case "UPDATE_BENELIST": {
			return {...state, primaryBeneList: action.primaryBeneList};
		}

		case "UPDATE_UI": {
			return {
				...state,
				pageFlow: action.pageFlow,
				displayMode: action.displayMode
			};
			// return state;
		}
	}
}

export {initialState, beneficiaryReducer, StateContext, DispatchContext};
