import React, {useState, useContext, useEffect, useRef} from "react";
import {StateContext} from "./Reducer";
import {Field} from "react-final-form";
import {getFormInstances, getInputData, checkSession} from "../../helpers";
import {appContent} from "../../digital-beneficiary-entry";
import InfoButton from "../commons/InfoButton";
import ModalWidget from "../commons/modal/ModalWidget";
//****************PURPOSE OF THIS FILE: CONTAINS ALL FIELD COMPONENTS OF REACT-FINAL-FORMS****************//
let modalType = "",
	modalTitle = "",
	modalBody = "",
	modalBtns = "",
	irrevocableFieldName = "",
	lang = document.getElementsByTagName("HTML")[0].lang;
// THIS COMPONENT TAKES VALUE AND CONDITION AND DISPLAYS OTHER FORM FIELDS -- (STARTS)
const Condition = React.memo(
	({when, checkType, is, children}) => {
		return (
			// WHY math.floor? Eg, values are 4.01/4.02 and so on..rounding it to 4 and grouping to display
			<Field name={when} subscription={{value: true}}>
				{({input: {value}}) =>
					is.includes(
						checkType === "string"
							? value
							: Math.floor(Number(value))
					)
						? children
						: null
				}
			</Field>
		);
	},
	(prevProps, nextProps) => {
		// console.log({prevProps, nextProps});
		return prevProps === nextProps;
	}
);
// THIS COMPONENT TAKES VALUE AND CONDITION AND DISPLAYS OTHER FORM FIELDS -- (STARTS)
const FormFields = React.memo(
	(props) => {
		let totalAllocIsHundred = props.totalAlloc, //RETURNS BOOLEAN VALUE IF SUM IS 100
			editContent = appContent.edit,
			editModal = appContent.edit.modal,
			editError = appContent.errors,
			relationshipList = appContent.edit.relationshipDropdownList,
			dobBunch = {
				dob: false,
				mob: false,
				yob: false,
				yobInputLength: false,
			},
			formName = props.formName;
		// -----------MODAL HANDLING ---------------- (STARTS)
		const getModalBodyData = (modalType) => {
			modalTitle = editModal[modalType].modalTitle;
			modalBody = editModal[modalType].modalBody;
			modalBtns = editModal[modalType].modalBtns;
		};
		const handleClose = () => {
			//this logic to move to close button of modal
			if (modalType === "irrevocableCheckbox")
				getFormInstances()[props.formName].mutators.setValue(
					irrevocableFieldName,
					[]
				);
			// window.setFormValue(irrevocableFieldName, []);
			modalType = "";
			modalTitle = "";
			modalBtns = "";
			modalBody = "";
			setModalShow(false);
		};
		const handleShow = (modlType, ind) => {
			modalType = modlType;
			getModalBodyData(modlType);
			setModalShow(true);
		};
		// -----------MODAL HANDLING ---------------- (ENDS)
		const {index, beneCount, submitClick} = props;
		const [show, setModalShow] = useState(false);
		const state = useContext(StateContext);
		const {data} = state;
		const [radioSelectionError, setRadioSelectionError] = React.useState(
			false
		); //TO HANDLE ERROR
		const [submitFailed, setSubmitFailed] = React.useState(false); //TO HANDLE ERROR
		const [dobError, setDOBError] = React.useState(false); //DOB HANDLING
		// const [qcRevocable, setQCRevocable] = React.useState(null);
		// const [dobReq, setDOBReq] = React.useState(dobBunch);
		let name =
			props.name === undefined ? "initialFieldArray[0]" : props.name;
		function ylwBtnClk() {
			if (
				[
					"allocation",
					"dob",
					"irrevocable",
					"revocable",
					"beneDesignation",
					"trustee",
					"contingentInfo",
				].indexOf(modalType) >= 0
			) {
				handleClose();
			}
			if (
				[
					"irrevocableCheckbox",
					"irrevocableRadio",
					"revocableRadio",
				].indexOf(modalType) >= 0
			) {
				getFormInstances()[props.formName].mutators.setValue(
					irrevocableFieldName,
					modalType === "irrevocableCheckbox"
						? ["irrevocable"]
						: modalType === "irrevocableRadio"
						? "irrevocable"
						: "revocable"
				);
				// window.setFormValue(irrevocableFieldName, ["irrevocable"]);
				modalType = "";
				modalBody = "";
				setModalShow(false);
				setModalShow(false);
			}
			if (modalType === "remove") {
				window.setFormValue("allocation", 0);
				props.remove(index, props.formName);
				setModalShow(false);
			}
		}

		//----------------------- LIMIT KEYBOARD ENTRY --- STARTS
		const checkEntry = (e) => {
			let val = e.target.value;
			let includeDecimalLimit = 3;
			//NO ADDITIONAL ERROR MESSAGES WILL BE PROVIDED, HENCE ADDING MULTIPLE INPUT BOX LOGIC
			val = val.replace(/[^0-9.]+/, "");
			if (val.split(".").length > 2) val = val.replace(/\.+$/, "");
			val =
				val.indexOf(".") >= 0
					? (val.substr(0, val.indexOf(".")).length > 3
							? val.substr(0, 3)
							: val.substr(0, val.indexOf("."))) +
					  val.substr(val.indexOf("."), includeDecimalLimit) //BLOCKING INPUT OF MORE THAN 2 DECIMAL PLACES
					: val.length > 3
					? val.substr(0, 3)
					: val;
			e.target.value = val;
		};
		// FRENCH ENTRY FIELD HAS DIFFERENT REQUIREMENT IN RD - PICKING UP LATE
		const checkFrenchEntry = (e) => {
			let val = e.target.value,
				regexWithComma = /^\d*\,?\d*$/,
				includeDecimalLimit = 3;
			if (!regexWithComma.test(val)) {
				e.target.value = val.substr(0, val.length - 1);
			} else {
				val = val.replace(/[^0-9,]+/, "");
				if (val.split(",").length > 2) val = val.replace(/\,+$/, "");
				val =
					val.indexOf(",") >= 0
						? (val.substr(0, val.indexOf(",")).length > 3
								? val.substr(0, 3)
								: val.substr(0, val.indexOf(","))) +
						  val.substr(val.indexOf(","), includeDecimalLimit) //BLOCKING INPUT OF MORE THAN 2 DECIMAL PLACES
						: val.length > 3
						? val.substr(0, 3)
						: val;
				e.target.value = val;
			}
		};
		//RD - ADD 00 IF NO DECIMALS ADDED --- STARTS (SHOULD HAVE USED format FROM FINAL FORM BUT WAS UNAWARE)
		const appendZeroesEn = (e) => {
			let val = e.target.value;
			if (val !== "" && val !== undefined) {
				e.target.value =
					val.indexOf(".") >= 0
						? val.substr(val.indexOf(",")).length === 1
							? Number(val).toFixed(2)
							: val
						: Number(val).toFixed(2);
				getFormInstances()[props.formName].mutators.setValue(
					`${name}.allocation`,
					e.target.value
				);
			}
		};
		//HANDLED IN A WRONG WAY BUT TIME LIMITATION
		const appendZeroesFr = (e) => {
			let val = e.target.value;
			if (val !== "" && val !== undefined) {
				e.target.value =
					val.indexOf(",") >= 0
						? val.substr(val.indexOf(",")).length === 1
							? val + "00"
							: val.substr(val.indexOf(",")).length === 2
							? val + "0"
							: val
						: val + ",00";
				getFormInstances()[props.formName].mutators.setValue(
					`${name}.allocation`,
					e.target.value
				);
			}
		};
		//RD - ADD 00 IF NO DECIMALS ADDED --- ENDS
		const checkAlphabetEntry = (e) => {
			let charCode = typeof e.which == "undefined" ? e.keyCode : e.which,
				nameRegex = /[a-zA-Z\x7f-\xff .^~�\-�'` ]/i;
			//CHARCODE INDEXOF CONDITION ADDED FOR DEFECT - 117 (2nd PART)
			if (
				!nameRegex.test(String.fromCharCode(charCode)) ||
				[215, 247, 163, 165].indexOf(charCode) >= 0
			) {
				e.preventDefault();
				return false;
			}
		};
		let androidCheck = /(android)/i.test(navigator.userAgent);
		const androidWorkAround = (e) => {
			e.preventDefault();
			let val = e.target.value;
			let charCode = val.charCodeAt(val.length - 1),
				nameRegex = /[a-zA-Z\x7f-\xff .^~�\-�'` ]/i,
				lastChar = String.fromCharCode(charCode);
			//CHARCODE INDEXOF CONDITION ADDED FOR DEFECT - 117 (2nd PART)
			if (
				!nameRegex.test(lastChar) ||
				[215, 247, 163, 165].indexOf(charCode) >= 0
			)
				val = val.replace(lastChar, "");
			e.target.value = val;
		};
		const limitEntry = (e, limit, type) => {
			let val = e.target.value;
			e.target.value = val.length > limit ? val.substr(0, limit) : val;
		};
		//----------------------- LIMIT KEYBOARD ENTRY --- ENDS

		//----------------------- VALIDATION RULES FOR FIELDS TIED TO FINAL FORM  --- STARTS
		const required = (value) => (value ? undefined : editError.mandatory);
		const allocRequired = (value) =>
			value ? undefined : editError.allocation;
		const yobEntered = (value) => {
			if (value) dobBunch.yob = true;
			else dobBunch.yob = false;
			if (value && value.length === 4) dobBunch.yobInputLength = true;
			else dobBunch.yobInputLength = false;
			return undefined;
		};
		const mobEntered = (value) => {
			if (value) dobBunch.mob = true;
			else dobBunch.mob = false;
			return undefined;
		};
		const dobEntered = (value) => {
			if (value) dobBunch.dob = true;
			else dobBunch.dob = false;
			return undefined;
		};
		const dobCheck = () => {
			if (
				submitClick &&
				(Object.keys(dobBunch).every((k) => dobBunch[k]) ||
					Object.keys(dobBunch).every((k) => !dobBunch[k]))
			) {
				setDOBError(false);
				return undefined;
			} else {
				// console.log(dobBunch);
				setDOBError(true);
				return editError.mandatory;
			}
		};
		// checkDOBBunch() ? undefined : editError.mandatory;
		const mustBeNumber = (value) =>
			isNaN(value) ? "Must be a number" : undefined;
		const maxValue = (value) =>
			isNaN(value) || value > 100 ? editError.allocation : undefined;
		// FRENCH ENTRY FIELD HAS DIFFERENT REQUIREMENT IN RD - PICKING UP LATE
		const maxFrenchVal = (value) => {
			let numericVal = 0;
			if (value.indexOf(",") > -1)
				numericVal = Number(
					value.substr(0, value.indexOf(",")) +
						"." +
						value.substr(value.indexOf(",") + 1)
				);
			else numericVal = Number(value);
			return numericVal > 100 ? editError.allocation : undefined;
		};
		const totalAllocCheck = (value) => {
			if (!totalAllocIsHundred) {
				return editError.allocation;
			} else return undefined;
		};
		const radioSelection = (value) => {
			if (value !== undefined) {
				setRadioSelectionError(false);
				return undefined;
			} else {
				setRadioSelectionError(true);
				return editError.mandatory;
			}
		};
		const relCheck = (value) =>
			[0, 404].indexOf(Number(value)) >= 0
				? editError.mandatory
				: undefined;
		const composeValidators = (...validators) => (value) =>
			validators.reduce(
				(error, validator) => error || validator(value),
				undefined
			);
		const addBeneHeader = useRef();
		useEffect(() => {
			// console.log(getInputData());
			if (addBeneHeader.current !== undefined && getInputData() === null)
				addBeneHeader.current.focus();
		}, []);
		//----------------------- VALIDATION RULES FOR FIELDS TIED TO FINAL FORM  --- ENDS
		return (
			<div key={index}>
				<div
					key={index}
					className={`bene-field-array ${
						index === "no_ind" ||
						(props.deleteFirstField && index === 0)
							? ""
							: "mar-top-25"
					}`}>
					{index === "no_ind" ? (
						props.formName === "contingencyFlow" ? (
							<p>{editContent.contingentDisclaimer}</p>
						) : (
							<div className='mar-bottom-15'>
								<h4>
									{editContent.benefitHead}
									<InfoButton
										modalType='beneDesignation'
										openModal={handleShow}
										srLabel={editContent.designationSrLabel}
									/>
								</h4>
								<p>{editContent.addBeneDesc}</p>
							</div>
						)
					) : props.deleteFirstField && index === 0 ? (
						props.formName === "contingencyFlow" ? (
							<p>{editContent.contingentDisclaimer}</p>
						) : (
							// ADDITIONAL LOGIC - QUICK FIX - DEFECT #52
							<div className='mar-bottom-15'>
								<h4>
									{editContent.benefitHead}
									<InfoButton
										modalType='beneDesignation'
										openModal={handleShow}
										srLabel={editContent.designationSrLabel}
									/>
								</h4>
								<p>{editContent.addBeneDesc}</p>
							</div>
						)
					) : (
						<h4 ref={addBeneHeader} tabIndex='0'>
							{props.formName === "contingencyFlow"
								? editContent.additionContBene
								: editContent.additionalBene}
						</h4>
					)}
					<div className='row'>
						{/* R E L A T I O N S H I P ------- B L O C K */}
						<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
							<Field
								name={`${name}.relationship`}
								validate={
									submitClick
										? composeValidators(required, relCheck)
										: null
								}
								// className='form-control'
								component='select'>
								{({input, meta}) => (
									<div className='form-group'>
										<label
											htmlFor={`${formName}-${name}-relationship`}>
											{editContent.relationship}
										</label>
										<div className='select-arrow-wrapper'>
											<select
												{...input}
												className={`form-control ${
													meta.submitFailed &&
													meta.invalid
														? "parsley-error"
														: ""
												}`}
												id={`${formName}-${name}-relationship`}
												// value={beneficiary.relationship || ""}
												// aria-labelledby={
												// 	meta.submitFailed &&
												// 	meta.invalid
												// 		? `${formName}-${name}-relationship-error`
												// 		: null
												// }
												aria-required='true'>
												<option value='0'>
													{editContent.select}
												</option>
												{/* {lang === "en" ||
												lang === "en-CA" ? (
													<option value='0'>
														Select
													</option>
												) : (
													<option value='0'></option>
												)} */}
												{relationshipList.map(
													(each, i) => (
														<option
															key={i}
															data-index={
																each.value
															}
															value={each.value}
															disabled={
																each.value ===
																"404"
																	? true
																	: null
															}>
															{each.label}
														</option>
													)
												)}
											</select>
										</div>
										{/* <pre>{JSON.stringify(meta)}</pre> */}
										{meta.submitFailed && meta.invalid && (
											<ul
												id={`${formName}-${name}-relationship-error`}
												className='parsley-errors-list filled'>
												<li className='parsley-type'>
													{meta.error}
												</li>
											</ul>
										)}
									</div>
								)}
							</Field>
						</div>
						{/* R E L A T I O N S H I P ------- B L O C K */}

						{/* A L L O C A T I O N ------- B L O C K */}
						<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
							<Field
								name={`${name}.allocation`}
								validate={
									submitClick
										? composeValidators(
												allocRequired,
												// mustBeNumber,
												lang === "en" ||
													lang === "en-CA"
													? maxValue
													: maxFrenchVal,
												totalAllocCheck
										  )
										: null
								}>
								{({input, meta}) => {
									if (meta.submitFailed)
										setSubmitFailed(true);
									return (
										<div className='form-group input-group'>
											<label
												htmlFor={`${formName}-${name}-allocation`}>
												{editContent.allocation}
												<InfoButton
													modalType='allocation'
													openModal={handleShow}
													srLabel={
														editContent.allocInfoLabel
													}
												/>
											</label>
											<div>
												<input
													{...input}
													type={`${
														lang === "en" ||
														lang === "en-CA"
															? "number"
															: "text"
													}`}
													placeholder={
														editContent.allocPlaceHolder
													}
													className={`form-control ${
														meta.submitFailed &&
														meta.invalid
															? "parsley-error"
															: ""
													}`}
													onInput={
														lang === "en" ||
														lang === "en-CA"
															? checkEntry
															: checkFrenchEntry
													}
													onBlur={
														lang === "en" ||
														lang === "en-CA"
															? appendZeroesEn
															: appendZeroesFr
													}
													id={`${formName}-${name}-allocation`}
													name='allocation'
													aria-required='true'
													aria-labelledby={
														meta.submitFailed &&
														meta.invalid
															? `${formName}-${name}-allocation-error`
															: null
													}
												/>
												<label className='input-group-addon slf-blue radio-label'>
													%
												</label>
											</div>
											{meta.submitFailed && meta.invalid && (
												<ul
													id={`${formName}-${name}-allocation-error`}
													className='parsley-errors-list filled'>
													<li className='parsley-type'>
														{meta.error}
													</li>
												</ul>
											)}
										</div>
									);
								}}
							</Field>
						</div>
						{/* A L L O C A T I O N ------- B L O C K */}
					</div>

					{/* DYNAMIC FIELDS START */}
					<Condition
						when={`${name}.relationship`}
						checkType='number'
						is={[0, 404, 3, 4, 5]}>
						<div className='row'>
							{/* F I R S T N A M E ------- B L O C K */}
							<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
								<Field
									name={`${name}.firstName`}
									validate={submitClick ? required : null}>
									{({input, meta}) => (
										<div className='form-group'>
											<label
												htmlFor={`${formName}-${name}.firstName`}>
												{editContent.firstName}
											</label>
											<input
												{...input}
												type='text'
												onKeyPress={(ev) =>
													checkAlphabetEntry(ev)
												}
												onInput={(e) => {
													androidCheck
														? androidWorkAround(e)
														: null;
													limitEntry(
														e,
														40,
														"string",
														androidCheck
													);
												}}
												className={`form-control ${
													meta.submitFailed &&
													meta.invalid
														? "parsley-error"
														: ""
												}`}
												id={`${formName}-${name}.firstName`}
												aria-required='true'
												// aria-labelledby={
												// 	meta.submitFailed &&
												// 	meta.invalid
												// 		? `${formName}-${name}.firstName-error`
												// 		: null
												// }
											/>
											{meta.submitFailed && meta.invalid && (
												<ul
													id={`${formName}-${name}.firstName-error`}
													className='parsley-errors-list filled'>
													<li className='parsley-type'>
														{meta.error}
													</li>
												</ul>
											)}
										</div>
									)}
								</Field>
							</div>
							{/* F I R S T N A M E ------- B L O C K */}

							{/* L A S T N A M E ------- B L O C K */}
							<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
								<Field
									name={`${name}.lastName`}
									validate={submitClick ? required : null}>
									{({input, meta}) => (
										<div className='form-group'>
											<label
												htmlFor={`${formName}-${name}.lastName`}>
												{editContent.lastName}
											</label>
											<input
												{...input}
												type='text'
												className={`form-control ${
													meta.submitFailed &&
													meta.invalid
														? "parsley-error"
														: ""
												}`}
												onKeyPress={(ev) =>
													checkAlphabetEntry(ev)
												}
												onInput={(e) => {
													androidCheck
														? androidWorkAround(e)
														: null;
													limitEntry(e, 40, "string");
												}}
												id={`${formName}-${name}.lastName`}
												aria-required='true'
												// aria-labelledby={
												// 	meta.submitFailed &&
												// 	meta.invalid
												// 		? `${formName}-${name}.lastName-error`
												// 		: null
												// }
											/>
											{meta.submitFailed && meta.invalid && (
												<ul
													id={`${formName}-${name}.lastName-error`}
													className='parsley-errors-list filled'>
													<li className='parsley-type'>
														{meta.error}
													</li>
												</ul>
											)}
										</div>
									)}
								</Field>
							</div>
							{/* L A S T N A M E ------- B L O C K */}
						</div>
					</Condition>
					<Condition
						when={`${name}.relationship`}
						checkType='number'
						is={[4]}>
						<div className='row'>
							{/* M I N O R --- S E L E C T I O N ------- B L O C K */}
							<div className='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
								<fieldset
									id={`${name}_minor_select_${
										props.beneId !== undefined
											? props.beneId
											: "contFlow"
									}`}
									className={`mar-bottom-10  ${
										submitFailed && radioSelectionError
											? "parsley-error"
											: ""
									}`}>
									<legend className='no-mar-bottom center-block'>
										<p>
											{editContent.under18}{" "}
											{/* <InfoButton
											modalType='trustee'
											openModal={handleShow}
											srLabel={
												editContent.under18InfoLabel
											}
										/> */}
										</p>
									</legend>
									<Field
										name={`${name}.minorSelection`}
										validate={
											submitClick ? radioSelection : null
										}
										component='input'
										type='radio'
										value='yes'
										className='custom-control-input'
										id={`${formName}-${name}_under_18_${props.beneId}`}
									/>
									<label
										className='custom-control-label'
										htmlFor={`${formName}-${name}_under_18_${props.beneId}`}>
										{editContent.minorYesRadio}
									</label>
									<Field
										name={`${name}.minorSelection`}
										validate={
											submitClick ? radioSelection : null
										}
										component='input'
										type='radio'
										value='no'
										className='custom-control-input'
										id={`${formName}-${name}_not_under_18_${props.beneId}`}
										onClick={(e) => {
											let formInst = getFormInstances()[
												props.formName
											].mutators;
											formInst.setValue(
												`${name}.trusteeFirstName`,
												""
											);
											formInst.setValue(
												`${name}.trusteeLastName`,
												""
											);
											formInst.setValue(
												`${name}.trusteeRel`,
												""
											);
										}}
									/>
									<label
										className='custom-control-label'
										htmlFor={`${formName}-${name}_not_under_18_${props.beneId}`}>
										{editContent.minorNoRadio}
									</label>
								</fieldset>
								{submitFailed && radioSelectionError && (
									<ul className='parsley-errors-list filled'>
										<li className='parsley-type'>
											{editError.mandatory}
										</li>
									</ul>
								)}
							</div>
							{/* M I N O R --- S E L E C T I O N ------- B L O C K */}
						</div>
					</Condition>
					<Condition
						when={`${name}.relationship`}
						checkType='number'
						is={[2]}>
						<div className='row'>
							{/* O R G A N I Z A T I O N -- N A M E ------- B L O C K */}
							<div className='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
								<Field
									name={`${name}.orgName`}
									validate={submitClick ? required : null}>
									{({input, meta}) => (
										<div className='form-group'>
											<label
												htmlFor={`${formName}-${name}-orgName`}>
												{editContent.orgName}
											</label>
											<input
												{...input}
												type='text'
												className={`form-control ${
													meta.submitFailed &&
													meta.invalid
														? "parsley-error"
														: ""
												}`}
												onInput={(e) =>
													limitEntry(e, 100, "string")
												}
												id={`${formName}-${name}-orgName`}
												aria-required='true'
												// aria-labelledby={
												// 	meta.submitFailed &&
												// 	meta.invalid
												// 		? `${formName}-${name}-orgName-error`
												// 		: null
												// }
											/>
											{meta.submitFailed && meta.invalid && (
												<ul
													id={`${formName}-${name}-orgName-error`}
													className='parsley-errors-list filled'>
													<li className='parsley-type'>
														{meta.error}
													</li>
												</ul>
											)}
										</div>
									)}
								</Field>
							</div>
							{/* O R G A N I Z A T I O N -- N A M E ------- B L O C K */}

							{/* O R G A N I Z A T I O N -- A D D R E S S ------- B L O C K */}
							<div className='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
								<Field name={`${name}.orgAddress`}>
									{({input, meta}) => (
										<div className='form-group'>
											<label
												htmlFor={`${formName}-${name}-orgAddress`}>
												{editContent.orgAddress}
											</label>
											<input
												{...input}
												type='text'
												className='form-control'
												onInput={(e) =>
													limitEntry(e, 300, "string")
												}
												id={`${formName}-${name}-orgAddress`}
											/>
										</div>
									)}
								</Field>
							</div>
							{/* O R G A N I Z A T I O N -- A D D R E S S ------- B L O C K */}
						</div>
					</Condition>
					<div className='row mar-bottom-20'>
						<div
							// Defect 29
							className={`${
								lang === "en" || lang === "en-CA"
									? "col-lg-6 col-md-6 col-sm-8"
									: "col-lg-8 col-md-8 col-sm-9"
							}  col-xs-12`}>
							<div className='row'>
								<Condition
									when={`${name}.relationship`}
									checkType='number'
									is={[0, 404, 3, 4, 5]}>
									{/* I R R E V O C A B L E -- S T A T U S ------- B L O C K */}
									<div
										className={`${
											lang === "en" || lang === "en-CA"
												? "col-lg-6 col-md-6 col-sm-6"
												: "col-lg-5 col-md-5 col-sm-5"
										}  col-xs-12`}>
										{/* <label
									// htmlFor={`${formName}-${name}-irrevocableStatus`}
									>
										{editContent.revocableStatus}
									</label> */}
										{data.member.quebec ? (
											<>
												<Condition
													when={`${name}.relationship`}
													checkType='number'
													is={[3]}>
													<fieldset
														id={`${formName}-${name}_quebec_irrevocable_${
															props.beneId !==
															undefined
																? props.beneId
																: "contFlow"
														}-radio`}
														className={`mar-bottom-10  ${
															submitFailed &&
															radioSelectionError
																? "parsley-error"
																: ""
														}`}>
														<legend className='mar-bottom-10'>
															{
																editContent.revocableStatus
															}
														</legend>
														{/* SPAN added due to iOS defect #77 */}
														<span name='revocable-status-quebec'>
															<Field
																name={`${name}.irrevocableStatus`}
																validate={
																	submitClick
																		? radioSelection
																		: null
																}
																component='input'
																type='radio'
																value='revocable'
																className='custom-control-input'
																id={`${formName}-${name}_revocable_${props.beneId}`}
																// onChange={() => {
																// 	irrevocableFieldName = `${name}.irrevocableStatus`;
																// 	handleShow(
																// 		"revocableRadio"
																// 	);
																// }}
															/>
															<label
																className='custom-control-label mar-bottom-10 revocable-radio'
																htmlFor={`${formName}-${name}_revocable_${props.beneId}`}>
																{
																	editContent.revocable
																}
															</label>
															<InfoButton
																modalType='revocable'
																openModal={
																	handleShow
																}
																srLabel={
																	editContent.revocableInfoLabel
																}
															/>
														</span>
														<span name='revocable-status-quebec'>
															<Field
																name={`${name}.irrevocableStatus`}
																validate={
																	submitClick
																		? radioSelection
																		: null
																}
																component='input'
																type='radio'
																value='irrevocable'
																className='custom-control-input'
																id={`${formName}-${name}_irrevocable_${props.beneId}`}
																onChange={(
																	e
																) => {
																	e.preventDefault();
																	irrevocableFieldName = `${name}.irrevocableStatus`;
																	handleShow(
																		"irrevocableRadio"
																	);
																}}
															/>
															<label
																className='custom-control-label revocable-radio'
																htmlFor={`${formName}-${name}_irrevocable_${props.beneId}`}>
																{
																	editContent.irrevocable
																}
															</label>
															<InfoButton
																modalType='irrevocable'
																openModal={
																	handleShow
																}
																srLabel={
																	editContent.irrevocableInfoLabel
																}
															/>
														</span>
													</fieldset>
													{submitFailed &&
														radioSelectionError && (
															<ul className='parsley-errors-list filled'>
																<li className='parsley-type'>
																	{
																		editError.mandatory
																	}
																</li>
															</ul>
														)}
												</Condition>
												<Condition
													when={`${name}.relationship`}
													checkType='number'
													is={[0, 404, 4, 5]}>
													<fieldset
														id={`${formName}-${name}-irrevocableStatus_${props.beneId}-chk`}>
														<legend className='mar-bottom-10'>
															{
																editContent.revocableStatus
															}
														</legend>
														<Field
															name={`${name}.irrevocableStatus`}
															component='input'
															type='checkbox'
															value='irrevocable'
															id={`${formName}-${name}-irrevocableStatus_${props.beneId}`}
															onChange={(e) => {
																irrevocableFieldName = `${name}.irrevocableStatus`;
																if (
																	e.target
																		.checked ===
																	true
																) {
																	handleShow(
																		"irrevocableCheckbox"
																	);
																} else {
																	getFormInstances()[
																		props
																			.formName
																	].mutators.setValue(
																		irrevocableFieldName,
																		[]
																	);
																}
															}}
														/>
														<label
															htmlFor={`${formName}-${name}-irrevocableStatus_${props.beneId}`}>
															{
																editContent.irrevocable
															}
															<InfoButton
																modalType='irrevocable'
																openModal={
																	handleShow
																}
																srLabel={
																	editContent.irrevocableInfoLabel
																}
															/>
														</label>
													</fieldset>
												</Condition>
											</>
										) : (
											<>
												<fieldset
													id={`${formName}-${name}-irrevocableStatus_${props.beneId}-chk`}>
													<legend className='mar-bottom-10'>
														{
															editContent.revocableStatus
														}
													</legend>
													<Field
														name={`${name}.irrevocableStatus`}
														component='input'
														type='checkbox'
														value='irrevocable'
														id={`${formName}-${name}-irrevocableStatus_${props.beneId}`}
														onChange={(e) => {
															irrevocableFieldName = `${name}.irrevocableStatus`;
															if (
																e.target
																	.checked ===
																true
															) {
																handleShow(
																	"irrevocableCheckbox"
																);
															} else {
																getFormInstances()[
																	props
																		.formName
																].mutators.setValue(
																	irrevocableFieldName,
																	[]
																);
															}
														}}
													/>
													<label
														htmlFor={`${formName}-${name}-irrevocableStatus_${props.beneId}`}>
														{
															editContent.irrevocable
														}
														<InfoButton
															modalType='irrevocable'
															openModal={
																handleShow
															}
															srLabel={
																editContent.irrevocableInfoLabel
															}
														/>
													</label>
												</fieldset>
											</>
										)}
									</div>
									{/* I R R E V O C A B L E -- S T A T U S ------- B L O C K */}

									{/* D A T E -- O F -- B I R T H ------- B L O C K */}
									<div
										className={`${
											lang === "en" || lang === "en-CA"
												? " col-sm-6"
												: "col-sm-7"
										} col-lg-6 col-md-6 col-xs-9 dob-col`}>
										<label
											htmlFor={`${formName}-${name}-yob`}>
											{editContent.dob}
											<InfoButton
												modalType='dob'
												openModal={handleShow}
												srLabel={
													editContent.dobInfoLabel
												}
											/>
										</label>
										<div className='row dob-row'>
											<div className='col-xs-4 col-0-pad'>
												<Field
													name={`${name}.yob`}
													validate={
														yobEntered
														// submitClick
														// 	? yobEntered
														// 	: null
													}>
													{({input, meta}) => (
														<>
															<div
																className={`form-group display-inline`}>
																<input
																	{...input}
																	onInput={(
																		e
																	) =>
																		limitEntry(
																			e,
																			4,
																			"yob"
																		)
																	}
																	placeholder={
																		editContent.yobPlaceHolder
																	}
																	aria-label={
																		editContent.dob
																	}
																	id={`${formName}-${name}-yob`}
																	type='number'
																	className={`dob form-control ${
																		submitFailed &&
																		dobError
																			? "parsley-error"
																			: ""
																	}`}
																	aria-labelledby={
																		meta.submitFailed &&
																		meta.invalid
																			? `${formName}-${name}-yob-error`
																			: null
																	}
																/>
															</div>
														</>
													)}
												</Field>
											</div>
											<div className='col-xs-3 mob-col col-0-pad'>
												<Field
													name={`${name}.mob`}
													validate={
														mobEntered
														// submitClick
														// 	? mobEntered
														// 	: null
													}>
													{({input, meta}) => (
														<div
															className={`form-group display-inline`}>
															<input
																{...input}
																onInput={(e) =>
																	limitEntry(
																		e,
																		2,
																		"mob"
																	)
																}
																placeholder={
																	editContent.mobPlaceHolder
																}
																aria-label={
																	editContent.dob
																}
																id={`${formName}-${name}-mob`}
																type='number'
																className={`dob form-control ${
																	submitFailed &&
																	dobError
																		? "parsley-error"
																		: ""
																}`}
															/>
														</div>
													)}
												</Field>
											</div>
											<div className='col-xs-3 col-0-pad'>
												<Field
													name={`${name}.dob`}
													validate={
														composeValidators(
															dobEntered,
															dobCheck
														)
														// submitClick
														// 	? dobEntered
														// 	: null
													}>
													{({input, meta}) => (
														<div
															className={`form-group display-inline`}>
															<input
																{...input}
																onInput={(e) =>
																	limitEntry(
																		e,
																		2,
																		"dob"
																	)
																}
																placeholder={
																	editContent.dobPlaceHolder
																}
																maxLength='2'
																id={`${formName}-${name}-dob`}
																type='number'
																className={`dob form-control ${
																	submitFailed &&
																	dobError
																		? "parsley-error"
																		: ""
																}`}
																aria-label={
																	editContent.dob
																}
															/>
														</div>
													)}
												</Field>
											</div>
										</div>
										{submitFailed && dobError && (
											<ul
												id={`${formName}-${name}-yob-error`}
												className='parsley-errors-list filled'>
												<li className='parsley-type'>
													{editError.mandatory}
												</li>
											</ul>
										)}
									</div>
									{/* D A T E -- O F -- B I R T H ------- B L O C K */}
									{/* <span onClick={() => props.remove(index)}>Remove</span> */}
								</Condition>
							</div>
						</div>
						{(beneCount > 1 ||
							props.formName === "contingencyFlow") && (
							// <div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
							<button
								type='button'
								id={`${formName}_${name}_remove_${props.index}`}
								aria-label={editContent.removeBene}
								className='btn btn-link text-burgundy remove-bene'
								onClick={() => {
									checkSession(data.context);
									handleShow("remove");
								}}>
								<i className='fa fa-trash mar-right-5'></i>
								{editContent.removeBene}
							</button>
							// </div>
						)}
					</div>
					<Condition
						when={`${name}.relationship`}
						checkType='number'
						is={[4]}>
						<Condition
							when={`${name}.minorSelection`}
							checkType='string'
							is={["yes"]}>
							{!data.member.quebec ? (
								<div id='trustee-sec' className='mar-bottom-20'>
									<div className='mar-bottom-15'>
										<h4>
											{editContent.trusteeHeader}
											<InfoButton
												modalType='trustee'
												openModal={handleShow}
												srLabel={
													editContent.under18InfoLabel
												}
											/>
										</h4>
									</div>
									<div className='row'>
										<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
											<Field
												name={`${name}.trusteeFirstName`}
												validate={
													submitClick
														? required
														: null
												}>
												{({input, meta}) => (
													<div className='form-group'>
														<label
															htmlFor={`${formName}-${name}.trusteeFirstName`}>
															{
																editContent.trusteeFName
															}
														</label>
														<input
															{...input}
															type='text'
															onKeyPress={(ev) =>
																checkAlphabetEntry(
																	ev
																)
															}
															onInput={(e) => {
																androidCheck
																	? androidWorkAround(
																			e
																	  )
																	: null;
																limitEntry(
																	e,
																	40,
																	"string"
																);
															}}
															id={`${formName}-${name}.trusteeFirstName`}
															className={`form-control ${
																meta.submitFailed &&
																meta.invalid
																	? "parsley-error"
																	: ""
															}`}
															aria-required='true'
															// aria-labelledby={
															// 	meta.submitFailed &&
															// 	meta.invalid
															// 		? `${formName}-${name}.trusteeFirstName-error`
															// 		: null
															// }
														/>
														{meta.submitFailed &&
															meta.invalid && (
																<ul
																	id={`${formName}-${name}.trusteeFirstName-error`}
																	className='parsley-errors-list filled'>
																	<li className='parsley-type'>
																		{
																			meta.error
																		}
																	</li>
																</ul>
															)}
													</div>
												)}
											</Field>
										</div>
										<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
											<Field
												name={`${name}.trusteeLastName`}
												validate={
													submitClick
														? required
														: null
												}>
												{({input, meta}) => (
													<div className='form-group'>
														<label
															htmlFor={`${formName}-${name}-trusteeLastName`}>
															{
																editContent.trusteeLName
															}
														</label>
														<input
															{...input}
															type='text'
															onKeyPress={(ev) =>
																checkAlphabetEntry(
																	ev
																)
															}
															id={`${formName}-${name}-trusteeLastName`}
															onInput={(e) => {
																androidCheck
																	? androidWorkAround(
																			e
																	  )
																	: null;
																limitEntry(
																	e,
																	40,
																	"string"
																);
															}}
															className={`form-control ${
																meta.submitFailed &&
																meta.invalid
																	? "parsley-error"
																	: ""
															}`}
															aria-required='true'
															// aria-labelledby={
															// 	meta.submitFailed &&
															// 	meta.invalid
															// 		? `${formName}-${name}-trusteeLastName-error`
															// 		: null
															// }
														/>
														{meta.submitFailed &&
															meta.invalid && (
																<ul
																	id={`${formName}-${name}-trusteeLastName-error`}
																	className='parsley-errors-list filled'>
																	<li className='parsley-type'>
																		{
																			meta.error
																		}
																	</li>
																</ul>
															)}
													</div>
												)}
											</Field>
										</div>
									</div>
									<div className='row'>
										<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
											<Field
												name={`${name}.trusteeRel`}
												validate={
													submitClick
														? required
														: null
												}>
												{({input, meta}) => (
													<div className='form-group'>
														<label
															htmlFor={`${formName}-${name}-trusteeRel`}>
															{
																editContent.relnToMinor
															}
														</label>
														<input
															{...input}
															type='text'
															onKeyPress={(ev) =>
																checkAlphabetEntry(
																	ev
																)
															}
															id={`${formName}-${name}-trusteeRel`}
															onInput={(e) => {
																androidCheck
																	? androidWorkAround(
																			e
																	  )
																	: null;
																limitEntry(
																	e,
																	50,
																	"string"
																);
															}}
															className={`form-control ${
																meta.submitFailed &&
																meta.invalid
																	? "parsley-error"
																	: ""
															}`}
															aria-required='true'
															// aria-labelledby={
															// 	meta.submitFailed &&
															// 	meta.invalid
															// 		? `${formName}-${name}-trusteeRel-error`
															// 		: null
															// }
														/>
														{meta.submitFailed &&
															meta.invalid && (
																<ul
																	id={`${formName}-${name}-trusteeRel-error`}
																	className='parsley-errors-list filled'>
																	<li className='parsley-type'>
																		{
																			meta.error
																		}
																	</li>
																</ul>
															)}
													</div>
												)}
											</Field>
										</div>
									</div>
								</div>
							) : (
								<p>{editContent.minorQuebec}</p>
							)}
						</Condition>
					</Condition>
					{/* // )} */}
				</div>
				<ModalWidget
					displayModal={show}
					modalTitle={modalTitle}
					modalBody={modalBody}
					modalBtns={modalBtns}
					srOnlyCloseBtn='Close'
					handleClose={handleClose}
					modalId='bene-form-fields-modal'
					modalLnkBtnClk={handleClose}
					modalYlwBtnClk={ylwBtnClk}
				/>
			</div>
		);
	},
	(prevProps, nextProps) => {
		// console.log({prevProps, nextProps});
		return prevProps === nextProps;
	}
);
export default FormFields;
