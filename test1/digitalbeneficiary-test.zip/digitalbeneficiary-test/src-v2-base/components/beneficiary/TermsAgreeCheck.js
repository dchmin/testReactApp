import React, {useState, useEffect} from "react";
import {appContent} from "../../digital-beneficiary-entry";
//PURPOSE OF THIS FILE: TO DISPLAY T&C AGREE CHECKBOX AND ERROR
function TermsAgreeCheck(props) {
	let agreeText = appContent.edit.tcAccept,
		errorMsg = appContent.errors.mandatory;
	const [confirmCheck, setConfirmCheck] = useState(false);
	const [removeError, setRemoveError] = useState(null); //NEW FLAG FOR DEFECT #58
	//DEFECT #58 (PART 1 SOLUTION - TESTERS WANT IT THIS WAY)
	useEffect(() => {
		if (props.modalSubmit) {
			setRemoveError(confirmCheck);
		} else props.confirmCheckVal(confirmCheck);
	}, [props.modalSubmit, removeError, confirmCheck]);
	return (
		<>
			<div
				className={
					confirmCheck === false && removeError === false
						? "parsley-error"
						: ""
				}>
				<input
					type='checkbox'
					id='bene-i-agree-checkbox'
					checked={confirmCheck}
					onChange={(e) => {
						setConfirmCheck(e.target.checked);
						props.confirmCheckVal(e.target.checked);
					}}
				/>
				<label htmlFor='bene-i-agree-checkbox' className='mar-top-10'>
					{agreeText}
				</label>
			</div>
			{confirmCheck === false && removeError === false && (
				<ul className='parsley-errors-list filled'>
					<li className='parsley-type'>{errorMsg}</li>
				</ul>
			)}
		</>
	);
}
export default TermsAgreeCheck;
