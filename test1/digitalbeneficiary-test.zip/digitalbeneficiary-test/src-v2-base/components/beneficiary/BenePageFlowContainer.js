import React, {useContext} from "react";
import {StateContext} from "./Reducer";
import BeneSummaryPage from "./BeneSummaryPage";
import BeneDesignationPage from "./BeneDesignationPage";
import BeneEditPage from "./BeneEditPage";
//****************PURPOSE OF THIS FILE: DETERMINES WHICH PARENT PAGE NEED TO BE LOADED****************//
function BenePageFlowContainer() {
	const state = useContext(StateContext);
	const {displayMode, pageFlow} = state;
	if (displayMode === "view" && pageFlow === "") {
		//TO DISPLAY SUMMARY AND CONFIRMATION PAGE
		document.title = "Beneficiary Summary page";
		return <BeneSummaryPage />;
	} else if (displayMode === "view" && pageFlow === "pageFlowOptions") {
		//TO DISPLAY DESIGNATION SELECTION PAGE
		document.title = "Beneficiary designation page";
		return <BeneDesignationPage />;
	} else if (
		displayMode === "edit" &&
		(pageFlow === "allBenefits" || pageFlow === "byBenefits")
	) {
		//TO DISPLAY EDIT PAGE FOR BY AND ALL BENEFIT FLOWS
		document.title = "Edit Beneficiary page";
		return <BeneEditPage pageFlow={pageFlow} />;
	} else {
		return <></>;
	}
}
export default BenePageFlowContainer;
