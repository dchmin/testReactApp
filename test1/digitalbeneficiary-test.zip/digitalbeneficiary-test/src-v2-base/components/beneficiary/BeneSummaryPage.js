import React, {useContext, useState, useEffect} from "react";
import {DispatchContext, StateContext} from "./Reducer";
import ButtonLink from "../commons/ButtonLink";
import {appContent} from "../../digital-beneficiary-entry";
import NotepadText from "./NotepadText";
import InfoButton from "../commons/InfoButton";
import ModalWidget from "../commons/modal/ModalWidget";
import {uTagCall, checkSession} from "../../helpers";
import "../../scss/view-form.scss";
let modalType = "",
	modalTitle = "",
	modalBody = "",
	modalBtns = "";
//****************PURPOSE OF THIS FILE: PARENT TO DISPLAY SUMMARY PAGE AND "CONFIRMATION PAGE" AS WELL****************//
const BeneSummaryPage = (props) => {
	const dispatch = useContext(DispatchContext);
	const state = useContext(StateContext);
	const [show, setModalShow] = useState(false); //STATE TO CONTROL HIDE AND SHOW OF MODAL
	const {data} = state;
	let summaryModal = appContent.summary.modal;
	const benefitList = data !== "" ? data.member.benefitList : "",
		notepadData =
			data !== ""
				? data.member.notepadDetails.notepadData === undefined
					? ""
					: data.member.notepadDetails.notepadData
				: "";
	let summaryCont = appContent.summary;
	const showFlowOptions = (event) => {
		event.preventDefault();
		delete data.success;
		dispatch({type: "UPDATE_DATA", data: data});
		dispatch({
			type: "UPDATE_UI",
			pageFlow: "pageFlowOptions",
			displayMode: "view",
		});
	};
	// -----------MODAL HANDLING ---------------- (STARTS)
	const handleClose = () => {
		modalType = "";
		modalTitle = "";
		modalBtns = "";
		modalBody = "";
		setModalShow(false);
	};
	const getModalBodyData = (modalType) => {
		modalTitle = summaryModal[modalType].modalTitle;
		modalBody = summaryModal[modalType].modalBody;
		modalBtns = summaryModal[modalType].modalBtns;
	};
	const handleShow = (modlType) => {
		modalType = modlType;
		getModalBodyData(modlType);
		setModalShow(true);
	};
	const checkUserType = (event) => {
		checkSession(data.context);
		if (data.irrevocable || data.sponsorShadow) {
			if (data.sponsorShadow) handleShow("sponsorShadowGBA");
			else if (
				data.irrevocable &&
				!data.sponsorShadow &&
				["TRUE_IA", "ADMIN_PLUS", "GBA"].indexOf(
					data.member.adminType
				) >= 0
			)
				handleShow(data.member.adminType);
			else handleShow("irrevocable");
		} else showFlowOptions(event);
	};
	// -----------MODAL HANDLING ---------------- (ENDS)
	useEffect(() => {
		uTagCall(
			window.location.href +
				(data.success
					? "/beneficiary+confirmation/"
					: "/beneficiary+summary/")
		);
		window.scrollTo({top: 0, behavior: "smooth"});
	}, []);
	if (data == "") {
		return null;
	} else {
		if (data.success) {
			document.title = "Confirmation page";
			window.scrollTo({top: 0, behavior: "smooth"});
			//CR - RELOAD THE PARENT PAGE
			try {
				reloadParentPage();
			} catch (err) {
				// console.log(err);
			}
		}
		return (
			<>
				{/* BENEFICIARY DESIGNATION */}
				<div className='row mar-bottom-20'>
					{data.success === undefined && (
						<div className='col-xs-12'>
							<h2>
								<span>{summaryCont.designationHead}</span>
								{/* CHANGES AS PER iOS defect #80 - probable fix*/}
								<InfoButton
									modalType='beneDesignation'
									openModal={handleShow}
									srLabel={summaryCont.designationSrLabel}
								/>
							</h2>
							<p
								dangerouslySetInnerHTML={{
									__html: summaryCont.designationCont,
								}}></p>
						</div>
					)}
					{data.success && (
						<div className='col-xs-12' role='alert'>
							<h2>{summaryCont.successHeader}</h2>
							<span>{`${data.member.mFirstName} ${data.member.mLastName} (${summaryCont.memberId}: ${data.member.certificateNum}) `}</span>
							<span>{summaryCont.successDesc}</span>
						</div>
					)}
				</div>
				<div className='view-form'>
					<div className='row'>
						<div className='col-xs-12 mar-bottom-10 mar-top-10'>
							<span>
								<h2 className='inline-block-element'>
									{summaryCont.summaryHead}
								</h2>
							</span>
							<ButtonLink
								cssClass='btn btn-blue edit-btn inline-block-element ele-mob-full-stretch'
								href='#'
								value={summaryCont.editBtn}
								onClick={checkUserType}
							/>
						</div>
					</div>
					<p>{summaryCont.summaryDesc}</p>
					<div className='row'>
						<div className='col-xs-12'>
							<div className='bene-card mar-bottom-20'>
								<div className='bene-card-item'>
									<h3>{summaryCont.benefitHead}</h3>
									<ul>
										{benefitList.map((benefit, index) => {
											return (
												<li key={index}>
													{benefit.benefitName}{" "}
													&#8212;{" "}
													<span
														dangerouslySetInnerHTML={{
															__html:
																benefit.clientBeneId,
														}}></span>{" "}
													{benefit.hasOCB && (
														<span>
															&#8212;{" "}
															{
																summaryCont.disclaimer
															}
														</span>
													)}
												</li>
											);
										})}
									</ul>
								</div>
								<div className='bene-card-item pad-bottom-20 border-top-grey'>
									<h3>{summaryCont.currentBenefitHead}</h3>
									{notepadData === "" ||
									notepadData === null ? (
										<span>
											<i className='fa fa-exclamation-circle mar-right-5'></i>{" "}
											{summaryCont.noBeneficiary}
										</span>
									) : (
										<NotepadText
											notepadData={notepadData}
										/>
									)}
								</div>
							</div>
						</div>
						{data.success && (
							<div className='col-xs-12'>
								<h2>{summaryCont.successTermsHeader}</h2>
								<p>{summaryCont.successTermsAgreed}</p>
								<p
									dangerouslySetInnerHTML={{
										__html: summaryCont.successTerms,
									}}></p>
							</div>
						)}
					</div>
				</div>
				<ModalWidget
					displayModal={show}
					modalType={modalType}
					modalTitle={modalTitle}
					modalBody={modalBody}
					modalBtns={modalBtns}
					srOnlyCloseBtn='Close'
					handleClose={handleClose}
					modalId='bene-summary-modal'
					modalLnkBtnClk={handleClose}
					modalYlwBtnClk={handleClose}
				/>
			</>
		);
	}
};
export default BeneSummaryPage;
