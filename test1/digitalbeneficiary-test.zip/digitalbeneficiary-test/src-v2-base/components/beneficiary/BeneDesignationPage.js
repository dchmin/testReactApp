import React, {useContext, useState, useEffect, useRef} from "react";
import {DispatchContext, StateContext} from "./Reducer";
import PageNavBtns from "../commons/PageNavBtn";
import {appContent} from "../../digital-beneficiary-entry";
import NotepadAccordion from "./NotepadAccordion";
import ModalWidget from "../commons/modal/ModalWidget";
import {
	setDesignationSelect,
	getDesignationSelect,
	setInputData,
	getInputData,
	setFormInstances,
	setContingencyCheck,
	uTagCall,
	checkSession,
} from "../../helpers";
//****************PURPOSE OF THIS FILE: PARENT TO DISPLAY DESIGNATION SELECTION PAGE****************//

// SET MODAL TYPE AND MODAL BODY SO THAT ONE INSTANCE OF MODAL CAN BE REUSED - (STARTS)
let modalType = "",
	modalTitle = "",
	modalBody = "",
	modalBtns = "",
	newSelection = "";
// SET MODAL TYPE AND MODAL BODY SO THAT ONE INSTANCE OF MODAL CAN BE REUSED - (ENDS)
function BeneDesignationPage() {
	let designationContent = appContent.designation,
		designationModals = designationContent.modal,
		designationErrors = appContent.errors;
	const [selectionType, setSelectionType] = React.useState(null),
		[showError, setShowError] = React.useState(false),
		[show, setModalShow] = useState(false),
		handleClose = () => setModalShow(false),
		dispatch = useContext(DispatchContext),
		state = useContext(StateContext),
		{data} = state;
	let context = data.context;
	// -----------MODAL HANDLING ---------------- (STARTS)
	const getModalBodyData = (modalType) => {
		modalTitle = designationModals[modalType].modalTitle;
		modalBody = designationModals[modalType].modalBody;
		modalBtns = designationModals[modalType].modalBtns;
	};
	const handleShow = (type) => {
		modalType = type;
		getModalBodyData(type);
		setModalShow(true);
	};
	const nextClk = () => {
		checkSession(context);
		if (selectionType !== null) {
			setShowError(false);
			dispatch({
				type: "UPDATE_UI",
				pageFlow: selectionType,
				displayMode: "edit",
			});
		} else setShowError(true);
	};
	const prevClk = () => {
		checkSession(context);
		dispatch({
			type: "UPDATE_UI",
			pageFlow: "",
			displayMode: "view",
		});
		handleClose();
	};
	const modalYellowClick = () => {
		setInputData(null);
		setFormInstances(null);
		handleClose();
		if (modalType === "loseData") {
			setDesignationSelect(newSelection);
			setSelectionType(newSelection);
			setInputData(null);
			setFormInstances(null);
			setContingencyCheck(null);
		}
		if (modalType === "cancel") {
			setDesignationSelect(null);
			setInputData(null);
			setFormInstances(null);
			setContingencyCheck(null);
			prevClk();
		}
	};
	// -----------MODAL HANDLING ---------------- (ENDS)

	// -----------WHEN RADIO BUTTON SELECTION IS CHANGED ---------------- (STARTS)
	const checkRadioChange = (val) => {
		let preselectedRadio = getDesignationSelect();
		if (
			preselectedRadio !== null &&
			getInputData() !== null &&
			preselectedRadio !== val
		) {
			newSelection = val;
			handleShow("loseData");
		} else {
			setShowError(false);
			setDesignationSelect(val);
			setSelectionType(val);
		}
	};
	// -----------WHEN RADIO BUTTON SELECTION IS CHANGED ---------------- (ENDS)
	//USE REF TO FOCUS ON THE HEADER WHEN THE PAGE IS NAVIGATED -- ELSE JAWS IS NOT READING FROM TOP OF THE PAGE
	const radioHeader = useRef();
	useEffect(() => {
		let preselectedRadio = getDesignationSelect();
		if (preselectedRadio !== null) setSelectionType(preselectedRadio);
		uTagCall(window.location.href + "/beneficiary+designation/");
		if (
			(data.member.notepadDetails.notepadData === "" ||
				data.member.notepadDetails.notepadData === undefined) &&
			radioHeader.current !== undefined
		)
			radioHeader.current.focus();
	}, []);
	return (
		<div id='bene-designation-sec' className='mar-bottom-40 col-xs-12'>
			<NotepadAccordion
				notepadData={data !== "" ? data.member.notepadDetails : ""}
				page='type-select'
			/>
			<div className='row radioOptions'>
				<fieldset
					id='bene-type-select'
					className={`mar-bottom-10 ${
						showError ? "parsley-error" : ""
					}`}>
					<legend className='mar-bottom-10 center-block'>
						<h2 ref={radioHeader} tabIndex='0'>
							{designationContent.chooseHead}
						</h2>
					</legend>
					<input
						type='radio'
						name='radioCheck'
						value='allBenefits'
						className='radioCheck'
						id='allBenefits'
						checked={selectionType === "allBenefits"}
						aria-checked={
							selectionType === "allBenefits" ? "true" : "false"
						}
						onChange={() => {
							checkRadioChange("allBenefits");
						}}
					/>
					<label
						htmlFor='allBenefits'
						className='radio-label mar-bottom-20'>
						{designationContent.allBeneLbl}
						<p>{designationContent.allBeneDesc}</p>
					</label>
					<input
						type='radio'
						name='radioCheck'
						value='byBenefits'
						className='radioCheck'
						id='byBenefits'
						checked={selectionType === "byBenefits"}
						aria-checked={
							selectionType === "byBenefits" ? "true" : "false"
						}
						onChange={() => {
							checkRadioChange("byBenefits");
						}}
					/>
					<label htmlFor='byBenefits' className='radio-label'>
						{designationContent.byBeneLbl}
						<p>{designationContent.byBeneDesc}</p>
					</label>
					{showError && (
						<ul role='alert' className='parsley-errors-list filled'>
							<li className='parsley-type'>
								{designationErrors.mandatory}
							</li>
						</ul>
					)}
				</fieldset>
				<hr className='soft-separator'></hr>
				<div className='btn-centered-container mar-top-10'>
					{Object.keys(designationContent.pageNavBtns).map(
						function (key, index, size) {
							if (
								designationContent.pageNavBtns[key].text !== ""
							) {
								return (
									<PageNavBtns
										key={key}
										index={index}
										size={size}
										btnDetails={
											designationContent.pageNavBtns[key]
										}
										cssClassName={key}
										customClass={`page-nav-mar`}
										// btnId={this.props.btnId}
										ylwBtnClk={nextClk}
										transBtnClk={prevClk}
										lnkBtnClk={() => {
											checkSession(context);
											handleShow("cancel");
										}}
										origin='page'
									/>
								);
							}
						}.bind(this)
					)}
				</div>
			</div>
			<ModalWidget
				displayModal={show}
				modalTitle={modalTitle}
				modalBody={modalBody}
				modalBtns={modalBtns}
				srOnlyCloseBtn='Close'
				handleClose={handleClose}
				modalId='bene-type-select-modal'
				modalLnkBtnClk={handleClose}
				modalYlwBtnClk={modalYellowClick}
			/>
		</div>
	);
}
export default BeneDesignationPage;
