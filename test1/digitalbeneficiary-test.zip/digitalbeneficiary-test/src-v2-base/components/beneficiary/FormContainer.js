import React, {useState, useContext, useEffect} from "react";
import {StateContext, DispatchContext} from "./Reducer";
import {Form} from "react-final-form";
import {FieldArray} from "react-final-form-arrays";
import arrayMutators from "final-form-arrays";
import {appContent} from "../../digital-beneficiary-entry";
import LoaderSpinner from "../commons/LoaderSpinner";
import {
	setInputData,
	getInputData,
	setFormInstances,
	getContingencyCheck,
	getValuesAsPerRelation,
	setDesignationSelect,
	setContingencyCheck,
	getCurrentdate,
	getFormInstances,
	checkSession,
} from "../../helpers";
// import ExistingForm from "./ExistingForm"; //THIS IS KEPT IN CASE INITIAL FORM DATA NEEDS TO BE LOADED - MAY NEED FOR GRS
import FormFields from "./FormFields";
import ModalWidget from "../commons/modal/ModalWidget";
import AddButton from "../commons/AddButton";
import axios from "axios";
import {
	saveMbrportalUrl,
	saveGBME2Url,
	saveGBMEUrl,
	errorUrl,
	timeoutUrl,
} from "../commons/dBeneContent";
//****************PURPOSE OF THIS FILE: PARENT TO REACT-FINAL-FORMS****************//
// SET MODAL TYPE AND MODAL BODY SO THAT ONE INSTANCE OF MODAL CAN BE REUSED - (STARTS)
let modalType = "",
	modalTitle = "",
	modalBody = "",
	modalBtns = "",
	lang = document.getElementsByTagName("HTML")[0].lang;
// SET MODAL TYPE AND MODAL BODY SO THAT ONE INSTANCE OF MODAL CAN BE REUSED - (ENDS)

// KEEPING ALL INSTANCES OF FORMS SO THAT THEY CAN BE VALIDATED TOGETHER - (STARTS)
let forms = {};
const setForm = (formName) => (form) => {
	forms[formName] = form;
	setFormInstances(forms);
};
// KEEPING ALL INSTANCES OF FORMS SO THAT THEY CAN BE VALIDATED TOGETHER - (ENDS)
let allFormData = [];

function FormContainer(props) {
	let editContent = appContent.edit,
		successContent = appContent.summary,
		notepadContent = appContent.notepad,
		submitClick = {props};
	const dispatch = useContext(DispatchContext), //TO NAVIGATE TO OTHER PAGE
		[show, setModalShow] = useState(false), //STATE TO CONTROL HIDE AND SHOW OF MODAL
		[confirmCheck, setConfirmCheck] = useState(false), //STATE TO CONTROL HIDE AND SHOW OF MODAL
		[modalSubmit, setModalSubmit] = useState(false),
		[showLoader, setShowLoader] = useState(false),
		[totalAllocationVal, setTotalAllocationVal] = React.useState(false), //TOTAL ALLOCATION
		[deleteFirstField, setDeleteFirstField] = useState(false), //THE FIRST FIELD IS DONE SEPARATELY BECAUSE INITIAL APPROACH WAS TAKEN TO LOAD WITH EXISTING DATA
		[deleteFirstFielfOfForm, setDeleteFirstFielfOfForm] = useState(""),
		[firstTime, setFirstTime] = useState(false);

	let [beneCount, setBeneCount] = useState(1); //SET THE BENEFICIARY COUNT TO HIDE AND SHOW "REMOVE" BUTTON
	const state = useContext(StateContext),
		{data} = state,
		benefitList = data !== "" ? data.member.benefitList : "";
	let storedVal = getInputData();
	let context = data.context;
	const handleClose = () => {
		if (modalType === "confirmation") {
			checkSession(context);
			setModalSubmit(false);
		}
		setModalShow(false);
	}; //CLOSE MODAL
	// if (storedVal !== null) console.log("OUT HERE", storedVal);
	const callbackIAgree = (val) => setConfirmCheck(val);
	const getModalBodyData = (modalType) => {
		let editModal = editContent.modal;
		// if (typeof modalType !== "string") modalType = "summary";
		modalTitle = editModal[modalType].modalTitle;
		modalBody = editModal[modalType].modalBody;
		modalBtns = editModal[modalType].modalBtns;
	};
	//SET SHOW MODAL STATE - (STARTS)
	const handleShow = (typeOfModal) => {
		if (typeOfModal === "mousedown" || typeof typeOfModal !== "string")
			typeOfModal = "cancel";
		if (typeOfModal === "cancel") checkSession(context);
		modalType = typeOfModal;
		getModalBodyData(typeOfModal); //DELEGATING FUNCTION
		setModalShow(true);
	};
	//SET SHOW MODAL STATE - (ENDS)

	// EACH FORM VALIDATION - STARTS
	const formArrayValidate = (values) => {};
	// EACH FORM VALIDATION - ENDS

	//DEFECT 57
	if (getFormInstances() === null) forms = {};

	const onSubmit = (values) => {};
	const handleSubmitAllForms = (callNum) => {
		checkSession(context);
		let arrayToCheckValidForms = [],
			errorCount = 0;
		//SUBMITTING EACH FORM TO GET THEIR STATE
		Object.keys(forms).map((form, index) => {
			let formInstance = forms[form];
			formInstance.submit();
			let formState = formInstance.getState();

			//IF FORM IS INVALID, ADD ERROR COUNTS
			// console.log(formState);
			if (!formState.valid) {
				Object.keys(formState.errors).map((eachBene, index) => {
					let eachBeneError = formState.errors[eachBene];
					Object.values(eachBeneError).map((eachBeneIndex, i) => {
						errorCount =
							errorCount +
							(eachBeneIndex !== undefined &&
								Object.keys(eachBeneIndex).length);
					});
				});
				arrayToCheckValidForms.push(formState.valid); //CHECKING IF EACH FORM IS VALID
			}
			// else {
			// 	//IF FORM IS VALID, CHECK IF ADDITION IS EQUAL TO 100
			// 	if (displayFormTotalAlloc(formState.values) !== 100) {
			// 		arrayToCheckValidForms.push(false); //CHECKING IF EACH FORM IS VALID
			// 	} else {
			// 		arrayToCheckValidForms.push(true); //CHECKING IF EACH FORM IS VALID
			// 	}
			// }
		});
		if (arrayToCheckValidForms.includes(false)) {
			//NO MODAL AND NO API CALL
			// SEND CALL BACK TO SET ERROR COUNT
			props.errorCount(errorCount);
		} else {
			if (callNum === 1) setFirstTime(true);
			else {
				// console.log(callNum, arrayToCheckValidForms.includes(false));
				props.errorCount(0);
				handleShow("confirmation");
			}
		}
	};
	//NAVIGATE TO RELEVANT PAGE WHEN CONFIRMED ON MODAL - (STARTS)
	const navigatePage = (navType) => {
		dispatch({
			type: "UPDATE_UI",
			pageFlow: navType === "summary" ? "" : "pageFlowOptions",
			displayMode: "view",
		});
	};
	//NAVIGATE TO RELEVANT PAGE WHEN CONFIRMED ON MODAL - (ENDS)
	const createPostData = () => {
		let notepadData = editContent.effective + getCurrentdate() + " </br>";
		let relationshipList = editContent.relationshipDropdownList;
		if (props.pageFlow === "byBenefits") delete forms.allFlow;
		if(!getContingencyCheck()) delete forms.contingencyFlow; //destroy contingent bene form if box unchecked
		Object.keys(forms).map((form, index) => {
			let eachFormValue = forms[form].getState().values;
			// if (props.pageFlow === "allBenefits") {
			if (props.pageFlow === "allBenefits") {
				notepadData +=
					form === "contingencyFlow"
						? notepadContent.contingentAllBene
						: notepadContent.allBene;
			} else {
				notepadData +=
					form === "contingencyFlow"
						? notepadContent.contingentAllBene
						: benefitList[
								Number(form.slice(-1))
						  ].benefitName.toUpperCase() + "</br>";
			}
			Object.keys(eachFormValue).map((type, index) => {
				if (type === "initialFieldArray") {
					let initialVal = eachFormValue[type][0];
					let relation = initialVal.relationship;
					notepadData += getValuesAsPerRelation(
						initialVal,
						relation,
						relationshipList,
						data.member.quebec,
						notepadContent
					);
				}
				if (type === "newFieldArray") {
					let allNewVal = eachFormValue[type];
					Object.keys(allNewVal).map((eachNew, i) => {
						let newVal = allNewVal[eachNew];
						let relation = newVal.relationship;
						notepadData += getValuesAsPerRelation(
							newVal,
							relation,
							relationshipList,
							data.member.quebec,
							notepadContent
						);
					});
				}
			});
			// }
		});
		let urlLogo =
			document.getElementById("TEMPLATE2015_WEBLOGOLEFT") !== null
				? document
						.getElementById("TEMPLATE2015_WEBLOGOLEFT")
						.getElementsByTagName("img")[0].src
				: document.getElementById("brandingleftlogo") !== null
				? document
						.getElementById("brandingleftlogo")
						.getElementsByTagName("img")[0].src
				: "";
		let postData = {
			memberId: data.member.memberId,
			contractNumber: data.contractNumber,
			notepadDetails: {
				notepadId:
					data.member.notepadDetails.notepadId === undefined
						? 0
						: data.member.notepadDetails.notepadId,
				notepadData: notepadData,
			},
			member: data.member,
			pdfDetails: {
				logoURL: urlLogo,
				successHeader: successContent.successHeader,
				successDesc: successContent.successDesc,
				beneSummaryHeader: successContent.summaryHead,
				yourBenefitsHeader: successContent.benefitHead,
				yourBeneficiaryDesignationHeader:
					successContent.currentBenefitHead,
				termsAndConditionHeader: successContent.successTermsHeader,
				successTnC:
					"<p>" +
					successContent.successTermsAgreed +
					"</p>" +
					successContent.successTerms,
				ocbDesc: editContent.disclaimer,
			},
		};
		// delete postData.member.notepadDetails;
		return postData;
	};
	const postBeneDetails = () => {
		setShowLoader(true);
		const postData = createPostData();
		// console.log(
		// 	"%c" + JSON.stringify(postData),
		// 	"background: #222; color: #bada55"
		// );
		let relUrl;
		//LOGIC UPDATED AFTER GB_ME2 INCLUSION - 11 Aug 2020
		if (data.context === "gb_me" || data.context === "GB_ME")
			relUrl = saveGBMEUrl;
		else if (data.context === "gb_me2" || data.context === "GB_ME2")
			relUrl = saveGBME2Url;
		else relUrl = saveMbrportalUrl;
		let url = window.location.origin + relUrl,
			httpClient = axios.create();
		httpClient.defaults.timeout = 30000;
		httpClient
			// .get(url)
			.post(url, postData, {
				headers: {
					"Content-Type": "application/json;charset=utf-8",
				},
			})
			.then(function (response) {
				// console.log(response);
				if (response.status === 200) {
					setShowLoader(false);
					if (typeof response.data === "string")
						window.location.href =
							window.location.origin + timeoutUrl;
					else if (response.data.responseCode === 0) {
						response.data.digitalBeneficiaryResponse.success = true;
						response.data.digitalBeneficiaryResponse.member =
							postData.member;
						response.data.digitalBeneficiaryResponse.member.notepadDetails.notepadData =
							postData.notepadDetails.notepadData;
						setInputData(null);
						setFormInstances(null);
						setDesignationSelect(null);
						setContingencyCheck(null);
						forms = {};
						dispatch({
							type: "UPDATE_DATA",
							data: response.data.digitalBeneficiaryResponse,
						});
						props.serviceFailed(false);
						navigatePage("summary");
					} else {
						//ERROR HANDLING SCENARIO
						handleClose();
						props.serviceFailed(true);
					}
					// window.location.href =
					// 	window.location.origin + errorUrl;
				} else window.location.href = window.location.origin + errorUrl;
			})
			.catch(function (error) {
				// handle error
				//URL FROM dbeneContent.js
				// window.location.href = window.location.origin + errorUrl;
				setShowLoader(false);
				handleClose();
				props.serviceFailed(true);
			});
	};
	//MODAL CONFIRMATION BTN CLICK (MOSTLY YELLOW) - (STARTS)
	const ylwClk = () => {
		if (modalType === "confirmation") {
			checkSession(context);
			setModalSubmit(true);
			if (confirmCheck) {
				if (data.impersonated) {
					alert(editContent.impersonated);
					// handleClose;
					// handleShow("impersonate");
				} else postBeneDetails();
				// SUBMIT
			}
		} else {
			handleClose;
			setInputData(null);
			setFormInstances(null);
			setDesignationSelect(null);
			setContingencyCheck(null);
			forms = {};
			navigatePage("summary");
		}
	};
	//MODAL CONFIRMATION BTN CLICK (MOSTLY YELLOW) - (ENDS)

	//PREVIOUS BUTTON CLICK HANDLING - SETTING STORED VALUE IN HELPER.JS (CONTEXT HAD AN ISSUE WHILE GETTING THE DATA) - (STARTS)
	const collectInputData = () => {
		setInputData(null);
		let formsData = {};
		Object.keys(forms).map((form, index) => {
			let assignVal = {
				[form]: forms[form].getState().values,
			};
			Object.assign(formsData, assignVal);
		});
		allFormData = formsData;
		setInputData(allFormData);
		return true;
	};
	const handlePreviousCall = () => {
		checkSession(context);
		if (collectInputData()) navigatePage("prev");
	};
	//PREVIOUS BUTTON CLICK HANDLING - SETTING STORED VALUE IN HELPER.JS (CONTEXT HAD AN ISSUE WHILE GETTING THE DATA) - (ENDS)

	//CALCULATE THE SUM OF THE ALLOCATION INPUT BOX - (STARTS)
	const checkFrenchAlloc = (alloc) => {
		if (alloc.indexOf(",") > -1) {
			return Number(
				alloc.substr(0, alloc.indexOf(",")) +
					"." +
					alloc.substr(alloc.indexOf(",") + 1)
			);
		} else return Number(alloc);
	};
	const displayFormTotalAlloc = (values) => {
		if (values) {
			let totalAlloc = 0;
			let initialArray =
				values.initialFieldArray === undefined
					? ""
					: values.initialFieldArray;
			let newArray =
				values.newFieldArray === undefined ? "" : values.newFieldArray;
			// FRENCH ENTRY FIELD HAS DIFFERENT REQUIREMENT IN RD - PICKING UP LATE
			if (lang === "en" || lang === "en-CA") {
				if (
					initialArray[0] !== undefined &&
					!isNaN(Number(initialArray[0]["allocation"]))
				)
					totalAlloc = Number(initialArray[0]["allocation"]);
				if (newArray !== "") {
					newArray.map((eachArray, index) => {
						if (eachArray !== undefined) {
							totalAlloc =
								totalAlloc +
								(isNaN(Number(eachArray.allocation))
									? 0
									: Number(eachArray.allocation));
						}
					});
				}
			} else {
				// FRENCH ENTRY FIELD HAS DIFFERENT REQUIREMENT IN RD - PICKING UP LATE
				if (
					initialArray[0] !== undefined &&
					initialArray[0]["allocation"] !== undefined
				) {
					let alloc = initialArray[0]["allocation"];
					totalAlloc =
						totalAlloc +
						(alloc !== undefined ? checkFrenchAlloc(alloc) : 0);
				}
				if (newArray !== "") {
					newArray.map((eachArray, index) => {
						if (eachArray !== undefined) {
							let alloc = eachArray.allocation;
							totalAlloc =
								totalAlloc +
								(alloc !== undefined
									? checkFrenchAlloc(alloc)
									: 0);
						}
					});
				}
			}
			setTotalAllocationVal(Number(totalAlloc.toFixed(2)));
			return Number(totalAlloc.toFixed(2));
		}
	};
	//CALCULATE THE SUM OF THE ALLOCATION INPUT BOX - (ENDS)

	//REMOVE ERRORS RECORDED ON CONTINGENCY FORM AFTER REMOVING CONTINGENCY FORM - (STARTS)
	const removeContingencyError = () => {
		Object.keys(forms).map((form, index) => {
			let formInstance = forms[form];
			let formState = formInstance.getState();
			if (formState.errors.contingencyFlowinitialFieldArray !== undefined)
				delete formState.errors.contingencyFlowinitialFieldArray;
		});
		delete forms.contingencyFlow;
		// collectInputData();
	};
	const handleContingentRemove = () => {
		if (props.formName === "contingencyFlow" && beneCount === 1) {
			removeContingencyError();
			props.removeContingencyCheck();
		}
	};
	//REMOVE ERRORS RECORDED ON CONTINGENCY FORM AFTER REMOVING CONTINGENCY FORM - (ENDS)

	//DEFECT - 52
	const checkInitial = (formName) => {
		let initialArrayDeleted = false;
		// Object.keys(forms).map((form, index) => {
		if (
			getFormInstances() !== null &&
			forms[formName].getState().values.initialFieldArray === undefined
		)
			initialArrayDeleted = true;
		// });
		if (initialArrayDeleted) return 0;
		else return 1;
	};
	useEffect(() => {
		if (
			getContingencyCheck() === false &&
			forms.contingencyFlow !== undefined
		)
			removeContingencyError();
		// ------- ON OLD DATA LOAD, SET BENE COUNT TO HIDE/SHOW "REMOVE" BUTTON --- (STARTS)
		if (storedVal !== null && storedVal[props.formName] !== undefined) {
			let currentForm = storedVal[props.formName];
			let initialArrayCount = checkInitial(props.formName),
				// currentForm.initialFieldArray !== undefined
				// 	? 1
				// 	: checkInitial(),
				newArrayCount =
					currentForm.newFieldArray !== undefined
						? Object.keys(currentForm.newFieldArray).length
						: 0;
			setBeneCount(initialArrayCount + newArrayCount);
		}
		// ------- ON OLD DATA LOAD, SET BENE COUNT TO HIDE/SHOW "REMOVE" BUTTON --- (STARTS)
	}, []);
	return (
		<div className='bene-each-item'>
			<Form
				onSubmit={onSubmit}
				validate={(values) => formArrayValidate(values)}
				initialValues={
					storedVal !== null ? storedVal[props.formName] : ""
				}
				subscription={{
					submitting: true,
					pristine: true,
					values: true,
				}}
				mutators={{
					setValue: ([field, value], state, {changeValue}) => {
						changeValue(state, field, () => value);
					},
					...arrayMutators,
				}}
				setForm={setForm(`${props.formName}`)}
				render={({
					handleSubmit,
					form: {
						mutators: {push, pop},
					}, // injected from final-form-arrays above
					form,
					values,
					errors,
					setForm,
				}) => {
					if (!window.setFormValue)
						window.setFormValue = form.mutators.setValue;
					window.cancel = handleShow;
					window.previous = handlePreviousCall;
					window.startValidate = handleSubmitAllForms;
					setForm(form);
					//DEFECT 52
					if (
						storedVal !== null &&
						storedVal[props.formName] !== undefined &&
						Object.keys(storedVal[props.formName]).length !== 0 &&
						storedVal[props.formName].initialFieldArray ===
							undefined
					) {
						setDeleteFirstField(true);
						setDeleteFirstFielfOfForm(props.formName);
					}
					// console.log(form);
					// console.log(form);
					return (
						<form onSubmit={handleSubmit}>
							{/* <FieldArray
									name='existingBeneficiaries'
									component={ExistingForm} //USE THIS IN CASE INITIAL DATA NEEDS TO BE LOADED
								/> */}
							{deleteFirstField &&
							deleteFirstFielfOfForm === props.formName ? null : (
								<FieldArray
									name='initialFieldArray'
									index='no_ind'
									component={FormFields}
									beneCount={beneCount}
									formName={props.formName}
									totalAlloc={
										totalAllocationVal === 100 ||
										totalAllocationVal === 99.99
											? true
											: false
									}
									remove={(ind, deleteFrom) => {
										delete form.getState().values
											.initialFieldArray; //DEFECT - 63
										// delete form.getState().errors
										// 	.initialFieldArray;
										setBeneCount(beneCount - 1);
										setDeleteFirstField(true);
										setDeleteFirstFielfOfForm(deleteFrom);
										handleContingentRemove();
									}}
									beneId={props.formName}
									submitClick={submitClick}
								/>
							)}
							{/* {!deleteFirstField &&
								deleteFirstFielfOfForm !== props.formName && (
									<FieldArray
										name='initialFieldArray'
										index='no_ind'
										component={FormFields}
										beneCount={beneCount}
										formName={props.formName}
										totalAlloc={
											totalAllocationVal === 100 ||
											totalAllocationVal === 99.99
												? true
												: false
										}
										remove={(ind, deleteFrom) => {
											delete form.getState().values
												.initialFieldArray; //DEFECT - 63
											// delete form.getState().errors
											// 	.initialFieldArray;
											setBeneCount(beneCount - 1);
											setDeleteFirstField(true);
											setDeleteFirstFielfOfForm(
												deleteFrom
											);
											handleContingentRemove();
										}}
										beneId={props.formName}
									/>
								)} */}
							<FieldArray name='newFieldArray'>
								{({fields}) =>
									fields.map((name, index) => {
										return (
											<FormFields
												key={`newFieldArray-${index}-${fields.length}-${props.beneId}`}
												index={index}
												// name={`${name}-${index}`}
												name={name}
												beneCount={beneCount}
												formName={props.formName}
												totalAlloc={
													totalAllocationVal ===
														100 ||
													totalAllocationVal === 99.99
														? true
														: false
												}
												remove={(ind) => {
													fields.remove(ind);
													setBeneCount(beneCount - 1);
													handleContingentRemove();
												}}
												beneId={
													props.beneId !== undefined
														? props.beneId
														: props.formName
												}
												submitClick={submitClick}
												deleteFirstField={
													deleteFirstField
												}
											/>
										);
									})
								}
							</FieldArray>
							<div className='row'>
								<div className='col-lg-6 col-md-6 col-xs-12'>
									<div className='large-body mar-top-10 mar-bottom-20'>
										{editContent.totalAllocationLabel} :{" "}
										<span className='total-alloc'>
											{isNaN(
												displayFormTotalAlloc(values)
											)
												? 0
												: totalAllocationVal === 99.99
												? lang === "en" ||
												  lang === "en-CA"
													? "100.00"
													: "100,00"
												: totalAllocationVal.toLocaleString(
														document.getElementsByTagName(
															"HTML"
														)[0].lang,
														{
															minimumFractionDigits: 2,
															maximumFractionDigits: 2,
														}
												  )}{" "}
											%
										</span>
									</div>
									<button
										type='submit'
										hidden=''
										className='invisible radio-label'
										onClick={(e) =>
											e.preventDefault()
										}></button>
									{beneCount < 15 && (
										<AddButton
											id={`${props.formName}-addBeneBtn`}
											value={editContent.addBtn}
											onClick={(e) => {
												e.preventDefault();
												checkSession(context);
												setBeneCount(beneCount + 1);
												push(
													"newFieldArray",
													undefined
												);
											}}
										/>
									)}
								</div>
							</div>
							{/* <button
									type='button'
									onClick={() => pop("newFieldArray")}>
									Remove Last
								</button> */}

							{/* <div className='buttons'>
									<button
										type='submit'
										disabled={submitting || pristine}>
										Submit
									</button>
									<button
										type='button'
										onClick={form.reset}
										disabled={submitting || pristine}>
										Reset
									</button>
								</div>
								<pre>{JSON.stringify(values, 0, 2)}</pre> */}
							{/* </div> */}
							{/* INVISIBLE BUTTON ADDED FOR SITEIMPROVE */}
						</form>
					);
				}}
			/>
			<ModalWidget
				displayModal={show}
				modalType={modalType}
				modalTitle={modalTitle}
				modalBody={modalBody}
				modalBtns={modalBtns}
				srOnlyCloseBtn='Close'
				handleClose={handleClose}
				modalId='bene-form-container-modal'
				modalLnkBtnClk={handleClose}
				modalYlwBtnClk={ylwClk}
				confirmCheckVal={callbackIAgree}
				modalSubmit={modalSubmit}
			/>
			{showLoader && <LoaderSpinner />}
		</div>
	);
}
export default FormContainer;
