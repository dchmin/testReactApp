import React, {useContext, useState, useCallback} from "react";
import {StateContext} from "./Reducer";
import FormFields from "./FormFields";
//****************PURPOSE OF THIS FILE: CURRENTLY NOT IN USE, MAY NEED FOR GRS****************//
function ExistingForm() {
	const state = useContext(StateContext);
	const {data} = state;
	const [beneficiaryList, setBeneficiaryList] = useState(data.beneficiary);
	//TO FORCE UPDATE VIEW AFTER REMOVE -- STARTS
	const [, updateState] = React.useState();
	const forceUpdate = useCallback(() => updateState({}), []);
	//TO FORCE UPDATE VIEW AFTER REMOVE -- ENDS
	if (beneficiaryList !== undefined) {
		return (
			<>
				{beneficiaryList.map((beneficiary, index) => (
					<div key={index}>
						<FormFields
							beneficiary={beneficiary}
							index={index}
							name={`existinBeneficiaries[${index}]`}
							remove={(ind) => {
								beneficiaryList.splice(ind, 1);
								forceUpdate();
							}}
						/>
					</div>
				))}
			</>
		);
	} else {
		return null;
	}
}
export default ExistingForm;
