import React, {useEffect, useRef} from "react";
import NotepadText from "./NotepadText";
import {appContent} from "../../digital-beneficiary-entry";
//****************PURPOSE OF THIS FILE: THE NOTEPAD ACCORDION HEADER****************//
function NotepadAccordion(props) {
	const notepadTextData = props.notepadData.notepadData;
	//USE REF TO FOCUS ON THE HEADER WHEN THE PAGE IS NAVIGATED -- ELSE JAWS IS NOT READING FROM TOP OF THE PAGE
	const accordionTitle = useRef();
	useEffect(() => {
		if (accordionTitle.current !== undefined)
			accordionTitle.current.focus();
	}, []);
	if (
		notepadTextData === "" ||
		notepadTextData === null ||
		notepadTextData === undefined
	)
		return null;
	else {
		return (
			<div
				className={`${
					props.page === "type-select" ? "row " : ""
				}notepad-designation-container mar-bottom-30`}>
				<h2 ref={accordionTitle} tabIndex='0'>
					{appContent.designation.notepadHead}
				</h2>
				<div className='panel slf-accordion-plus blue'>
					<a
						className='accordion-heading collapsed'
						data-toggle='collapse'
						href='#notepad-designation'
						data-parent='#notepad-designation-container'
						aria-expanded='false'>
						{appContent.designation.notepadAccTitle}
					</a>
					<div
						id='notepad-designation'
						className='collapse'
						aria-expanded='false'>
						<div className='content'>
							<NotepadText
								notepadData={notepadTextData}
								notepadType='accordion'
							/>
						</div>
					</div>
				</div>
			</div>
		);
	}
}
export default NotepadAccordion;
