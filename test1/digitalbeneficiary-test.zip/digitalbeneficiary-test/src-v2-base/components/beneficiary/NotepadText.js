import React from "react";
//PURPOSE OF THIS FILE: TO DISPLAY NOTEPAD TEXT ONLY WHICH COMES FROM OASIS IN SUMMARY, DESIGNATION & EDIT PAGES
function NotepadText(props) {
	return (
		<div
			className={`word-wrap ${
				props.notepadType === "accordion" ? "mar-left-30" : ""
			}`}
			dangerouslySetInnerHTML={{
				__html: props.notepadData,
			}}></div>
	);
}
export default NotepadText;
