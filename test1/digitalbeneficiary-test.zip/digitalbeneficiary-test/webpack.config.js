"use strict";
const path = require("path");
const webpack = require('webpack');
const UglifyJsPlugin = require("uglifyjs-webpack-plugin");
const HtmlWebPackPlugin = require("html-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");

const config = (env) => {
	return {		
	devtool: "hidden-source-map",
	entry: {
		"dbeneficiary": [
			// require.resolve("./src/polyfills.js"),
			"@babel/polyfill",
			"./src/digital-beneficiary-entry.js",
		],
		"dbeneficiary-v2": [
			"@babel/polyfill",
			"./src-v2/digital-beneficiary-entry.js",
		]
	},
	output: {
		path: path.resolve(__dirname, "target/dist"),
		filename: "[name].bundle.js",
	},
	resolve: {
		modules: [path.resolve(__dirname, "src"), "node_modules"],
	},
	mode: "production",
	module: {
		rules: [
			{
				test: /\.(js|jsx)$/,
				exclude: /node_modules/,
				loaders: "babel-loader",
			},
			{
				test: /\.(s?)css$/,
				exclude: /node_modules/,
				use: [MiniCssExtractPlugin.loader, "css-loader", "sass-loader"],
			},
		],
	},
	optimization: {
		//Uglify JavaScript(minification)
		minimizer: [
			new UglifyJsPlugin({
				test: /\.(js|jsx)$/i,
				exclude: /\/node_modules/,
				cache: false,
				extractComments: false,
				parallel: true,
				uglifyOptions: {
					compress: {},
					output: {
						comments: false,
					},
				},
			}),
		],
	},
	plugins: [
		new MiniCssExtractPlugin({
			filename: "[name].css",
		}),
		// new HtmlWebPackPlugin({
		// 	template: __dirname + "/src-v2/index.html",
		// 	filename: "index.html",
		// 	xhtml: true,
		// 	inject: true
		// }),
		new HtmlWebPackPlugin({ //Will run src folder under default localhost:<port>
			xhtml: true,
			inject: true,
			template: __dirname + "/src/index.html",
			filename: "index.html",
			chunks: ["dbeneficiary"]
		}),
		new HtmlWebPackPlugin({ //Runs src-v2 folder under localhost:<port>/dbeneficiary-v2.html"
            inject: true,
			xhtml: true,
			template: __dirname + "/src-v2/index.html",
			filename: "dbeneficiary-v2.html",
			chunks: ["dbeneficiary-v2"]
		}),
		// add the plugin to export env variable to be used in reactJS code
		new webpack.DefinePlugin({ 
			"process.env.development": env ? env.development : false
		})
	],
	devServer: {
		disableHostCheck: true,
		contentBase: "target/dist",
		publicPath: "/",
		compress: true,
		port: 80,
		open: true,
		hot: true,
		inline: true,
		// host: "10.95.128.39",
	}
}};
module.exports = config;
