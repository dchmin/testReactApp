import React, {useReducer} from "react";
import ReactDom from "react-dom";
import BeneficiaryWidget from "./components/beneficiary/BeneficiaryWidget";
import BeneficiaryGRSWidget from "./components/beneficiary/BeneficiaryGRSWidget";
import {
	initialState,
	beneficiaryReducer,
	StateContext,
	DispatchContext,
} from "./components/beneficiary/Reducer";
import "./scss/commons.scss";
import {dBeneContent} from "./components/commons/dBeneContent";
let ES6Promise = require("es6-promise");
ES6Promise.polyfill();

// Content setup
export let appContent =
	document.getElementsByTagName("HTML")[0].lang == "en" ||
	document.getElementsByTagName("HTML")[0].lang == "en-CA"
		? dBeneContent.en
		: dBeneContent.fr;
export const setAppContent = (content) => {
	appContent = {...appContent, ...content};
}
// LOB variable
export const appLob = (typeof(reactLob) !== 'undefined' && reactLob !== "") ? reactLob : "GB";		

function DigitalBeneficiary() {
	const [state, dispatch] = useReducer(beneficiaryReducer, initialState);
		
	return (
		<div className={(appLob === "GRS") ? "": 'mar-top-20 pad-xs-10'}>
			<div className='row content-area content-gap'>
				<DispatchContext.Provider value={dispatch}>
					<StateContext.Provider value={state}>
						{(appLob === "GRS") ? <BeneficiaryGRSWidget /> : <BeneficiaryWidget /> }
					</StateContext.Provider>
				</DispatchContext.Provider>
			</div>
		</div>
	);
}

var mountNode = document.getElementById("reactBody");
ReactDom.render(<DigitalBeneficiary />, mountNode);
