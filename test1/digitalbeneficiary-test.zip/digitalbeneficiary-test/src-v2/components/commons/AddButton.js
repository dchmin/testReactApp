import React from "react";
import "../../scss/commons.scss";

const AddButton = ({id, href, value, onClick, ...props}) => {
	return (
		<button
			id={id}
			onClick={onClick}
			className='btn btn-green btn-xs-full-width'
			{...props}>
			<i className='fa fa-plus-circle mar-right-5' aria-hidden='true'></i>
			{value}
		</button>
	);
};
export default AddButton;
