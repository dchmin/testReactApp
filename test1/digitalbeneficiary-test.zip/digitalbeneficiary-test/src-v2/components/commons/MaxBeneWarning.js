import React from "react";
import {appContent, appLob} from "../../digital-beneficiary-entry";

const MaxBeneWarning = () => {    
    const msg = appContent.edit.maxBeneficiariesWarning;
    
    if (appLob !== "GRS") {
        return null;
    }

    return (
        <div class="field-set-validation-errors slf-yellow-bg" 
            dangerouslySetInnerHTML={{__html: msg}} />
    );
}

export default MaxBeneWarning;