import React, {useContext} from "react";
import {appContent} from "../../digital-beneficiary-entry";
import "../../scss/commons/infoMsgContainer.scss";

	
const InfoMsgContainer = ({id, infoMsg, cssClass, ...props}) => {	
	cssClass = (cssClass && typeof (cssClass) !== "undefined") ? cssClass : "";
	
	if (!infoMsg || (infoMsg && infoMsg === "")) {
	  return null;
	}

	return (
		<div id={id} className={"info-msg-container slf-alert-box slf-slate-blue-bg-10 mar-bottom-10 " + cssClass}>
			<span className={"info-msg-container-icon fa slf-slate-blue-color " + (infoMsg.icon || "fa-info-circle")} aria-hidden="true"></span> 
			<div>
			<span className="sr-only">{infoMsg.srText}</span>
				<div className="messageContent" 
					data-automation-name="messageContent" 
					dangerouslySetInnerHTML={{__html: infoMsg.value}} />
			</div>
		</div> 
	);
}

export default InfoMsgContainer;