import React from "react";

const NameInputField = (props) => {
    const {
        id,
        label,
        onInput, 
        onBlur,
        hasError, 
        input, 
        error,
        maxLength,
        required = true
    } = props;

    return (
        <div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
            <div className='form-group'>
                <label
                    htmlFor={id}>
                    {label}
                </label>
                <input
                    {...input}
                    type='text'
                    maxLength={maxLength}
                    onInput={onInput}
                    onBlur={onBlur}
                    className={`form-control ${
                        hasError
                            ? "parsley-error"
                            : ""
                    }`}
                    id={id}
                    aria-required={required ? 'true' : 'false'}
                    aria-describedby={
                        hasError
                            ? `${id}-error`
                            : null
                        }
                    aria-invalid={hasError}
                />
                {hasError && (
                    <ul
                        id={`${id}-error`}
                        className='parsley-errors-list filled'>
                        <li className='parsley-type'>
                            {error}
                        </li>
                    </ul>
                )}
            </div>
        </div>
    )
}

export default NameInputField;