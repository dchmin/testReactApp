import React from "react";
import {Modal} from "react-bootstrap";
import PageNavBtns from "../PageNavBtn";
import TermsAgreeCheck from "../../beneficiary/TermsAgreeCheck";
import {modalStartEnd} from "../../commons/dBeneContent";

// CREATE CONTAINER FOR MODAL - TRAPS FOCUS IN MODAL FOR ACCESSIBILTY - (STARTS)
const containerId = "modal-container";
const modalContainer = () => {	
	let container = document.getElementById(containerId);
	if (container === null) {
		let modalEle = document.createElement("div");
		modalEle.id = containerId;
		document.getElementById('reactBody').appendChild(modalEle);  
		container = document.getElementById(containerId);
	}
}
modalContainer();
// CREATE CONTAINER FOR MODAL - TRAPS FOCUS IN MODAL FOR ACCESSIBILTY - (ENDS)

function ModalWidget(props) {
	const {
		displayModal,
		srOnlyCloseBtn,
		modalTitle,
		modalBtns,
		modalBody,
		modalId,
		modalStartSrOnlyText,
		modalEndSrOnlyText
	} = props;
	const lnkBtnClk = () => props.modalLnkBtnClk();
	const ylwBtnClk = () => props.modalYlwBtnClk();
	const handleClose = () => props.handleClose();
	let start = (modalStartSrOnlyText) ||
			(document.getElementsByTagName("HTML")[0].lang == "en" ||
			document.getElementsByTagName("HTML")[0].lang == "en-CA"
				? modalStartEnd.start_en
				: modalStartEnd.start_fr),
		end = (modalEndSrOnlyText) || 
			(document.getElementsByTagName("HTML")[0].lang == "en" ||
			document.getElementsByTagName("HTML")[0].lang == "en-CA"
				? modalStartEnd.end_en
				: modalStartEnd.end_fr);
	return (
		<Modal
			show={displayModal}
			onHide={handleClose}
			onShow={props.handleOnShow}
			id={modalId}
			role='dialog'
			className='slf-modal'
			tabIndex='-1'
			dialogClassName='slf-yellow-modal'
			aria-labelledby={`${modalId}-modal-title`}
			backdrop={props.disableBackdropClick ? 'static' : true}
			aria-modal={true}
			container={document.getElementById(containerId)} 
		>
			<span className='sr-only'>{start}</span>
			<Modal.Header>
				<div className='modal-main-header'>
					<Modal.Title
						id={`${modalId}-modal-title`}
						className='h3'
						dangerouslySetInnerHTML={{
							__html: modalTitle,
						}}
					/>
					<button
						type='button'
						className='close'
						data-dismiss='modal'
						aria-label={srOnlyCloseBtn}
						onClick={handleClose}>
						<span className='fa fa-times' aria-hidden='true' />
					</button>
				</div>
			</Modal.Header>

			<Modal.Body>
				<>
					<div
						dangerouslySetInnerHTML={{
							__html: modalBody,
						}}></div>
					{props.modalBodyJsx}
					{props.modalType === "confirmation" && (
						<TermsAgreeCheck
							confirmCheckVal={props.confirmCheckVal}
							modalSubmit={props.modalSubmit}
						/>
					)}
				</>
			</Modal.Body>
			<Modal.Footer>
				{Object.keys(modalBtns).map(
					function (key, index, size) {
						if (modalBtns[key] !== "" && modalBtns[key].text !== "") {
							return (
								<PageNavBtns
									key={key}
									index={index}
									size={size}
									btnDetails={modalBtns[key]}
									cssClassName={key}
									customClass={`page-nav-mar`}
									// btnId={this.props.btnId}
									ylwBtnClk={ylwBtnClk}
									// prevClk={prevClk}
									lnkBtnClk={lnkBtnClk}
									origin='modal'
								/>
							);
						}
					}.bind(this)
				)}
			</Modal.Footer>
			<span className='sr-only'>{end}</span>
		</Modal>
	);
}

export default ModalWidget;
