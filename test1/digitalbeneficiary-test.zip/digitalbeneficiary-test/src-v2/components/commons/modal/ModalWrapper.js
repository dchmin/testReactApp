import React, {useState, useEffect} from "react";
import {appContent} from "../../../digital-beneficiary-entry";
import ModalWidget from "./ModalWidget";

let modalType = "",
modalTitle = "",
modalBody = "",
modalBodyJsx = "",
modalBtns = "",
modalSrCloseBtn = "",
modalStartSrOnlyText="",
modalEndSrOnlyText="";
//PURPOSE OF THIS FILE: GENERIC MODAL WRAPPER
function ModalWrapper(props) {
	let summaryModal = appContent.summary.modal;
	let editModal = appContent.edit.modal;
	
	// -----------MODAL HANDLING ---------------- (STARTS)
	const handleClose = () => {
		modalType = "";
		modalTitle = "";
		modalBtns = "";
		modalBody = "";
		modalBodyJsx = "";
		modalSrCloseBtn = "";
		modalStartSrOnlyText="",
		modalEndSrOnlyText="";
        props.handleClose();
	};
	const getModalBodyData = (modalType) => {
		if (modalType === "irrevocableCheckbox" || modalType === "irrevocableRadio") {
			modalTitle = editModal[modalType].modalTitle;
			modalBody = editModal[modalType].modalBody;
			modalBtns = editModal[modalType].modalBtns;
			modalSrCloseBtn = editModal[modalType].modalCloseText;
			modalStartSrOnlyText = editModal[modalType].modalStartSrOnlyText;
			modalEndSrOnlyText = editModal[modalType].modalEndSrOnlyText;
		}
		else {
			modalTitle = summaryModal[modalType].modalTitle;
			modalBody = summaryModal[modalType].modalBody;
			modalBtns = summaryModal[modalType].modalBtns;
			modalSrCloseBtn = summaryModal[modalType].modalCloseText;
			modalStartSrOnlyText=summaryModal[modalType].modalStartSrOnlyText;
			modalEndSrOnlyText=summaryModal[modalType].modalEndSrOnlyText;
		}
    };
    getModalBodyData(props.modalType);
	// -----------MODAL HANDLING ---------------- (ENDS)
    
	return (
		<>
			<ModalWidget
                //{...props}
				displayModal={props.show}
				modalType={props.modalType}
				modalTitle={modalTitle}
				modalBody={null}
				modalBodyJsx={
					props.modalBodyJsx
				}
				modalBtns={modalBtns}
				srOnlyCloseBtn={modalSrCloseBtn}
				handleClose={handleClose}
                handleOnShow={props.handleOnShow}
				modalId={'beneModal_' + props.modalType}
				modalLnkBtnClk={handleClose}
				modalYlwBtnClk={props.ylwClk}
				modalStartSrOnlyText={modalStartSrOnlyText}
				modalEndSrOnlyText={modalEndSrOnlyText}  
				disableBackdropClick={props.disableBackdropClick}
			/>
		</>
	);
}
export default ModalWrapper;
