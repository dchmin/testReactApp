import React, {useContext} from "react";
	
const ErrorMsgContainer = ({id, msg, cssClass, ...props}) => {	
	cssClass = (cssClass && typeof (cssClass) !== "undefined") ? cssClass : "";
	
	if (!msg || (msg && msg === "")) {
	  return null;
	}

	return (
		<div id={id} className={"slf-alert-box slf-burgundy-bg-10 mar-bottom-10 slf-alert-box-error" + cssClass}>
			<div className="messageContent" 
					data-automation-name="messageContent" 
					dangerouslySetInnerHTML={{__html: msg}} />
		</div> 
	);
}

export default ErrorMsgContainer;