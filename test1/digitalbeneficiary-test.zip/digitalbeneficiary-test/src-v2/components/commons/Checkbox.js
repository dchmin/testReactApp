import React from "react";

//PURPOSE OF THIS FILE: TO DISPLAY CHECKBOX
const CheckBox = (props) => (
    <>
        <input
            {...props}
            type='checkbox'
            label={null}
        />
        <label htmlFor={props.id} className='mar-top-10'>
            {props.label}
        </label>   
    </>
)
export default CheckBox;
