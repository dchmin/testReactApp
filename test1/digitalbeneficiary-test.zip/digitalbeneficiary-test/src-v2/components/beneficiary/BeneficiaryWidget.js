import React, {useContext, useEffect} from "react";
import {DispatchContext} from "./Reducer";
import {setImpersonatedFlag} from "../../helpers";
import BenePageFlowContainer from "./BenePageFlowContainer";

let beneDetails = {
	sponsorName: "MAGNA INTERNATIONAL INC",
	contractNumber: "083901",
	responseCode: 0,
	responseMessage: null,
	member: {
		mFirstName: "Fnamexx",
		mLastName: "Lnameyy",
		memberStatusCode: 1,
		benefitList: [
			{
				memberBenefitId: 441465,
				clientBeneId: "083901",
				benefitName: "Employee Life",
				benefitStatusCode: 1,
				effectiveDate: "2013-09-01T00:00:00",
				volumeAmt: 40000,
				terminatedDate: "2050-05-01T00:00:00",
				hasOCB: false,
				benefitCode: 101,
			},
			{
				memberBenefitId: 441466,
				clientBeneId: "083901",
				benefitName: "Employee Life 22",
				benefitStatusCode: 1,
				effectiveDate: "2013-09-01T00:00:00",
				volumeAmt: 40000,
				terminatedDate: "2050-05-01T00:00:00",
				hasOCB: false,
				benefitCode: 101,
			},
		],
		adminType: "GBA",
		notepadDetails: {
			notepadId: 4931129,
			notepadData:
				"Designation effective: 2020-05-05 </br>DESIGNATION FOR ALL BENEFITS</br>A B, Mother &#8212 100.00%</br>",
		},
		certificateNum: "5552201",
		quebec: true,
		memberId: 117482,
		clientId: "790",
	},
	languageCode: null,
	showGbBeneficiaryFlag: true,
	allBenefitFlag: false,
	apologyMessage: null,
	hasWidgetAccess: true,
	irrevocable: false,
	context: "PPHP",
	impersonated: false,
	onApology: false,
	sponsorShadow: false,
};
function BeneficiaryWidget() {
	const dispatch = useContext(DispatchContext);
	// const data = useGetData();
	let data;
	// if (typeof beneficiaryDetails !== undefined) data = beneficiaryDetails;
	try {
		data = beneficiaryDetails;
		setImpersonatedFlag(data.impersonated);
		// console.log(
		// 	"beneficiaryDetails from JSP: ",
		// 	JSON.stringify(beneficiaryDetails)
		// );
	} catch (err) {
		// data = beneDetails;
		// setImpersonatedFlag(data.impersonated);
		// console.log("beneDetails not available on JSP: ", err);
	}
	useEffect(() => {
		dispatch({type: "UPDATE_DATA", data: data});
	}, [data]);
	
	return (
		<div className='col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2 col-lg-offset-2'>
			<BenePageFlowContainer />
		</div>
	);
}
export default BeneficiaryWidget;
