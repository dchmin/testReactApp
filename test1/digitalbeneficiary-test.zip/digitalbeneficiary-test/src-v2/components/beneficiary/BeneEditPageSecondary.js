import React, {useState, useEffect} from "react";
import {appContent} from "../../digital-beneficiary-entry";
import FormContainer from "./FormContainer";
import InfoButton from "../commons/InfoButton";
import AddButton from "../commons/AddButton";
import MaxBeneWarning from "../commons/MaxBeneWarning";
import ModalWidget from "../commons/modal/ModalWidget";
import BeneEditContingentHeader from "./editForm/BeneEditContingentHeader";
import {
    getInputData
} from "../../helpers";
let modalType = "",
modalTitle = "",
modalBody = "",
modalBtns = "",
modalSrCloseBtn = "",
modalStartSrOnlyText="",
modalEndSrOnlyText="";
//****************PURPOSE OF THIS FILE: DISPLAY SECONDARY BENEFICIARY****************//
function BeneEditPageSecondary({benefit, submitClick, showTechnicalFailure, setErrorCount, ...props}) {	
    // Component Variables
    const formName = `byFlow${benefit.clientBeneId}-secondary`;
    const existingForm = getInputData()[formName] && getInputData()[formName].newFieldArray;
    const hasExistingForm = existingForm && existingForm.length > 0;

    // States
    const [showForm, setShowForm] = useState(hasExistingForm); 
    const [show, setModalShow] = useState(false); //STATE TO CONTROL HIDE AND SHOW OF MODAL

    // Content
    let editContent = appContent.edit,
        editModal = editContent.modal;

    // TODO: Refactor modal handling
    // -----------MODAL HANDLING ---------------- (STARTS)
	const handleClose = () => {
		modalType = "";
		modalTitle = "";
		modalBtns = "";
		modalBody = "";
		modalSrCloseBtn = "";
		modalStartSrOnlyText="",
		modalEndSrOnlyText="";
		setModalShow(false);
	};
	const getModalBodyData = (modalType) => {
		modalTitle = editModal[modalType].modalTitle;
		modalBody = editModal[modalType].modalBody;
		modalBtns = editModal[modalType].modalBtns;
		modalSrCloseBtn = editModal[modalType].modalCloseText;
		modalStartSrOnlyText=editModal[modalType].modalStartSrOnlyText;
		modalEndSrOnlyText=editModal[modalType].modalEndSrOnlyText;
	};
	const handleShow = (modlType) => {
		modalType = modlType;
		getModalBodyData(modlType);
		setModalShow(true);
	};
    // -----------MODAL HANDLING ---------------- (ENDS)
    useEffect(() => {
        const newForm = document.getElementById(`${formName}-secondaryHeading`);      
        const addBtn = document.getElementById(`${formName}-addSecondaryBeneBtn`);
        //const newFormDropdown = document.getElementById(`${formName}-initialFieldArray[0]-relationship`);
		if (showForm && newForm) {
            newForm.focus(); //Accessibility - focus on new form created
        }
        else if (addBtn) {
            addBtn.focus(); //Accessibility - focus on add button
        }
    }, [showForm]);
    
	return (
		<div className="bene-border-top">
            {showForm ? 
                <FormContainer
                    formName={formName}
                    removeContingencyCheck={() => {
                        setShowForm(false); //Hide the form
                        props.updateTotalBeneCount(formName, 0);

                        //Setting secondary form intitial value to be blank
                        if (getInputData()[formName]) {
                            delete getInputData()[formName].newFieldArray; 
                            getInputData()[formName].initialFieldArray = []; 
                        }
                    }}
                    errorCount={(val) => setErrorCount(val)}
            		termsConditionsErrorCount={props.termsConditionsErrorCount}
                    setExistingFormErrorCount={props.setExistingFormErrorCount}
                    productLevelError={props.productLevelError}
                    contingentIsChecked={true}
                    beneId={benefit.clientBeneId}
            		productCategory={benefit.productCategory}
                    pageFlow={props.pageFlow}
                    submitClick={submitClick}
                    serviceFailed={showTechnicalFailure}
                    addBtn={editContent.addAnotherContingentBeneBtn}
                    addBtnSrText={`${editContent.addAnotherContingentBeneBtn} ${benefit.benefitName}`}
                    contingentcy={true}
            		minorChange={props.minorChange}
                    showAddBtn={props.showAddBtn}
                    updateTotalBeneCount={props.updateTotalBeneCount}
                />
                :
				<div className="bene-each-item">
                    <div className="mar-bottom-15">
                        <BeneEditContingentHeader 
                            id={`${formName}-noForm-secondaryHeading`} 
                            openModal={handleShow} />
                    </div>
                    {props.showAddBtn ?  
                        <AddButton
                            id={`${formName}-addSecondaryBeneBtn`}
                            value={editContent.addContingentBeneBtn}
                            onClick={() => {
                                setShowForm(true);
                                props.updateTotalBeneCount(formName, 1);
                            }}
                            aria-label={`${editContent.addContingentBeneBtn} ${benefit.benefitName}`}
                        />
                        : <MaxBeneWarning />
                    }
                </div>
            }
            <ModalWidget
                displayModal={show}
                modalType={modalType}
                modalTitle={modalTitle}
                modalBody={modalBody}
                modalBtns={modalBtns}
                srOnlyCloseBtn={modalSrCloseBtn}
                handleClose={handleClose}
                modalId={'beneModal_' + modalType}
                modalLnkBtnClk={handleClose}
                modalYlwBtnClk={handleClose}
                modalStartSrOnlyText={modalStartSrOnlyText}
                modalEndSrOnlyText={modalEndSrOnlyText}
            />
		</div>
	);
}
export default BeneEditPageSecondary;
