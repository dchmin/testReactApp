import React, {useState, useEffect} from "react";
import {appContent} from "../../digital-beneficiary-entry";
import {Field} from "react-final-form";
import "../../scss/edit-form.scss";
import TermsAgreeCheck from "./TermsAgreeCheck";

// GRS Terms and Conditions
function TermsConditions(props) {
	let tcHeader = appContent.edit.tcHeader,
		tcBody = appContent.edit.tcBody,
		agreeText = appContent.edit.tcAccept,
		errorMsg = appContent.errors.mandatory;
	const [confirmCheck, setConfirmCheck] = useState(false);
	const {submitClick} = props;
	
	return (
		<>
			<div className="mar-left-10 mar-right-10">
				<h3 dangerouslySetInnerHTML={{__html: tcHeader}} />
				<div dangerouslySetInnerHTML={{__html: tcBody}} />
				<TermsAgreeCheck
					confirmCheckVal={props.confirmCheckVal}
					modalSubmit={props.submitClick}
				/>
			</div>
		</>
	);
}
export default TermsConditions;
