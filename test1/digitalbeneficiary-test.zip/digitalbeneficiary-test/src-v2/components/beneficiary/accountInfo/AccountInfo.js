import React, {useContext, useState, useEffect} from "react";
import {StateContext} from "../Reducer";

const AccountInfo = (props) => {
	const state = useContext(StateContext);
	const {data} = state;
	
	if (data == "") {
		return null;
	}

	return (
		<div className='col-xs-12'>
			<span>{data.acctDetails.planName}</span>
			<span
				dangerouslySetInnerHTML={{
					__html: data.acctDetails.acNumber
				}}>
			</span>
			<hr className='soft-separator mar-top-25 mar-bottom-40'></hr>
		</div>
	);

};
export default AccountInfo;
