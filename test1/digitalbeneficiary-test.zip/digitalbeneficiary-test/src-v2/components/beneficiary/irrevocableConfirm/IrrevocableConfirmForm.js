import React, {useState, useEffect, useRef, useContext} from "react";
import {StateContext} from "../Reducer";
import {appContent} from "../../../digital-beneficiary-entry";
import ModalWrapper from "../../commons/modal/ModalWrapper";
import "../../../scss/edit-form.scss";

function IrrevocableConfirmForm(props) {
	const state = useContext(StateContext);

	// Content
	let lang = document.getElementsByTagName("HTML")[0].lang;
	let yesText = (lang === "en" || lang === "en-CA") ? "YES" : "OUI";
	let editCont = appContent.edit;
	let editModal = appContent.edit.modal;
	let errorMsg = appContent.errors.irrevocableConfirm;
	// TODO - Set the modal name here OR pass in the modal name from FormFields parent via props.modalType?
	let modalType = "irrevocableCheckbox";

	// States
	// const [show, setModalShow] = useState(false); //STATE TO CONTROL HIDE AND SHOW OF MODAL
	const [showError, setShowError] = useState(false);
	const [txtConfirm, setTxtConfirm] = useState("");

	const txtConfirmRef = useRef();
	const show = props.show;
	// const handleClose = () => props.handleClose();
	
	const handleTxtConfirmChange = (e) => {
		setTxtConfirm(e.target.value);
		if (e.target.value.toUpperCase() === yesText) {
			setShowError(false);
		}
	};
	
	const handleClose = () => {
		setShowError(false);
		setTxtConfirm("");
		props.handleClose();
	};
	
	const ylwClk = () => {
		if (txtConfirm.toUpperCase() === yesText) {
			setShowError(false);
			setTxtConfirm("");
			props.ylwBtnClk();
		}
		else {
			setShowError(true);
			txtConfirmRef.current.focus();
		}
	};

	return (
		<ModalWrapper
			ylwClk={ylwClk}
			show={show}
			modalType={modalType}
			handleClose={handleClose}
			modalLnkBtnClk={handleClose}
			disableBackdropClick={true}
			modalBodyJsx={
				<div>
					<div 
						dangerouslySetInnerHTML={{__html: editModal[modalType].modalBody}} 
					/>
					<div className="row">
						<div className="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<label htmlFor="irrevocableTxtConfirm"
								dangerouslySetInnerHTML={{__html: editModal[modalType].modalAdditionalProps.confirmLabel }} />
							<input
								ref={txtConfirmRef}
								id="irrevocableTxtConfirm"
								value={txtConfirm}
								onInput={(e) => {
									handleTxtConfirmChange(e);
								}}
								name="irrevocableTxtConfirm"
								type="text"
								maxlength="3"
								className={"upper-case form-control " + (showError ? "parsley-error" : "")}
								aria-required='true'
								aria-describedby={showError ? "irrevocableTxtConfirm-error": null}
								aria-invalid={showError ? "true" : null}
							/>
						</div>
					</div>
					{showError && (
						<ul
							id="irrevocableTxtConfirm-error" 
							className='parsley-errors-list filled'>
							<li className='parsley-type'
								dangerouslySetInnerHTML={{__html: errorMsg }} />
						</ul>
					)}
				</div>
			}
		/>
	);
}
export default IrrevocableConfirmForm;
