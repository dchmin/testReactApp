import React, {useState, useContext, useEffect, useRef} from "react";
import {StateContext} from "./Reducer";
import NotepadAccordion from "./NotepadAccordion";
import PageNavBtns from "../commons/PageNavBtn";
import BeneSummarySection from "./BeneSummarySection";
import BeneEditPageContingencyByProduct from "./BeneEditPageContingencyByProduct";
import BeneEditPageSingleContingency from "./BeneEditPageSingleContingency";
import TermsConditions from "./TermsConditions";
import {appContent, appLob} from "../../digital-beneficiary-entry";
import {
	setContingencyCheck,
	getContingencyCheck,
	uTagCall,
	checkSession,
} from "../../helpers";
import "../../scss/edit-form.scss";
import ModalWidget from "../commons/modal/ModalWidget";
//****************PURPOSE OF THIS FILE: PARENT TO DISPLAY EDIT FORM LAYOUT *********************//
//**************** 1) EDIT FORM WITH SINGLE CONTINGENCY FOR ALL PRODUCTS USED BY GB ************//
//**************** 2) EDIT FORM WITH CONTINGENCY/SECONDARY BENE FOR EACH PRODUCT USED BY GRS ***//
// SET MODAL TYPE AND MODAL BODY SO THAT ONE INSTANCE OF MODAL CAN BE REUSED - (STARTS)
let modalType = "",
	modalTitle = "",
	modalBody = "",
	modalBtns = "",
	modalSrCloseBtn = "",
	modalStartSrOnlyText = "",
	modalEndSrOnlyText = "";
// SET MODAL TYPE AND MODAL BODY SO THAT ONE INSTANCE OF MODAL CAN BE REUSED - (ENDS)
const leavePagePopup = (e) => { 
	// Display leave page popup when user is going to navigate away from eBene Edit mode
	e.preventDefault();
	e.returnValue = '';
 }

function BeneEditPage(props) {
	let editContent = appContent.edit,
		editModal = editContent.modal,
		editErrors = appContent.errors;
	const [show, setModalShow] = useState(false), //STATE TO CONTROL HIDE AND SHOW OF MODAL
		[contingentBeneficiary, setContingentBeneficiary] = useState(false),
		[errorCount, setErrorCount] = React.useState(0),
		[existingFormErrorCount, setExistingFormErrorCount] = React.useState(0),
		[termsConditionsErrorCount, setTermsConditionsErrorCount] = React.useState(0),
		[serviceFailed, setServiceFailed] = useState(false),
		state = useContext(StateContext),
		{data} = state,
		benefitList = data !== "" ? data.member.benefitList : "";
	const [submitClick, setSubmitClick] = useState(false);
	let context = data.context;

	// -----------MODAL HANDLING ---------------- (STARTS)
	const handleClose = () => {
		modalType = "";
		modalTitle = "";
		modalBtns = "";
		modalBody = "";
		modalSrCloseBtn = "";
		modalStartSrOnlyText="",
		modalEndSrOnlyText="";
		setModalShow(false);
	};
	const getModalBodyData = (modalType) => {
		modalTitle = editModal[modalType].modalTitle;
		modalBody = editModal[modalType].modalBody;
		modalBtns = editModal[modalType].modalBtns;
		modalSrCloseBtn = editModal[modalType].modalCloseText;
		modalStartSrOnlyText=editModal[modalType].modalStartSrOnlyText;
		modalEndSrOnlyText=editModal[modalType].modalEndSrOnlyText;
	};
	const handleShow = (modlType) => {
		modalType = modlType;
		getModalBodyData(modlType);
		setModalShow(true);
	};
	// -----------MODAL HANDLING ---------------- (ENDS)

	// Call Shadow disable submit button
	const disableNavBtn = (btn) => {
		if (data.member.shadowMode === "C" && btn === "btnYellow") return true;
		return false;
	}

	const showTechnicalFailure = (val) => {
		setTimeout(() => {
			setServiceFailed(val);
			if (val === true) {
				window.scrollTo({top: 0, behavior: "smooth"});
				document.getElementById("technical-error").focus();
			}
		}, 500);
	};

	const [submitClickCount, setSubmitClickCount] = useState(0); 
	const setClick = () => {
		setSubmitClick(true);
		setSubmitClickCount((previousState) => previousState + 1);
		
		// Excecute form submission and validation
		window.startValidate(1);
		if (appLob === "GB") {
			setTimeout(function () {
				window.startValidate(2);
			}, 500);
		}
	};
	
	useEffect(() => {
		// Determine the number of errors found during form submit validation
		if (appLob === "GRS" && submitClick && submitClickCount !== 0) {
			window.startValidate(2);
			focusErrorCount();
		}
	},[submitClickCount, submitClick]);

	const addBeneHeader = useRef();
	useEffect(() => {
		// GRS LOB upon entering Edit mode focus on new header section
		if (appLob === "GRS" && addBeneHeader.current !== undefined) {
			addBeneHeader.current.focus();
			// Inform user they're navigating away from page when in Edit mode
			window.leavePagePopup = leavePagePopup;
			window.addEventListener("beforeunload", window.leavePagePopup);

			// Remove event listener when component dismounts
			return () => {
				window.removeEventListener("beforeunload", window.leavePagePopup);
			}
		}
	}, []);

	const errorCountMsg = useRef();
	useEffect(() => {
		if (appLob === "GB") { //GB LOB contingency check and tealium tagging
			const previouslySetContingency = getContingencyCheck();
			if (previouslySetContingency !== null) {
				setContingentBeneficiary(previouslySetContingency);
			}
			uTagCall(window.location.href + "/edit+beneficiary/");
		}
		focusErrorCount(); //Focus on the error count after it has been updated
		if (data.member.shadowMode === "A") {
			window.submit = ()=>{handleShow("accessRestricted")}; //show a modal when it's Advisor shadowing
		}
		else {
			window.submit = setClick;
		}
	}, [errorCount]);

	const focusErrorCount = () => {
		if (errorCount > 0) window.scrollTo({top: 0, behavior: "smooth"});
		if (errorCount > 0 && errorCountMsg.current !== undefined)
			errorCountMsg.current.focus();
	}
	
	// Set the error count for Terms and conditions checkbox and use it to update the total error count
	const confirmCheckVal = (val) => {
		if (!val) {
			setTermsConditionsErrorCount(1);
		}
		else {
			setTermsConditionsErrorCount(0);
		}
	};

	return (
		<>
			{appLob === "GRS" ? 
				<div className='row mar-bottom-20'>
					<BeneSummarySection />
				</div>
				:
				<NotepadAccordion
				 	notepadData={data !== "" ? data.member.notepadDetails : ""}
				 	page='edit-form'
				/>
			}

			<div className='mar-bottom-20'>
				<h2 ref={addBeneHeader} tabIndex='-1'>{editContent.addBeneHeader}</h2>
				{appLob !== "GRS" &&
					<p>
						{props.pageFlow === "byBenefits"
							? editContent.byFlowSubHeader
							: editContent.allFlowSubHeader}
					</p>
				}
			</div>

			{(errorCount > 0 || existingFormErrorCount > 0) && (
				<div
					id='all-error-count'
					className='field-set-validation-errors mar-bottom-10'
					// role='alert'
					ref={errorCountMsg}
					tabIndex='0'>
					{editErrors.totalCount1}
					{errorCount || existingFormErrorCount}
					{editErrors.totalCount2}
				</div>
			)}
			{serviceFailed && (
				<div
					id='technical-error'
					className='field-set-validation-errors mar-bottom-10'
					role='alert'
					tabIndex='0'>
					{editErrors.technicalError}
				</div>
			)}

			{props.pageFlow === "existingBenefits" ? 
				<BeneEditPageContingencyByProduct 
					pageFlow={props.pageFlow}
					submitClick={submitClick}
					showTechnicalFailure={showTechnicalFailure}
					setErrorCount={setErrorCount}
					termsConditionsErrorCount={termsConditionsErrorCount}
					setExistingFormErrorCount={setExistingFormErrorCount}
				/>
				: 
				<BeneEditPageSingleContingency 
					pageFlow={props.pageFlow}
					submitClick={submitClick}
					showTechnicalFailure={showTechnicalFailure}
					setErrorCount={setErrorCount}
					contingentBeneficiary={contingentBeneficiary}
					setContingentBeneficiary={setContingentBeneficiary}
				/>
			}

			{appLob === "GRS" &&
				<TermsConditions
					submitClick={submitClick}
					confirmCheckVal={confirmCheckVal}
				/>
			}
			
			<hr className='soft-separator'></hr>
			<div className='btn-centered-container mar-top-10'>
				{Object.keys(editContent.pageNavBtns).map(
					function (key, index, size) {
						if (editContent.pageNavBtns[key].text !== "") {
							return (
								<PageNavBtns
									key={key}
									index={index}
									size={size}
									btnDetails={editContent.pageNavBtns[key]}
									cssClassName={key}
									customClass={`page-nav-mar`}
									origin='page'
									disabled={disableNavBtn(key)}
								/>
							);
						}
					}.bind(this)
				)}
			</div>
			<ModalWidget
				displayModal={show}
				modalType={modalType}
				modalTitle={modalTitle}
				modalBody={modalBody}
				modalBtns={modalBtns}
				srOnlyCloseBtn={modalSrCloseBtn}
				handleClose={handleClose}
				modalId={'beneModal_' + modalType}
				modalLnkBtnClk={handleClose}
				modalYlwBtnClk={handleClose}
				modalStartSrOnlyText={modalStartSrOnlyText}
				modalEndSrOnlyText={modalEndSrOnlyText}
			/>
		</>
	);
}
export default BeneEditPage;