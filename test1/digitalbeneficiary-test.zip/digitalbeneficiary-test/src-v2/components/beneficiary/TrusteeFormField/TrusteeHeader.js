import React from "react";
import {appContent} from "../../../digital-beneficiary-entry";
import InfoButton from "../../commons/InfoButton";

const TrusteeHeader = ({id, openModal, ...props}) => {
    const editContent = appContent.edit;
    const addTrusteeDesc = editContent.addTrusteeDesc;
    return (
        <>
            <h4>
                {editContent.trusteeHeader}
                <InfoButton
                    modalType='trustee'
                    openModal={openModal}
                    srLabel={
                        editContent.trusteeInfoLabel
                    }
                />
            </h4>
            {addTrusteeDesc && <div dangerouslySetInnerHTML={{__html: addTrusteeDesc}}></div>}
        </>
    );
};
export default TrusteeHeader;
