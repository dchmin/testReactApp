import React, {useState, useEffect, useRef, useContext} from "react";
import {StateContext} from "../Reducer";
import {Field} from "react-final-form";
import {appContent, appLob} from "../../../digital-beneficiary-entry";
import TrusteeHeader from "./TrusteeHeader";
import NameInputField from "../../commons/NameInputField";
import ModalWidget from "../../commons/modal/ModalWidget";
import {
	nameCheck, 
	nameHasError, 
	getNameCharLimit,
	setOnBlurNameError,
	setEditError,
	setLob
} from "../ValidationFunctions";

let modalType = "",
	modalTitle = "",
	modalBody = "",
	modalBtns = "",
	modalSrCloseBtn = "",
	modalStartSrOnlyText="",
	modalEndSrOnlyText="";

const TrusteeFormField = (props) => {
	const state = useContext(StateContext);
	
	const [show, setModalShow] = useState(false);
	const {data} = state;
	
	let formName = props.formName;
	let name = props.name;
	
    let editContent = appContent.edit;
    let editModal = appContent.edit.modal;
    
	const {submitClick, initialValidate} = props;
	
	const nameCharLimit = getNameCharLimit();
    
    // -----------MODAL HANDLING ---------------- (STARTS)
	const handleClose = () => {
		modalType = "";
		modalTitle = "";
		modalBtns = "";
		modalBody = "";
		modalSrCloseBtn = "";
		modalStartSrOnlyText="",
		modalEndSrOnlyText="";
		setModalShow(false);
	};
	const getModalBodyData = (modalType) => {
		modalTitle = editModal[modalType].modalTitle;
		modalBody = editModal[modalType].modalBody;
		modalBtns = editModal[modalType].modalBtns;
		modalSrCloseBtn = editModal[modalType].modalCloseText;
		modalStartSrOnlyText=editModal[modalType].modalStartSrOnlyText;
		modalEndSrOnlyText=editModal[modalType].modalEndSrOnlyText;
	};
	const handleShow = (modlType) => {
		modalType = modlType;
		getModalBodyData(modlType);
		setModalShow(true);
	};

	useEffect(() => {
		// Set validation errors and lob
		setEditError(appContent.errors);
		setLob(appLob);
	}, []);

    return (
    	<>
		<div id={'trustee-sec-' + props.formName} className='mar-bottom-20'>
			<div className='mar-bottom-15'>
				<TrusteeHeader openModal={handleShow}/>
			</div>
			<div className='row'>
				{/* T R U S T E E -- F I R S T -- N A M E ------- B L O C K */}
				<Field
					name={`${name}.firstName`}
					validate={ nameCheck(submitClick || initialValidate) }>
					{({input, meta}) => (
						<NameInputField 
							id={`${formName}-${name}.firstName`}
							label={editContent.trusteeFName}
							maxLength={nameCharLimit}
							onBlur={(e) => setOnBlurNameError(e, formName, `${name}.firstName`)}
							hasError={nameHasError(meta)}
							error={meta.error}
							input={input}
						/>
					)}
				</Field>
				{/* T R U S T E E -- F I R S T -- N A M E ------- B L O C K */}
				{/* T R U S T E E -- L A S T -- N A M E ------- B L O C K */}
				<Field
					name={`${name}.lastName`}
					validate={ nameCheck(submitClick || initialValidate)  }>
					{({input, meta}) => (
						<NameInputField 
							id={`${formName}-${name}.lastName`}
							label={editContent.trusteeLName}
							maxLength={nameCharLimit}
							onBlur={(e) => setOnBlurNameError(e, formName, `${name}.lastName`)}
							hasError={nameHasError(meta)}
							error={meta.error}
							input={input}
						/>
					)}
				</Field>
				{/* T R U S T E E -- L A S T -- N A M E ------- B L O C K */}
			</div>
		</div>
		
		{/* INVISIBLE BUTTON ADDED FOR SITEIMPROVE - START*/}
		<button
			type='submit'
			hidden=''
			className='invisible radio-label'
			onClick={(e) =>
				e.preventDefault()
			}></button>
		{/* INVISIBLE BUTTON ADDED FOR SITEIMPROVE - END*/}

		<ModalWidget
			displayModal={show}
			modalType={modalType}
			modalTitle={modalTitle}
			modalBody={modalBody}
			modalBtns={modalBtns}
			srOnlyCloseBtn={modalSrCloseBtn}
			handleClose={handleClose}
			modalId={'trusteeModal_' + modalType}
			modalLnkBtnClk={handleClose}
			modalYlwBtnClk={handleClose}
			modalStartSrOnlyText={modalStartSrOnlyText}
			modalEndSrOnlyText={modalEndSrOnlyText}
		/>
		</>
    );
};
export default TrusteeFormField;
