import React, {useState, useContext, useEffect} from "react";
import {StateContext} from "./Reducer";
import {getBeneEditList} from "./BeneficiaryGRSWidget";
import FormContainer from "./FormContainer";
import BeneCardTop from "./beneCard/BeneCardTop";
import {appContent} from "../../digital-beneficiary-entry";
import BeneEditPageSecondary from "./BeneEditPageSecondary";
import {
	setInputData,
	getInputData,
	getFormInstances,
	setFormInstances
} from "../../helpers";
//****************PURPOSE OF THIS FILE: 1) DISPLAY LAYOUT OF PRIMARY, SECONDARY AND TRUSTEE FORMS****************//
//************************************* 2) CONTAINS GRS LOGIC AND RULES ON BENE COUNT AND MINOR/TRUSTEE**********//
const maxBeneDisplay = 10; //Maximum number of beneficiary for one product

// Initial values for beneInfo state on component load
const initialBeneInfo = (benefit) => {
	let trusteeCount = 0;
	let initialVal = {
		showAddBtn: true,
		primary: {
			beneCount: 0,
			hasMinor: false
		},
		secondary: {
			beneCount: 0,
			hasMinor: false
		}		
	}	

	// Get length of editable bene and check if minor exists for primary and secondary
	let primaryBene = benefit.primaryBeneficiaries
		.filter(bene => bene.relationship !== "EST")
		.map((beneficiary) => {
			if (beneficiary.minorSelection === "yes") {
				initialVal.primary.hasMinor = true;
				trusteeCount = 1;
			}
			return beneficiary;
		});
	initialVal.primary.beneCount = primaryBene.length === 0 ? 1 : primaryBene.length;
	let secondaryBene = benefit.secondaryBeneficiaries
		.filter(bene => bene.relationship !== "EST")
		.map((beneficiary) => {
			if (beneficiary.minorSelection === "yes") {
				initialVal.secondary.hasMinor = true;
				trusteeCount = 1;
			}
			return beneficiary;
		});
	initialVal.secondary.beneCount = secondaryBene.length;

	// Add Button would be available if less than 10 bene is listed (including trustee)
	let beneCount = primaryBene.length + secondaryBene.length + trusteeCount; 
	initialVal.showAddBtn =  beneCount < maxBeneDisplay;

	return initialVal;
}

function BeneEditPageGRSProductWrapper({submitClick, showTechnicalFailure, setErrorCount, setExistingFormErrorCount, benefit, ...props}) {
	const state = useContext(StateContext),
	{data} = state,
	benefitList = getBeneEditList();

	let editContent = appContent.edit;
	const errors = appContent.errors;

	const [beneInfo, setBeneInfo] = useState(initialBeneInfo(benefit));
	
	// Keeps track of beneficiaries in both primary or secondary forms
	const updateTotalBeneCount = (formName, count) => {
		let trusteeCount = (beneInfo.primary.hasMinor || beneInfo.secondary.hasMinor) ? 1 : 0;
		let updateBeneInfo = beneInfo;

		// Update state counter on the number of bene for Primary and Secondary forms
		let totalBeneCount = count;
		if (formName.match(/secondary/g)) {
			if (formName.match(/secondary/g) && count === 0) {
				// Entire secondary form is removed - reset state
				updateBeneInfo.secondary = {
					beneCount: 0,
					hasMinor: false
				};
				trusteeCount = (beneInfo.primary.hasMinor) ? 1 : 0;
			}
			totalBeneCount += beneInfo.primary.beneCount;
			updateBeneInfo.secondary.beneCount = count;
		}
		else {
			totalBeneCount += beneInfo.secondary.beneCount;
			updateBeneInfo.primary.beneCount = count;
		}

		// Determine if the Add button should be displayed
		totalBeneCount += trusteeCount;
		updateBeneInfo.showAddBtn = totalBeneCount < maxBeneDisplay;

		// Update bene product states
		setBeneInfo((previousState) => ({
			...previousState,
			...updateBeneInfo
		}));
	}

	// Toggle the Trustee section if a minor selection is made on either the primary or secondary forms
	const minorChange = (formName, minorCount, updatedBeneCount) => {
		const productId = formName.replace("byFlow", "").replace("-primary", "").replace("-secondary", "");
		let updateBeneInfo = {};
		let newPrimaryMinorExists = beneInfo.primary.hasMinor;
		let newSecondaryMinorExists = beneInfo.secondary.hasMinor;		
		let totalBeneCount = 0;
		
		// Update state counter on the number of bene and minor info for Primary and Secondary forms
		if (formName.match(/secondary/g)) {			
			newSecondaryMinorExists = minorCount > 0;			
			totalBeneCount = beneInfo.primary.beneCount + updatedBeneCount;				
			updateBeneInfo.secondary = {
				beneCount: updatedBeneCount,
				hasMinor: newSecondaryMinorExists
			};
		}
		else {			
			newPrimaryMinorExists = minorCount > 0;
			totalBeneCount = beneInfo.secondary.beneCount + updatedBeneCount;
			updateBeneInfo.primary = {
				beneCount: updatedBeneCount,
				hasMinor: newPrimaryMinorExists
			};
		}

		// Determine if the Add button should be displayed
		let showAddBtn = false;
		if (newPrimaryMinorExists || newSecondaryMinorExists) {
			// If at least one minor exists then include trustee in count
			totalBeneCount += 1; 
		}
		updateBeneInfo.showAddBtn = totalBeneCount < maxBeneDisplay;

		// Update bene product states
		setBeneInfo((previousState) => ({
			...previousState,
			...updateBeneInfo
		}));

		// If the product does not have minors in primary and secondary
		// set the trustee data to be empty next time form is initialized
		if (!newPrimaryMinorExists && !newSecondaryMinorExists) {
			delete getInputData()[`byFlow${productId}-trustee`];
			delete getFormInstances()[`byFlow${productId}-trustee`];
		}

		// Remove product level error message for over 10 bene
		const productError = props.productErrorMsgs[benefit.clientBeneId];
		if (submitClick && productError && productError.length > 0 && productError[0] === errors.overMaxBeneficiaries) {
			productError.shift();
			props.productLevelError({
				...props.productErrorMsgs, 
				[benefit.clientBeneId]: productError
			});
		}
	};
	return (
		<>
			{/* Primary Beneficiary */}
			<FormContainer
				formName={`byFlow${benefit.clientBeneId}-primary`}
				errorCount={(val) => setErrorCount(val)}
				termsConditionsErrorCount={props.termsConditionsErrorCount}
				setExistingFormErrorCount={setExistingFormErrorCount}
				productLevelError={props.productLevelError}
				contingentIsChecked={false}
				beneId={benefit.clientBeneId}
				productCategory={benefit.productCategory}
				pageFlow={props.pageFlow}
				submitClick={submitClick}
				serviceFailed={showTechnicalFailure}
				addBtn={editContent.addAnotherPrimaryBeneBtn}
				addBtnSrText={`${editContent.addAnotherPrimaryBeneBtn} ${benefit.benefitName}`}
				minorChange={minorChange}
				updateTotalBeneCount={updateTotalBeneCount}
				showAddBtn={beneInfo.showAddBtn}
			/>
			
			{/* Secondary Beneficiary */}
			{(benefit.showSecondaryBeneficiaries === "V" || 
					benefit.showSecondaryBeneficiaries === "E") && 
					<BeneEditPageSecondary 
						benefit={benefit}
						pageFlow={props.pageFlow}
						submitClick={submitClick} 
						showTechnicalFailure={showTechnicalFailure}
						setErrorCount={setErrorCount}
						termsConditionsErrorCount={props.termsConditionsErrorCount}
						setExistingFormErrorCount={setExistingFormErrorCount}
						productLevelError={props.productLevelError}
						minorChange={minorChange}
						updateTotalBeneCount={updateTotalBeneCount}
						showAddBtn={beneInfo.showAddBtn}
					/>
			}
			
			{/* Trustee Section */}
			{(beneInfo.primary.hasMinor || beneInfo.secondary.hasMinor) && !data.member.quebec &&
				<div className="bene-border-top">
					<FormContainer
						formName={`byFlow${benefit.clientBeneId}-trustee`}
						errorCount={(val) => setErrorCount(val)}
						termsConditionsErrorCount={props.termsConditionsErrorCount}
						setExistingFormErrorCount={setExistingFormErrorCount}
						productLevelError={props.productLevelError}
						contingentIsChecked={false}
						beneId={benefit.clientBeneId}
						pageFlow={props.pageFlow}
						submitClick={submitClick}
						serviceFailed={showTechnicalFailure}
						initialValidate={benefit.trustee !== ""}
					/>
				</div>
			}
		</>
	);
}
export default BeneEditPageGRSProductWrapper;
