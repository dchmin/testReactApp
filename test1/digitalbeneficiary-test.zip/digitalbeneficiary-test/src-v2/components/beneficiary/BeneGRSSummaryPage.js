import React, {useContext, useState, useEffect, useRef} from "react";
import {DispatchContext, StateContext} from "./Reducer";
import {getBeneEditList, getBeneFormList} from "./BeneficiaryGRSWidget";
import ButtonLink from "../commons/ButtonLink";
import {appContent} from "../../digital-beneficiary-entry";
import BeneSummarySection from "./BeneSummarySection";
import BeneCardTop from "./beneCard/BeneCardTop";
import BeneTable from "./beneCard/BeneTable";
import BeneTrusteeView from "./beneCard/BeneTrusteeView";
import BeneEditableProductsForm from "./editForm/BeneEditableProductsForm";
import BeneFormDownload from "./beneFormDownload/BeneFormDownload";
import InfoButton from "../commons/InfoButton";
import ModalWidget from "../commons/modal/ModalWidget";
import "../../scss/view-form.scss";
let modalType = "",
	modalTitle = "",
	modalBody = "",
	modalBtns = "",
	modalSrCloseBtn = "",
	modalStartSrOnlyText="",
	modalEndSrOnlyText="";
//****************PURPOSE OF THIS FILE: PARENT TO DISPLAY SUMMARY PAGE AND "CONFIRMATION PAGE" AS WELL****************//
const BeneGRSSummaryPage = (props) => {
	const dispatch = useContext(DispatchContext);
	const state = useContext(StateContext);
	const [show, setModalShow] = useState(false); //STATE TO CONTROL HIDE AND SHOW OF MODAL
	const {data, pageFlow} = state;

	const benefitList = data.member &&  data.member.benefitList ? data.member.benefitList : [];
	const isEnrol = (benefitList.length > 0);
	const showEditBtn = getBeneEditList().length > 0; 
	const showDownloadFormBtn = !showEditBtn && getBeneFormList().length > 0;

	let summaryCont = appContent.summary	
	let summaryModal = appContent.summary.modal;
	
	// -----------MODAL HANDLING ---------------- (STARTS)
	const handleClose = () => {
		modalType = "";
		modalTitle = "";
		modalBtns = "";
		modalBody = "";
		modalSrCloseBtn = "";
		modalStartSrOnlyText="",
		modalEndSrOnlyText="";
		setModalShow(false);
	};
	const getModalBodyData = (modalType) => {
		modalTitle = summaryModal[modalType].modalTitle;
		modalBody = summaryModal[modalType].modalBody;
		modalBtns = summaryModal[modalType].modalBtns;
		modalSrCloseBtn = summaryModal[modalType].modalCloseText;
		modalStartSrOnlyText=summaryModal[modalType].modalStartSrOnlyText;
		modalEndSrOnlyText=summaryModal[modalType].modalEndSrOnlyText;
	};
	const handleShow = (modlType) => {
		modalType = modlType;
		getModalBodyData(modlType);
		setModalShow(true);
	};
	const checkUserType = (event) => {
		dispatch({
			type: "UPDATE_UI",
			pageFlow: "existingBenefits",
			displayMode: "edit",
		});
	};	
	// -----------MODAL HANDLING ---------------- (ENDS)
	const successHeader = useRef();
	const designationHead = useRef();
	useEffect(() => {		
		if (pageFlow === "submitSuccessConfirmation") {
			// If user submit successfully and returns to view page 
			// Focus on success header 
			successHeader.current.focus();
		}
		else if (pageFlow === "pageCancelled") {
			// User is coming from Edit page after clicking cancel
			// Should focus them back before the edit button instead of top of the page
			designationHead.current.focus();
		}
	},[]);

	// User is not enrolled
	if (!isEnrol) {
		return (
			<div className='row view-not-enrol'>
				<BeneSummarySection isEnrol={isEnrol}/>
			</div>
		); 
	}

	// User is enrolled in at least one product
	return (
		<>
			{/* Beneficiary Heading */}
			<div className='row mar-bottom-20'>
				{/* Success Confirmation Header */}
				{(pageFlow === "submitSuccessConfirmation")  && (
					<div className='col-xs-12 mar-bottom-25' role='alert'>
						<h2 ref={successHeader} tabIndex="-1">
							<span className="fa fa-check mar-right-10"></span>
							{summaryCont.successHeader}
						</h2>
						<p dangerouslySetInnerHTML={{__html: summaryCont.successDesc}} />
					</div>
				)}
				
				{/* Summary Section */}
				<BeneSummarySection />
			</div>
			
			{/* View Beneficiary Info */}
			<div className='view-form'>
				{/* Beneficiary Designation Heading + Edit Button */}
				<div className='row'>
					<div className='col-xs-12 mar-bottom-10 mar-top-102'>
						<h2 ref={designationHead} className='inline-block-element' tabIndex="-1">
							{summaryCont.designationHead}
						</h2>
						{showEditBtn && 
							<BeneEditableProductsForm />
						}
						{showDownloadFormBtn && 
							<ButtonLink
								id="bene-download-btn"
								cssClass='btn btn-blue edit-btn inline-block-element ele-mob-full-stretch'
								data-react-modal='beneForm'
								href='#'
								value={summaryCont.downloadFormBtn}
								onClick={null}
							/>
						}
					</div>
				</div>
				
				{/* Product card */}
				<div className='row'>
					<div className='col-xs-12'>
						{benefitList.map((benefit, index) => {
							return (
								<div 
									key={index} 
									id={`bene-view-${benefit.clientBeneId}`}
									className='bene-card mar-bottom-20'>
									<BeneCardTop product={benefit} />
									<div className='bene-card-item pad-top-0 pad-bottom-20 border-top-grey slf-table table-responsive'>
										{/* Primary Beneficiary Table */}
										<BeneTable 
											tblCaption={
												<div>
													{summaryCont.benefitHead}
													<InfoButton
														modalType='beneDesignation'
														openModal={handleShow}
														srLabel={summaryCont.designationSrLabel}
													/>
												</div>
											}
											benefit={benefit.primaryBeneficiaries}
											cssClass="bene-primary-tbl"
										/>

										{/* Secondary Beneficiary Table */}
										{benefit.showSecondaryBeneficiaries === "V" && 
											<BeneTable 
												tblCaption={
													<div>
														{summaryCont.contingentBene}
														<InfoButton
															modalType='contingentInfo'
															openModal={handleShow}
															srLabel={summaryCont.contingentBeneInfoLabel}
														/>
													</div>
												}
												benefit={benefit.secondaryBeneficiaries}
												hideRevocableStatus={true}
												cssClass="bene-contingent-tbl"
											/>	
										}									
									</div>
									<div className='bene-card-item pad-top-0 pad-bottom-20'>
										{/* Trustee Table */}
										<BeneTrusteeView 
											trustee={benefit.trustee}
											openModal={handleShow}
										/>
									</div>
								</div>
							)
						})}
					</div>
				</div>
			</div>
			<BeneFormDownload />
			<ModalWidget
				displayModal={show}
				modalType={modalType}
				modalTitle={modalTitle}
				modalBody={modalBody}
				modalBtns={modalBtns}
				srOnlyCloseBtn={modalSrCloseBtn}
				handleClose={handleClose}
				modalId={'beneModal_' + modalType}
				modalLnkBtnClk={handleClose}
				modalYlwBtnClk={handleClose}
				modalStartSrOnlyText={modalStartSrOnlyText}
				modalEndSrOnlyText={modalEndSrOnlyText}
			/>
		</>
	);

};
export default BeneGRSSummaryPage;
