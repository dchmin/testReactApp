import React from "react";
import {appContent, appLob} from "../../../digital-beneficiary-entry";

const TotalAllocationError = ({totalAllocationVal, submitClick, ...props}) => {
    let errors = appContent.errors;

    if (submitClick === false || appLob === "GB" || totalAllocationVal === 100.00) {
        return null;
    }

	return (
        <div class="field-set-validation-errors">
           {errors.allocation}
        </div>
    );
}
export default TotalAllocationError;