import React from "react";
import {appContent} from "../../../digital-beneficiary-entry";

const TotalAllocationStatus = ({totalAllocationVal,lang, ...props}) => {
    let editContent = appContent.edit;
	const formatTotalAllocationVal =(totalAllocationValRemain) => {
		return totalAllocationValRemain.toLocaleString(
											lang,
											{
												minimumFractionDigits: 2,
												maximumFractionDigits: 2,
											}
										);
	}
	const replaceTotalAllocationVal = (totalAllocationValRemain, label) => {
		return label.replace('$value$', formatTotalAllocationVal(totalAllocationValRemain));
	}
	if (totalAllocationVal > 100.00){
		// more than 100
		return (
            <>
				({replaceTotalAllocationVal(totalAllocationVal-100,editContent.overAllocationLabel)})
            </>
        );
	} else if (totalAllocationVal === 100.00) {
        return (
            <>
                (<span className='fa fa-check' aria-hidden='true'/>
                {editContent.doneAllocationLabel})
            </>
        );
    } else {
		// less than 100
		return (
            <>
				({replaceTotalAllocationVal(100-totalAllocationVal,editContent.underAllocationLabel)})
            </>
        );
		
	}
};

export default TotalAllocationStatus;
