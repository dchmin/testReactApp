import React from "react";
import {appContent} from "../../../digital-beneficiary-entry";
import InfoButton from "../../commons/InfoButton";

const BeneEditPrimaryHeader = React.forwardRef(({id, openModal, ...props}, ref) => {
    const editContent = appContent.edit;
    return (
        <>
            <h4 ref={ref} id={id} tabIndex="-1">
                {editContent.benefitHead}
                <InfoButton
                    modalType='beneDesignation'
                    openModal={openModal}
                    srLabel={editContent.designationSrLabel}
                />
            </h4>
            <p>{editContent.addBeneDesc}</p>
        </>
    );
});
export default BeneEditPrimaryHeader;
