import React, {useState, useEffect, useRef, useContext} from "react";
import {DispatchContext, StateContext} from "../Reducer";
import {appContent} from "../../../digital-beneficiary-entry";
import {getBeneEditList, getBeneNonEditList} from "../BeneficiaryGRSWidget";
import ModalWrapper from "../../commons/modal/ModalWrapper";
import ButtonLink from "../../commons/ButtonLink";
import "../../../scss/view-form.scss";

function BeneEditableProductsForm(props) {
	const dispatch = useContext(DispatchContext);
	const state = useContext(StateContext);
	const {data} = state;

	// Content
	let summaryCont = appContent.summary;
	let summaryModal = appContent.summary.modal;
	let modalType = "editableProducts";

	// States
	const [show, setModalShow] = useState(false); //STATE TO CONTROL HIDE AND SHOW OF MODAL

	const benefitList = data.member &&  data.member.benefitList ? data.member.benefitList : [];
	const beneEditList = getBeneEditList();
	const beneNonEditList = getBeneNonEditList();

	// -----------MODAL HANDLING ---------------- (STARTS)
	const handleClose = () => {
		setModalShow(false);
	};
	
	const goToEditMode = () => {
		// Close the modal and go to the Edit mode
		setModalShow(false);
		dispatch({
			type: "UPDATE_UI",
			pageFlow: "existingBenefits",
			displayMode: "edit",
		});
	};
	
	const ylwClk = () => {
		goToEditMode();
	};

	// -----------MODAL HANDLING ---------------- (ENDS)

	// change it to a function
	const handleShow = () => {
		if (beneEditList.length === benefitList.length) {
			goToEditMode();
		}
		else {
			setModalShow(true);
		}
	}
	

	// Don't display modal if there are no editable products
	if (beneEditList.length <= 0) {
		return null;
	}

	return (
		<>
		<ButtonLink
			id="bene-edit-btn"
			cssClass='btn btn-blue edit-btn inline-block-element ele-mob-full-stretch'
			href='#'
			value={summaryCont.editBtn}
			onClick={handleShow}
		/>
		
		{summaryModal[modalType] && 
			<ModalWrapper
				ylwClk={ylwClk}
				show={show}
				modalType={modalType}
				handleClose={handleClose}
				modalLnkBtnClk={handleClose}
				modalBodyJsx={
					<div>
						<div 
							dangerouslySetInnerHTML={{__html: summaryModal[modalType].modalAdditionalProps.editableContent}} 
						/>
						<ul className='no-list-indent editable-products-check'>
							{beneEditList.map((bene, index) => (
								<li>
									<span dangerouslySetInnerHTML={{__html: bene.benefitName + " (" + bene.productType + ")"}} />
								</li>
							))}
						</ul>
						
						<div class="mar-top-25" 
							dangerouslySetInnerHTML={{__html: summaryModal[modalType].modalAdditionalProps.nonEditableContent}} 
						/>
						<ul className='no-list-indent editable-products-ban'>
							{beneNonEditList.map((bene, index) => (
								<li>
									<span dangerouslySetInnerHTML={{__html: bene.benefitName + " (" + bene.productType + ")"}} />
								</li>
							))}
						</ul>
					</div>
				}
			/>
		}
		</>
	);
}
export default BeneEditableProductsForm;
