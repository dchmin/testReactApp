import React, {useState, useEffect, useRef, useContext} from "react";
import {StateContext} from "../Reducer";
import {appContent} from "../../../digital-beneficiary-entry";
import {getBeneFormList} from "../BeneficiaryGRSWidget";
import DownloadForm from "./DownloadForm";
import ModalWrapper from "../../commons/modal/ModalWrapper";
import ModalWidget from "../../commons/modal/ModalWidget";
import "../../../scss/beneFormDownload/beneFormDownload.scss";
//PURPOSE OF THIS FILE: TO DISPLAY LIST OF DOWNLOADABLE BENEFICIARY FORMS AND ERROR
let checkBoxSelected = false;
function BeneFormDownload(props) {
	const state = useContext(StateContext);
	const {data} = state;

	// Content
	let summaryCont = appContent.summary;
	let summaryModal = appContent.summary.modal;
	let modalType = "";

	if (data.member.shadowMode === "A") {
		modalType = "accessRestricted";
	}
	else {
		modalType = "beneForm";
	}
	let modalTitle = "",
		modalBody = "",
		modalBtns = "",
		modalSrCloseBtn = "",
		modalStartSrOnlyText="",
		modalEndSrOnlyText="";

	// States
	const [showError, setShowError] = useState(false); 
	const [show, setModalShow] = useState(false); //STATE TO CONTROL HIDE AND SHOW OF MODAL
	const [showShadowToolAccessRestrictedMessage, setShowShadowToolAccessRestrictedMessage] = useState(false);

	// References
	const selectAllRef = useRef();

	// Determine if all checkboxes are selected 
	const beneFormList = getBeneFormList();
	
	const baseUrl = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ":9080" : "");
	const benePdfUrl = data.member.benePdfUrl ? baseUrl + data.member.benePdfUrl : "";
	
	const handleCloseShadowToolAccessRestrictedMessage = () => {
		modalType = "";
		modalTitle = "";
		modalBtns = "";
		modalBody = "";
		modalSrCloseBtn = "";
		modalStartSrOnlyText="",
		modalEndSrOnlyText="";
		setShowShadowToolAccessRestrictedMessage(false);
	};
	const getModalBodyData = (modalType) => {
		modalTitle = summaryModal[modalType].modalTitle;
		modalBody = summaryModal[modalType].modalBody;
		modalBtns = summaryModal[modalType].modalBtns;
		modalSrCloseBtn = summaryModal[modalType].modalCloseText;
		modalStartSrOnlyText=summaryModal[modalType].modalStartSrOnlyText;
		modalEndSrOnlyText=summaryModal[modalType].modalEndSrOnlyText;
	};
	const handleShowShadowToolAccessRestrictedMessage = () => {
		setShowShadowToolAccessRestrictedMessage(true);
	};
	
	// -----------FORM DOWNLOAD HANDLING ---------------- (STARTS)
	const handleDownloadForm = () => {
		let form = document.getElementById("productForm");
		form.submit();
	}
	// -----------FORM DOWNLOAD HANDLING ---------------- (STARTS)

	// -----------MODAL HANDLING ---------------- (STARTS)
	const handleClose = () => {		
		// Clear state and close modal
		checkBoxSelected = false;
		setShowError(false);
		setModalShow(false);
	};
	
	const ylwClk = () => {
		if (checkBoxSelected) {
			handleDownloadForm();
			setShowError(false);
		}
		else {
			setShowError(true);
			selectAllRef.current.focus();
		}
	};

	const handleShow = () => {
		// if only one product just make call for download
		if (beneFormList.length === 1) {
			handleDownloadForm();
		}
		else {
			setModalShow(true);
		}
	}

	const onModalOpen = () => {
		// JAWS 2019 - workaround for issue not reading inputs in dialog - START
		const ele = document.getElementById("beneModal_beneForm");
		if (ele) {
			ele.setAttribute("role", "");
			ele.querySelector(".modal-dialog").setAttribute("role", "dialog");
		}
		// JAWS 2019 - workaround for issue not reading inputs in dialog - END
	}
	// -----------MODAL HANDLING ---------------- (ENDS)
	
	const handleCheckBoxChange = (checkBoxList) => {
		let selectedValues = Object.keys(checkBoxList).filter((key, index) => checkBoxList[key]);
		if (selectedValues.length > 0) {
			checkBoxSelected = true;
			setShowError(false);
		}
		else {
			checkBoxSelected = false;
		}
	}

	useEffect(() => {
		const formBtn = document.querySelectorAll("[data-react-modal='beneForm'");
		const formBtnAry = [...formBtn];

		if (data.member.shadowMode === "A") {
			formBtnAry.forEach((ele, indx) => ele.addEventListener("click", function(event){
				handleShowShadowToolAccessRestrictedMessage();
				event.preventDefault();
			}));
		}
		else if (benePdfUrl) {
			// Static PDF
			formBtnAry.forEach((ele, indx) => {
				ele.setAttribute("href", benePdfUrl);
				ele.setAttribute("target", "_blank");
				ele.setAttribute("aria-label", `${ele.text.trim()} ${summaryCont.newWindowSrText}`);
			});
		}
		else {
			// Dynamic PDF
			formBtnAry.forEach((ele, indx) => ele.addEventListener("click", function(event){
				handleShow();
				event.preventDefault();
			}));

			// One downloadable product
			if (beneFormList.length === 1) {
				formBtnAry.forEach((ele, indx) => {
					ele.setAttribute("aria-label", `${ele.text.trim()} ${summaryCont.newWindowSrText}`);
				});
			}
		}
	}, []);
	

	// Display Access restricted message if launching from Advisor shadow tool
	// Don't display modal if: 
	// 1) No products have beneficiary form download. OR 
	// 2) There's only one product, so download the form directly 
	// 3) Static PDF. No need to render the <DownloadForm>
	if (data.member.shadowMode === "A") {
		getModalBodyData(modalType);
		return (
			<ModalWidget
			displayModal={showShadowToolAccessRestrictedMessage}
			modalType={modalType}
			modalTitle={modalTitle}
			modalBody={modalBody}
			modalBtns={modalBtns}
			srOnlyCloseBtn={modalSrCloseBtn}
			handleClose={handleCloseShadowToolAccessRestrictedMessage}
			modalId={'beneModal_' + modalType}
			modalLnkBtnClk={handleCloseShadowToolAccessRestrictedMessage}
			modalYlwBtnClk={handleCloseShadowToolAccessRestrictedMessage}
			modalStartSrOnlyText={modalStartSrOnlyText}
			modalEndSrOnlyText={modalEndSrOnlyText}
			/>
		);
	}
	else if (beneFormList.length <= 0 || benePdfUrl) {
		return null;
	} 
	else if (beneFormList.length === 1) {
		return (
			<DownloadForm />
		);
	}

	// At least two products have beneficiary form download - Display modal
	return (
		<ModalWrapper
			ylwClk={ylwClk}
			show={show}
			modalType={modalType}
			handleClose={handleClose}
			handleOnShow={onModalOpen}
			modalLnkBtnClk={handleClose}
			disableBackdropClick={true}
			modalBodyJsx={
				<DownloadForm
					ref={selectAllRef}
					onCheckBoxListChange={handleCheckBoxChange}
					showError={showError}
				/>
			}
		/>
	);
}
export default BeneFormDownload;
