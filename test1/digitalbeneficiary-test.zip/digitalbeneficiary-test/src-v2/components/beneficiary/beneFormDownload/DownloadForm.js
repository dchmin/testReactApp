import React, {useState, useEffect, useRef, useContext} from "react";
import {StateContext} from "../Reducer";
import {appContent} from "../../../digital-beneficiary-entry";
import {getBeneFormList} from "../BeneficiaryGRSWidget";
import Checkbox from "../../commons/Checkbox";
import "../../../scss/beneFormDownload/beneFormDownload.scss"; 
// PURPOSE OF THIS FILE: <form> element for the Download form modal
const DownloadForm = React.forwardRef((props, ref) => {
	const state = useContext(StateContext);
    const {data} = state;

	// Content
	let summaryCont = appContent.summary;
	let summaryModal = appContent.summary.modal;
	let modalType = "beneForm";
	let errorMsg = appContent.errors.errorSelectOption;

	// States
	const [checkBoxList, setCheckBoxList] = useState({});	

	// Determine if all checkboxes are selected 
	const beneFormList = getBeneFormList();
	const multiProducts = beneFormList.length >= 2;
	let checkedValue = Object.keys(checkBoxList).filter((key, index) => checkBoxList[key]);	// List of selected products
	const isAllChecked = checkedValue.length === beneFormList.length;
	
	const baseUrl = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ":9080" : "");
	const postUrl = baseUrl + data.member.benePdfActionUrl;
	
	const formStyle = multiProducts ? "" : "beneFormHidden"
	
	// -----------CHECKBOX HANDLING ---------------- (START)
	const handleChange = (key, e) => {
		let newCheckBoxList = {...checkBoxList}
		newCheckBoxList[key] =  e.target.checked;
		setCheckBoxList(newCheckBoxList);
		// Inform parent that checkbox has changed
		props.onCheckBoxListChange(newCheckBoxList);
	}

	const handleSelectAll = (e) => {
		let newCheckBoxList = {};
		beneFormList.forEach((bene, index) => {
			newCheckBoxList[bene.planNumberList] = e.target.checked
		});
		setCheckBoxList(newCheckBoxList);
		// Inform parent that checkbox has changed
		props.onCheckBoxListChange(newCheckBoxList);
	}
	
	return (
		<form method="post" id="productForm" action={postUrl} className={formStyle} target="_blank">
			<fieldset>
				{multiProducts &&
					<legend>{summaryModal[modalType].modalAdditionalProps.topContent}</legend>
				}
				<div
					className={
						props.showError
							? "parsley-error"
							: ""
					}>
				
				<input
					ref={ref}
					id={"bene-form-all"}
					checked={isAllChecked} 
					onChange={handleSelectAll}
					name="beneFormDownload"
					type='checkbox'
					aria-describedby={props.showError ? "form-select-error": null}
					aria-invalid={props.showError ? "true" : null}
				/>
				<label htmlFor={"bene-form-all"}>
					{summaryCont.selectAll}
				</label> 
		
				<hr class="soft-separator mar-top-10 mar-bottom-5" />
				{beneFormList.map((bene, index) =>
					<Checkbox 
						id={"plan_" + bene.planNumberList}
						value={bene.planNumberList}
						checked={multiProducts ? checkBoxList[bene.planNumberList] : true}
						onChange={(e) => handleChange(bene.planNumberList, e)}
						label={bene.planName}
						name="planNumberList"
						aria-describedby={props.showError ? "form-select-error": null}
						aria-invalid={props.showError ? "true" : null}
					/>
				)}
				</div>
			</fieldset>					
			{props.showError && (
				<div id="form-select-error" 
					className="field-set-validation-errors no-mar-bottom"
					dangerouslySetInnerHTML={{__html: errorMsg }} />
			)}
			{multiProducts && summaryModal[modalType].modalAdditionalProps.bottomContent && 
				<div class="mar-top-25" 
					dangerouslySetInnerHTML={{__html: summaryModal[modalType].modalAdditionalProps.bottomContent}} 
				/>
			}
		</form>
	);
});
export default DownloadForm;
