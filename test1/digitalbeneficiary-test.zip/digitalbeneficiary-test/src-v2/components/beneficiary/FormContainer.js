import React, {useState, useContext, useEffect} from "react";
import {StateContext, DispatchContext} from "./Reducer";
import {Form} from "react-final-form";
import {FieldArray} from "react-final-form-arrays";
import arrayMutators from "final-form-arrays";
import {appContent, appLob} from "../../digital-beneficiary-entry";
import LoaderSpinner from "../commons/LoaderSpinner";
import TotalAllocationStatus from "./editForm/TotalAllocationStatus";
import TotalAllocationError from "./editForm/TotalAllocationError";
import ButtonLink from "../commons/ButtonLink";

import {
	setInputData,
	getInputData,
	setFormInstances,
	getContingencyCheck,
	getValuesAsPerRelation,
	setDesignationSelect,
	setContingencyCheck,
	getCurrentdate,
	getFormInstances,
	checkSession,
	getOriginalFormInstance,
} from "../../helpers";
// import ExistingForm from "./ExistingForm"; //THIS IS KEPT IN CASE INITIAL FORM DATA NEEDS TO BE LOADED - MAY NEED FOR GRS
import FormFields from "./FormFields";
import TrusteeFormField from "./TrusteeFormField/TrusteeFormField";
import ModalWidget from "../commons/modal/ModalWidget";
import AddButton from "../commons/AddButton";
import MaxBeneWarning from "../commons/MaxBeneWarning";
import axios from "axios";
import {
	saveMbrportalUrl,
	saveGBME2Url,
	saveGBMEUrl,
	errorUrl,
	timeoutUrl,
} from "../commons/dBeneContent";
import "../../scss/edit-form.scss";
import {collectDataAndSubmit, checkProductLevelErrors} from "./BeneGRSSubmitData";

//****************PURPOSE OF THIS FILE: PARENT TO REACT-FINAL-FORMS****************//
// SET MODAL TYPE AND MODAL BODY SO THAT ONE INSTANCE OF MODAL CAN BE REUSED - (STARTS)
let modalType = "",
	modalTitle = "",
	modalBody = "",
	modalBtns = "",
	lang = document.getElementsByTagName("HTML")[0].lang;
// SET MODAL TYPE AND MODAL BODY SO THAT ONE INSTANCE OF MODAL CAN BE REUSED - (ENDS)

// KEEPING ALL INSTANCES OF FORMS SO THAT THEY CAN BE VALIDATED TOGETHER - (STARTS)
let forms = {};
const setForm = (formName) => (form) => {
	forms[formName] = form;
	setFormInstances(forms);
};
// KEEPING ALL INSTANCES OF FORMS SO THAT THEY CAN BE VALIDATED TOGETHER - (ENDS)
let allFormData = [];

function FormContainer(props) {
	let editContent = appContent.edit,
		successContent = appContent.summary,
		notepadContent = appContent.notepad,
		{submitClick} = props;
	const dispatch = useContext(DispatchContext), //TO NAVIGATE TO OTHER PAGE
		[show, setModalShow] = useState(false), //STATE TO CONTROL HIDE AND SHOW OF MODAL
		[confirmCheck, setConfirmCheck] = useState(false), //STATE TO CONTROL HIDE AND SHOW OF MODAL
		[modalSubmit, setModalSubmit] = useState(false),
		[showLoader, setShowLoader] = useState(false),
		[totalAllocationVal, setTotalAllocationVal] = React.useState(false), //TOTAL ALLOCATION
		[deleteFirstField, setDeleteFirstField] = useState(false), //THE FIRST FIELD IS DONE SEPARATELY BECAUSE INITIAL APPROACH WAS TAKEN TO LOAD WITH EXISTING DATA
		[deleteFirstFielfOfForm, setDeleteFirstFielfOfForm] = useState(""),
		[firstTime, setFirstTime] = useState(false),
		[headerFocusIndex, setHeaderFocusIndex] = useState(null); //COMMUNICATES WITH FIELD ARRAY ON WHERE FOCUS SHOULD BE AFTER REMOVE/ADD INTERACTION

	let [beneCount, setBeneCount] = useState(1); //SET THE BENEFICIARY COUNT TO HIDE AND SHOW "REMOVE" BUTTON
	const state = useContext(StateContext),
		{data} = state,
		benefitList = data !== "" ? data.member.benefitList : "";
	let storedVal = getInputData();
	let context = data.context;

	// LOB display settings
	const isGRS = appLob === "GRS";
	const useCheckSession = appLob !== "GRS";
	const showExtraSpace = appLob !== "GRS";
	const allocationMaxVal = appLob !== "GRS" ? 99.99 : 100.00;
	const isTrusteeForm = props.formName.match(/trustee/g);

	const handleClose = () => {
		if (modalType === "confirmation") {
			checkSession(context);
			setModalSubmit(false);
		}
		setModalShow(false);
	}; //CLOSE MODAL
	// if (storedVal !== null) console.log("OUT HERE", storedVal);
	const callbackIAgree = (val) => setConfirmCheck(val);
	const getModalBodyData = (modalType) => {
		let editModal = editContent.modal;
		// if (typeof modalType !== "string") modalType = "summary";
		modalTitle = editModal[modalType].modalTitle;
		modalBody = editModal[modalType].modalBody;
		modalBtns = editModal[modalType].modalBtns;
	};
	//SET SHOW MODAL STATE - (STARTS)
	const handleShow = (typeOfModal) => {
		if (typeOfModal === "mousedown" || typeof typeOfModal !== "string")
			typeOfModal = "cancel";
		if (useCheckSession && typeOfModal === "cancel") checkSession(context);
		modalType = typeOfModal;
		getModalBodyData(typeOfModal); //DELEGATING FUNCTION
		setModalShow(true);
	};
	//SET SHOW MODAL STATE - (ENDS)

	// EACH FORM VALIDATION - STARTS
	const formArrayValidate = (values) => {};
	// EACH FORM VALIDATION - ENDS

	//DEFECT 57
	if (getFormInstances() === null) forms = {};

	const onSubmit = (values) => {};
	const handleSubmitAllForms = (callNum) => {
		// Save current form initial data 
		// so when user comes back to the page the form will be intitialized with the values they entered
		setInputData(null);
		let formsData = {};		
		Object.keys(forms).map((form, index) => {
			let assignVal = {
				[form]: forms[form].getState().values,
			};
			let newInitial = assignVal[form];
			if (newInitial.newFieldArray) {
				let newForm = newInitial.newFieldArray.map((bene, index) => {
					return {...bene, existing: true};
				});
				newInitial.newFieldArray = newForm;
			}
			else if (newInitial && !newInitial.initialFieldArray) {
				//If user has added empty form make sure it still there when form is reinitialized
				newInitial.initialFieldArray = [{existing: true}];
			}
			assignVal[form] = newInitial;
			Object.assign(formsData, assignVal);
		});
		setInputData(formsData);

		if (useCheckSession) checkSession(context);
		let arrayToCheckValidForms = [],
			errorCount = 0;
		//SUBMITTING EACH FORM TO GET THEIR STATE
		Object.keys(forms).map((form, index) => {
			let formInstance = forms[form];
			formInstance.submit();
			let formState = formInstance.getState();

			//IF FORM IS INVALID, ADD ERROR COUNTS
			// console.log(formState);
			if (!formState.valid) {
				// Object.keys(formState.errors).map((eachBene, index) => {
				// 	let eachBeneError = formState.errors[eachBene];
				// 	Object.values(eachBeneError).map((eachBeneIndex, i) => {
				// 		errorCount =
				// 			errorCount +
				// 			(eachBeneIndex !== undefined &&
				// 				Object.keys(eachBeneIndex).length);
				// 	});
				// });
				errorCount += formFieldErrorCount(formState, form);
				arrayToCheckValidForms.push(formState.valid); //CHECKING IF EACH FORM IS VALID
			}
			// else {
			// 	//IF FORM IS VALID, CHECK IF ADDITION IS EQUAL TO 100
			// 	if (displayFormTotalAlloc(formState.values) !== 100) {
			// 		arrayToCheckValidForms.push(false); //CHECKING IF EACH FORM IS VALID
			// 	} else {
			// 		arrayToCheckValidForms.push(true); //CHECKING IF EACH FORM IS VALID
			// 	}
			// }
		});

		// Validate GRS product level errors
		let productError = {};
		if (isGRS) {
			if (callNum === 1) return true; //don't update the error counter till submitclick is rerendered
			const grsProductError = checkProductLevelErrors(forms);
			productError = grsProductError.productError;
			errorCount += grsProductError.errorCount + props.termsConditionsErrorCount;	
		}

		if (isGRS && errorCount > 0) { // GRS has error count in combination with product level errors
			props.productLevelError(productError);
			props.errorCount(errorCount);
		}
		else if (appLob === "GB" && arrayToCheckValidForms.includes(false)) {
			//NO MODAL AND NO API CALL
			// SEND CALL BACK TO SET ERROR COUNT
			props.errorCount(errorCount);
		} else {
			if (callNum === 1) setFirstTime(true);
			else {
				// console.log(callNum, arrayToCheckValidForms.includes(false));
				props.errorCount(0);
				if (appLob === "GRS") {
					props.setExistingFormErrorCount(0);
					collectDataAndSubmit(forms, data, dispatch);
				}
				else {
					handleShow("confirmation");
				}
			}
		}
	};
	const existingFormValidation = () => {
		let errorCount = 0;
		// Validate form if contain existing data from server that needs to be corrected
		if (storedVal !== null && storedVal[props.formName] !== undefined) {
			let currentForm = storedVal[props.formName];
			if (currentForm.newFieldArray !== undefined || currentForm.trustee !== undefined) {
				let formInstance = forms[props.formName]
				formInstance.submit();

				let formState = formInstance.getState();
				
				//IF FORM IS INVALID, ADD ERROR COUNTS
				if (!formState.valid) {
					errorCount = formFieldErrorCount(formState, props.formName);
					props.setExistingFormErrorCount(errorCount)
				}
			}
		}
	}
	// COUNT NUMBER OF INVALID FIELD IN ERROR STATE
	const formFieldErrorCount = (formState, formName) => {
		let errorCount = 0;
		Object.keys(formState.errors).map((eachBene, index) => {
			let eachBeneError = formState.errors[eachBene];
			
			if (formName.match(/trustee/g)) {
				Object.values(eachBeneError).map((eachBeneIndex, i) => {
					errorCount = errorCount + 1;
				});
			}
			else {
				Object.values(eachBeneError).map((eachBeneIndex, i) => {
					errorCount =
						errorCount +
						(eachBeneIndex !== undefined &&
							Object.keys(eachBeneIndex).length);
				});
			}
		});
		return errorCount;
	}
	//NAVIGATE TO RELEVANT PAGE WHEN CONFIRMED ON MODAL - (STARTS)
	const navigatePage = (navType) => {
		let pageFlowName = "";
		if (isGRS) pageFlowName = "pageCancelled"; //LOB GRS toggles between view and edit. The focus will go to header
		dispatch({
			type: "UPDATE_UI",
			pageFlow: navType === "summary" ? pageFlowName : "pageFlowOptions",
			displayMode: "view",
		});
	};
	//NAVIGATE TO RELEVANT PAGE WHEN CONFIRMED ON MODAL - (ENDS)
	const createPostData = () => {
		let notepadData = editContent.effective + getCurrentdate() + " </br>";
		let relationshipList = editContent.relationshipDropdownList;
		if (props.pageFlow === "byBenefits") delete forms.allFlow;
		if(!getContingencyCheck()) delete forms.contingencyFlow; //destroy contingent bene form if box unchecked
		Object.keys(forms).map((form, index) => {
			let eachFormValue = forms[form].getState().values;
			// if (props.pageFlow === "allBenefits") {
			if (props.pageFlow === "allBenefits") {
				notepadData +=
					form === "contingencyFlow"
						? notepadContent.contingentAllBene
						: notepadContent.allBene;
			} else {
				notepadData +=
					form === "contingencyFlow"
						? notepadContent.contingentAllBene
						: benefitList[
								Number(form.slice(-1))
						  ].benefitName.toUpperCase() + "</br>";
			}
			Object.keys(eachFormValue).map((type, index) => {
				if (type === "initialFieldArray") {
					let initialVal = eachFormValue[type][0];
					let relation = initialVal.relationship;
					notepadData += getValuesAsPerRelation(
						initialVal,
						relation,
						relationshipList,
						data.member.quebec,
						notepadContent
					);
				}
				if (type === "newFieldArray") {
					let allNewVal = eachFormValue[type];
					Object.keys(allNewVal).map((eachNew, i) => {
						let newVal = allNewVal[eachNew];
						let relation = newVal.relationship;
						notepadData += getValuesAsPerRelation(
							newVal,
							relation,
							relationshipList,
							data.member.quebec,
							notepadContent
						);
					});
				}
			});
			// }
		});
		let urlLogo =
			document.getElementById("TEMPLATE2015_WEBLOGOLEFT") !== null
				? document
						.getElementById("TEMPLATE2015_WEBLOGOLEFT")
						.getElementsByTagName("img")[0].src
				: document.getElementById("brandingleftlogo") !== null
				? document
						.getElementById("brandingleftlogo")
						.getElementsByTagName("img")[0].src
				: "";
		let postData = {
			memberId: data.member.memberId,
			contractNumber: data.contractNumber,
			notepadDetails: {
				notepadId:
					data.member.notepadDetails.notepadId === undefined
						? 0
						: data.member.notepadDetails.notepadId,
				notepadData: notepadData,
			},
			member: data.member,
			pdfDetails: {
				logoURL: urlLogo,
				successHeader: successContent.successHeader,
				successDesc: successContent.successDesc,
				beneSummaryHeader: successContent.summaryHead,
				yourBenefitsHeader: successContent.benefitHead,
				yourBeneficiaryDesignationHeader:
					successContent.currentBenefitHead,
				termsAndConditionHeader: successContent.successTermsHeader,
				successTnC:
					"<p>" +
					successContent.successTermsAgreed +
					"</p>" +
					successContent.successTerms,
				ocbDesc: editContent.disclaimer,
			},
		};
		// delete postData.member.notepadDetails;
		return postData;
	};
	const postBeneDetails = () => {
		setShowLoader(true);
		const postData = createPostData();
		// console.log(
		// 	"%c" + JSON.stringify(postData),
		// 	"background: #222; color: #bada55"
		// );
		let relUrl;
		//LOGIC UPDATED AFTER GB_ME2 INCLUSION - 11 Aug 2020
		if (data.context === "gb_me" || data.context === "GB_ME")
			relUrl = saveGBMEUrl;
		else if (data.context === "gb_me2" || data.context === "GB_ME2")
			relUrl = saveGBME2Url;
		else relUrl = saveMbrportalUrl;
		let url = window.location.origin + relUrl,
			httpClient = axios.create();
		httpClient.defaults.timeout = 30000;
		httpClient
			// .get(url)
			.post(url, postData, {
				headers: {
					"Content-Type": "application/json;charset=utf-8",
				},
			})
			.then(function (response) {
				// console.log(response);
				if (response.status === 200) {
					setShowLoader(false);
					if (typeof response.data === "string")
						window.location.href =
							window.location.origin + timeoutUrl;
					else if (response.data.responseCode === 0) {
						response.data.digitalBeneficiaryResponse.success = true;
						response.data.digitalBeneficiaryResponse.member =
							postData.member;
						response.data.digitalBeneficiaryResponse.member.notepadDetails.notepadData =
							postData.notepadDetails.notepadData;
						setInputData(null);
						setFormInstances(null);
						setDesignationSelect(null);
						setContingencyCheck(null);
						forms = {};
						dispatch({
							type: "UPDATE_DATA",
							data: response.data.digitalBeneficiaryResponse,
						});
						props.serviceFailed(false);
						navigatePage("summary");
					} else {
						//ERROR HANDLING SCENARIO
						handleClose();
						props.serviceFailed(true);
					}
					// window.location.href =
					// 	window.location.origin + errorUrl;
				} else window.location.href = window.location.origin + errorUrl;
			})
			.catch(function (error) {
				// handle error
				//URL FROM dbeneContent.js
				// window.location.href = window.location.origin + errorUrl;
				setShowLoader(false);
				handleClose();
				props.serviceFailed(true);
			});
	};
	//MODAL CONFIRMATION BTN CLICK (MOSTLY YELLOW) - (STARTS)
	const ylwClk = () => {
		if (modalType === "confirmation") {
			checkSession(context);
			setModalSubmit(true);
			if (confirmCheck) {
				if (data.impersonated) {
					alert(editContent.impersonated);
					// handleClose;
					// handleShow("impersonate");
				} else postBeneDetails();
				// SUBMIT
			}
		} else {
			handleClose;
			if (appLob === "GRS") {
				// Reset data to original page load
				let originalFormInstance = JSON.parse( getOriginalFormInstance() ); //Create a deep copy
				setInputData(originalFormInstance);
				setFormInstances(originalFormInstance);
			}
			else {
				// Clear form on cancel
				setInputData(null);
				setFormInstances(null);
			}
			setDesignationSelect(null);
			setContingencyCheck(null);
			forms = {};
			navigatePage("summary");
		}
	};
	//MODAL CONFIRMATION BTN CLICK (MOSTLY YELLOW) - (ENDS)

	//PREVIOUS BUTTON CLICK HANDLING - SETTING STORED VALUE IN HELPER.JS (CONTEXT HAD AN ISSUE WHILE GETTING THE DATA) - (STARTS)
	const collectInputData = () => {
		setInputData(null);
		let formsData = {};
		Object.keys(forms).map((form, index) => {
			let assignVal = {
				[form]: forms[form].getState().values,
			};
			Object.assign(formsData, assignVal);
		});
		allFormData = formsData;
		setInputData(allFormData);
		return true;
	};
	const handlePreviousCall = () => {
		checkSession(context);
		if (collectInputData()) navigatePage("prev");
	};
	//PREVIOUS BUTTON CLICK HANDLING - SETTING STORED VALUE IN HELPER.JS (CONTEXT HAD AN ISSUE WHILE GETTING THE DATA) - (ENDS)

	//CALCULATE THE SUM OF THE ALLOCATION INPUT BOX - (STARTS)
	const checkFrenchAlloc = (alloc) => {
		if (alloc.indexOf(",") > -1) {
			return Number(
				alloc.substr(0, alloc.indexOf(",")) +
					"." +
					alloc.substr(alloc.indexOf(",") + 1)
			);
		} else return Number(alloc);
	};
	const displayFormTotalAlloc = (values) => {
		if (values) {
			let totalAlloc = 0;
			let initialArray =
				values.initialFieldArray === undefined
					? ""
					: values.initialFieldArray;
			let newArray =
				values.newFieldArray === undefined ? "" : values.newFieldArray;
			// FRENCH ENTRY FIELD HAS DIFFERENT REQUIREMENT IN RD - PICKING UP LATE
			if (lang === "en" || lang === "en-CA") {
				if (
					initialArray[0] !== undefined &&
					!isNaN(Number(initialArray[0]["allocation"]))
				)
					totalAlloc = Number(initialArray[0]["allocation"]);
				if (newArray !== "") {
					newArray.map((eachArray, index) => {
						if (eachArray !== undefined) {
							totalAlloc =
								totalAlloc +
								(isNaN(Number(eachArray.allocation))
									? 0
									: Number(eachArray.allocation));
						}
					});
				}
			} else {
				// FRENCH ENTRY FIELD HAS DIFFERENT REQUIREMENT IN RD - PICKING UP LATE
				if (
					initialArray[0] !== undefined &&
					initialArray[0]["allocation"] !== undefined
				) {
					let alloc = initialArray[0]["allocation"];
					totalAlloc =
						totalAlloc +
						(alloc !== undefined ? checkFrenchAlloc(alloc) : 0);
				}
				if (newArray !== "") {
					newArray.map((eachArray, index) => {
						if (eachArray !== undefined) {
							let alloc = eachArray.allocation;
							totalAlloc =
								totalAlloc +
								(alloc !== undefined
									? checkFrenchAlloc(alloc)
									: 0);
						}
					});
				}
			}
			setTotalAllocationVal(Number(totalAlloc.toFixed(2)));
			return Number(totalAlloc.toFixed(2));
		}
	};
	const totalAllocStyle = () => {
		// Update the colour style
		let cssStyle = "";
		if (appLob === "GRS") {
			if (totalAllocationVal === 100.00) {
				cssStyle = "text-green";
			}
			else if (totalAllocationVal > 100.00) {
				cssStyle = "text-burgundy"
			}
		}
		return cssStyle;
	}
	//CALCULATE THE SUM OF THE ALLOCATION INPUT BOX - (ENDS)
	
	const updateMinorCount = (updatedBeneCount = beneCount) => {
		if (data.member.quebec && appLob === "GRS") props.minorChange(props.formName, 0, updatedBeneCount);
		if (data.member.quebec || appLob !== "GRS") {
			return;
		}
		
		let minorCount = 0;
		
		let initialArray = "";
		if (getFormInstances() !== null &&
			forms[props.formName].getState().values.initialFieldArray !== undefined) {
			initialArray = forms[props.formName].getState().values.initialFieldArray;
		}
		
		let newArray = "";
		if (getFormInstances() !== null &&
			forms[props.formName].getState().values.newFieldArray !== undefined) {
			newArray = forms[props.formName].getState().values.newFieldArray;
		}
		
		if (initialArray[0] !== undefined) {
			if (initialArray[0]["relationship"] !== undefined && initialArray[0]["relationship"].match("^4.") && initialArray[0]["minorSelection"] === "yes") {
				minorCount++;
			}
		}
		
		if (newArray !== "") {
			newArray.map((eachArray, index) => {
				if (eachArray !== undefined) {
					if (eachArray.relationship !== undefined && eachArray.relationship.match("^4.") && eachArray.minorSelection === "yes") {
						minorCount++;
					}
				}
			});
		}

		// Inform parent about changes in minor counts
		props.minorChange(props.formName, minorCount, updatedBeneCount);
	};

	//REMOVE ERRORS RECORDED ON CONTINGENCY FORM AFTER REMOVING CONTINGENCY FORM - (STARTS)
	const removeContingencyError = () => {
		Object.keys(forms).map((form, index) => {
			let formInstance = forms[form];
			let formState = formInstance.getState();
			if (formState.errors.contingencyFlowinitialFieldArray !== undefined)
				delete formState.errors.contingencyFlowinitialFieldArray;
		});
		delete forms.contingencyFlow;
		// collectInputData();
	};
	const handleContingentRemove = () => {
		if ((props.formName === "contingencyFlow" || props.formName.match(/secondary/g)) && beneCount === 1) {
			if (isGRS) delete forms[props.formName];
			removeContingencyError();
			props.removeContingencyCheck();
		}
	};
	//REMOVE ERRORS RECORDED ON CONTINGENCY FORM AFTER REMOVING CONTINGENCY FORM - (ENDS)
	//UPDATE FOCUS WHEN A FIELD SECTION IS REMOVED OR ADDED - (STARTS)
	const handleRemoveBtnFocusNewFieldAry = (index) => {
		let form = forms[props.formName] ? forms[props.formName].getState().values : {};
		if (form.initialFieldArray && beneCount === 2) {
			setHeaderFocusIndex({
				index: -1,
				increment: -1
			});
		} 
		else if (form.initialFieldArray ) {
			setHeaderFocusIndex({
				index: index + 1,
				increment: 1
			});
		}
		else {
			setHeaderFocusIndex({
				index: index,
				increment: 0
			});
		}
	}
	const handleRemoveBtnFocusInitialAry = (index) => {		
		setHeaderFocusIndex({
			index: index,
			increment: 0,
			initial: false
		});
	}
	const handleAddBtnFocus = () => {
		let form = forms[props.formName].getState().values;
		if (form.initialFieldArray ||
			(appLob === "GB" && 
				getInputData() === null && 
				form.newFieldArray && 
				form.newFieldArray.length !== beneCount + 1 )) {
			// Has an Initial form preloaded
			setHeaderFocusIndex({
				index: beneCount,
				increment: 1
			});
		}
		else {
			// No intial bene form (due to user removing it if it existed)
			setHeaderFocusIndex({
				index: beneCount,
				increment: 0
			});
		}
	}
	//UPDATE FOCUS WHEN A FIELD SECTION IS REMOVED OR ADDED - (ENDS)

	//DEFECT - 52
	const checkInitial = (formName) => {
		let initialArrayDeleted = false;
		// Object.keys(forms).map((form, index) => {
		if (
			getFormInstances() !== null &&
			forms[formName].getState().values.initialFieldArray === undefined
		)
			initialArrayDeleted = true;
		// });
		if (initialArrayDeleted) return 0;
		else return 1;
	};
	useEffect(() => {
		if (
			getContingencyCheck() === false &&
			forms.contingencyFlow !== undefined
		)
			removeContingencyError();
		// ------- ON OLD DATA LOAD, SET BENE COUNT TO HIDE/SHOW "REMOVE" BUTTON --- (STARTS)
		if (storedVal !== null && storedVal[props.formName] !== undefined) {
			let currentForm = storedVal[props.formName];
			let initialArrayCount = checkInitial(props.formName),
				// currentForm.initialFieldArray !== undefined
				// 	? 1
				// 	: checkInitial(),
				newArrayCount =
					currentForm.newFieldArray !== undefined
						? Object.keys(currentForm.newFieldArray).length
						: 0;
			setBeneCount(initialArrayCount + newArrayCount);
		}
		// ------- ON OLD DATA LOAD, SET BENE COUNT TO HIDE/SHOW "REMOVE" BUTTON --- (STARTS)
		if (appLob === "GRS") {
			existingFormValidation(); //Validate form if contain existing data from server that needs to be corrected
		}
	}, []);

	useEffect(() => {
		// Focus on the Add button if last newFieldAry form is removed
		let addBtnEle = document.getElementById(`${props.formName}-addBeneBtn`);
		if (headerFocusIndex && headerFocusIndex.index === -1 && addBtnEle) {
			document.getElementById(`${props.formName}-addBeneBtn`).focus();
		}

		// Focus on the main primary/secondary header if initialFieldAry form is removed
		if (headerFocusIndex && headerFocusIndex.initial === false) {
			const primaryHeader = document.getElementById(`${props.formName}-primaryHeading`);
			const secondaryHeader = document.getElementById(`${props.formName}-secondaryHeading`);
			
			if (props.formName.match(/secondary/g) && secondaryHeader) {
				secondaryHeader.focus();
			}
			else if (primaryHeader) {
				primaryHeader.focus();
			}
		}

	}, [headerFocusIndex]);

	return (
		<div className='bene-each-item'>
			<Form
				onSubmit={onSubmit}
				validate={(values) => formArrayValidate(values)}
				initialValues={
					storedVal !== null ? storedVal[props.formName] : ""
				}
				subscription={{
					submitting: true,
					pristine: true,
					values: true,
				}}
				mutators={{
					setValue: ([field, value], state, {changeValue}) => {
						changeValue(state, field, () => value);
					},
					setOnBlurNameError: ([field, errorMsg], state) => {
						const { fields } = state;
						let fieldState = fields[field];

						if (errorMsg !== undefined) {
							fieldState.data.error = errorMsg;
						}
						else {
							fieldState.data.error = undefined;
						}						
					},
					...arrayMutators,
				}}
				setForm={setForm(`${props.formName}`)}
				render={({
					handleSubmit,
					form: {
						mutators: {push, pop},
					}, // injected from final-form-arrays above
					form,
					values,
					errors,
					setForm,
				}) => {
					if (!window.setFormValue)
						window.setFormValue = form.mutators.setValue;
					window.cancel = handleShow;
					window.previous = handlePreviousCall;
					window.startValidate = handleSubmitAllForms;
					setForm(form);
					//DEFECT 52
					if (
						storedVal !== null &&
						storedVal[props.formName] !== undefined &&
						Object.keys(storedVal[props.formName]).length !== 0 &&
						storedVal[props.formName].initialFieldArray ===
							undefined
					) {
						setDeleteFirstField(true);
						setDeleteFirstFielfOfForm(props.formName);
					}
					// console.log(form);
					// console.log(form);
					return (
						<form onSubmit={handleSubmit}>
							{/* <FieldArray
									name='existingBeneficiaries'
									component={ExistingForm} //USE THIS IN CASE INITIAL DATA NEEDS TO BE LOADED
								/> */}
							{isTrusteeForm ||
							(deleteFirstField &&
							deleteFirstFielfOfForm === props.formName) ? null : (
								<FieldArray
									name='initialFieldArray'
									index='no_ind'
									component={FormFields}
									beneCount={beneCount}
									productCategory={props.productCategory}
									formName={props.formName}
									updateMinorCount={updateMinorCount}
									totalAlloc={
										totalAllocationVal === 100 ||
										totalAllocationVal === allocationMaxVal
											? true
											: false
									}
									remove={(ind, deleteFrom) => {
										delete form.getState().values
											.initialFieldArray; //DEFECT - 63
										// delete form.getState().errors
										// 	.initialFieldArray;
										setBeneCount(beneCount - 1);
										setDeleteFirstField(true);
										setDeleteFirstFielfOfForm(deleteFrom);
										updateMinorCount(beneCount - 1);
										handleContingentRemove();										
										handleRemoveBtnFocusInitialAry(0);
									}}
									beneId={props.formName}
									submitClick={submitClick}
									headerFocusIndex={headerFocusIndex}
								/>
							)}
							{/* {!deleteFirstField &&
								deleteFirstFielfOfForm !== props.formName && (
									<FieldArray
										name='initialFieldArray'
										index='no_ind'
										component={FormFields}
										beneCount={beneCount}
										formName={props.formName}
										totalAlloc={
											totalAllocationVal === 100 ||
											totalAllocationVal === 99.99
												? true
												: false
										}
										remove={(ind, deleteFrom) => {
											delete form.getState().values
												.initialFieldArray; //DEFECT - 63
											// delete form.getState().errors
											// 	.initialFieldArray;
											setBeneCount(beneCount - 1);
											setDeleteFirstField(true);
											setDeleteFirstFielfOfForm(
												deleteFrom
											);
											handleContingentRemove();
										}}
										beneId={props.formName}
									/>
								)} */}
							{!isTrusteeForm &&
							<>
							<FieldArray name='newFieldArray'>
								{({fields}) =>
									fields.map((name, index) => {
										return (
											<FormFields
												key={`newFieldArray-${index}-${fields.length}-${props.beneId}`}
												index={index}
												// name={`${name}-${index}`}
												name={name}
												beneCount={beneCount}
												productCategory={props.productCategory}
												formName={props.formName}
												updateMinorCount={updateMinorCount}
												totalAlloc={
													totalAllocationVal ===
														100 ||
													totalAllocationVal === allocationMaxVal
														? true
														: false
												}
												remove={(ind) => {
													fields.remove(ind);
													setBeneCount(beneCount - 1);
													updateMinorCount(beneCount - 1);
													handleContingentRemove();													
													handleRemoveBtnFocusNewFieldAry(ind);
													
												}}
												beneId={
													props.beneId !== undefined
														? props.beneId
														: props.formName
												}
												//submitClick={submitClick}
												submitClick={submitClick && fields.value[index] && fields.value[index].existing} //check if field is "undefined"/existed before submit click in combination with "submitClick" instead
												initialValidate={fields.value[index] && fields.value[index].existing}
												deleteFirstField={
													deleteFirstField
												}
												headerFocusIndex={headerFocusIndex}
											/>
										);
									})
								}
							</FieldArray>
							<div className='row'>
								<div className='col-lg-12 col-md-12 col-xs-12'>
									<div className='mar-top-10 mar-bottom-20'>
										<div className='large-body'>
											{editContent.totalAllocationLabel}{showExtraSpace && " :"}{" "}
											<span className={`total-alloc ${totalAllocStyle()}`}>
												{isNaN(
													displayFormTotalAlloc(values)
												)
													? 0
													: totalAllocationVal === allocationMaxVal
													? lang === "en" ||
													lang === "en-CA"
														? "100.00"
														: "100,00"
													: totalAllocationVal.toLocaleString(
															lang,
															{
																minimumFractionDigits: 2,
																maximumFractionDigits: 2,
															}
													)}
												{appLob === "GB" 
													? " %" 
													: (appLob === "GRS" && (lang === "en" ||lang === "en-CA")) 
														? "%"
														: " %."
												}
												<span className="total-alloc-status">
													{" "}{appLob === "GRS" && <TotalAllocationStatus totalAllocationVal={totalAllocationVal} lang={lang}/>}
												</span>
											</span>
										</div>
										<TotalAllocationError totalAllocationVal={totalAllocationVal} submitClick={submitClick} />
									</div>
									<button
										type='submit'
										hidden=''
										className='invisible radio-label'
										onClick={(e) =>
											e.preventDefault()
										}></button>
									{((isGRS) ? props.showAddBtn : beneCount < 15) ? 
										<AddButton
											id={`${props.formName}-addBeneBtn`}
											value={props.addBtn || editContent.addBtn}
											onClick={(e) => {
												e.preventDefault();
												if (useCheckSession) checkSession(context);
												setBeneCount(beneCount + 1);
												push(
													"newFieldArray",
													undefined
												);
												handleAddBtnFocus();
												if (isGRS) props.updateTotalBeneCount(props.formName, beneCount + 1);
											}}
											aria-label={props.addBtnSrText}
										/>
										: <MaxBeneWarning />
									}
								</div>
							</div>							
							</>
							}
							
							{isTrusteeForm &&
								<TrusteeFormField
									name='trustee'
									formName={props.formName}
									beneCount={beneCount}
									submitClick={submitClick}
									initialValidate={props.initialValidate}
								/>
							}
							
							{/* <button
									type='button'
									onClick={() => pop("newFieldArray")}>
									Remove Last
								</button> */}

							{/* <div className='buttons'>
									<button
										type='submit'
										disabled={submitting || pristine}>
										Submit
									</button>
									<button
										type='button'
										onClick={form.reset}
										disabled={submitting || pristine}>
										Reset
									</button>
								</div>
								<pre>{JSON.stringify(values, 0, 2)}</pre> */}
							{/* </div> */}
							{/* INVISIBLE BUTTON ADDED FOR SITEIMPROVE */}
						</form>
					);
				}}
			/>
			<ModalWidget
				displayModal={show}
				modalType={modalType}
				modalTitle={modalTitle}
				modalBody={modalBody}
				modalBtns={modalBtns}
				srOnlyCloseBtn='Close'
				handleClose={handleClose}
				modalId='bene-form-container-modal'
				modalLnkBtnClk={handleClose}
				modalYlwBtnClk={ylwClk}
				confirmCheckVal={callbackIAgree}
				modalSubmit={modalSubmit}
			/>
			{showLoader && <LoaderSpinner />}
		</div>
	);
}
export default FormContainer;
