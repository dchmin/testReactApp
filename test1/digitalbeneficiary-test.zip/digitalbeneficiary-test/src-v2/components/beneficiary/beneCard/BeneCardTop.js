import React from "react";
import {appContent} from "../../../digital-beneficiary-entry";
import BeneficiaryMessages from "./BeneficiaryMessages";
import ErrorMsgContainer from "../../commons/ErrorMsgContainer";

const BeneCardTop = ({product, errorMsgs, ...props}) => {    
    const beneMsg = appContent.beneficiaryMessages;
    let beneMsgKeys = product.beneficiaryMessageKeys || [];

    // eBeneOn product messages to be shown first before others
    let eBeneOnKeys = [];
    beneMsgKeys = beneMsgKeys.filter(key => {
        if (key.match(/^ebeneOn/)) {
            eBeneOnKeys.push(key)
            return false;
        }
        return true
    });
    beneMsgKeys.unshift(...eBeneOnKeys);

    return (
        <div className='bene-card-item pad-bottom-10'>
            {/* Product name */}
            <h3>{product.benefitName} ({product.productType})</h3>

            {/* Product level error messages */}
            {errorMsgs && errorMsgs.map((msg) => (
                <ErrorMsgContainer msg={msg} />
            ))}

            {/* Product messages */}
            {beneMsgKeys.map((key, index) => (
                <BeneficiaryMessages beneMsg={beneMsg[key]} />
            ))} 
        </div>
    );
}

export default BeneCardTop;