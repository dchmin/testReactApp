import React from "react";
import {appContent} from "../../../digital-beneficiary-entry";
import InfoMsgContainer from "../../commons/InfoMsgContainer";

const BeneficiaryMessages = ({beneMsg, ...props}) => {    
    // Styled Message
    if (beneMsg.type === "info") { // Info Message
        return <InfoMsgContainer infoMsg={beneMsg} />
    }

    // No style content
    return <div className="messageContent mar-bottom-10" 
				data-automation-name="messageContent" 
                dangerouslySetInnerHTML={{__html: beneMsg.value}} />
}

export default BeneficiaryMessages;