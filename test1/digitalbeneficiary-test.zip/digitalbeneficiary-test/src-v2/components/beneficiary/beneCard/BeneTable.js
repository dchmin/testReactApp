import React, {useContext} from "react";
import {StateContext} from "../Reducer";
import {appContent} from "../../../digital-beneficiary-entry";
import "../../../scss/beneCard/beneTable.scss";

const BeneTable = ({benefit=[], tblCaption, hideRevocableStatus, cssClass, ...props}) => {
    const state = useContext(StateContext);
    const {data} = state;    
    const defaultBene = data.member.defaultNoBeneficiary || {};
    const summaryCont = appContent.summary;
    
    return (
        <table className={"slf-grey-borderless-table bene-tbl " + (cssClass || "")}>
            <caption className="h4">{tblCaption}</caption>
            <thead>
                <tr className="grey-top-border">
                    <th scope="col">{summaryCont.beneficiary}</th>
                    <th scope="col">{summaryCont.relationship}</th>
                    <th scope="col">{summaryCont.allocation}</th>
                    {!hideRevocableStatus && 
                        <th scope="col">{summaryCont.revocableStatus}</th>
                    }
                </tr>
            </thead>
            <tbody>
                {benefit.length > 0 ? 
                    (benefit.map((info, index) => (
                        <tr>
                            <th scope="row">{info.displayName}</th>
                            <td>{info.relationshipText}</td>
                            <td>{info.allocation}%</td>
                            {!hideRevocableStatus && 
                                <td>{info.irrevocableStatusText}</td>
                            }
                        </tr>
                    )))
                    :
                    <tr>
                        <th scope="row">
							<span className='fa fa-exclamation-circle mar-right-5' aria-hidden='true' />
							<span className='sr-only'>{defaultBene.srText}</span>{" "}
							{defaultBene.displayName}
                        </th>
                        <td>{defaultBene.relationshipText}</td>
                        <td>{defaultBene.allocation}%</td>
                        {!hideRevocableStatus && 
                            <td>{defaultBene.irrevocableStatusText}</td>
                        }
                    </tr>
                }
            </tbody>
        </table>
    );
}

export default BeneTable;