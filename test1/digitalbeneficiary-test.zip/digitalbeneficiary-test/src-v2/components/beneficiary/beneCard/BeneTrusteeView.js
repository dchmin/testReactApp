import React from "react";
import {appContent} from "../../../digital-beneficiary-entry";
import InfoButton from "../../commons/InfoButton";
import "../../../scss/beneCard/beneTrusteeView.scss";

const BeneTrusteeView = ({trustee="", ...props}) => {
    const summaryCont = appContent.summary;
    
    if (!trustee || trustee === "") {
        return null;
    }

    return (
        <div className="bene-trustee-tbl">
            <h4 class="mar-bottom-20">
                {summaryCont.trusteeHeader}<InfoButton
                    modalType='trustee'
                    openModal={props.openModal}
                    srLabel={summaryCont.trusteeInfoLabel}
                />
            </h4>
            <div className="grey-top-border bene-trustee-label">
                <strong>{summaryCont.trustee}</strong>
            </div>
            <div className="grey-btm-border bene-trustee-name">
                {trustee.displayName}
            </div>
        </div>
    );
}

export default BeneTrusteeView;