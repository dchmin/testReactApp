import React, {useState, useContext, useEffect, useRef} from "react";
import {StateContext} from "./Reducer";
import {Field} from "react-final-form";
import {getFormInstances, getInputData, checkSession} from "../../helpers";
import {appContent, appLob} from "../../digital-beneficiary-entry";
import InfoButton from "../commons/InfoButton";
import ModalWidget from "../commons/modal/ModalWidget";
import BeneEditPrimaryHeader from "./editForm/BeneEditPrimaryHeader";
import BeneEditContingentHeader from "./editForm/BeneEditContingentHeader";
import TrusteeHeader from "./TrusteeFormField/TrusteeHeader";
import IrrevocableConfirmForm from "./irrevocableConfirm/IrrevocableConfirmForm";
import NameInputField from "../commons/NameInputField"; 
import {
	required,
	nameCheck, 
	institutionCheck,
	optionalNameCheck,
	nameHasError, 
	allocRequired,
	allocIsZero,
	mustBeNumber,
	maxValue,
	maxFrenchVal,
	radioSelectionCheck,
	relCheck,
	composeValidators,
	setOnBlurNameError,
	getNameCharLimit,
	setEditError,
	setLob
} from "./ValidationFunctions";

//****************PURPOSE OF THIS FILE: CONTAINS ALL FIELD COMPONENTS OF REACT-FINAL-FORMS****************//
let modalType = "",
	modalTitle = "",
	modalBody = "",
	modalBtns = "",
	irrevocableFieldName = "",
	lang = document.getElementsByTagName("HTML")[0].lang;
// THIS COMPONENT TAKES VALUE AND CONDITION AND DISPLAYS OTHER FORM FIELDS -- (STARTS)
const Condition = React.memo(
	({when, checkType, is, children}) => {
		return (
			// WHY math.floor? Eg, values are 4.01/4.02 and so on..rounding it to 4 and grouping to display
			<Field name={when} subscription={{value: true}}>
				{({input: {value}}) =>
					is.includes(
						checkType === "string"
							? value
							: Math.floor(Number(value))
					)
						? children
						: null
				}
			</Field>
		);
	},
	(prevProps, nextProps) => {
		// console.log({prevProps, nextProps});
		return prevProps === nextProps;
	}
);
// THIS COMPONENT TAKES VALUE AND CONDITION AND DISPLAYS OTHER FORM FIELDS -- (STARTS)
const FormFields = React.memo(
	(props) => {
		let totalAllocIsHundred = props.totalAlloc, //RETURNS BOOLEAN VALUE IF SUM IS 100
			editContent = appContent.edit,
			editModal = appContent.edit.modal,
			editError = appContent.errors,
			relationshipList = appContent.edit.relationshipDropdownList || [],
			dobBunch = {
				dob: false,
				mob: false,
				yob: false,
				yobInputLength: false,
			},
			formName = props.formName;
		
		// Default values
		const defaultAllocPlaceHolder = (lang === "en" || lang === "en-CA") ? "0.00": "0,00"; //Allocation field supports two decimal places for both GB and GRS
		let relationshipsRevocableAndDob = [0, 404, 3, 4, 5];
		let nameCharLimit = 40;

		// LOB specific settings
		const isGRS = appLob === "GRS";
		const useCheckSession = appLob !== "GRS";
		const showAllocationInfoIcon = appLob !== "GRS";
		const showDob = appLob !== "GRS";
		const stackRevocableOpt = appLob !== "GRS";
		// List of relationships that have Revocable status and DOB fields
		// Values for GRS TBD. List for GRS is empty for now.
		const hasExistingFormData = isGRS;
		const isGRSSecondaryBeneficiary = isGRS && props.formName.match(/secondary/g);
		const singleRowMinorAndRemove = isGRSSecondaryBeneficiary;

		// GRS Rules and limitations
		if (isGRS) {
			relationshipsRevocableAndDob =  [3, 4, 5]; //Don't display irrevocable section if no relationship is selected
			nameCharLimit = 32; //GLOBAL only allows 32 characters

			if (isGRSSecondaryBeneficiary) {
				relationshipsRevocableAndDob = [];
			}			
		}
		
		// -----------MODAL HANDLING ---------------- (STARTS)
		const getModalBodyData = (modalType) => {
			modalTitle = editModal[modalType].modalTitle;
			modalBody = editModal[modalType].modalBody;
			modalBtns = editModal[modalType].modalBtns;
		};
		const handleClose = () => {
			//this logic to move to close button of modal
			if (modalType === "irrevocableCheckbox")
				getFormInstances()[props.formName].mutators.setValue(
					irrevocableFieldName,
					[]
				);
			// window.setFormValue(irrevocableFieldName, []);
			if (isGRS && (modalType === "irrevocableCheckbox" || modalType === "irrevocableRadio")) {
				setModalIrrevocableFormShow(false);
			}
			else {
				setModalShow(false);
			}
			modalType = "";
			modalTitle = "";
			modalBtns = "";
			modalBody = "";
		};
		const handleShow = (modlType, ind) => {
			modalType = modlType;
			getModalBodyData(modlType);
			if (isGRS && (modalType === "irrevocableCheckbox" || modalType === "irrevocableRadio")) {
				setModalIrrevocableFormShow(true);
			}
			else {
				setModalShow(true);
			}
		};
		// -----------MODAL HANDLING ---------------- (ENDS)
		const {index, beneCount, submitClick, initialValidate} = props;
		const [show, setModalShow] = useState(false);
		const [showIrrevocableConfirmForm, setModalIrrevocableFormShow] = useState(false);
		const state = useContext(StateContext);
		const {data} = state;
		const [radioSelectionError, setRadioSelectionError] = React.useState(
			false
		); //TO HANDLE ERROR
		const [submitFailed, setSubmitFailed] = React.useState(false); //TO HANDLE ERROR
		const [dobError, setDOBError] = React.useState(false); //DOB HANDLING
		// const [qcRevocable, setQCRevocable] = React.useState(null);
		// const [dobReq, setDOBReq] = React.useState(dobBunch);
		let name =
			props.name === undefined ? "initialFieldArray[0]" : props.name;
		function ylwBtnClk() {
			if (
				[
					"allocation",
					"dob",
					"revocableStatus",
					"irrevocable",
					"revocable",
					"beneDesignation",
					"minor",
					"trustee",
					"contingentInfo",
				].indexOf(modalType) >= 0
			) {
				handleClose();
			}
			if (
				[
					"irrevocableCheckbox",
					"irrevocableRadio",
					"revocableRadio",
				].indexOf(modalType) >= 0
			) {
				getFormInstances()[props.formName].mutators.setValue(
					irrevocableFieldName,
					modalType === "irrevocableCheckbox"
						? ["irrevocable"]
						: modalType === "irrevocableRadio"
						? "irrevocable"
						: "revocable"
				);
				// window.setFormValue(irrevocableFieldName, ["irrevocable"]);
				if (isGRS && (modalType === "irrevocableCheckbox" || modalType === "irrevocableRadio")) {
					setModalIrrevocableFormShow(false);
				}
				else {
					setModalShow(false);
				}
				modalType = "";
				modalBody = "";
			}
			if (modalType === "remove") {
				window.setFormValue("allocation", 0);
				props.remove(index, props.formName);
				setModalShow(false);
			}
		}

		//----------------------- LIMIT KEYBOARD ENTRY --- STARTS
		const checkEntry = (e) => {
			e.target.value = updateEnglishEntry(e.target.value);
		};
		// FRENCH ENTRY FIELD HAS DIFFERENT REQUIREMENT IN RD - PICKING UP LATE
		const checkFrenchEntry = (e) => {
			e.target.value = updateFrenchEntry(e.target.value);
		};

		const updateEnglishEntry = (val) => {
			let includeDecimalLimit = 3;
			//NO ADDITIONAL ERROR MESSAGES WILL BE PROVIDED, HENCE ADDING MULTIPLE INPUT BOX LOGIC
			val = val.replace(/[^0-9.]+/, "");
			if (val.split(".").length > 2) val = val.replace(/\.+$/, "");
			val =
				val.indexOf(".") >= 0
					? (val.substr(0, val.indexOf(".")).length > 3
							? val.substr(0, 3)
							: val.substr(0, val.indexOf("."))) +
					  val.substr(val.indexOf("."), includeDecimalLimit) //BLOCKING INPUT OF MORE THAN 2 DECIMAL PLACES
					: val.length > 3
					? val.substr(0, 3)
					: val;
			return val;
		}

		const updateFrenchEntry = (val) => {
			let regexWithComma = /^\d*\,?\d*$/,
				includeDecimalLimit = 3;
			if (!regexWithComma.test(val)) {
				return val.substr(0, val.length - 1);
			} else {
				val = val.replace(/[^0-9,]+/, "");
				if (val.split(",").length > 2) val = val.replace(/\,+$/, "");
				val =
					val.indexOf(",") >= 0
						? (val.substr(0, val.indexOf(",")).length > 3
								? val.substr(0, 3)
								: val.substr(0, val.indexOf(","))) +
						val.substr(val.indexOf(","), includeDecimalLimit) //BLOCKING INPUT OF MORE THAN 2 DECIMAL PLACES
						: val.length > 3
						? val.substr(0, 3)
						: val;
			}
			return val;
		}
		// FORMAT INITIAL VALUE
		const checkInitialEntryVal = (val) => {
			// No need to format initial values
			if (appLob !== "GRS") {
				return val;
			}

			// Format initial values
			if (lang === "en" || lang === "en-CA") {
				return updateEnglishEntry(val);
			}
			else {
				return updateFrenchEntry(val);
			}
		};
		//RD - ADD 00 IF NO DECIMALS ADDED --- STARTS (SHOULD HAVE USED format FROM FINAL FORM BUT WAS UNAWARE)
		const appendZeroesEn = (e) => {
			let val = e.target.value;
			if (val !== "" && val !== undefined) {
				e.target.value =
					val.indexOf(".") >= 0
						? val.substr(val.indexOf(",")).length === 1
							? Number(val).toFixed(2)
							: val
						: Number(val).toFixed(2);
				getFormInstances()[props.formName].mutators.setValue(
					`${name}.allocation`,
					e.target.value
				);
			}
		};
		//HANDLED IN A WRONG WAY BUT TIME LIMITATION
		const appendZeroesFr = (e) => {
			let val = e.target.value;
			if (val !== "" && val !== undefined) {
				let updatedVal =
					val.indexOf(",") >= 0
						? val.substr(val.indexOf(",")).length === 1
							? val + "00"
							: val.substr(val.indexOf(",")).length === 2
							? val + "0"
							: val
						: val + ",00";
				// Remove leading zero
				updatedVal = Number(updatedVal.split(",")[0]) + "," + updatedVal.split(",")[1];
				// Update instance
				e.target.value = updatedVal;
				getFormInstances()[props.formName].mutators.setValue(
					`${name}.allocation`,
					e.target.value
				);
			}
		};
		//RD - ADD 00 IF NO DECIMALS ADDED --- ENDS
		const checkAlphabetEntry = (e) => {
			//LOB GRS allows invalid character entry and invalid characters will be validated on blur 
			if (isGRS) return false;

			// LOB GB does NOT allow invalid character entry
			let charCode = typeof e.which == "undefined" ? e.keyCode : e.which,
				nameRegex = /[a-zA-Z\x7f-\xff .^~¸\-¨'` ]/i;
			//CHARCODE INDEXOF CONDITION ADDED FOR DEFECT - 117 (2nd PART)
			if (
				!nameRegex.test(String.fromCharCode(charCode)) ||
				[215, 247, 163, 165].indexOf(charCode) >= 0
			) {
				e.preventDefault();
				return false;
			}
		};
		let androidCheck = /(android)/i.test(navigator.userAgent);
		const androidWorkAround = (e) => {
			//LOB GRS allows invalid character entry and invalid characters will be validated on blur 
			if (isGRS) return false;

			// LOB GB does NOT allow invalid character entry
			e.preventDefault();
			let val = e.target.value;
			let charCode = val.charCodeAt(val.length - 1),
				nameRegex = /[a-zA-Z\x7f-\xff .^~¸\-¨'` ]/i,
				lastChar = String.fromCharCode(charCode);
			//CHARCODE INDEXOF CONDITION ADDED FOR DEFECT - 117 (2nd PART)
			if (
				!nameRegex.test(lastChar) ||
				[215, 247, 163, 165].indexOf(charCode) >= 0
			)
				val = val.replace(lastChar, "");
			e.target.value = val;
		};
		const limitEntry = (e, limit, type) => {
			let val = e.target.value;
			e.target.value = val.length > limit ? val.substr(0, limit) : val;
		};
		//----------------------- LIMIT KEYBOARD ENTRY --- ENDS

		//----------------------- VALIDATION RULES FOR FIELDS TIED TO FINAL FORM  --- STARTS
		// Date of birth (DOB) validation functions - (START)
		// Note: Should be moved to "validationFunction" file once more testing support is available for regression
		const yobEntered = (value) => {
			if (value) dobBunch.yob = true;
			else dobBunch.yob = false;
			if (value && value.length === 4) dobBunch.yobInputLength = true;
			else dobBunch.yobInputLength = false;
			return undefined;
		};
		const mobEntered = (value) => {
			if (value) dobBunch.mob = true;
			else dobBunch.mob = false;
			return undefined;
		};
		const dobEntered = (value) => {
			if (value) dobBunch.dob = true;
			else dobBunch.dob = false;
			return undefined;
		};
		const dobCheck = () => {
			if (
				submitClick &&
				(Object.keys(dobBunch).every((k) => dobBunch[k]) ||
					Object.keys(dobBunch).every((k) => !dobBunch[k]))
			) {
				setDOBError(false);
				return undefined;
			} else {
				// console.log(dobBunch);
				setDOBError(true);
				return editError.mandatory;
			}
		};
		// Date of birth (DOB) validation functions - (END)
		// checkDOBBunch() ? undefined : editError.mandatory;
		// const mustBeNumber = (value) =>
		// 	isNaN(value) ? "Must be a number" : undefined;
		// const maxValue = (value) =>
		// 	isNaN(value) || value > 100 ? editError.allocation : undefined;
		// FRENCH ENTRY FIELD HAS DIFFERENT REQUIREMENT IN RD - PICKING UP LATE
		// const maxFrenchVal = (value) => {
		// 	let numericVal = convertToNumberVal(value);
		// 	return numericVal > 100 ? editError.allocation : undefined;
		// };
		// const convertToNumberVal = (value) => {
		// 	if (value === undefined) value = "";
		// 	// Converts String value to a Number value
		// 	if (value.indexOf(",") > -1)
		// 		return Number(
		// 			value.substr(0, value.indexOf(",")) +
		// 				"." +
		// 				value.substr(value.indexOf(",") + 1)
		// 		);
		// 	return Number(value);
		// }
		const totalAllocCheck = (value) => {
			if (!totalAllocIsHundred) {
				return editError.allocation;
			} else return undefined;
		};
		const radioSelection = (value) => {
			const errMsg = radioSelectionCheck(value);
			if (errMsg === undefined) {
				setRadioSelectionError(false);
			}
			else {
				setRadioSelectionError(true);
			}
			return errMsg;
		};
		//----------------------- VALIDATION RULES FOR FIELDS TIED TO FINAL FORM  --- ENDS

		const addBeneHeader = useRef();
		const formBeneHeader = useRef();
		useEffect(() => {
			// Set the focus to applicable element if the form field is rerendered due to add/remove interaction
			if (props.headerFocusIndex && props.headerFocusIndex.index !== -1) {
				let headerFocusIndex =  props.headerFocusIndex.index ;
				let indexVal =  props.index + props.headerFocusIndex.increment; 
				let addBtnEle = document.getElementById(`${props.formName}-addBeneBtn`);

				if (headerFocusIndex === 0 && formBeneHeader.current) {
					formBeneHeader.current.focus(); //Focus on main header 
				}
				else if (headerFocusIndex === indexVal && addBeneHeader.current) {
					addBeneHeader.current.focus(); //Focus on new bene header 
				}
				else if (headerFocusIndex > indexVal && addBtnEle) {
					addBtnEle.focus(); //Focus on add button due to removal of last form field
				}
			}

			// Set validation errors and lob
			setEditError(editError);
			setLob(appLob);	
		}, []);

		const getRemoveBeneId = () => {
			// Default fields that screen reader should read
			let fieldIdList =  `${formName}_${name}_remove_${props.index}   
								${formName}-${name}.firstName  
								${formName}-${name}.lastName `;
			
			// If relationship is selected add it to screen reader
			const relationship = getFormInstances()[props.formName].getFieldState(`${name}.relationship`);
			if (relationship && relationship.value !== "" && relationship.value !== "0" && relationship.value !== undefined) {
				fieldIdList += `${formName}-${name}-relationship`;				
				if (relationship.value == "2") {
					// If relationship is organization get the org name input field
					fieldIdList =  `${formName}_${name}_remove_${props.index} 
									${formName}-${name}.orgName  
									${formName}-${name}-relationship `;
				}
				else if (relationship.value == "1") {
					// If relationship is estate only have the relationship
					fieldIdList =  `${formName}_${name}_remove_${props.index} 
									${formName}-${name}-relationship `;
				}
			}
			return fieldIdList;
		}
		return (
			<div key={index}>
				<div
					key={index}
					className={`bene-field-array ${
						index === "no_ind" ||
						(props.deleteFirstField && index === 0)
							? ""
							: "mar-top-25"
					}`}>
					{index === "no_ind" ? (
						props.formName === "contingencyFlow" ? (
							<p>{editContent.contingentDisclaimer}</p>
						) : (
							<div className='mar-bottom-15'>
								{isGRSSecondaryBeneficiary ?
									<BeneEditContingentHeader 
										ref={formBeneHeader}
										id={`${props.formName}-secondaryHeading`}
											openModal={handleShow}
										/>
									:
									<BeneEditPrimaryHeader 
										ref={formBeneHeader}
										id={`${props.formName}-primaryHeading`}
										openModal={handleShow} />
								}
								
							</div>
						)
					) : props.deleteFirstField && index === 0 ? (
						props.formName === "contingencyFlow" ? (
							<p>{editContent.contingentDisclaimer}</p>
						) : (
							// ADDITIONAL LOGIC - QUICK FIX - DEFECT #52
							<div className='mar-bottom-15'>
								{isGRSSecondaryBeneficiary ?
									<BeneEditContingentHeader 
										ref={formBeneHeader}
										id={`${props.formName}-secondaryHeading`}
											openModal={handleShow}
										/>
									:
									<BeneEditPrimaryHeader 
										ref={formBeneHeader}
										id={`${props.formName}-primaryHeading`}
										openModal={handleShow} />
								}
								
							</div>
						)
					) : (
						<h4 ref={addBeneHeader} tabIndex='-1'>
							{props.formName === "contingencyFlow" || isGRSSecondaryBeneficiary
								? editContent.additionContBene
								: editContent.additionalBene}
						</h4>
					)}
					<div className='row'>
						{/* R E L A T I O N S H I P ------- B L O C K */}
						<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
							<Field
								name={`${name}.relationship`}
								validate={
									submitClick || initialValidate
										? composeValidators(required, relCheck)
										: null
								}
								// className='form-control'
								component='select'>
								{({input, meta}) => (
									<div className='form-group'>
										<label
											htmlFor={`${formName}-${name}-relationship`}>
											{editContent.relationship}
										</label>
										<div className='select-arrow-wrapper'>
											<select
												{...input}
												className={`form-control ${
													meta.submitFailed &&
													meta.invalid
														? "parsley-error"
														: ""
												}`}
												id={`${formName}-${name}-relationship`}
												onChange={(e) => {
													// Return on change event to react-final-form
													input.onChange(e);
													
													// Update fields effected by relationship change
													if (isGRS) {
														let irrevocableStatus = data.member.quebec ? "" : [];
														getFormInstances()[props.formName].mutators.setValue(`${name}.irrevocableStatus`, irrevocableStatus); //Clear irrevocable/revocable value
														getFormInstances()[props.formName].mutators.setValue(`${name}.minorSelection`, ""); //Clear minor selection							
														
														// For GRS to inform that relationship has changed, which can impact the availability of minors
														props.updateMinorCount();
													}
												}}
												// value={beneficiary.relationship || ""}
												aria-describedby={
													meta.submitFailed &&
													meta.invalid
														? `${formName}-${name}-relationship-error`
														: null
												}
												aria-invalid={meta.submitFailed && meta.invalid}
												aria-required='true'
												>
												<option value='0'>
													{editContent.select}
												</option>
												{/* {lang === "en" ||
												lang === "en-CA" ? (
													<option value='0'>
														Select
													</option>
												) : (
													<option value='0'></option>
												)} */}
												{relationshipList.map(
													(each, i) => (
														<option
															key={i}
															data-index={
																each.value
															}
															value={each.value}
															disabled={
																each.value ===
																"404"
																	? true
																	: null
															}>
															{each.label}
														</option>
													)
												)}
											</select>
										</div>
										{/* <pre>{JSON.stringify(meta)}</pre> */}
										{meta.submitFailed && meta.invalid && (
											<ul
												id={`${formName}-${name}-relationship-error`}
												className='parsley-errors-list filled'>
												<li className='parsley-type'>
													{meta.error}
												</li>
											</ul>
										)}
									</div>
								)}
							</Field>
						</div>
						{/* R E L A T I O N S H I P ------- B L O C K */}

						{/* A L L O C A T I O N ------- B L O C K */}
						<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
							<Field
								name={`${name}.allocation`}
								validate={
									submitClick
										? composeValidators(
												allocRequired,
												// mustBeNumber,
												lang === "en" ||
													lang === "en-CA"
													? maxValue
													: maxFrenchVal,
												totalAllocCheck,
												allocIsZero
										  )
										: initialValidate 
										  ? allocIsZero
										  : null
								}>
								{({input, meta}) => {
									if (meta.submitFailed)
										setSubmitFailed(true);
									return (
										<div className='form-group input-group'>
											<label
												htmlFor={`${formName}-${name}-allocation`}>
												{editContent.allocation}
												{showAllocationInfoIcon &&
												<InfoButton
													modalType='allocation'
													openModal={handleShow}
													srLabel={
														editContent.allocInfoLabel
													}
												/>
												}
											</label>
											<div className="allocation-wrapper">
												<input
													{...input}
													type={`${
														lang === "en" ||
														lang === "en-CA"
															? "number"
															: "text"
													}`}
													//value={checkInitialEntryVal(input.value)}
													placeholder={
														editContent.allocPlaceHolder || defaultAllocPlaceHolder
													}
													className={`form-control ${
														meta.submitFailed &&
														meta.invalid
															? "parsley-error"
															: ""
													}`}
													onInput={
														lang === "en" ||
														lang === "en-CA"
															? checkEntry
															: checkFrenchEntry
													}
													onBlur={
														lang === "en" ||
														lang === "en-CA"
															? appendZeroesEn
															: appendZeroesFr
													}
													id={`${formName}-${name}-allocation`}
													name='allocation'
													aria-required='true'
													aria-describedby={
														meta.submitFailed &&
														meta.invalid
															? `${formName}-${name}-allocation-error`
															: null
													}
													aria-invalid={meta.submitFailed && meta.invalid}
												/>
												<label className='input-group-addon slf-blue radio-label'>
													%
												</label>
											</div>
											{meta.submitFailed && meta.invalid && (
												<ul
													id={`${formName}-${name}-allocation-error`}
													className='parsley-errors-list filled'>
													<li className='parsley-type'>
														{meta.error}
													</li>
												</ul>
											)}
										</div>
									);
								}}
							</Field>
						</div>
						{/* A L L O C A T I O N ------- B L O C K */}
					</div>
					
					{/* DYNAMIC FIELDS START */}
					<Condition
						when={`${name}.relationship`}
						checkType='number'
						is={[0, 404, 3, 4, 5]}>
						<div className='row'>
							{/* F I R S T N A M E ------- B L O C K */}
							<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
								<Field
									name={`${name}.firstName`}
									validate={nameCheck(submitClick || initialValidate)}>
									{({input, meta}) => (
										<div className='form-group'>
											<label
												htmlFor={`${formName}-${name}.firstName`}>
												{editContent.firstName}
											</label>
											<input
												{...input}
												type='text'
												maxLength={nameCharLimit}
												onKeyPress={(ev) =>
													checkAlphabetEntry(ev)
												}
												onInput={(e) => {
													androidCheck
														? androidWorkAround(e)
														: null;
													//limitEntry(
													//	e,
													//	nameCharLimit,
													//	"string",
													//	androidCheck
													//);
												}}
												onBlur={(e) => setOnBlurNameError(e, formName, `${name}.firstName`)}
												className={`form-control ${
													nameHasError(meta)
														? "parsley-error"
														: ""
												}`}
												id={`${formName}-${name}.firstName`}
												aria-required='true'
												aria-describedby={
													nameHasError(meta)
														? `${formName}-${name}.firstName-error`
														: null
													}
												aria-invalid={nameHasError(meta)}
											/>
											{nameHasError(meta) && (
												<ul
													id={`${formName}-${name}.firstName-error`}
													className='parsley-errors-list filled'>
													<li className='parsley-type'>
														{meta.error}
													</li>
												</ul>
											)}
										</div>
									)}
								</Field>
							</div>
							{/* F I R S T N A M E ------- B L O C K */}

							{/* L A S T N A M E ------- B L O C K */}
							<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
								<Field
									name={`${name}.lastName`}
									validate={nameCheck(submitClick || initialValidate)}>
									{({input, meta}) => (
										<div className='form-group'>
											<label
												htmlFor={`${formName}-${name}.lastName`}>
												{editContent.lastName}
											</label>
											<input
												{...input}
												type='text'
												maxLength={nameCharLimit}
												className={`form-control ${
													nameHasError(meta)
														? "parsley-error"
														: ""
												}`}
												onKeyPress={(ev) =>
													checkAlphabetEntry(ev)
												}
												onInput={(e) => {
													androidCheck
														? androidWorkAround(e)
														: null;
													//limitEntry(e, nameCharLimit, "string");
												}}
												onBlur={(e) => setOnBlurNameError(e, formName, `${name}.lastName`)}
												id={`${formName}-${name}.lastName`}
												aria-required='true'
												aria-describedby={
													nameHasError(meta) 
														? `${formName}-${name}.lastName-error`
														: null
													}
												aria-invalid={nameHasError(meta)}
											/>
											{nameHasError(meta) && (
												<ul
													id={`${formName}-${name}.lastName-error`}
													className='parsley-errors-list filled'>
													<li className='parsley-type'>
														{meta.error}
													</li>
												</ul>
											)}
										</div>
									)}
								</Field>
							</div>
							{/* L A S T N A M E ------- B L O C K */}
						</div>
					</Condition>
					{(!isGRS || !data.member.quebec) &&
					<Condition
						when={`${name}.relationship`}
						checkType='number'
						is={[4]}>
						<div 
							className={`row ${
								singleRowMinorAndRemove 
									? "minor-field-row" 
									: ""
								}`}>
							{/* M I N O R --- S E L E C T I O N ------- B L O C K */}
							<div className='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
								<fieldset
									id={`${name}_minor_select_${
										props.beneId !== undefined
											? props.beneId
											: "contFlow"
									}`}
									className={`mar-bottom-10  ${
										submitFailed && radioSelectionError
											? "parsley-error"
											: ""
									}`}>
									<legend className='no-mar-bottom center-block'>
										<p>
											{editContent.under18}{" "}
											{isGRS &&
												<InfoButton
													modalType='minor'
													openModal={handleShow}
													srLabel={editContent.under18InfoLabel}
												/>
											}
										</p>
									</legend>
									<Field
										name={`${name}.minorSelection`}
										validate={
											submitClick || initialValidate ? radioSelection : null
										}
										component='input'
										type='radio'
										value='yes'
										className='custom-control-input'
										id={`${formName}-${name}_under_18_${props.beneId}`}
										onClick={(e) => {
											// For GRS to inform that minor selection has changed
											getFormInstances()[props.formName].mutators.setValue(`${name}.minorSelection`, "yes");
											props.updateMinorCount();
										}}
									/>
									<label
										className='custom-control-label'
										htmlFor={`${formName}-${name}_under_18_${props.beneId}`}>
										{editContent.minorYesRadio}
									</label>
									<Field
										name={`${name}.minorSelection`}
										validate={
											submitClick || initialValidate ? radioSelection : null
										}
										component='input'
										type='radio'
										value='no'
										className='custom-control-input'
										id={`${formName}-${name}_not_under_18_${props.beneId}`}
										onClick={(e) => {
											// For GRS to inform that minor selection has changed
											getFormInstances()[props.formName].mutators.setValue(`${name}.minorSelection`, "no");
											props.updateMinorCount();
											
											let formInst = getFormInstances()[
												props.formName
											].mutators;
											formInst.setValue(
												`${name}.trusteeFirstName`,
												""
											);
											formInst.setValue(
												`${name}.trusteeLastName`,
												""
											);
											formInst.setValue(
												`${name}.trusteeRel`,
												""
											);
										}}
									/>
									<label
										className='custom-control-label'
										htmlFor={`${formName}-${name}_not_under_18_${props.beneId}`}>
										{editContent.minorNoRadio}
									</label>
								</fieldset>
								{submitFailed && radioSelectionError && (
									<ul className='parsley-errors-list filled'>
										<li className='parsley-type'>
											{editError.mandatory}
										</li>
									</ul>
								)}
							</div>
							{/* M I N O R --- S E L E C T I O N ------- B L O C K */}
						</div>
					</Condition>
					}
					<Condition
						when={`${name}.relationship`}
						checkType='number'
						is={[2]}>
						<div className='row'>
							{/* O R G A N I Z A T I O N -- N A M E ------- B L O C K */}
							<div className='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
								<Field
									name={`${name}.orgName`}
									validate={submitClick ? required : null}>
									{({input, meta}) => (
										<div className='form-group'>
											<label
												htmlFor={`${formName}-${name}-orgName`}>
												{editContent.orgName}
											</label>
											<input
												{...input}
												type='text'
												maxLength={100}
												className={`form-control ${
													meta.submitFailed &&
													meta.invalid
														? "parsley-error"
														: ""
												}`}
												//onInput={(e) =>
												//	limitEntry(e, 100, "string")
												//}
												id={`${formName}-${name}-orgName`}
												aria-required='true'
												// aria-labelledby={
												// 	meta.submitFailed &&
												// 	meta.invalid
												// 		? `${formName}-${name}-orgName-error`
												// 		: null
												// }
											/>
											{meta.submitFailed && meta.invalid && (
												<ul
													id={`${formName}-${name}-orgName-error`}
													className='parsley-errors-list filled'>
													<li className='parsley-type'>
														{meta.error}
													</li>
												</ul>
											)}
										</div>
									)}
								</Field>
							</div>
							{/* O R G A N I Z A T I O N -- N A M E ------- B L O C K */}

							{/* O R G A N I Z A T I O N -- A D D R E S S ------- B L O C K */}
							<div className='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
								<Field name={`${name}.orgAddress`}>
									{({input, meta}) => (
										<div className='form-group'>
											<label
												htmlFor={`${formName}-${name}-orgAddress`}>
												{editContent.orgAddress}
											</label>
											<input
												{...input}
												type='text'
												maxLength={300}
												className='form-control'
												//onInput={(e) =>
												//	limitEntry(e, 300, "string")
												//}
												id={`${formName}-${name}-orgAddress`}
											/>
										</div>
									)}
								</Field>
							</div>
							{/* O R G A N I Z A T I O N -- A D D R E S S ------- B L O C K */}
						</div>
					</Condition>
					<Condition
						when={`${name}.relationship`}
						checkType='number'
						is={[6]}>
						<div className='row'>
							{/* I N S T I T U T I O N -- N A M E -- L I N E 1 ------- B L O C K */}
							<Field
								name={`${name}.firstName`}
								validate={institutionCheck(submitClick || initialValidate)}>
								{({input, meta}) => 
									<NameInputField 
										id={`${formName}-${name}.firstName`}
										label={editContent.institutionLabelReq}
										maxLength={nameCharLimit}
										onBlur={(e) => setOnBlurNameError(e, formName, `${name}.firstName`, "6")}
										hasError={nameHasError(meta)}
										error={meta.error}
										input={input}
									/>
								}
							</Field>							
							{/* I N S T I T U T I O N -- N A M E -- L I N E 1 ------- B L O C K */}

							{/* I N S T I T U T I O N -- N A M E -- L I N E 2 ------- B L O C K */}
							<Field
								name={`${name}.lastName`}
								validate={optionalNameCheck(submitClick || initialValidate)}>
								{({input, meta}) => 
									<NameInputField 
										id={`${formName}-${name}.lastName`}
										label={editContent.institutionLabelOpt}
										maxLength={nameCharLimit}
										onBlur={(e) => setOnBlurNameError(e, formName, `${name}.lastName`, "6")}
										hasError={nameHasError(meta)}
										error={meta.error}
										input={input}
										required={false}
									/>
								}
							</Field>
							{/* I N S T I T U T I O N -- N A M E -- L I N E 2 ------- B L O C K */}
						</div>
					</Condition>
					<div className={`row mar-bottom-20 ${
								singleRowMinorAndRemove 
									? "irrevocable-remove-field-row" 
									: ""
								}`}>
						<div
							// Defect 29
							className={`${
								lang === "en" || lang === "en-CA" || !showDob
									? "col-lg-6 col-md-6 col-sm-8"
									: "col-lg-8 col-md-8 col-sm-9"
							}  col-xs-12`}>
							<div className='row'>
								<Condition
									when={`${name}.relationship`}
									checkType='number'
									is={relationshipsRevocableAndDob}>
									{/* I R R E V O C A B L E -- S T A T U S ------- B L O C K */}
									<div
										className={`${
											!stackRevocableOpt 
											? ""
											: (lang === "en" || lang === "en-CA")
												? "col-lg-6 col-md-6 col-sm-6"
												: "col-lg-5 col-md-5 col-sm-5"
										}  col-xs-12`}>
										{/* <label
									// htmlFor={`${formName}-${name}-irrevocableStatus`}
									>
										{editContent.revocableStatus}
									</label> */}
										{data.member.quebec ? (
											<>
												<Condition
													when={`${name}.relationship`}
													checkType='number'
													is={[3]}>
													<fieldset
														id={`${formName}-${name}_quebec_irrevocable_${
															props.beneId !==
															undefined
																? props.beneId
																: "contFlow"
														}-radio`}
														className={`mar-bottom-10  ${
															submitFailed &&
															radioSelectionError
																? "parsley-error"
																: ""
														}`}>
														<legend className='mar-bottom-10'>
															<p>
															{
																editContent.revocableStatus
															}
															{isGRS &&
															    <InfoButton
															        modalType='revocableStatus'
															        openModal={
															            handleShow
															        }
															        srLabel={
															            editContent.revocableStatusInfoLabel
															        }
															    />
															}
															</p>
														</legend>
														{/* SPAN added due to iOS defect #77 */}
														<span name='revocable-status-quebec'>
															<Field
																name={`${name}.irrevocableStatus`}
																validate={
																	submitClick
																		? radioSelection
																		: null
																}
																component='input'
																type='radio'
																value='revocable'
																className='custom-control-input'
																id={`${formName}-${name}_revocable_${props.beneId}`}
																// onChange={() => {
																// 	irrevocableFieldName = `${name}.irrevocableStatus`;
																// 	handleShow(
																// 		"revocableRadio"
																// 	);
																// }}
															/>
															<label
																className={`custom-control-label mar-bottom-10 ${stackRevocableOpt ? "revocable-radio" : "mar-right-25"}`}
																htmlFor={`${formName}-${name}_revocable_${props.beneId}`}>
																{
																	editContent.revocable
																}
															</label>
															{!isGRS &&
															<InfoButton
																modalType='revocable'
																openModal={
																	handleShow
																}
																srLabel={
																	editContent.revocableInfoLabel
																}
															/>
															}
														</span>
														<span name='revocable-status-quebec'>
															<Field
																name={`${name}.irrevocableStatus`}
																validate={
																	submitClick
																		? radioSelection
																		: null
																}
																component='input'
																type='radio'
																value='irrevocable'
																className='custom-control-input'
																id={`${formName}-${name}_irrevocable_${props.beneId}`}
																onChange={(
																	e
																) => {
																	e.preventDefault();
																	irrevocableFieldName = `${name}.irrevocableStatus`;
																	handleShow(
																		"irrevocableRadio"
																	);
																}}
															/>
															<label
																className='custom-control-label revocable-radio'
																htmlFor={`${formName}-${name}_irrevocable_${props.beneId}`}>
																{
																	editContent.irrevocable
																}
															</label>
															{!isGRS &&
															<InfoButton
																modalType='irrevocable'
																openModal={
																	handleShow
																}
																srLabel={
																	editContent.irrevocableInfoLabel
																}
															/>
															}
														</span>
													</fieldset>
													{submitFailed &&
														radioSelectionError && (
															<ul className='parsley-errors-list filled'>
																<li className='parsley-type'>
																	{
																		editError.mandatory
																	}
																</li>
															</ul>
														)}
												</Condition>
												<Condition
													when={`${name}.relationship`}
													checkType='number'
													is={[0, 404, 4, 5]}>
													<fieldset
														id={`${formName}-${name}-irrevocableStatus_${props.beneId}-chk`}>
														<legend className='mar-bottom-10'>
															<p>
															{
																editContent.revocableStatus
															}
															{isGRS &&
															    <InfoButton
															        modalType='revocableStatus'
															        openModal={
															            handleShow
															        }
															        srLabel={
															            editContent.revocableStatusInfoLabel
															        }
															    />
															}
															</p>
														</legend>
														<Field
															name={`${name}.irrevocableStatus`}
															component='input'
															type='checkbox'
															value='irrevocable'
															id={`${formName}-${name}-irrevocableStatus_${props.beneId}`}
															onChange={(e) => {
																irrevocableFieldName = `${name}.irrevocableStatus`;
																if (
																	e.target
																		.checked ===
																	true
																) {
																	handleShow(
																		"irrevocableCheckbox"
																	);
																} else {
																	getFormInstances()[
																		props
																			.formName
																	].mutators.setValue(
																		irrevocableFieldName,
																		[]
																	);
																}
															}}
														/>
														<label
															htmlFor={`${formName}-${name}-irrevocableStatus_${props.beneId}`}>
															{
																editContent.irrevocable
															}
															{!isGRS &&
															<InfoButton
																modalType='irrevocable'
																openModal={
																	handleShow
																}
																srLabel={
																	editContent.irrevocableInfoLabel
																}
															/>
															}
														</label>
													</fieldset>
												</Condition>
											</>
										) : (
											<>
												<fieldset
													id={`${formName}-${name}-irrevocableStatus_${props.beneId}-chk`}>
													<legend className='mar-bottom-10'>
														<p>
														{
															editContent.revocableStatus
														}
														{isGRS &&
														    <InfoButton
														        modalType='revocableStatus'
														        openModal={
														            handleShow
														        }
														        srLabel={
														            editContent.revocableStatusInfoLabel
														        }
														    />
														}
														</p>
													</legend>
													<Field
														name={`${name}.irrevocableStatus`}
														component='input'
														type='checkbox'
														value='irrevocable'
														id={`${formName}-${name}-irrevocableStatus_${props.beneId}`}
														onChange={(e) => {
															irrevocableFieldName = `${name}.irrevocableStatus`;
															if (
																e.target
																	.checked ===
																true
															) {
																handleShow(
																	"irrevocableCheckbox"
																);
															} else {
																getFormInstances()[
																	props
																		.formName
																].mutators.setValue(
																	irrevocableFieldName,
																	[]
																);
															}
														}}
													/>
													<label
														htmlFor={`${formName}-${name}-irrevocableStatus_${props.beneId}`}>
														{
															editContent.irrevocable
														}
														{!isGRS &&
														<InfoButton
															modalType='irrevocable'
															openModal={
																handleShow
															}
															srLabel={
																editContent.irrevocableInfoLabel
															}
														/>
														}
													</label>
												</fieldset>
											</>
										)}
									</div>
									{/* I R R E V O C A B L E -- S T A T U S ------- B L O C K */}

									{/* D A T E -- O F -- B I R T H ------- B L O C K */}
									{showDob &&
									<div
										className={`${
											lang === "en" || lang === "en-CA"
												? " col-sm-6"
												: "col-sm-7"
										} col-lg-6 col-md-6 col-xs-9 dob-col`}>
										<label
											htmlFor={`${formName}-${name}-yob`}>
											{editContent.dob}
											<InfoButton
												modalType='dob'
												openModal={handleShow}
												srLabel={
													editContent.dobInfoLabel
												}
											/>
										</label>
										<div className='row dob-row'>
											<div className='col-xs-4 col-0-pad'>
												<Field
													name={`${name}.yob`}
													validate={
														yobEntered
														// submitClick
														// 	? yobEntered
														// 	: null
													}>
													{({input, meta}) => (
														<>
															<div
																className={`form-group display-inline`}>
																<input
																	{...input}
																	onInput={(
																		e
																	) =>
																		limitEntry(
																			e,
																			4,
																			"yob"
																		)
																	}
																	placeholder={
																		editContent.yobPlaceHolder
																	}
																	aria-label={
																		editContent.dob
																	}
																	id={`${formName}-${name}-yob`}
																	type='number'
																	className={`dob form-control ${
																		submitFailed &&
																		dobError
																			? "parsley-error"
																			: ""
																	}`}
																	aria-labelledby={
																		meta.submitFailed &&
																		meta.invalid
																			? `${formName}-${name}-yob-error`
																			: null
																	}
																/>
															</div>
														</>
													)}
												</Field>
											</div>
											<div className='col-xs-3 mob-col col-0-pad'>
												<Field
													name={`${name}.mob`}
													validate={
														mobEntered
														// submitClick
														// 	? mobEntered
														// 	: null
													}>
													{({input, meta}) => (
														<div
															className={`form-group display-inline`}>
															<input
																{...input}
																onInput={(e) =>
																	limitEntry(
																		e,
																		2,
																		"mob"
																	)
																}
																placeholder={
																	editContent.mobPlaceHolder
																}
																aria-label={
																	editContent.dob
																}
																id={`${formName}-${name}-mob`}
																type='number'
																className={`dob form-control ${
																	submitFailed &&
																	dobError
																		? "parsley-error"
																		: ""
																}`}
															/>
														</div>
													)}
												</Field>
											</div>
											<div className='col-xs-3 col-0-pad'>
												<Field
													name={`${name}.dob`}
													validate={
														submitClick &&
														composeValidators(
															dobEntered,
															dobCheck
														)
														// submitClick
														// 	? dobEntered
														// 	: null
													}>
													{({input, meta}) => (
														<div
															className={`form-group display-inline`}>
															<input
																{...input}
																onInput={(e) =>
																	limitEntry(
																		e,
																		2,
																		"dob"
																	)
																}
																placeholder={
																	editContent.dobPlaceHolder
																}
																maxLength='2'
																id={`${formName}-${name}-dob`}
																type='number'
																className={`dob form-control ${
																	submitFailed &&
																	dobError
																		? "parsley-error"
																		: ""
																}`}
																aria-label={
																	editContent.dob
																}
															/>
														</div>
													)}
												</Field>
											</div>
										</div>
										{submitFailed && dobError && (
											<ul
												id={`${formName}-${name}-yob-error`}
												className='parsley-errors-list filled'>
												<li className='parsley-type'>
													{editError.mandatory}
												</li>
											</ul>
										)}
									</div>
									}
									{/* D A T E -- O F -- B I R T H ------- B L O C K */}
									{/* <span onClick={() => props.remove(index)}>Remove</span> */}
								</Condition>
							</div>
						</div>
						{/* C H A N G E -- O F -- R E C O R D ------- B L O C K*/}
						{isGRS && props.productCategory === "DCPP" && (
							<Condition
								when={`${name}.relationship`}
								checkType='string'
								is={["3.01", "3.02", "3.03", "3.05", "5.06", "5.13"]}>
								<div className='col-xs-12 mar-top-10'>
									<div dangerouslySetInnerHTML={{__html: editContent.changeOfRecordsForm}} />
								</div>
							</Condition>
						)}
						{/* C H A N G E -- O F -- R E C O R D ------- B L O C K*/}
						{/* R E M O V E -- B U T T O N ------- B L O C K*/}
						{(beneCount > 1 ||
							props.formName === "contingencyFlow" ||
							isGRSSecondaryBeneficiary) && (
							// <div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
							<button
								type='button'
								id={`${formName}_${name}_remove_${props.index}`}
								//aria-label={editContent.removeBene}
								aria-labelledby={getRemoveBeneId()}
								className='btn btn-link text-burgundy remove-bene'
								onClick={() => {
									if (useCheckSession) checkSession(data.context);
									handleShow("remove");
								}}>
								<i className='fa fa-trash mar-right-5'></i>
								{editContent.removeBene}
							</button>
							// </div>
						)}
						{/* R E M O V E -- B U T T O N ------- B L O C K*/}
					</div>
					{!isGRS &&
					<Condition
						when={`${name}.relationship`}
						checkType='number'
						is={[4]}>
						<Condition
							when={`${name}.minorSelection`}
							checkType='string'
							is={["yes"]}>
							{!data.member.quebec ? (
								<div id='trustee-sec' className='mar-bottom-20'>
									<div className='mar-bottom-15'>
										<TrusteeHeader openModal={handleShow}/>
									</div>
									<div className='row'>
										<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
											<Field
												name={`${name}.trusteeFirstName`}
												validate={
													submitClick
														? required
														: null
												}>
												{({input, meta}) => (
													<div className='form-group'>
														<label
															htmlFor={`${formName}-${name}.trusteeFirstName`}>
															{
																editContent.trusteeFName
															}
														</label>
														<input
															{...input}
															type='text'
															maxLength={nameCharLimit}
															onKeyPress={(ev) =>
																checkAlphabetEntry(
																	ev
																)
															}
															onInput={(e) => {
																androidCheck
																	? androidWorkAround(
																			e
																	  )
																	: null;
																//limitEntry(
																//	e,
																//	nameCharLimit,
																//	"string"
																//);
															}}
															id={`${formName}-${name}.trusteeFirstName`}
															className={`form-control ${
																meta.submitFailed &&
																meta.invalid
																	? "parsley-error"
																	: ""
															}`}
															aria-required='true'
															// aria-labelledby={
															// 	meta.submitFailed &&
															// 	meta.invalid
															// 		? `${formName}-${name}.trusteeFirstName-error`
															// 		: null
															// }
														/>
														{meta.submitFailed &&
															meta.invalid && (
																<ul
																	id={`${formName}-${name}.trusteeFirstName-error`}
																	className='parsley-errors-list filled'>
																	<li className='parsley-type'>
																		{
																			meta.error
																		}
																	</li>
																</ul>
															)}
													</div>
												)}
											</Field>
										</div>
										<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
											<Field
												name={`${name}.trusteeLastName`}
												validate={
													submitClick
														? required
														: null
												}>
												{({input, meta}) => (
													<div className='form-group'>
														<label
															htmlFor={`${formName}-${name}-trusteeLastName`}>
															{
																editContent.trusteeLName
															}
														</label>
														<input
															{...input}
															type='text'
															maxLength={nameCharLimit}
															onKeyPress={(ev) =>
																checkAlphabetEntry(
																	ev
																)
															}
															id={`${formName}-${name}-trusteeLastName`}
															onInput={(e) => {
																androidCheck
																	? androidWorkAround(
																			e
																	  )
																	: null;
																//limitEntry(
																//	e,
																//	nameCharLimit,
																//	"string"
																//);
															}}
															className={`form-control ${
																meta.submitFailed &&
																meta.invalid
																	? "parsley-error"
																	: ""
															}`}
															aria-required='true'
															// aria-labelledby={
															// 	meta.submitFailed &&
															// 	meta.invalid
															// 		? `${formName}-${name}-trusteeLastName-error`
															// 		: null
															// }
														/>
														{meta.submitFailed &&
															meta.invalid && (
																<ul
																	id={`${formName}-${name}-trusteeLastName-error`}
																	className='parsley-errors-list filled'>
																	<li className='parsley-type'>
																		{
																			meta.error
																		}
																	</li>
																</ul>
															)}
													</div>
												)}
											</Field>
										</div>
									</div>
									<div className='row'>
										<div className='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
											<Field
												name={`${name}.trusteeRel`}
												validate={
													submitClick
														? required
														: null
												}>
												{({input, meta}) => (
													<div className='form-group'>
														<label
															htmlFor={`${formName}-${name}-trusteeRel`}>
															{
																editContent.relnToMinor
															}
														</label>
														<input
															{...input}
															type='text'
															maxLength={50}
															onKeyPress={(ev) =>
																checkAlphabetEntry(
																	ev
																)
															}
															id={`${formName}-${name}-trusteeRel`}
															onInput={(e) => {
																androidCheck
																	? androidWorkAround(
																			e
																	  )
																	: null;
																//limitEntry(
																//	e,
																//	50,
																//	"string"
																//);
															}}
															className={`form-control ${
																meta.submitFailed &&
																meta.invalid
																	? "parsley-error"
																	: ""
															}`}
															aria-required='true'
															// aria-labelledby={
															// 	meta.submitFailed &&
															// 	meta.invalid
															// 		? `${formName}-${name}-trusteeRel-error`
															// 		: null
															// }
														/>
														{meta.submitFailed &&
															meta.invalid && (
																<ul
																	id={`${formName}-${name}-trusteeRel-error`}
																	className='parsley-errors-list filled'>
																	<li className='parsley-type'>
																		{
																			meta.error
																		}
																	</li>
																</ul>
															)}
													</div>
												)}
											</Field>
										</div>
									</div>
								</div>
							) : (
								<p>{editContent.minorQuebec}</p>
							)}
						</Condition>
					</Condition>
					}
					{/* // )} */}
				</div>
				<ModalWidget
					displayModal={show}
					modalTitle={modalTitle}
					modalBody={modalBody}
					modalBtns={modalBtns}
					srOnlyCloseBtn='Close'
					handleClose={handleClose}
					modalId='bene-form-fields-modal'
					modalLnkBtnClk={handleClose}
					modalYlwBtnClk={ylwBtnClk}
				/>
				{isGRS &&
				<IrrevocableConfirmForm
					show={showIrrevocableConfirmForm}
					handleClose={handleClose}
					ylwBtnClk={ylwBtnClk}
				/>
				}
			</div>
		);
	},
	(prevProps, nextProps) => {
		// console.log({prevProps, nextProps});
		return prevProps === nextProps;
	}
);
export default FormFields;
