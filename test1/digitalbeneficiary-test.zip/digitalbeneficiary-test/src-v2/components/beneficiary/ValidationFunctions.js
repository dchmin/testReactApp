import React from "react";
import {appContent, appLob} from "../../digital-beneficiary-entry";
import {getFormInstances} from "../../helpers";

let validCharRegex = {
	// LOB GRS Supported French special characters in Hex Code: 
	// [������������������������������������������] = [\xc0-\xc2\xc7-\xcf\xd2-\xd4\xd6\xd9-\xdd\xe0-\xe2\xe7-\xef\xf2-\xf4\xf6\xf9-\xff]
	"name":  /^[A-Za-z' .\-\xc0-\xc2\xc7-\xcf\xd2-\xd4\xd6\xd9-\xdd\xe0-\xe2\xe7-\xef\xf2-\xf4\xf6\xf9-\xff]+$/i,
	// LOB GRS - Insitution has additional supported special characters which are []$+ and numeric values
	"institution": /^[A-Za-z0-9' .\-+$[\]\xc0-\xc2\xc7-\xcf\xd2-\xd4\xd6\xd9-\xdd\xe0-\xe2\xe7-\xef\xf2-\xf4\xf6\xf9-\xff]+$/i
}

let nameCharLimit = 40; //LOB GB allows for 40 characters
export const getNameCharLimit = () => {
	return nameCharLimit; 
}

// GRS Rules and limitations - TODO - NEEDS TO BE REFACTORED
let isGRS = appLob === "GRS";
if (isGRS) rulesGRS();
const rulesGRS = () => {
	nameCharLimit = 32;	 //GLOBAL only allows 32 characters
}

let editError = appContent ? appContent.errors : {};
export const setEditError = (content) => {
	editError = content;
}

export const setLob = (appLobTest) => {
	isGRS = appLobTest === "GRS";
	rulesGRS();
}

//----------------------- VALIDATION RULES FOR FIELDS TIED TO FINAL FORM  --- STARTS
export const required = (value) => {
	let check = value; // LOB GB - validates input is empty
	if (isGRS) { // LOB GRS - validates input is empty or contains only spaces
		check = value && value.trim()
	}
	return (check ? undefined : editError.mandatory);
};
export const nameCheck = (validateNameFlag) => (value, allValues, meta) => {
	// LOB GRS - don't run validation if relationship is institution (relationship code = 6)
	let relationship = getRelationship(allValues, meta.name);
	if (isGRS && relationship == 6) return undefined;

	// Validate name fields
	return validateNameRules(validateNameFlag, value, allValues, meta, validCharRegex.name);
};
export const institutionCheck = (validateNameFlag) => (value, allValues, meta) => validateNameRules(validateNameFlag, value, allValues, meta, validCharRegex.institution);
const validateNameRules = (validateNameFlag, value, allValues, meta, nameRegex) => {
	let errorMsg = undefined;
	if (validateNameFlag) { 
		errorMsg = required(value); //check if it's empty
	}
	
	if (invalidCharCheck(value, nameRegex) === undefined) {
		meta.data.error = undefined; //Clear onBlur error
	}

	if (isGRS && errorMsg === undefined) {
		// Check for invalid characters on blur
		if (meta.data.error !== undefined) {
			return meta.data.error;
		}
		else if (meta.active === false ) { //This applies on page load
			errorMsg = invalidCharCheck(value, nameRegex);
		}	 
	}
	return errorMsg;
}
const getRelationship = (allValues,name) => {
	// Get the form instance and index value
	// ie. "newFieldArray[0].firstName" or "initialFieldArray[0].firstName" to ["newFieldArray", "0"] or ["initialFieldArray", "0"]
	let formNameAry = name.split(".")[0].replace("[", ".").replace("]", "").split("."); 
	let formName = formNameAry[0];
	let beneNum = formNameAry[1];
	let formFields = allValues[formName];

	// Get the relationship value set for the form 
	if (formFields && formFields.length > 0 && formFields[beneNum] && "relationship" in formFields[beneNum]) {
		return formFields[beneNum].relationship;
	}
	return undefined;
}
//Optional field - check only for invalid characters 
export const optionalNameCheck = (validateNameFlag) => (value, allValues, meta) => {
	// LOB GRS - don't run validation if relationship is not institution (relationship code = 6)
	let relationship = getRelationship(allValues, meta.name);
	if (isGRS && relationship != 6) return undefined;

	// Validate optional field for institution
	if (value && value.trim().length > 0) {
		return  validateNameRules(validateNameFlag, value, allValues, meta, validCharRegex.institution);
	}
	meta.data.error = undefined; //Clear onBlur error			
	return undefined;	
}
const invalidCharCheck = (value, nameRegex) => {
	if (value && !value.match(nameRegex)) {
		//return appContent.errors.invalidChar;
		return editError.invalidChar;
	}
	return undefined;
}
export const nameHasError = (meta) => ((meta.submitFailed && meta.invalid) || (meta.data && meta.data.error !== undefined));
export const allocRequired = (value) => {
	// LOB GRS will check if it's value is empty or 0% after user total allocation is correct
	if (isGRS) return undefined; 
	// LOB GB uses same error message for empty and total allocation. 
	// In addition 0% allocation to be assigned to the beneficiary
	return value ? undefined : editError.allocation;
}	
export const allocIsZero = (value) => {
	// LOB GRS doesn't allow 0% allocation for benenficiary and treats it as empty
	let numericVal = convertToNumberVal(value);
	if (isGRS) return (value && numericVal != 0) ? undefined :  editError.mandatory;
}
export const mustBeNumber = (value) =>
	isNaN(value) ? "Must be a number" : undefined;
export const maxValue = (value) =>
	isNaN(value) || value > 100 ? editError.allocation : undefined;
// FRENCH ENTRY FIELD HAS DIFFERENT REQUIREMENT IN RD - PICKING UP LATE
export const maxFrenchVal = (value) => {
	let numericVal = convertToNumberVal(value);
	return numericVal > 100 ? editError.allocation : undefined;
};
const convertToNumberVal = (value) => {
	if (value === undefined) value = "";
	// Converts String value to a Number value
	if (value.indexOf(",") > -1)
		return Number(
			value.substr(0, value.indexOf(",")) +
				"." +
				value.substr(value.indexOf(",") + 1)
		);
	return Number(value);
}
export const radioSelectionCheck = (value) => {
	if (value !== undefined && value !== "") {
		// setRadioSelectionError(false);
		return undefined;
	} else {
		// setRadioSelectionError(true);
		return editError.mandatory;
	}
};
export const relCheck = (value) =>
	[0, 404].indexOf(Number(value)) >= 0
		? editError.mandatory
		: undefined;
export const composeValidators = (...validators) => (value) =>
	validators.reduce(
		(error, validator) => error || validator(value),
		undefined
	);

export const setOnBlurNameError = (e, formName, fieldName, nameRegex = validCharRegex.name) => { 
	if (!isGRS) return false;
	if (nameRegex === "6") nameRegex = validCharRegex.institution;

	// Set up onblur
	let formInst = getFormInstances()[formName].mutators;
	formInst.setOnBlurNameError(fieldName, invalidCharCheck(e.target.value, nameRegex));
}
//----------------------- VALIDATION RULES FOR FIELDS TIED TO FINAL FORM  --- ENDS