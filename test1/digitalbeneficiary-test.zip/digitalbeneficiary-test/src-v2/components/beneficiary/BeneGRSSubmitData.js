import React, {useContext, useEffect} from "react";
import {StateContext} from "./Reducer";
import {getBeneEditList, updateBeneLists} from "./BeneficiaryGRSWidget";
import {appContent, setAppContent} from "../../digital-beneficiary-entry";
import axios from "axios";
import {axiosGRSHandler} from "../../helpers";

const addBeneObject = (objVal, beneType, quebec, primaryBeneficiaries, secondaryBeneficiaries) => {
	let bene = createBeneObject(objVal.relationship, objVal.allocation, objVal.firstName, objVal.lastName, objVal.minorSelection, objVal.irrevocableStatus, beneType, quebec);
	if (beneType === "primary") {
		primaryBeneficiaries.push(bene);
	}
	else if (beneType === "secondary") {
		secondaryBeneficiaries.push(bene);
	}
}

const createBeneObject = (relationship, allocation, firstName, lastName, minorSelectionVal, irrevocableStatusVal, beneType, quebec) => {
	// Estate does not have first name and last name
	if (relationship === "1") {
		firstName = "";
		lastName = "";
	}
	
	let minorSelection = "";
	if (relationship.match("^4.") && !quebec) {
		minorSelection = minorSelectionVal;
	}
	let isMinor;
	if (minorSelection === "yes") {
		isMinor = true;
	}
	else {
		isMinor = false;
	}
	
	let irrevocableStatus;
	// Estate, Institution and secondary beneficiaries don't have irrevocable status
	if (['1', '6'].indexOf(relationship) >= 0 || beneType === "secondary") {
		irrevocableStatus = "";
	}
	else if (irrevocableStatusVal === undefined) {
		irrevocableStatus = "revocable";
	}
	else {
		irrevocableStatus = "revocable";
		if (irrevocableStatusVal[0] === "irrevocable" || irrevocableStatusVal === "irrevocable") {
			irrevocableStatus = "irrevocable";
		}
	}
	
	let isIrrevocable;
	if (irrevocableStatus === "irrevocable") {
		isIrrevocable = true;
	}
	else {
		isIrrevocable = false;
	}

	let bene = {
		relationship: relationship,
		allocation: allocation,
		firstName: firstName,
		lastName: lastName,
		isMinor: isMinor,
		isIrrevocable: isIrrevocable
	};
	return bene;
};

export function collectDataAndSubmit(forms, data, dispatch) {
	const beneEditList = getBeneEditList();
	
	let tmpProductList = {};

	// Initialize the temp list of products
	beneEditList.map((tmpProduct, index) => {
		let initProduct = {
			clientBeneId: tmpProduct.clientBeneId,
			primaryBeneficiaries: [],
			secondaryBeneficiaries: [],
			trustee: ""
		};
		tmpProductList[tmpProduct.clientBeneId] = initProduct;
	});
	
	// Loop through all FormContainer forms on the page
	// Note that the forms are not necessarily ordered by product Id
	Object.keys(forms).map((form, index) => {
		let eachFormValue = forms[form].getState().values;
		
		// Get the form name, product Id, beneType
		// beneType can be primary, secondary, trustee
		// Examples:
		// byFlow12345-primary
		// byFlow12345-secondary
		// byFlow12345-trustee
		let fn = form;
		fn = fn.replace("byFlow", "");
		let pos = fn.indexOf("-");
		let productId = fn.substring(0, pos);
		let beneType = fn.substring(pos + 1);
		
		let primaryBeneficiaries = [];
		let secondaryBeneficiaries = [];
		
		// Loop through each beneficiary or trustee inside the form
		Object.keys(eachFormValue).map((type, index) => {
			if (type === "initialFieldArray" && beneType !== "trustee") {
				let initialVal = eachFormValue[type][0];
				if (initialVal !== undefined) {
					addBeneObject(initialVal, beneType, data.member.quebec, primaryBeneficiaries, secondaryBeneficiaries);
				}
			}
			
			if (type === "newFieldArray") {
				let allNewVal = eachFormValue[type];
				Object.keys(allNewVal).map((eachNew, i) => {
					let newVal = allNewVal[eachNew];
					if (newVal !== undefined) {
						addBeneObject(newVal, beneType, data.member.quebec, primaryBeneficiaries, secondaryBeneficiaries);
					}
				});
			}
			
			if (type === "trustee") {
				let trusteeVal = eachFormValue[type];
				let trusteeObj = {
					firstName: trusteeVal.firstName,
					lastName: trusteeVal.lastName
				};
				tmpProductList[productId].trustee = trusteeObj;
			}
		});
		
		if (beneType === "primary") {
			tmpProductList[productId].primaryBeneficiaries = primaryBeneficiaries;
		}
		else if (beneType === "secondary") {
			tmpProductList[productId].secondaryBeneficiaries = secondaryBeneficiaries;
		}
	});
	
	// Set and order the final product list by product Id, where each product includes list of primary beneficiaries, list of secondary beneficiaries, trustee
	let productList = [];
	beneEditList.map((tmpProduct, index) => {
		let productId = tmpProduct.clientBeneId;
		let product = {
			clientBeneId: productId,
			primaryBeneficiaries: tmpProductList[productId].primaryBeneficiaries,
			secondaryBeneficiaries: tmpProductList[productId].secondaryBeneficiaries,
			trustee: tmpProductList[productId].trustee
		};
		productList.push(product);
	});
	
	// Final data
	let postData = {
		benefitList: productList
	};

	// Call the submit service
	let url = "/grsapps_dt/req/beneficiaryDetails/updateBeneficiaries";
	axiosGRSHandler(postData, url, "POST")
	.then(response => {
		/*
		console.log("response:");
		console.log(response);
		console.log("responseCode:");
		console.log(response.responseCode);
		console.log("responseMessage:");
		console.log(response.responseMessage);
		*/
		if (response.responseCode === "0") {
			console.log("Success responseCode = 0");
			
			let content = response.pageLvlContent,
				responseData = response.data;

			// setup content
			setAppContent(content);
			updateBeneLists(responseData.member.benefitList);

			// Call dispatch to update the state data
			dispatch({type: "UPDATE_INITIAL_DATA", data: responseData});
			
			// Call dispatch to navigate to View page with success confirmation message
			dispatch({
                type: "UPDATE_UI",
                pageFlow: "submitSuccessConfirmation",
                displayMode: "view"
			});
		} else {
			console.log("Error occurred. Error responseCode = " + response.responseCode);
		}
	})
    .catch(err => {
		console.log("Catch error in BeneGRSSubmitData");
		console.log(err);
	});
}

export const checkProductLevelErrors = (forms) => {
    const errors = appContent.errors;
    const beneEditList = getBeneEditList();
    let errorCount = 0;
    let productError = {};
    beneEditList.map((bene) => {
        const baseName = "byFlow"
        const primary = forms[baseName + bene.clientBeneId + "-primary"];
        const secondary = forms[baseName + bene.clientBeneId + "-secondary"];
        const trustee = forms[baseName + bene.clientBeneId + "-trustee"];
        let count = 0;
        let estateExist = false;

        // Primary
        if (primary) {
            const primaryVal = primary.getState().values;
            // Find if Estate is selected
            if (primaryVal.initialFieldArray) {
                count++; //Count number of primary
                // Check if Estate is selected as a bene
                if (primaryVal.initialFieldArray[0] &&
                    primaryVal.initialFieldArray[0].relationship == "1") {
                    estateExist = true;
                }
            }
            if (primaryVal.newFieldArray) {
                count += primaryVal.newFieldArray.length;  //Count number of primary
                // Check if Estate is selected as a bene
                if (!estateExist) {
                    primaryVal.newFieldArray.forEach((item)=> {
                        if (item.relationship == "1") estateExist = true;
                    });
                }
            }
        }

        // Secondary
        let secondaryCount = 0;
        if (secondary) {
			const secondaryVal = secondary.getState().values;
             //Count number of secondary
            if (secondaryVal.initialFieldArray) secondaryCount++;
            if (secondaryVal.newFieldArray) secondaryCount += secondaryVal.newFieldArray.length;
        }

        // Trustee
        if (trustee) {
            const trusteeVal = trustee.getState().values;
            if (trusteeVal.initialFieldArray) count++;
        }

        // Display error if beneficiary count including trustee is over 10
        productError[bene.clientBeneId] = [];
        if ((count + secondaryCount) > 10) {
            errorCount++;
            productError[bene.clientBeneId].push(errors.overMaxBeneficiaries); 
		}
		// Display error if Estate is in primary with secondary bene defined
        if (estateExist && secondaryCount > 0) {
            errorCount++;
            productError[bene.clientBeneId].push(errors.estateIsPrimary);
        }
    });

    return {errorCount: errorCount, productError: productError};
}