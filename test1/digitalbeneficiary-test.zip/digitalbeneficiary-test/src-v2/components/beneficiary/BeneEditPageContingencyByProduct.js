import React, {useState, useContext, useEffect, useRef} from "react";
import {StateContext} from "./Reducer";
import {getBeneEditList} from "./BeneficiaryGRSWidget";
import FormContainer from "./FormContainer";
import NotepadAccordion from "./NotepadAccordion";
import PageNavBtns from "../commons/PageNavBtn";
import BeneSummarySection from "./BeneSummarySection";
import BeneCardTop from "./beneCard/BeneCardTop";
import {appContent} from "../../digital-beneficiary-entry";
import InfoButton from "../commons/InfoButton";
import BeneEditPageSecondary from "./BeneEditPageSecondary";
import BeneEditPageGRSProductWrapper from "./BeneEditPageGRSProductWrapper";
import {
	setInputData,
	getInputData,
	getFormInstances,
	setFormInstances
} from "../../helpers";
import "../../scss/edit-form-by-product.scss";
//****************PURPOSE OF THIS FILE: DISPLAY EACH BENEFICIARY PRODUCT****************//
let existingFormErrorCount = 0;
function BeneEditPageContingencyByProduct({submitClick, showTechnicalFailure, setErrorCount, ...props}) {
	const state = useContext(StateContext),
		{data} = state,
		benefitList = getBeneEditList();

	let editContent = appContent.edit;

	const [productError, setProductError] = useState({});

	useEffect(() => {
		existingFormErrorCount = 0; // Reset existing form error count
	}, []);

	// Update existing form load error count
	const setExistingFormErrorCount = (count) => {
		existingFormErrorCount += count;
		props.setExistingFormErrorCount(existingFormErrorCount);
	}

	return (
		<>
			{benefitList.map((benefit, index) => {
				return (
					<div
						key={`byFlow-${index}`}
						id={`bene-edit-${benefit.clientBeneId}`}
						className='all-bene-edit-form bene-by-product'>
						<div className='bene-each-item bene-border-bottom pad-bottom-0'>
							<BeneCardTop 
								product={benefit} 
								errorMsgs={productError[benefit.clientBeneId]} />
						</div>
						<BeneEditPageGRSProductWrapper 
							benefit={benefit}
							pageFlow={props.pageFlow}
							submitClick={submitClick}
							showTechnicalFailure={showTechnicalFailure}
							setErrorCount={setErrorCount}
							termsConditionsErrorCount={props.termsConditionsErrorCount}
							setExistingFormErrorCount={setExistingFormErrorCount}
							productLevelError={(errorList) => setProductError(errorList)}
							productErrorMsgs={productError}
						/>
					</div>
			)})}
		</>
	);
}
export default BeneEditPageContingencyByProduct;

