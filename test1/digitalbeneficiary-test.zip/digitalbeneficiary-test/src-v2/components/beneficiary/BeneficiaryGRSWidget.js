import React, {useContext, useEffect} from "react";
import {DispatchContext, StateContext} from "./Reducer";
import {
	setImpersonatedFlag, 
	getGRSData, 
	setupAxiosGRS,
	setInputData,
	setFormInstances,
	setOriginalFormInstance
} from "../../helpers";
import {setAppContent} from "../../digital-beneficiary-entry";
import AccountInfo from "./accountInfo/AccountInfo";
import BenePageFlowContainer from "./BenePageFlowContainer";

// Editable Beneficiary list
let beneEditList = [];
export function setBeneEditList(forms) {
	beneEditList = forms;
}

export function getBeneEditList() {
	return beneEditList;
}
// Downloadable Form list
let beneFormList = [];
export function setBeneFormList(forms) {
	beneFormList = forms;
}

export function getBeneFormList() {
	return beneFormList;
}
// Non-editable Beneficiary list
let beneNonEditList = [];
export function setBeneNonEditList(forms) {
	beneNonEditList = forms;
}

export function getBeneNonEditList() {
	return beneNonEditList;
}

export function updateBeneLists(benefitList) {
	let formInstance = {};
	beneEditList = [];
	beneNonEditList = [];
	beneFormList = [];

	benefitList.map((benefit, index) => {
		if (benefit.updateMode === "E") {
			beneEditList.push(benefit);

			// Primary Beneficiary
			if (benefit.primaryBeneficiaries.length === 0) {
				formInstance[`byFlow${benefit.clientBeneId}-primary`] = {"initialFieldArray": []};
			}
			else {
				formInstance[`byFlow${benefit.clientBeneId}-primary`] = editFormExistingBeneList(benefit.primaryBeneficiaries);
			}

			// Secondary Beneficiary - V = Show in both View and Edit / E = Show in Edit only / N = Show in neither
			if (benefit.showSecondaryBeneficiaries === "V" || benefit.showSecondaryBeneficiaries === "E") {
				if (benefit.secondaryBeneficiaries.length > 0) {
					formInstance[`byFlow${benefit.clientBeneId}-secondary`] = editFormExistingBeneList(benefit.secondaryBeneficiaries);
				}
				else {
					formInstance[`byFlow${benefit.clientBeneId}-secondary`] = {"initialFieldArray": []};
				}
			}
			
			// Trustee
			if (benefit.trustee) {
				formInstance[`byFlow${benefit.clientBeneId}-trustee`] = {"trustee": benefit.trustee};
			}
			else {
				let blankTrustee = {
					firstName: "",
					lastName: "",
					displayName: ""
				};
				formInstance[`byFlow${benefit.clientBeneId}-trustee`] = {"trustee": blankTrustee};
			}
		}
		else if (benefit.updateMode === "F") {
			beneFormList.push({
				"planName": `${benefit.benefitName} (${benefit.productType})`,
				"planNumberList": benefit.clientBeneId
			});
			beneNonEditList.push(benefit);
		}
		else {
			beneNonEditList.push(benefit);
		}
	});

	// Initializing the form instance
	setInputData(formInstance); //after navigation previous/next
	setFormInstances(formInstance); //for react final Form
	setOriginalFormInstance(JSON.stringify(formInstance)); //Create a copy of initial form value on page load - will be used when user click cancel button
}

// Handle GRS Rules:
// 1) Estate by default should not appear on edit mode
// 2) Existing info should be validated
const editFormExistingBeneList = (beneList) => {
	let existingField = [];
	existingField = beneList.filter(bene => bene.relationship !== "EST")
		.map((bene, index) => {
			// In edit mode the allocation cannot be more than 2 decimal places
			let allocation = bene.allocation; 
			if (allocation && allocation !== "" && allocation.split(/[.,]/g)[1].length > 2) {
				allocation = allocation.slice(0,-2);
			}

			// Return cleaned up edit mode values
			return {
				...bene, 
				existing: true, 
				allocation: allocation,
				irrevocableStatus: "revocable"
			};
		});
	if (existingField.length > 0) {
		return {"newFieldArray": [...existingField]}
	}
	return {"initialFieldArray": []}
}
function BeneficiaryGRSWidget() {
	const dispatch = useContext(DispatchContext);
	const state = useContext(StateContext);
	const {loading} = state;

	// Call getGRSData() from helpers.js to get GRS beneficiary data and WEM content
	useEffect(() => {
		//Apply axios interceptor to display and hide loading spinners
		setupAxiosGRS(); 
		
		// Get initial page data
		getGRSData()
		.then(response => {   
			let content = response.pageLvlContent,
				data = response.data;

			// setup content
			setAppContent(content);
			updateBeneLists(data.member.benefitList); //NEED TO UPDATE LOGIC FOR WHEN NOTHING IS RETURNED

	        // Call dispatch to update the state
			dispatch({type: "UPDATE_INITIAL_DATA", data: data});
	    })
	    .catch(err => {
	    	console.log(err);
	    	// Call dispatch to update the state
			dispatch({type: "PAGE_ERROR"});
	    });
	}, []);
	
	// Don't render component if loading state
	if (loading) {
		return null; 
	}

	return (
		<div id="beneficiaryGrsWidget">
			<AccountInfo />
			<div className='col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2 col-lg-offset-2'>
				<BenePageFlowContainer />
			</div>
		</div>
	);
}
export default BeneficiaryGRSWidget;
