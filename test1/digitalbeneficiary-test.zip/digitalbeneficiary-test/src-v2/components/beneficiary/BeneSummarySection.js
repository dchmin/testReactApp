import React from "react";
import {appContent} from "../../digital-beneficiary-entry";

const BeneSummarySection = (props) => {
    const summaryCont = appContent.summary;
    
    return (
        <div className='col-xs-12'>
            <h2>{summaryCont.summaryHead}</h2>
            <div
                dangerouslySetInnerHTML={{
                    __html: props.isEnrol === false ? summaryCont.noProducts : summaryCont.summaryDesc
                }}>
            </div>
            {summaryCont.sponsorPlanLevelMessage &&
            	<div class="mar-top-25"
            	    dangerouslySetInnerHTML={{__html: summaryCont.sponsorPlanLevelMessage}} 
				/>
            }
        </div>
    );
}

export default BeneSummarySection;