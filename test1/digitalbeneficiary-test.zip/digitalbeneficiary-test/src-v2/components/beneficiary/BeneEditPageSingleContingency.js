import React, {useState, useContext, useEffect, useRef} from "react";
import {StateContext} from "./Reducer";
import FormContainer from "./FormContainer";
import NotepadAccordion from "./NotepadAccordion";
import PageNavBtns from "../commons/PageNavBtn";
import BeneSummarySection from "./BeneSummarySection";
import BeneCardTop from "./beneCard/BeneCardTop";
import {appContent} from "../../digital-beneficiary-entry";
import InfoButton from "../commons/InfoButton";
import {
	setInputData,
	setFormInstances,
	setContingencyCheck,
	getContingencyCheck,
	uTagCall,
	checkSession,
} from "../../helpers";
import ModalWidget from "../commons/modal/ModalWidget";
//****************PURPOSE OF THIS FILE: PARENT TO DISPLAY BOTH BY-BENEFIT AND ALL-BENEFIT FORMS****************//
function BeneEditPageSingleContingency({submitClick, showTechnicalFailure, setErrorCount, setContingentBeneficiary, contingentBeneficiary, ...props}) {
	let editContent = appContent.edit,
		contingentModal = editContent.modal.contingentInfo;
	const [show, setModalShow] = useState(false), //STATE TO CONTROL HIDE AND SHOW OF MODAL
		state = useContext(StateContext),
		{data} = state,
		benefitList = data !== "" ? data.member.benefitList : "",
		handleShow = () => setModalShow(true),
		handleClose = () => setModalShow(false);
	let context = data.context;

	return (
		<>
			{props.pageFlow === "allBenefits" && (
				<div className='all-bene-edit-form'>
					<div className='bene-each-item bene-border-bottom'>
						<h3>{editContent.beneSumHead}</h3>
						<ul>
							{benefitList.map((benefit, index) => {
								return (
									<li key={index}>
										{benefit.benefitName} &#8212;{" "}
										<span
											dangerouslySetInnerHTML={{
												__html: benefit.clientBeneId,
											}}></span>{" "}
										{benefit.hasOCB && (
											<span>
												&#8212; {editContent.disclaimer}
											</span>
										)}
									</li>
								);
							})}
						</ul>
					</div>
					<FormContainer
						formName='allFlow'
						errorCount={(val) => setErrorCount(val)}
						contingentIsChecked={contingentBeneficiary}
						pageFlow={props.pageFlow}
						submitClick={submitClick}
						serviceFailed={showTechnicalFailure}
					/>
				</div>
			)}
			{props.pageFlow === "byBenefits" &&
				benefitList.map((benefit, index) => {
					return (
						<div
							key={`byFlow-${index}`}
							className='all-bene-edit-form'>
							<div className='bene-each-item bene-border-bottom'>
								<h2>
									{benefit.benefitName} &#8212;{" "}
									<span
										dangerouslySetInnerHTML={{
											__html: benefit.clientBeneId,
										}}></span>{" "}
									{benefit.hasOCB && (
										<span>
											&#8212; {editContent.disclaimer}
										</span>
									)}
								</h2>
							</div>
							<FormContainer
								formName={`byFlow${index}`}
								errorCount={(val) => setErrorCount(val)}
								contingentIsChecked={contingentBeneficiary}
								beneId={benefit.clientBeneId}
								pageFlow={props.pageFlow}
								submitClick={submitClick}
								serviceFailed={showTechnicalFailure}
							/>
						</div>
					);
				})}
			<h3>
				{editContent.contingentBene}{" "}
				<InfoButton
					openModal={handleShow}
					srLabel={editContent.contingentBeneInfoLabel}
				/>
			</h3>
			<input
				type='checkbox'
				name='contingent-beneficiary'
				className='form-control'
				id='contingentBeneficiary'
				checked={contingentBeneficiary}
				onChange={(ev) => {
					checkSession(context);
					setContingencyCheck(ev.target.checked);
					setContingentBeneficiary(ev.target.checked);
				}}
			/>
			<label
				className='consent-check-box-lbl mar-bottom-15'
				htmlFor='contingentBeneficiary'>
				{editContent.contingentChkbox}
			</label>
			{contingentBeneficiary && (
				<div className='all-bene-edit-form'>
					<div className='bene-each-item bene-border-bottom'>
						<h2>{editContent.contingentBeneSec}</h2>
						<p>{editContent.contingentBeneSecDesc}</p>
					</div>
					<FormContainer
						formName='contingencyFlow'
						removeContingencyCheck={() => {
							checkSession(context);
							setContingencyCheck(false);
							setContingentBeneficiary(false);
						}}
						contingentIsChecked={contingentBeneficiary}
						errorCount={(val) => setErrorCount(val)}
						pageFlow={props.pageFlow}
						submitClick={submitClick}
						serviceFailed={showTechnicalFailure}
					/>
				</div>
			)}
			<ModalWidget
				displayModal={show}
				modalType='contingentInfo'
				modalTitle={contingentModal.modalTitle}
				modalBody={contingentModal.modalBody}
				modalBtns={contingentModal.modalBtns}
				srOnlyCloseBtn='Close'
				handleClose={handleClose}
				modalId='bene-edit-modal'
				modalLnkBtnClk={handleClose}
				modalYlwBtnClk={handleClose}
			/>
		</>
	);
}
export default BeneEditPageSingleContingency;
